```csharp
        RecordingTheDeleter();
        var before = _person.Hash();
        var played = new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => AnswersFromTheCopy(request) };

        await CheckAsync(Settings(string.Empty), played, TestContext.Current.CancellationToken);

        var request = played.Shims.Should().ContainSingle().Subject.Request;
        HomeOf(request).Should().Contain(Path.Combine("own", "kh-"), "a root-less check keeps its Kimi home under its own scratch");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the scratch is gone after the check");
        TheDeleterNeverMetTheJunction();
        ThePersonsFolderIsWhole(before);
```