```csharp
RecordingTheDeleter();
var before = _person.Hash();
using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var started = new TaskCompletionSource();
var played = new PlayedKimi(new ProcessLauncher())
{
    During = async (_, ct) =>
    {
        started.TrySetResult();
        await Task.Delay(Timeout.Infinite, ct);
    },
};

var check = CheckAsync(Settings(_homes), played, cts.Token);
await started.Task.WaitAsync(TimeSpan.FromSeconds(30), TestContext.Current.CancellationToken);
await cts.CancelAsync();

try
{
    var (_, said) = await check;
    said.GetProperty("state").GetString().Should().NotBe("answered", said.ToString());
    said.ToString().Should().ContainEquivalentOf("cancel");
}
catch (OperationCanceledException)
{
    await Assert.ThrowsAnyAsync<OperationCanceledException>(() => check);
}

Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when a cancelled check ends");
TheDeleterNeverMetTheJunction();
ThePersonsFolderIsWhole(before);
```

Notes:
- The body uses `VibeHomes.OneShotFolder`. The file needs `using CoaiMcp.Runners.Vibe;`.
- I have not run the test. The word "cancel" is not yet checked. Read the real `state` and `said` text on the first run, then update the assert if needed.
- The `catch` branch covers the case where `CheckAsync` throws instead of returning a record.