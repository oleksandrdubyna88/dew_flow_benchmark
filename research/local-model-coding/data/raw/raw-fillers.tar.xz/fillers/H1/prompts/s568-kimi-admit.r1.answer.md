```typescript
  // QWEN-FILL-BEGIN s568-kimi-admit test   <<< REGION s568-kimi-admit STARTS AFTER THIS LINE
  // For 'none' and 'disk': `const admission = admit('kimi', capability);` → `assert.equal(admission.admitted, true, admission.reason)`,
  //   `assert.equal(admission.standing, 'unconfined')`, `assert.equal(admission.flag, 'unconfined')`, `assert.match(admission.caveat, /can read this machine/u)`.
  // For 'web': `const refusal = admit('kimi', 'web');` → `assert.equal(refusal.admitted, false)`, `assert.match(refusal.reason, /not been measured/u)`,
  //   `assert.match(refusal.reason, /RESULTS_kimi_confinement\.md/u)` and `assert.ok(!refusal.reason.includes('RESULTS_question_consultant_capabilities.md'))`.
  // Before the table holds kimi: "'kimi' is not a runtime the question consultant can launch". (The runtimes-list assertion of the 'words are the file's words' test already gained 'kimi'.)
  for (const capability of ['none', 'disk']) {
    const admission = admit('kimi', capability);

    assert.equal(admission.admitted, true, admission.reason);
    assert.equal(admission.standing, 'unconfined');
    assert.equal(admission.flag, 'unconfined');
    assert.match(admission.caveat, /can read this machine/u);
  }

  const refusal = admit('kimi', 'web');

  assert.equal(refusal.admitted, false);
  assert.match(refusal.reason, /not been measured/u);
  assert.match(refusal.reason, /RESULTS_kimi_confinement\.md/u);
  assert.ok(!refusal.reason.includes('RESULTS_question_consultant_capabilities.md'));
  // QWEN-FILL-END s568-kimi-admit   <<< REGION s568-kimi-admit ENDS BEFORE THIS LINE
```