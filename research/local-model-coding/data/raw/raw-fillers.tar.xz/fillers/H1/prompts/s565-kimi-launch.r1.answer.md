```csharp
var consultant = KimiForQuestions();
var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));

none.Request.WorkingDirectory.Should().Be(Scratch);
disk.Request.WorkingDirectory.Should().Be(RowTree);

foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    var args = request.Arguments.ToList();
    var home = args[args.IndexOf("--home") + 1];

    request.Arguments.Should().ContainInConsecutiveOrder("--home", home);
    home.Should().StartWith(RowFolder + Path.DirectorySeparatorChar);
    request.Arguments.Should().NotContain("--session").And.NotContain(RootA).And.NotContain(RootB);
    request.InheritsEnvironment.Should().BeFalse();

    var places = Runners.Kimi.KimiPlaces.ForShim(home, Path.Combine(RowFolder, "persons-bin"));
    Runners.Kimi.KimiEnvironment.Refusal(request, places).Should().BeEmpty();
}

none.Role.Should().Be(ConsultantRoles.Question);
```