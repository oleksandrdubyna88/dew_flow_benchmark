You write the body of ONE region in an existing TypeScript file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s568-kimi-admit — no marker lines, no method signature, no
explanation — as one ```typescript code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
For 'none' and 'disk': `const admission = admit('kimi', capability);` → `assert.equal(admission.admitted, true, admission.reason)`,
  `assert.equal(admission.standing, 'unconfined')`, `assert.equal(admission.flag, 'unconfined')`, `assert.match(admission.caveat, /can read this machine/u)`.
For 'web': `const refusal = admit('kimi', 'web');` → `assert.equal(refusal.admitted, false)`, `assert.match(refusal.reason, /not been measured/u)`,
  `assert.match(refusal.reason, /RESULTS_kimi_confinement\.md/u)` and `assert.ok(!refusal.reason.includes('RESULTS_question_consultant_capabilities.md'))`.
Before the table holds kimi: "'kimi' is not a runtime the question consultant can launch". (The runtimes-list assertion of the 'words are the file's words' test already gained 'kimi'.)

## The exact existing types and members you may use (context pack)
# Region s568-kimi-admit - context pack

Context pack — GROUP A: the planner, the matrix, the Kimi question launch, the TS admission. All names below are copied from the repository at
commit 2aacf633 (branch exp/kimi-e56-skeleton-haiku-1). Namespace of each type is given. C# is .NET 10, latest C#, FluentAssertions, xUnit v3
(`Xunit`; `TestContext.Current.CancellationToken`). Never `dotnet test`: the tests are run as the MTP executable.

## Production types (namespace `CoaiMcp.Core.QuestionConsult`, file `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`)

```csharp
public enum CwdKind { Scratch, Root, Snapshot }

public abstract record Confinement
{
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,   // argv BEFORE the CLI's subcommand
        IReadOnlyList<string> Flags,     // the sandbox flags, complete
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];   // the roots read through COPIES (Snapshot cwd)
    }

    public sealed record Refused(string Reason) : Confinement;
}

// file src_mcp/core/QuestionConsult/Capability.cs
public enum Capability { None, Disk, Web }   // spelled none/disk/web
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    public static CapabilityGrant None { get; }                       // question alone
    public static CapabilityGrant Web { get; }
    public static CapabilityGrant Disk(params string[] roots);        // read-only under these roots
}

// file src_mcp/core/QuestionConsult/CapabilityMatrix.cs
public enum AdmissionFlag { None, Unconfined, DefaultDeny }           // (third member's exact name: DefaultDeny — spelled "default-deny")
// CapabilityMatrix.Admit(string runtime, string capability) and Admit(string runtime, Capability capability) return Admission:
//   Admission.Admitted { Standing, Flag } or Admission.Refused { Reason }

// the planner (same file as above)
public static class ConfinementPlanner
{
    public static Confinement Plan(string runtime, CapabilityGrant grant);   // asks CapabilityMatrix first; a refusal comes back as Confinement.Refused
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag), "codex" => Codex(grant, flag), "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),      // <- written; its body is the FILL region s56-planner-kimi
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
}
```

The model to follow for `Kimi(...)` (the existing Vibe arm, same file):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

`Kimi` has the SAME shape with `[]` instead of `VibeReadOnly` (no flags at all) and the runtime name `"kimi"`. Its skeleton is a block-bodied method
`private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag) { <FILL region> }` — so the filled body is `return grant.Capability switch { ... };`
(keep the region's comment lines; replace only the `throw`).

## The Kimi consultant (namespace `CoaiMcp.Runners.Kimi`, file `src_mcp/runners/Kimi/KimiConsultant.cs`)

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)          // for a planned launch (`launch.Confinement is LaunchConfinement.Planned planned`) calls MustCarryNoFlag(planned.Plan)
    private static void MustCarryNoFlag(Confinement.Planned plan)      // FILL region s56-kimi-noflags; throws ArgumentException(message, nameof(plan)) for a plan with Leading/Flags/AddDirs
}
// the launch (namespace CoaiMcp.Runners.Consultation)
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
{
    public LaunchConfinement Confinement { get; init; } = LaunchConfinement.AsShipped;
    public string ScratchDir { get; init; } = string.Empty;   // EMPTY folder for a planned launch standing in Scratch
    public string Workdir { get; init; } = string.Empty;      // the snapshot / the copy of the roots
}
public abstract record LaunchConfinement
{
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;       // pattern: `launch.Confinement is LaunchConfinement.Planned planned` then `planned.Plan`
    public static LaunchConfinement AsShipped { get; }
}
// namespace CoaiMcp.Runners.Reviewers
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, string SharedResource = "", ...);
// namespace CoaiMcp.Runners.Processes
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)
{ IReadOnlyDictionary<string,string?> Environment; string StdIn; bool InheritsEnvironment; ProcessEnvironment Passthrough; ... }
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut, bool Cancelled = false, bool Truncated = false, ...);
// ConsultantRoles.Question / ConsultantRoles.Consult are string constants (namespace CoaiMcp.Runners.Consultation) — `built.Role`.
```

## The test file `src_mcp/tests/ConfinementPlannerTests.cs` (namespace `CoaiMcp.Tests`; usings: CoaiMcp.Core.QuestionConsult, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Reviewers, FluentAssertions, Xunit)

Existing members you may call (all `private static`, in `public sealed class ConfinementPlannerTests`):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private const string Repo = "D:/rsd/some-checkout";
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{
    Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
    ScratchDir = Scratch,
    Workdir = RowTree,
};
private static Runners.Kimi.KimiConsultant KimiForQuestions();   // a consultant over a fake person's paths: builds, reads nothing of this machine
```

The Vibe test the Kimi launch test is modelled on (existing, in the same file):

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file").And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
    request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "...");
}
```

Kimi's request is the shim request: argv `--ask-acp --profile kimi --model kimi-code/k3-256k --cwd <cwd> --home <RowFolder>\kh-<10 hex>` (no `--session`; one shot),
the prompt on `StdIn`. The value after a flag: `args[args.ToList().IndexOf("--home") + 1]` (`AcpWords.HomeFlag` is `"--home"`, namespace `CoaiMcp.Runners.Acp`).

Refusal check of the built request (namespace `CoaiMcp.Runners.Kimi`; `KimiEnvironment` is a static class):

```csharp
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty string = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin);           // the places the SHIM knows
// How the existing consultant tests use it (KimiConsultantTests, with a `KimiFixture _person`):
//   KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("the one launch control admits exactly what the adapter builds");
// where `home` is the value after "--home". `KimiFixture` (namespace CoaiMcp.Tests, IDisposable, `new KimiFixture()`) has `PlacesAt(string ownedRoot)`.
// For s565 build the consultant with it, so the check is real:
//   using var person = new KimiFixture();
//   var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
//       new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
// (`KimiRuntime(string id, HostKind host, KimiSeams seams)`, `KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`.)
```

## The matrix tests (`src_mcp/tests/CapabilityMatrixTests.cs`, namespace `CoaiMcp.Tests`)

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability)   // -> RuntimeCapabilityRow? (null for a runtime the table does not know)
// existing test of the same shape (Vibe):
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

The kimi rows' data (already in `shared/runtime-capabilities.json`): none → `unconfined`, cells `M-K6, M-K3, M-K4`; disk → `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`;
web → `unmeasured`, no cells; version `2.1.1`; every `resultRef` names `research/RESULTS_kimi_confinement.md`.

## TypeScript (file `src_vs_code/src/test/capabilityAdmission.test.ts`; node:test + `node:assert/strict`)

```ts
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
export interface Admission { readonly admitted: boolean; readonly standing: CapabilityStanding | ''; readonly flag: AdmissionFlag; readonly reason: string; readonly caveat: string; }
// admit(runtime: string, capability: string): Admission
// A flagged caveat: unconfined -> 'unconfined: can read this machine — a shell is always there, and no flag removes it'
// An unmeasured refusal reads: "'<runtime>' has not been measured for '<cap>' (<note>) — a measured cell in <record> is what admits it; until then give this row a prompt of another capability"
// where <record> is the `research/RESULTS_*.md` file the row's resultRef cites.
// An existing test in the same file of the same shape:
test('an unmeasured pair names the record its row cites: ...', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
});
```


## The whole file (the region is marked with <<<)
```typescript
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { test } from 'node:test';

import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
import { RUNTIME_CAPABILITIES, RUNTIMES } from '../runtimeCapabilities.generated';

/**
 * The TS half of `shared/capability-matrix-vectors.json` — the extension's admission over the same
 * table the server embeds (PLAN_question_consultant.md, D3; S1 acceptance 1).
 *
 * <p>A3 says an incompatible model + prompt pair is blocked in the UI AND refused by the server. That is
 * one rule only while both halves answer one set of vectors: two self-consistent loaders cannot notice
 * that they disagree, and the pair the panel lets a person save is then the pair the server never
 * launches, with nothing on either side saying so. `CapabilityMatrixTests.cs` is the other half.</p>
 *
 * <p>The JSON is VALIDATED into shape rather than cast: `JSON.parse(...) as Vector[]` is an `as` standing
 * in for a real type, and a fixture that lost its `admitted` field would read as `undefined` and quietly
 * compare unequal to `false`.</p>
 */

interface Vector {
  readonly runtime: string;
  readonly capability: string;
  readonly admitted: boolean;
  readonly standing: string;
  readonly flag: string;
  readonly why: string;
}

interface SeedRow {
  readonly runtime: string;
  readonly capability: string;
  readonly standing: string;
  readonly measuredWith: {
    readonly cli: string;
    readonly version: string;
    readonly date: string;
    readonly resultRef: string;
    readonly cells: readonly string[];
    readonly note: string;
  };
}

// out/test at run time, so three levels reach the repository root.
const shared = (file: string): unknown =>
  JSON.parse(readFileSync(join(__dirname, '..', '..', '..', 'shared', file), 'utf8'));

function field(row: Record<string, unknown>, name: string, where: string): string {
  const value = row[name];

  assert.equal(typeof value, 'string', `${where} has no string ${name}`);

  return value as string;
}

function vectors(): readonly Vector[] {
  const rows: unknown = (shared('capability-matrix-vectors.json') as Record<string, unknown>)['vectors'];

  assert.ok(Array.isArray(rows), 'shared/capability-matrix-vectors.json carries no `vectors` array');

  return rows.map((row: unknown, at: number) => {
    const one = row as Record<string, unknown>;
    const where = `vector ${at}`;

    assert.equal(typeof one['admitted'], 'boolean', `${where} has no admitted verdict`);

    return {
      runtime: field(one, 'runtime', where),
      capability: field(one, 'capability', where),
      admitted: one['admitted'] as boolean,
      standing: field(one, 'standing', where),
      flag: field(one, 'flag', where),
      why: field(one, 'why', where),
    };
  });
}

function seed(): readonly SeedRow[] {
  const rows: unknown = (shared('runtime-capabilities.json') as Record<string, unknown>)['rows'];

  assert.ok(Array.isArray(rows), 'shared/runtime-capabilities.json carries no `rows` array');

  return rows.map((row: unknown, at: number) => {
    const one = row as Record<string, unknown>;
    const measured = one['measuredWith'] as Record<string, unknown>;
    const where = `row ${at}`;
    const cells: unknown = measured['cells'];

    assert.ok(Array.isArray(cells), `${where} has no cells array`);

    return {
      runtime: field(one, 'runtime', where),
      capability: field(one, 'capability', where),
      standing: field(one, 'standing', where),
      measuredWith: {
        cli: field(measured, 'cli', where),
        version: field(measured, 'version', where),
        date: field(measured, 'date', where),
        resultRef: field(measured, 'resultRef', where),
        cells: cells.map((cell: unknown) => String(cell)),
        note: field(measured, 'note', where),
      },
    };
  });
}

const VECTORS = vectors();
const SEED = seed();

test('the vectors and the seed actually loaded', () => {
  // A comparison of two empty lists is the most convincing green there is.
  assert.ok(VECTORS.length > 15, `fifteen pairs plus the refusals by name, got ${VECTORS.length}`);
  assert.equal(SEED.length, RUNTIMES.length * CAPABILITIES.length, 'one row per runtime × capability');
});

test('the generated table is the seed, row for row and field for field', () => {
  assert.deepStrictEqual(
    RUNTIME_CAPABILITIES.map((r) => ({ ...r, measuredWith: { ...r.measuredWith, cells: [...r.measuredWith.cells] } })),
    SEED.map((r) => ({ ...r, measuredWith: { ...r.measuredWith, cells: [...r.measuredWith.cells] } })),
    'run `node src_vs_code/scripts/generate-runtime-capabilities.mjs` — the generated file is behind the seed',
  );
});

for (const vector of VECTORS) {
  test(`${vector.runtime} × ${vector.capability}: ${vector.admitted ? 'admitted' : 'refused'} — ${vector.why}`, () => {
    const admission = admit(vector.runtime, vector.capability);

    assert.equal(admission.admitted, vector.admitted, admission.reason);
    assert.equal(admission.standing, vector.standing, 'the row the decision was made from');
    assert.equal(admission.flag, vector.flag, 'D13: unconfined and default-deny are flagged, nothing else is');
    if (!vector.admitted) {
      assert.ok(admission.reason.includes(vector.runtime) && admission.reason.includes(vector.capability),
        `a refusal names the pair it refused: ${admission.reason}`);
    }
  });
}

test('the words are the file’s words, and a word outside them is refused rather than defaulted', () => {
  assert.deepStrictEqual([...CAPABILITIES], ['none', 'disk', 'web']);
  assert.deepStrictEqual([...STANDINGS], ['confined', 'unconfined', 'default-deny', 'unsupported', 'unmeasured']);
  assert.deepStrictEqual([...RUNTIMES], ['claude', 'codex', 'antigravity', 'local', 'api', 'vibe', 'kimi']);
  assert.equal(isCapability('disk'), true);
  assert.equal(isCapability('Disk'), false, 'the panel writes the file’s spelling, lower case, and nothing else');
  assert.equal(isCapability('shell'), false);
  for (const row of RUNTIME_CAPABILITIES) {
    assert.ok(STANDINGS.includes(row.standing), `${row.runtime} × ${row.capability}: '${row.standing}' is not a standing`);
    assert.ok(isCapability(row.capability), `${row.runtime}: '${row.capability}' is not a capability`);
  }
});

test('an unmeasured pair names the record its row cites: the Vibe probe for vibe, the first run for the rest, unchanged', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
  assert.ok(!vibe.includes('RESULTS_question_consultant_capabilities.md'), 'no cell of that run could admit a Vibe pair');
  assert.equal(admit('api', 'web').reason,
    "'api' has not been measured for 'web' (not measured; vendor-specific (a tails-plan item)) — a measured cell in "
    + 'research/RESULTS_question_consultant_capabilities.md is what admits it; until then give this row a prompt of another capability');
});

test('a refusal says what cures it: a measurement for an unmeasured pair, another prompt for an unsupported one', () => {
  assert.match(admit('api', 'web').reason, /not been measured/u);
  assert.match(admit('api', 'web').reason, /RESULTS_question_consultant_capabilities\.md/u);
  assert.match(admit('antigravity', 'web').reason, /cannot fetch a page headless/u);
  assert.match(admit('gemini', 'none').reason, /claude, codex, antigravity, local, api, vibe/u);
  assert.match(admit('vibe', 'web').reason, /not been measured/u, 'no Vibe cell exercises the web (S3 of PLAN_vibe_and_kimi_runtimes.md)');
  assert.match(admit('claude', 'shell').reason, /none, disk, web/u);
});

test('a flagged admission carries the caveat a person must acknowledge (D13)', () => {
  assert.match(admit('codex', 'web').caveat, /can read this machine/u);
  assert.match(admit('antigravity', 'disk').caveat, /headless/u);
  assert.equal(admit('claude', 'web').caveat, '', 'a confined pair has nothing to acknowledge');
  assert.equal(admit('vibe', 'disk').caveat, '', 'vibe reads its working folder only — a snapshot of the roots (M-V6)');
});

test('kimi rows admit flagged, web refuses naming its record', () => {
  // QWEN-FILL-BEGIN s568-kimi-admit test   <<< REGION s568-kimi-admit STARTS AFTER THIS LINE
  // For 'none' and 'disk': `const admission = admit('kimi', capability);` → `assert.equal(admission.admitted, true, admission.reason)`,
  //   `assert.equal(admission.standing, 'unconfined')`, `assert.equal(admission.flag, 'unconfined')`, `assert.match(admission.caveat, /can read this machine/u)`.
  // For 'web': `const refusal = admit('kimi', 'web');` → `assert.equal(refusal.admitted, false)`, `assert.match(refusal.reason, /not been measured/u)`,
  //   `assert.match(refusal.reason, /RESULTS_kimi_confinement\.md/u)` and `assert.ok(!refusal.reason.includes('RESULTS_question_consultant_capabilities.md'))`.
  // Before the table holds kimi: "'kimi' is not a runtime the question consultant can launch". (The runtimes-list assertion of the 'words are the file's words' test already gained 'kimi'.)
  throw new Error('s568-kimi-admit');
  // QWEN-FILL-END s568-kimi-admit   <<< REGION s568-kimi-admit ENDS BEFORE THIS LINE
});

```
