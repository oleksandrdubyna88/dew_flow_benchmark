```csharp
var none = Plan("kimi", CapabilityGrant.None);
var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));

none.Cwd.Should().Be(CwdKind.Scratch);
none.Flags.Should().BeEmpty();
none.Leading.Should().BeEmpty();
none.AddDirs.Should().BeEmpty();
none.SnapshotSources.Should().BeEmpty();
none.Flag.Should().Be(AdmissionFlag.Unconfined);

disk.Cwd.Should().Be(CwdKind.Snapshot);
disk.SnapshotSources.Should().Equal([RootA, RootB]);
disk.Flags.Should().BeEmpty();
disk.Leading.Should().BeEmpty();
disk.AddDirs.Should().BeEmpty();
disk.Flag.Should().Be(AdmissionFlag.Unconfined);

ConfinementPlanner.Plan("kimi", new CapabilityGrant(Capability.Web, []))
    .Should().BeOfType<Confinement.Refused>()
    .Which.Reason.Should().Contain("not been measured").And.Contain("RESULTS_kimi_confinement.md");
```