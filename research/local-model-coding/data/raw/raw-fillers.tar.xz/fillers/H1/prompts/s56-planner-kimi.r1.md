You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s56-planner-kimi — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Disk: `new("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots }`.
Anything else (None; `web` never reaches here, the matrix refuses it): `new("kimi", grant, [], [], CwdKind.Scratch, [], flag)`.
Use a switch on grant.Capability as Vibe(...) does. No flags, no leading flags, no AddDirs.

## The exact existing types and members you may use (context pack)
# Region s56-planner-kimi - context pack

Context pack — GROUP A: the planner, the matrix, the Kimi question launch, the TS admission. All names below are copied from the repository at
commit 2aacf633 (branch exp/kimi-e56-skeleton-haiku-1). Namespace of each type is given. C# is .NET 10, latest C#, FluentAssertions, xUnit v3
(`Xunit`; `TestContext.Current.CancellationToken`). Never `dotnet test`: the tests are run as the MTP executable.

## Production types (namespace `CoaiMcp.Core.QuestionConsult`, file `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`)

```csharp
public enum CwdKind { Scratch, Root, Snapshot }

public abstract record Confinement
{
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,   // argv BEFORE the CLI's subcommand
        IReadOnlyList<string> Flags,     // the sandbox flags, complete
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];   // the roots read through COPIES (Snapshot cwd)
    }

    public sealed record Refused(string Reason) : Confinement;
}

// file src_mcp/core/QuestionConsult/Capability.cs
public enum Capability { None, Disk, Web }   // spelled none/disk/web
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    public static CapabilityGrant None { get; }                       // question alone
    public static CapabilityGrant Web { get; }
    public static CapabilityGrant Disk(params string[] roots);        // read-only under these roots
}

// file src_mcp/core/QuestionConsult/CapabilityMatrix.cs
public enum AdmissionFlag { None, Unconfined, DefaultDeny }           // (third member's exact name: DefaultDeny — spelled "default-deny")
// CapabilityMatrix.Admit(string runtime, string capability) and Admit(string runtime, Capability capability) return Admission:
//   Admission.Admitted { Standing, Flag } or Admission.Refused { Reason }

// the planner (same file as above)
public static class ConfinementPlanner
{
    public static Confinement Plan(string runtime, CapabilityGrant grant);   // asks CapabilityMatrix first; a refusal comes back as Confinement.Refused
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag), "codex" => Codex(grant, flag), "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),      // <- written; its body is the FILL region s56-planner-kimi
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
}
```

The model to follow for `Kimi(...)` (the existing Vibe arm, same file):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

`Kimi` has the SAME shape with `[]` instead of `VibeReadOnly` (no flags at all) and the runtime name `"kimi"`. Its skeleton is a block-bodied method
`private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag) { <FILL region> }` — so the filled body is `return grant.Capability switch { ... };`
(keep the region's comment lines; replace only the `throw`).

## The Kimi consultant (namespace `CoaiMcp.Runners.Kimi`, file `src_mcp/runners/Kimi/KimiConsultant.cs`)

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)          // for a planned launch (`launch.Confinement is LaunchConfinement.Planned planned`) calls MustCarryNoFlag(planned.Plan)
    private static void MustCarryNoFlag(Confinement.Planned plan)      // FILL region s56-kimi-noflags; throws ArgumentException(message, nameof(plan)) for a plan with Leading/Flags/AddDirs
}
// the launch (namespace CoaiMcp.Runners.Consultation)
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
{
    public LaunchConfinement Confinement { get; init; } = LaunchConfinement.AsShipped;
    public string ScratchDir { get; init; } = string.Empty;   // EMPTY folder for a planned launch standing in Scratch
    public string Workdir { get; init; } = string.Empty;      // the snapshot / the copy of the roots
}
public abstract record LaunchConfinement
{
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;       // pattern: `launch.Confinement is LaunchConfinement.Planned planned` then `planned.Plan`
    public static LaunchConfinement AsShipped { get; }
}
// namespace CoaiMcp.Runners.Reviewers
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, string SharedResource = "", ...);
// namespace CoaiMcp.Runners.Processes
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)
{ IReadOnlyDictionary<string,string?> Environment; string StdIn; bool InheritsEnvironment; ProcessEnvironment Passthrough; ... }
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut, bool Cancelled = false, bool Truncated = false, ...);
// ConsultantRoles.Question / ConsultantRoles.Consult are string constants (namespace CoaiMcp.Runners.Consultation) — `built.Role`.
```

## The test file `src_mcp/tests/ConfinementPlannerTests.cs` (namespace `CoaiMcp.Tests`; usings: CoaiMcp.Core.QuestionConsult, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Reviewers, FluentAssertions, Xunit)

Existing members you may call (all `private static`, in `public sealed class ConfinementPlannerTests`):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private const string Repo = "D:/rsd/some-checkout";
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{
    Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
    ScratchDir = Scratch,
    Workdir = RowTree,
};
private static Runners.Kimi.KimiConsultant KimiForQuestions();   // a consultant over a fake person's paths: builds, reads nothing of this machine
```

The Vibe test the Kimi launch test is modelled on (existing, in the same file):

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file").And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
    request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "...");
}
```

Kimi's request is the shim request: argv `--ask-acp --profile kimi --model kimi-code/k3-256k --cwd <cwd> --home <RowFolder>\kh-<10 hex>` (no `--session`; one shot),
the prompt on `StdIn`. The value after a flag: `args[args.ToList().IndexOf("--home") + 1]` (`AcpWords.HomeFlag` is `"--home"`, namespace `CoaiMcp.Runners.Acp`).

Refusal check of the built request (namespace `CoaiMcp.Runners.Kimi`; `KimiEnvironment` is a static class):

```csharp
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty string = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin);           // the places the SHIM knows
// How the existing consultant tests use it (KimiConsultantTests, with a `KimiFixture _person`):
//   KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("the one launch control admits exactly what the adapter builds");
// where `home` is the value after "--home". `KimiFixture` (namespace CoaiMcp.Tests, IDisposable, `new KimiFixture()`) has `PlacesAt(string ownedRoot)`.
// For s565 build the consultant with it, so the check is real:
//   using var person = new KimiFixture();
//   var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
//       new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
// (`KimiRuntime(string id, HostKind host, KimiSeams seams)`, `KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`.)
```

## The matrix tests (`src_mcp/tests/CapabilityMatrixTests.cs`, namespace `CoaiMcp.Tests`)

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability)   // -> RuntimeCapabilityRow? (null for a runtime the table does not know)
// existing test of the same shape (Vibe):
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

The kimi rows' data (already in `shared/runtime-capabilities.json`): none → `unconfined`, cells `M-K6, M-K3, M-K4`; disk → `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`;
web → `unmeasured`, no cells; version `2.1.1`; every `resultRef` names `research/RESULTS_kimi_confinement.md`.

## TypeScript (file `src_vs_code/src/test/capabilityAdmission.test.ts`; node:test + `node:assert/strict`)

```ts
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
export interface Admission { readonly admitted: boolean; readonly standing: CapabilityStanding | ''; readonly flag: AdmissionFlag; readonly reason: string; readonly caveat: string; }
// admit(runtime: string, capability: string): Admission
// A flagged caveat: unconfined -> 'unconfined: can read this machine — a shell is always there, and no flag removes it'
// An unmeasured refusal reads: "'<runtime>' has not been measured for '<cap>' (<note>) — a measured cell in <record> is what admits it; until then give this row a prompt of another capability"
// where <record> is the `research/RESULTS_*.md` file the row's resultRef cites.
// An existing test in the same file of the same shape:
test('an unmeasured pair names the record its row cites: ...', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
});
```


## The whole file (the region is marked with <<<)
```csharp
namespace CoaiMcp.Core.QuestionConsult;

/// <summary>Where a planned launch stands: an empty scratch directory, or the first granted root.</summary>
/// <remarks>
/// Two kinds and not three. The plan's §4 also named <c>repo</c>, which is where the SHIPPED stuck
/// consultant stands (<c>LaunchConfinement.AsShipped</c>, decided by the adapter, not planned here);
/// no question row ever stands in the checkout, so a planner that could answer <c>repo</c> would be a
/// value nothing checks and one wrong arm away from a none row reading the tree.
/// </remarks>
public enum CwdKind
{
    Scratch,

    Root,

    /// <summary>
    /// A coai-owned SANITISED SNAPSHOT of the granted roots, made by the launch (D6 of todo/PLAN_vibe_and_kimi_runtimes.md)
    /// — for a CLI that reads only its working folder and loads its configuration from it (Vibe, M-V11), whose roots
    /// therefore can be neither its cwd nor an added directory.
    /// </summary>
    Snapshot,
}

/// <summary>What the planner decided for one runtime × grant: the fragments to compose, or a refusal.</summary>
public abstract record Confinement
{
    /// <param name="Leading">Argv BEFORE the CLI's subcommand — codex's top-level <c>--search</c> (F1); empty everywhere else.</param>
    /// <param name="Flags">The sandbox flags, in order, complete — an adapter splices them and adds none of its own.</param>
    /// <param name="Cwd">Where the process stands.</param>
    /// <param name="AddDirs">The roots the flags grant as LAUNCH FLAGS (<c>--add-dir</c>), for the record; the flags already spell them the runtime's way — never a copy's sources.</param>
    /// <param name="Flag">D13's caveat on an admitted pair — shown beside every answer the row produces.</param>
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,
        IReadOnlyList<string> Flags,
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        /// <summary>
        /// The folders the launch reads through COPIES (<see cref="CwdKind.Snapshot"/>, D6) — never a launch flag. Its own field,
        /// not <see cref="AddDirs"/>: there a root is something the CLI is told to read, and Vibe is never given one (D3, the
        /// #811 checkpoint round).
        /// </summary>
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }

    public sealed record Refused(string Reason) : Confinement;

    private Confinement() { }
}

/// <summary>
/// The ONE place a question row's sandbox is decided: runtime × grant → argv fragments, a cwd kind and
/// the granted roots (PLAN_question_consultant.md, D4). Adapters compose; they never choose a flag.
/// </summary>
/// <remarks>
/// <para>Every fragment is a measured fact of the probe run of 2026-10-01, cited per row in
/// <c>shared/runtime-capabilities.json</c>: claude launches ONLY through <c>--tools</c> (plus
/// <c>--restricted</c> for disk), never through <c>--disallowedTools</c> (F3, F5 — the shipped deny
/// lists were offered the user environment's whole tool set and leaked 6 of 6 through PowerShell);
/// codex's <c>--search</c> is a top-level flag before <c>exec</c> (F1); agy's measured launch is plan
/// mode on the stream (F7). The matrix is asked FIRST, so a pair it refuses is refused here with its
/// own sentence and no runtime arm is reached.</para>
/// <para>Pure: every flag is a golden test (<c>ConfinementPlannerTests</c>), per runtime × capability,
/// over the whole argv an adapter then builds.</para>
/// </remarks>
public static class ConfinementPlanner
{
    /// <summary>The flag no planned launch ever carries (F3/F5): a deny list is not a boundary.</summary>
    public const string NeverSent = "--disallowedTools";

    /// <summary>What a claude disk row may do: read, find, search — and no shell (F4).</summary>
    public static IReadOnlyList<string> ClaudeDiskTools { get; } = ["Read", "Glob", "Grep"];

    /// <summary>What a claude web row may do: the two client web tools, which refuse <c>file://</c> (F6).</summary>
    public static IReadOnlyList<string> ClaudeWebTools { get; } = ["WebSearch", "WebFetch"];

    /// <summary>
    /// Vibe's read-only pair, both always (D2 of todo/PLAN_vibe_and_kimi_runtimes.md): together they denied 9 of 9 write
    /// attempts (research/RESULTS_vibe_confinement.md §4) and every write under forced experiment variants (§23). Spelled
    /// once — the reviewer's argv (<c>VibeRuntime</c>) and a question row's plan both read it.
    /// </summary>
    public static IReadOnlyList<string> VibeReadOnly { get; } = ["--agent", "plan", "--enabled-tools", "read_file"];

    /// <summary>
    /// Every argument that decides a sandbox on any of the six runtimes — what a planned launch may
    /// carry ONLY from a plan. The structural test in <c>ConfinementPlannerTests</c> reads it.
    /// </summary>
    private static readonly string[] SandboxVocabulary =
    [
        "--tools", "--restricted", "--add-dir", "--permission-mode", NeverSent, "--disallowed-tools", "--allowedTools",
        "--allowed-tools", "--dangerously-skip-permissions",
        "--search", "-s", "--sandbox", "--ephemeral", "-C", "--full-auto", "--yolo",
        "--mode",
        // Vibe's (D2, D3). Not `--agent`: agy's adapter names its own read-only agent (`--agent coai-reader`), which is
        // the adapter's confinement of agy, not a plan's — and Vibe's `--agent plan` comes from the plan beside it.
        "--enabled-tools", "--trust",
    ];

    public static bool IsSandboxVocabulary(string argument) => SandboxVocabulary.Contains(argument, StringComparer.Ordinal);

    /// <summary>The plan for one row, or why there is none.</summary>
    public static Confinement Plan(string runtime, CapabilityGrant grant)
    {
        if (CapabilityMatrix.Admit(runtime, grant.Capability) is not Admission.Admitted admitted)
        {
            return new Confinement.Refused(((Admission.Refused)CapabilityMatrix.Admit(runtime, grant.Capability)).Reason);
        }

        var roots = WhyNotTheseRoots(grant);

        return roots.Length > 0
            ? new Confinement.Refused(roots)
            : Fragments(runtime.Trim().ToLowerInvariant(), grant, admitted.Flag);
    }

    /// <summary>A disk grant has roots, every root is absolute, and nothing else carries one.</summary>
    private static string WhyNotTheseRoots(CapabilityGrant grant)
    {
        if (grant.Capability != Capability.Disk)
        {
            return grant.Roots.Count == 0
                ? string.Empty
                : $"a '{grant.Capability.Spelled()}' grant carries no roots — a directory on a row that reads no directory is a leak path; the roots are a 'disk' prompt's";
        }

        if (grant.Roots.Count == 0)
        {
            return "a 'disk' grant needs at least one root to read — set the folders in ConnectOtherAIs > Question consultant";
        }

        return grant.Roots.FirstOrDefault(root => !IsAbsolute(root)) is { } relative
            ? $"the root '{relative}' is not an absolute path — a relative root resolves against whatever the cwd happens to be; every root is spelled from a drive or from /"
            : string.Empty;
    }

    /// <summary>
    /// Absolute on either platform's spelling — lexical, so the same table and the same tests decide
    /// alike on Windows and on Linux (a <c>D:/</c> root is not rooted to <c>Path.IsPathRooted</c> on Linux).
    /// </summary>
    private static bool IsAbsolute(string root)
    {
        var text = root.Trim();

        return text.Length >= 3 && char.IsAsciiLetter(text[0]) && text[1] == ':' && text[2] is '/' or '\\'
            || text.Length >= 2 && text[0] is '/' or '\\';
    }

    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag),
        "codex" => Codex(grant, flag),
        "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),
        // A completion has no tools, so it has no sandbox flag: the question alone, from nowhere.
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Claude(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        // `--tools ""` offers nothing at all (F3, read-denied × allowlist 3 of 3).
        Capability.None => new("claude", grant, [], ["--permission-mode", "plan", "--tools", ""], CwdKind.Scratch, [], flag),
        // `--restricted` confines the file tools to the working directories and `--add-dir` is the only
        // way out (F4); `--tools` alone is no path boundary.
        Capability.Disk => new("claude", grant, [],
            ["--permission-mode", "plan", "--restricted", "--tools", string.Join(',', ClaudeDiskTools), .. AddDirs("--add-dir", grant.Roots)],
            CwdKind.Root, grant.Roots, flag),
        // The two client web tools and nothing file-capable (F6: web-confined × allowlist 3 of 3).
        _ => new("claude", grant, [], ["--permission-mode", "plan", "--tools", string.Join(',', ClaudeWebTools)], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Codex(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        // `--ephemeral`: one-shot, nothing left in the person's codex store — the opposite of the
        // stuck consultant's trade, because a question row is never resumed.
        Capability.None => new("codex", grant, [], ["-s", "read-only", "--ephemeral"], CwdKind.Scratch, [], flag),
        // `-C <root 0>` tells it where to read; nothing stops it reading elsewhere (F2) — hence the flag.
        Capability.Disk => new("codex", grant, [], ["-s", "read-only", "--ephemeral", "-C", grant.Roots[0]], CwdKind.Root, grant.Roots, flag),
        // `--search` BEFORE `exec` (F1): `codex exec --search` is a usage error, exit 2.
        _ => new("codex", grant, ["--search"], ["-s", "read-only", "--ephemeral"], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Antigravity(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        Capability.Disk => new("antigravity", grant, [], ["--mode", "plan", .. AddDirs("--add-dir", grant.Roots)], CwdKind.Root, grant.Roots, flag),
        // `web` never reaches here: the matrix refuses it (F7, it cannot fetch a page headless).
        _ => new("antigravity", grant, [], ["--mode", "plan"], CwdKind.Scratch, [], flag),
    };

    /// <remarks>
    /// D2's pair on every capability, never <c>--trust</c> or <c>--add-dir</c> (D3: a trusted folder runs its hooks, and
    /// <c>--add-dir</c> trusts its folder). Vibe reads only its working folder (M-V11, 6 of 6), so a disk row's roots are
    /// COPIED into the snapshot it stands in (D6) and named to it there; a none row stands in an empty folder.
    /// </remarks>
    private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
        // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
        _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
    };

    /// <remarks>
    /// No flags, ever (E5.6 decision 1): Kimi's confinement is the shim's (D15), not its argv. A disk row's roots are COPIED into the
    /// snapshot it stands in (a branch's AGENTS.md, skills, sub-agents and .mcp.json load from disk, M-K9); a none row stands in an empty
    /// folder. Both are <c>unconfined</c> (<c>Grep</c> and <c>Glob</c> read the disk, M-K6), so the matrix flags them.
    /// </remarks>
    private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag)
    {
        // QWEN-FILL-BEGIN s56-planner-kimi prod   <<< REGION s56-planner-kimi STARTS AFTER THIS LINE
        // Disk: `new("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots }`.
        // Anything else (None; `web` never reaches here, the matrix refuses it): `new("kimi", grant, [], [], CwdKind.Scratch, [], flag)`.
        // Use a switch on grant.Capability as Vibe(...) does. No flags, no leading flags, no AddDirs.
        throw new NotImplementedException("s56-planner-kimi");
        // QWEN-FILL-END s56-planner-kimi   <<< REGION s56-planner-kimi ENDS BEFORE THIS LINE
    }

    private static IEnumerable<string> AddDirs(string flag, IReadOnlyList<string> roots) =>
        roots.SelectMany(root => (string[])[flag, root]);
}

```
