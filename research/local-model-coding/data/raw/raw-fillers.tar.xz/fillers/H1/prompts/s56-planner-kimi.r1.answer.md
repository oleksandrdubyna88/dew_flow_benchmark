```csharp
        return grant.Capability switch
        {
            Capability.Disk => new("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
            // `web` never reaches here: the matrix refuses it (no Kimi cell exercises the web).
            _ => new("kimi", grant, [], [], CwdKind.Scratch, [], flag),
        };
```