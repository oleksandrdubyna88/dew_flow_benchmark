You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s565-kimi-launch — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Arrange: `var consultant = KimiForQuestions();`.
Act: `var none = consultant.Build(Planned("kimi", CapabilityGrant.None));` and `var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));`
  (`Planned` is the helper above; it sets Workdir = RowTree, ScratchDir = Scratch, OwnedScratch = RowFolder).
Assert: `none.Request.WorkingDirectory.Should().Be(Scratch)`; `disk.Request.WorkingDirectory.Should().Be(RowTree)`.
  For each of `none.Request` and `disk.Request`: `Arguments.Should().ContainInConsecutiveOrder("--home", <value>)` where the value is the argument
  after "--home" and `.Should().StartWith(RowFolder + Path.DirectorySeparatorChar)`; `Arguments` contains no "--session", no RootA, no RootB;
  `request.InheritsEnvironment.Should().BeFalse()`; `Runners.Kimi.KimiEnvironment.Refusal(request, places)` is empty where
  `places = Runners.Kimi.KimiPlaces.ForShim(<the --home value>, Path.Combine(RowFolder, "persons-bin"))` (the context pack gives the exact signature).
  `none.Role.Should().Be(ConsultantRoles.Question)`.
Fails against a stub that ignores the plan: "Expected Request.WorkingDirectory to be <Scratch>, but found ...".

## The exact existing types and members you may use (context pack)
# Region s565-kimi-launch - context pack

Context pack — GROUP A: the planner, the matrix, the Kimi question launch, the TS admission. All names below are copied from the repository at
commit 2aacf633 (branch exp/kimi-e56-skeleton-haiku-1). Namespace of each type is given. C# is .NET 10, latest C#, FluentAssertions, xUnit v3
(`Xunit`; `TestContext.Current.CancellationToken`). Never `dotnet test`: the tests are run as the MTP executable.

## Production types (namespace `CoaiMcp.Core.QuestionConsult`, file `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`)

```csharp
public enum CwdKind { Scratch, Root, Snapshot }

public abstract record Confinement
{
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,   // argv BEFORE the CLI's subcommand
        IReadOnlyList<string> Flags,     // the sandbox flags, complete
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];   // the roots read through COPIES (Snapshot cwd)
    }

    public sealed record Refused(string Reason) : Confinement;
}

// file src_mcp/core/QuestionConsult/Capability.cs
public enum Capability { None, Disk, Web }   // spelled none/disk/web
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    public static CapabilityGrant None { get; }                       // question alone
    public static CapabilityGrant Web { get; }
    public static CapabilityGrant Disk(params string[] roots);        // read-only under these roots
}

// file src_mcp/core/QuestionConsult/CapabilityMatrix.cs
public enum AdmissionFlag { None, Unconfined, DefaultDeny }           // (third member's exact name: DefaultDeny — spelled "default-deny")
// CapabilityMatrix.Admit(string runtime, string capability) and Admit(string runtime, Capability capability) return Admission:
//   Admission.Admitted { Standing, Flag } or Admission.Refused { Reason }

// the planner (same file as above)
public static class ConfinementPlanner
{
    public static Confinement Plan(string runtime, CapabilityGrant grant);   // asks CapabilityMatrix first; a refusal comes back as Confinement.Refused
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag), "codex" => Codex(grant, flag), "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),      // <- written; its body is the FILL region s56-planner-kimi
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
}
```

The model to follow for `Kimi(...)` (the existing Vibe arm, same file):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

`Kimi` has the SAME shape with `[]` instead of `VibeReadOnly` (no flags at all) and the runtime name `"kimi"`. Its skeleton is a block-bodied method
`private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag) { <FILL region> }` — so the filled body is `return grant.Capability switch { ... };`
(keep the region's comment lines; replace only the `throw`).

## The Kimi consultant (namespace `CoaiMcp.Runners.Kimi`, file `src_mcp/runners/Kimi/KimiConsultant.cs`)

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)          // for a planned launch (`launch.Confinement is LaunchConfinement.Planned planned`) calls MustCarryNoFlag(planned.Plan)
    private static void MustCarryNoFlag(Confinement.Planned plan)      // FILL region s56-kimi-noflags; throws ArgumentException(message, nameof(plan)) for a plan with Leading/Flags/AddDirs
}
// the launch (namespace CoaiMcp.Runners.Consultation)
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
{
    public LaunchConfinement Confinement { get; init; } = LaunchConfinement.AsShipped;
    public string ScratchDir { get; init; } = string.Empty;   // EMPTY folder for a planned launch standing in Scratch
    public string Workdir { get; init; } = string.Empty;      // the snapshot / the copy of the roots
}
public abstract record LaunchConfinement
{
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;       // pattern: `launch.Confinement is LaunchConfinement.Planned planned` then `planned.Plan`
    public static LaunchConfinement AsShipped { get; }
}
// namespace CoaiMcp.Runners.Reviewers
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, string SharedResource = "", ...);
// namespace CoaiMcp.Runners.Processes
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)
{ IReadOnlyDictionary<string,string?> Environment; string StdIn; bool InheritsEnvironment; ProcessEnvironment Passthrough; ... }
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut, bool Cancelled = false, bool Truncated = false, ...);
// ConsultantRoles.Question / ConsultantRoles.Consult are string constants (namespace CoaiMcp.Runners.Consultation) — `built.Role`.
```

## The test file `src_mcp/tests/ConfinementPlannerTests.cs` (namespace `CoaiMcp.Tests`; usings: CoaiMcp.Core.QuestionConsult, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Reviewers, FluentAssertions, Xunit)

Existing members you may call (all `private static`, in `public sealed class ConfinementPlannerTests`):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private const string Repo = "D:/rsd/some-checkout";
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{
    Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
    ScratchDir = Scratch,
    Workdir = RowTree,
};
private static Runners.Kimi.KimiConsultant KimiForQuestions();   // a consultant over a fake person's paths: builds, reads nothing of this machine
```

The Vibe test the Kimi launch test is modelled on (existing, in the same file):

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file").And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
    request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "...");
}
```

Kimi's request is the shim request: argv `--ask-acp --profile kimi --model kimi-code/k3-256k --cwd <cwd> --home <RowFolder>\kh-<10 hex>` (no `--session`; one shot),
the prompt on `StdIn`. The value after a flag: `args[args.ToList().IndexOf("--home") + 1]` (`AcpWords.HomeFlag` is `"--home"`, namespace `CoaiMcp.Runners.Acp`).

Refusal check of the built request (namespace `CoaiMcp.Runners.Kimi`; `KimiEnvironment` is a static class):

```csharp
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty string = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin);           // the places the SHIM knows
// How the existing consultant tests use it (KimiConsultantTests, with a `KimiFixture _person`):
//   KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("the one launch control admits exactly what the adapter builds");
// where `home` is the value after "--home". `KimiFixture` (namespace CoaiMcp.Tests, IDisposable, `new KimiFixture()`) has `PlacesAt(string ownedRoot)`.
// For s565 build the consultant with it, so the check is real:
//   using var person = new KimiFixture();
//   var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
//       new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
// (`KimiRuntime(string id, HostKind host, KimiSeams seams)`, `KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`.)
```

## The matrix tests (`src_mcp/tests/CapabilityMatrixTests.cs`, namespace `CoaiMcp.Tests`)

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability)   // -> RuntimeCapabilityRow? (null for a runtime the table does not know)
// existing test of the same shape (Vibe):
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

The kimi rows' data (already in `shared/runtime-capabilities.json`): none → `unconfined`, cells `M-K6, M-K3, M-K4`; disk → `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`;
web → `unmeasured`, no cells; version `2.1.1`; every `resultRef` names `research/RESULTS_kimi_confinement.md`.

## TypeScript (file `src_vs_code/src/test/capabilityAdmission.test.ts`; node:test + `node:assert/strict`)

```ts
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
export interface Admission { readonly admitted: boolean; readonly standing: CapabilityStanding | ''; readonly flag: AdmissionFlag; readonly reason: string; readonly caveat: string; }
// admit(runtime: string, capability: string): Admission
// A flagged caveat: unconfined -> 'unconfined: can read this machine — a shell is always there, and no flag removes it'
// An unmeasured refusal reads: "'<runtime>' has not been measured for '<cap>' (<note>) — a measured cell in <record> is what admits it; until then give this row a prompt of another capability"
// where <record> is the `research/RESULTS_*.md` file the row's resultRef cites.
// An existing test in the same file of the same shape:
test('an unmeasured pair names the record its row cites: ...', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
});
```


## The whole file (the region is marked with <<<)
```csharp
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Reviewers;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The confinement planner is the ONE place a question row's sandbox flags are decided, and every
/// adapter composes them rather than choosing its own (PLAN_question_consultant.md, D4; S1 acceptance 2).
/// </summary>
/// <remarks>
/// <para>Every fragment below is a fact from the probe run of 2026-10-01 (F1–F7 of the plan, cited by
/// row in <c>shared/runtime-capabilities.json</c>): claude's <c>--tools</c> allow-list and
/// <c>--restricted</c>, codex's top-level <c>--search</c>, agy's <c>--mode plan</c>. The goldens are
/// asserted as WHOLE argv lists, so an adapter that adds a sandbox flag of its own — or drops one the
/// planner gave it — fails here rather than reading past its roots with nothing in the output to say so.</para>
/// <para><c>--disallowedTools</c> appears in no plan and no planned launch: the shipped deny lists are
/// offered the user environment's whole tool set and leaked the canary 6 of 6 (F5).</para>
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------

    [Fact]
    public void Claude_None_OffersNoToolAtAll_InAScratchCwd()
    {
        var plan = Plan("claude", CapabilityGrant.None);

        plan.Leading.Should().BeEmpty();
        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "");
        plan.Cwd.Should().Be(CwdKind.Scratch);
        plan.AddDirs.Should().BeEmpty();
        plan.Flag.Should().Be(AdmissionFlag.None);
    }

    [Fact]
    public void Claude_Disk_IsRestricted_WithTheThreeReadTools_AndEveryRootAdded()
    {
        var plan = Plan("claude", CapabilityGrant.Disk(RootA, RootB));

        plan.Flags.Should().Equal(
            "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB);
        plan.Cwd.Should().Be(CwdKind.Root, "the first root is the working directory (F4: --restricted confines to the working directories)");
        plan.AddDirs.Should().Equal(RootA, RootB);
        plan.Flags.Should().NotContain("Bash").And.NotContain("PowerShell", "no shell tool is offered to a disk row");
    }

    [Fact]
    public void Claude_Web_OffersTheTwoWebTools_AndNoDirectory()
    {
        var plan = Plan("claude", CapabilityGrant.Web);

        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "WebSearch,WebFetch");
        plan.Flags.Should().NotContain("--add-dir", "a web row has no directory to read (A2)");
        plan.Flags.Should().NotContain("--restricted", "nothing file-capable is offered, so there is nothing to restrict");
        plan.Cwd.Should().Be(CwdKind.Scratch);
    }

    [Fact]
    public void Codex_EveryCapability_IsReadOnlyEphemeral_AndFlaggedUnconfined()
    {
        var none = Plan("codex", CapabilityGrant.None);
        none.Leading.Should().BeEmpty();
        none.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        none.Cwd.Should().Be(CwdKind.Scratch);

        var disk = Plan("codex", CapabilityGrant.Disk(RootA));
        disk.Flags.Should().Equal("-s", "read-only", "--ephemeral", "-C", RootA);
        disk.Cwd.Should().Be(CwdKind.Root);

        var web = Plan("codex", CapabilityGrant.Web);
        // The expectation is an ARRAY: `Equal("--search", "because…")` would assert the reason as a
        // second expected item — the trap ConsultantArgvTests already names.
        web.Leading.Should().Equal(["--search"], "F1: `--search` is a TOP-LEVEL flag; `codex exec --search` is a usage error (exit 2)");
        web.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        web.Cwd.Should().Be(CwdKind.Scratch);

        foreach (var plan in (Confinement.Planned[])[none, disk, web])
        {
            plan.Flag.Should().Be(AdmissionFlag.Unconfined, "F2: codex reads anywhere and no flag removes the shell (D13)");
        }
    }

    [Fact]
    public void Antigravity_None_IsPlanMode_AndDisk_AddsTheRoots_BothFlaggedDefaultDeny()
    {
        var none = Plan("antigravity", CapabilityGrant.None);
        none.Flags.Should().Equal("--mode", "plan");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.Flag.Should().Be(AdmissionFlag.DefaultDeny);

        var disk = Plan("antigravity", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--mode", "plan", "--add-dir", RootA, "--add-dir", RootB);
        disk.Cwd.Should().Be(CwdKind.Root);
        disk.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
    }

    [Fact]
    public void LocalAndApi_None_HaveNoFlagToSend_AndAScratchCwd()
    {
        foreach (var runtime in (string[])["local", "api"])
        {
            var plan = Plan(runtime, CapabilityGrant.None);

            plan.Leading.Should().BeEmpty(runtime);
            plan.Flags.Should().BeEmpty($"{runtime}: a completion has no sandbox flag — it has no tools");
            plan.Cwd.Should().Be(CwdKind.Scratch, runtime);
            plan.Flag.Should().Be(AdmissionFlag.None, runtime);
        }
    }

    /// <summary>
    /// Vibe (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): D2's two flags, both, on every capability — and no
    /// <c>--trust</c> or <c>--add-dir</c> ever (D3). A none row stands in an EMPTY scratch folder; a disk row stands in a
    /// SNAPSHOT of its roots (D6), because Vibe reads only its working folder (M-V11) — so its roots are never its cwd.
    /// </summary>
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    /// <summary>
    /// Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md, S5.6.3): no flags, ever — its confinement is the shim's (D15). A none row stands in an
    /// EMPTY scratch folder, a disk row in the SNAPSHOT of its roots (the copies, never the roots); `web` is refused by the matrix before any arm.
    /// </summary>
    [Fact]
    public void ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb()
    {
        // QWEN-FILL-BEGIN s563-planner-arm test
        // Arrange/Act: `var none = Plan("kimi", CapabilityGrant.None);` and `var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));`.
        // Assert none: `none.Cwd.Should().Be(CwdKind.Scratch)`, `none.Flags` / `none.Leading` / `none.AddDirs` / `none.SnapshotSources` each `.Should().BeEmpty()`,
        //   `none.Flag.Should().Be(AdmissionFlag.Unconfined)`.
        // Assert disk: `disk.Cwd.Should().Be(CwdKind.Snapshot)`, `disk.SnapshotSources.Should().Equal([RootA, RootB])`, `disk.Flags` / `disk.Leading` /
        //   `disk.AddDirs` each empty, `disk.Flag.Should().Be(AdmissionFlag.Unconfined)`.
        // Web: `ConfinementPlanner.Plan("kimi", new CapabilityGrant(Capability.Web, []))` is `Confinement.Refused` whose `.Reason` contains
        //   "not been measured" and "RESULTS_kimi_confinement.md".
        // Fails before the arm: the default arm gives CwdKind.Scratch for disk too ("Expected plan.Cwd to be CwdKind.Snapshot, but found CwdKind.Scratch.").
        throw new NotImplementedException("s563-planner-arm");
        // QWEN-FILL-END s563-planner-arm
    }

    // ---------- refusals ----------

    [Theory]
    [InlineData("antigravity", Capability.Web, "cannot fetch a page headless")]
    [InlineData("api", Capability.Disk, "cannot do 'disk'")]
    [InlineData("api", Capability.Web, "not been measured")]
    [InlineData("local", Capability.Disk, "cannot do 'disk'")]
    [InlineData("local", Capability.Web, "cannot do 'web'")]
    [InlineData("vibe", Capability.Web, "not been measured")]
    public void APairTheMatrixRefuses_IsRefusedByThePlannerToo_WithTheMatrixsOwnSentence(string runtime, Capability capability, string says)
    {
        var grant = capability == Capability.Disk ? CapabilityGrant.Disk(RootA) : new CapabilityGrant(capability, []);

        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain(says, "the planner asks the matrix first and never re-decides it");
    }

    [Fact]
    public void AnUnknownRuntime_IsRefused_NamingTheOnesItKnows()
    {
        ConfinementPlanner.Plan("gemini", CapabilityGrant.None).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe");
    }

    [Fact]
    public void ADiskGrantWithNoRoot_IsRefused_AndARootOnANoneOrWebGrant_IsRefused()
    {
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Disk, [])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("at least one root", "a disk row with nowhere to read would read its cwd — which is nowhere");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.None, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a root on a none row is a leak path");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Web, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a web row is given the question and nothing of this machine (A2)");
    }

    [Theory]
    [InlineData("projects/alpha")]
    [InlineData("./alpha")]
    [InlineData("")]
    [InlineData("  ")]
    public void ARootThatIsNotAnAbsolutePath_IsRefused(string root)
    {
        ConfinementPlanner.Plan("claude", CapabilityGrant.Disk(root)).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("absolute", "a relative root resolves against whatever the cwd happens to be");
    }

    [Fact]
    public void DisallowedTools_AppearsInNoPlan()
    {
        // F3/F5: the shipped deny lists leaked the canary 6 of 6 through PowerShell, which no deny
        // list names. A question row is confined by an ALLOW list or by `--restricted`, never by naming
        // what it may not do.
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is Confinement.Planned plan)
                {
                    plan.Flags.Concat(plan.Leading).Should().NotContain(ConfinementPlanner.NeverSent, $"{runtime} × {grant.Capability}");
                }
            }
        }
    }

    // ---------- the adapters compose the plan and nothing of their own ----------

    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
    {
        var none = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.None, "sonnet"));
        none.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "", NoMcpServers.ClaudeFlag, "--model", "sonnet");
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty directory, never the checkout");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB, NoMcpServers.ClaudeFlag);
        disk.Request.WorkingDirectory.Should().Be(RootA);

        var web = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Web));
        web.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "WebSearch,WebFetch", NoMcpServers.ClaudeFlag);
        web.Request.Arguments.Should().NotContain("--add-dir").And.NotContain(Repo, "a web row sees nothing of the checkout");
        web.Request.WorkingDirectory.Should().Be(Scratch);
    }

    [Fact]
    public void ACodexQuestionLaunch_PutsSearchBeforeExec_AndStaysEphemeral()
    {
        var web = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Web, "gpt-6-astra"));
        var args = web.Request.Arguments.ToList();
        var output = args[args.IndexOf("-o") + 1];

        args.Should().Equal(
            "--search", "exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check", "--color", "never",
            // The row's fast mode, Off by default (research/PLAN_fast_mode.md), before the instructions on stdin.
            "--json", "-o", output, "-m", "gpt-6-astra", "-c", "service_tier=default", "-");
        Path.GetDirectoryName(Path.GetFullPath(output)).Should().Be(Path.GetFullPath(Answers));
        web.Request.WorkingDirectory.Should().Be(Scratch);

        var none = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.None));
        none.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check"])
            .And.NotContain("--search").And.NotContain("-C");

        var disk = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "-C", RootA]);
        disk.Request.WorkingDirectory.Should().Be(RootA);
    }

    [Fact]
    public void AnAgyQuestionLaunch_IsTheMeasuredStreamLaunch_WithThePlansFlags()
    {
        var none = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.None, "gemini-3.1-pro-high"));
        // Both run as the reader agent from the read-only folder, never from the root or the scratch directory
        // (research/PLAN_agy_cannot_write_its_roots.md); a disk row still reaches its root through the plan's --add-dir.
        none.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "gemini-3.1-pro-high");
        none.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
        none.Request.StdIn.Should().Contain("the question").And.StartWith("{", "the prompt rides the stream, serialised");

        var disk = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--add-dir", RootA,
            "--agent", "coai-reader");
        disk.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
    }

    [Fact]
    public void ALocalQuestionLaunch_RunsTheShimInTheScratchDirectory()
    {
        Directory.CreateDirectory(Answers);
        var schema = Path.Combine(Answers, "schema.json");
        File.WriteAllText(schema, "{}");
        var launch = Planned("local", CapabilityGrant.None) with { AnswerSchemaFile = schema };

        var built = new LocalConsultant(new LocalRuntime("local", "http://127.0.0.1:11434/v1"), "local").Build(launch);

        built.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands nowhere near the checkout");
        built.Request.Arguments.Should().Contain("--ask-local");
        built.Role.Should().Be(ConsultantRoles.Question);
    }

    /// <summary>
    /// A Vibe question row (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): the plan's read-only pair, a none row in its EMPTY
    /// scratch and a disk row in the copy of its roots — never a root, never the checkout — on the row's own home in the
    /// built environment: <c>VIBE_CLI=python</c> and the model in the EXPLICIT environment, which is all a question row's
    /// minimal child gets (M-V12, 3 of 3).
    /// </summary>
    [Fact]
    public void AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));

        var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file")
            .And.ContainInConsecutiveOrder("--workdir", Scratch)
            .And.NotContain("--trust").And.NotContain("--add-dir").And.NotContain("--resume", "one shot");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-V11: Vibe reads its cwd only — the copy of the roots (D6)");
        disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.InheritsEnvironment.Should().BeFalse();
            request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
            request.Environment.Should().Contain(Runners.Vibe.VibeLaunch.CliVariable, "python").And.Contain(Runners.Vibe.VibeLaunch.ModelVariable, "glm-5-3");
            request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");
            Runners.Vibe.VibeLaunch.EnvironmentRefusal(request).Should().BeEmpty("the one launch control admits it (D17)");
        }
    }

    /// <summary>A consultant over a fake person's paths (the <c>Adapters()</c> shape) — building reads nothing of this machine.</summary>
    private static Runners.Kimi.KimiConsultant KimiForQuestions() => new(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
        new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))));

    /// <summary>
    /// A Kimi question row (E5.6, S5.6.5): the shim request in the row's EMPTY scratch (none) or the copy of its roots (disk), no <c>--session</c>,
    /// the home a child of the row's folder, neither root named, the minimal child environment.
    /// </summary>
    [Fact]
    public void AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome()
    {
        // QWEN-FILL-BEGIN s565-kimi-launch test   <<< REGION s565-kimi-launch STARTS AFTER THIS LINE
        // Arrange: `var consultant = KimiForQuestions();`.
        // Act: `var none = consultant.Build(Planned("kimi", CapabilityGrant.None));` and `var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));`
        //   (`Planned` is the helper above; it sets Workdir = RowTree, ScratchDir = Scratch, OwnedScratch = RowFolder).
        // Assert: `none.Request.WorkingDirectory.Should().Be(Scratch)`; `disk.Request.WorkingDirectory.Should().Be(RowTree)`.
        //   For each of `none.Request` and `disk.Request`: `Arguments.Should().ContainInConsecutiveOrder("--home", <value>)` where the value is the argument
        //   after "--home" and `.Should().StartWith(RowFolder + Path.DirectorySeparatorChar)`; `Arguments` contains no "--session", no RootA, no RootB;
        //   `request.InheritsEnvironment.Should().BeFalse()`; `Runners.Kimi.KimiEnvironment.Refusal(request, places)` is empty where
        //   `places = Runners.Kimi.KimiPlaces.ForShim(<the --home value>, Path.Combine(RowFolder, "persons-bin"))` (the context pack gives the exact signature).
        //   `none.Role.Should().Be(ConsultantRoles.Question)`.
        // Fails against a stub that ignores the plan: "Expected Request.WorkingDirectory to be <Scratch>, but found ...".
        throw new NotImplementedException("s565-kimi-launch");
        // QWEN-FILL-END s565-kimi-launch   <<< REGION s565-kimi-launch ENDS BEFORE THIS LINE
    }

    /// <summary>A plan that carries a flag is not one coai made for kimi (E5.6 decision 3, S5.6.6): refused, naming the shim.</summary>
    [Fact]
    public void APlanWithFlags_IsRefusedForKimi()
    {
        var plan = new Confinement.Planned("kimi", CapabilityGrant.None, [], ["--yolo"], CwdKind.Scratch, [], AdmissionFlag.Unconfined);
        var build = () => KimiForQuestions().Build(Planned("kimi", CapabilityGrant.None) with { Confinement = new LaunchConfinement.Planned(plan) });
        build.Should().Throw<ArgumentException>().WithMessage("*the shim*");
    }

    /// <summary>No Vibe launch carries <c>--add-dir</c>, whatever the grant (D3: <c>--add-dir</c> trusts its folder).</summary>
    [Fact]
    public void NoVibeLaunch_CarriesAddDir_WhateverTheGrant()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
        foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Disk(RootA, RootB), CapabilityGrant.Web])
        {
            if (ConfinementPlanner.Plan("vibe", grant) is not Confinement.Planned plan)
            {
                continue;
            }

            plan.AddDirs.Should().BeEmpty($"vibe × {grant.Capability}");
            consultant.Build(Planned("vibe", grant)).Request.Arguments.Should().NotContain("--add-dir", $"vibe × {grant.Capability}")
                .And.NotContain(RootA).And.NotContain(RootB);
        }
    }

    [Fact]
    public void ASnapshotCwd_NeedsAWorkdir_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("vibe", CapabilityGrant.Disk(RootA)) with { Workdir = string.Empty };

        var build = () => new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*Workdir*",
            "falling back to a root would hand Vibe the branch's own .vibe/ and AGENTS.md (D6)");
    }

    /// <summary>The structural half of acceptance 2: whatever a planned launch sends of the sandbox vocabulary, the plan gave it.</summary>
    [Fact]
    public void NoAdapter_SendsASandboxFlag_ThePlanDidNotGiveIt()
    {
        foreach (var (runtime, consultant) in Adapters())
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is not Confinement.Planned plan)
                {
                    continue;
                }

                var argv = consultant.Build(Planned(runtime, grant)).Request.Arguments.ToList();
                var ownFlags = argv.Except(plan.Flags.Concat(plan.Leading)).Where(ConfinementPlanner.IsSandboxVocabulary);

                ownFlags.Should().BeEmpty($"{runtime} × {grant.Capability}: the planner is the one place");
            }
        }
    }

    [Fact]
    public void APlannedLaunch_IsOneShot_SoAHandleIsAContractViolation()
    {
        var resumed = Planned("claude", CapabilityGrant.None) with { Handle = "67289235-65f7-40b5-9532-e63515d90f30" };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(resumed);

        build.Should().Throw<ArgumentException>().WithMessage("*one-shot*");
    }

    [Fact]
    public void AScratchCwd_NeedsAScratchDirectory_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("claude", CapabilityGrant.None) with { ScratchDir = string.Empty };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*ScratchDir*",
            "falling back to the checkout would hand a none row the very directory it must not see");
    }

    /// <summary>The regression guard (acceptance 5): today's argv, byte for byte, with the defaulted confinement.</summary>
    /// <remarks>
    /// The claude row moved when PLAN_the_consultant_works_on_every_vendor.md merged second, as that plan's §7 said it
    /// must: the stuck consultant is confined by the planner's own disk allowlist (<see cref="ConfinementPlanner.ClaudeDiskTools"/>)
    /// plus <c>--restricted</c> where the installed CLI declares it — never the deny list. Its launch is PREPARED first
    /// (<c>IConsultantRuntime.PrepareAsync</c> reads the CLI's help), which is what <c>ClaudeCli</c> stands for here;
    /// the CLI without the flag is <c>ClaudeConsultantArgvTests</c>' business.
    /// </remarks>
    [Fact]
    public void TheShippedConsultants_StillBuildTodaysArgv_ByteForByte()
    {
        var launch = new ConsultantLaunch(Repo, "help me", string.Empty, Answers, new ReviewerSettings("v") { Model = "m", ClaudeCli = ClaudeCapability.WithRestricted });
        launch.Confinement.Should().Be(LaunchConfinement.AsShipped, "the default is the stuck consultant as it ships");

        new ClaudeConsultant(new ClaudeRuntime()).Build(launch).Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan",
            "--restricted", "--tools", string.Join(',', ConfinementPlanner.ClaudeDiskTools),
            NoMcpServers.ClaudeFlag, "--add-dir", Repo, "--model", "m");

        var codex = new CodexConsultant(new CodexRuntime()).Build(launch).Request.Arguments.ToList();
        codex.Should().Equal(
            "exec", "-s", "read-only", "--skip-git-repo-check", "--color", "never", "-C", Repo, "--json", "-o", codex[codex.IndexOf("-o") + 1], "-m", "m",
            "-c", "service_tier=default", "-");

        // agy's argv CHANGED on purpose (research/PLAN_agy_cannot_write_its_roots.md): it runs as the reader agent, from the
        // read-only folder, and reaches the checkout through --add-dir — plan mode alone let it write there.
        var agy = new AntigravityConsultant(new AntigravityRuntime()).Build(launch).Request;
        agy.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "m", "--add-dir", Repo);
        agy.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());

        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is not "local" and not "antigravity" and not "vibe" and not "kimi"))
        {
            consultant.Build(launch).Request.WorkingDirectory.Should().Be(Repo, consultant.Vendor);
            consultant.Build(launch).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }

        // Vibe and Kimi never stand in the checkout (D6): the conversation's snapshot, which the service makes (S5.4.13 for Kimi).
        var inTheSnapshot = launch with { Workdir = RowTree, Settings = launch.Settings with { OwnedScratch = RowFolder } };
        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is "vibe" or "kimi"))
        {
            consultant.Build(inTheSnapshot).Request.WorkingDirectory.Should().Be(RowTree, consultant.Vendor);
            consultant.Build(inTheSnapshot).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }
    }

    private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters() =>
    [
        ("claude", new ClaudeConsultant(new ClaudeRuntime())),
        ("codex", new CodexConsultant(new CodexRuntime())),
        ("antigravity", new AntigravityConsultant(new AntigravityRuntime())),
        ("vibe", new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows))),
        // A fake person's paths, so building reads nothing of this machine: the request names the places, it does not open them.
        ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
            new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))))),
    ];
}

```
