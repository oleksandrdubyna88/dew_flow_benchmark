You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s55-answer — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
The check's prompt wants two lines: `marker: <the marker>` and `canary: CANNOT`. The marker is the last word of the copy's `CHECK.md` with its
trailing '.' trimmed: `File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.')`
(the same read `ConsultantCheckTests` does). Return `PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT")`.

## The exact existing types and members you may use (context pack)
# Region s55-answer - context pack

Context pack — GROUP B: the Kimi consultant check tests (`src_mcp/tests/AKimiConsultantCheckTests.cs`, class `AKimiConsultantCheckTests : IDisposable`,
namespace `CoaiMcp.Tests`). Names are copied from the repository at commit 2aacf633. C# is .NET 10, FluentAssertions, xUnit v3 (`Xunit`).
Usings already in the file: System.Text.Json, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Files, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Platform,
CoaiMcp.Runners.Processes, CoaiMcp.Server, FluentAssertions, Xunit. Add `using CoaiMcp.Runners.Vibe;` for `VibeHomes.OneShotFolder` (= "coai-vh") if the body needs it.
A body that needs a name not in this pack is a mistake: ask for it in your notes, do not invent it.

## What the file already has (private members of the class; do not redefine)

```csharp
private readonly KimiFixture _person = new();                                   // a fake person's ~/.kimi-code inside its own testsToDelete-kimi- folder
private readonly TempDir _homes = TempDir.For("testsToDelete-kimi-check-homes-"); // implicit conversion to string (its Path); `Path.Combine(_homes, "x")` works
private readonly string _data;    // PanelSettings.DataDir
private readonly string _temp;    // the check's temp root: the check makes `coai-check-*` folders here
private readonly List<string> _warned = [];
private readonly List<string> _unlinkedByTheDeleter = [];
private PanelSettings Settings(string homesRoot);          // Kimi row `my-kimi` (runtime kimi) for the `claude` caller; empty homesRoot = root-less check
private void RecordingTheDeleter();                         // GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before);   // asserts _person.Hash() equals `before`
private void TheDeleterNeverMetTheJunction();               // asserts _unlinkedByTheDeleter is empty
private static string HomeOf(ProcessRequest request);       // the value after `--home` on the shim request
private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played, CancellationToken ct);   // FILL s55-check-helper
private static ProcessResult AnswersFromTheCopy(ProcessRequest request);                                                       // FILL s55-answer
```

## Types the helper needs

```csharp
// namespace CoaiMcp.Server (src_mcp/src/Server/Consultation/ConsultantCheckMode.cs) — internal static, reachable from the tests:
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
// `Noticing.None` is the no-op notices value (namespace CoaiMcp.Server). Existing helper in ConsultantCheckTests, to copy:
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
// call it with args "--caller", "claude".

// the stand-ins (the seams are async-local: a SYNCHRONOUS call in the test's own flow reaches every awaited call below it)
internal static class WindowsStandIn { public static IDisposable Begin(); }                       // namespace CoaiMcp.Tests
public static IDisposable KimiCredentialsLock.RootFor(string folder);                             // namespace CoaiMcp.Runners.Kimi
internal static IDisposable KimiSeams.Using(HostKind host, KimiSeams seams);                      // namespace CoaiMcp.Runners.Kimi; HostKind is CoaiMcp.Runners.Platform
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
// the way AKimiConsultationScenarioTests composes them (its private nested `Scopes` disposes in reverse):
//   WindowsStandIn.Begin(),
//   KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
//   KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, [])))
// `_person.PlacesAt(string ownedRoot)` is `KimiPlaces PlacesAt(string)`; `_person.Folder` is the fixture's folder; `_person.Hash()` is `IReadOnlyList<string>`.
```

## The played shim (`src_mcp/tests/PlayedKimi.cs`, namespace `CoaiMcp.Tests`, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`)

```csharp
public const string Shim = "played-coai-mcp";            // the executable the seams name — recognised, never started
public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }            // one entry per shim launch, added when it ENDS
public int Peak { get; }
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }                 // what the n-th shim launch (0-based) prints; default: an answered turn
public Func<ProcessRequest, CancellationToken, Task> During { get; init; }          // runs while the shim is "alive" — a seam to block or to cancel
public static string SessionOf(ProcessRequest request);                             // the --session value, else Minted
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);   // exit 0
public static ProcessResult Uncaptured(string session, string answer = Advice);
public static ProcessResult Lost(string session);                                    // end session_lost, exit 70
public const string Advice = "...";
// `new PlayedKimi(new ProcessLauncher())` — every non-shim process (git) runs for real; `kimi --version` answers "kimi 2.1.1".
// A launch whose `During` throws OperationCanceledException (ct.ThrowIfCancellationRequested()) ends the launch cancelled; its `Launch` is still enqueued in a `finally`.
```

## How the Vibe check test reads (the model for S5.5.1; `ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself`)

```csharp
var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
{
    AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
};
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());          // Text(e, name) = e.GetProperty(name).GetString() ?? string.Empty
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
```

The check's result JSON has `state` (one of `answered`, `failed`, `unavailable`, `already-checking`, ... — `ConsultCheckStates` constants are public strings in namespace
`CoaiMcp.Server`: `Answered = "answered"`, `Failed = "failed"`, `Unavailable = "unavailable"`), `markerRead` (bool) and `canary` (a `CanaryReadings` word). A check
cancelled by its token may end with an exception instead of a record: handle both as the fill comment of s553 says, and write down which one you saw.

The shim request of a Kimi check: argv `--ask-acp --profile kimi --model … --cwd <copy of the scratch>\tree-like path under <scratch>\own\tree --home <root>\coai-vh\<8>\kh-<10 hex>`;
`request.WorkingDirectory` is the same cwd; the prompt rides `request.StdIn`. A root-less check keeps the home at `<scratch>\own\kh-<10 hex>` where `<scratch>` is a `coai-check-*` folder under `_temp`.

## Existing test with the same junction-first assertions (`AOneShotKimiHomeIsDisposedJunctionFirstTests`)

```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) => _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
private void TheDeleterNeverMetTheJunction() => _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
// and in the test:  using var standIn = WindowsStandIn.Begin();  var before = _person.Hash();  RecordingTheDeleter();  ...  home.Dispose();  Directory.Exists(home.Folder).Should().BeFalse(...)
```


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Platform;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Server;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// <c>--check-consultant</c> for a Kimi row (E5.5 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.5.1–S5.5.4): the check runs one turn as a
/// consultation makes it — in a COPY of its scratch repository, on a ONE-SHOT owned home under <c>&lt;root&gt;\coai-vh\&lt;8&gt;</c> (or under its own
/// scratch when no root is set) — and the home is disposed junction-first whatever ended the check: an answer, a failed turn, a cancellation.
/// </summary>
/// <remarks>
/// <para>The whole mode (<c>ConsultantCheckMode.AnswerAsync</c>), git for real, the shim played in process (<see cref="PlayedKimi"/>) over a fake
/// person's sign-in (<see cref="KimiFixture"/>; the person's folder lives outside the homes root the check deletes). No test starts a real
/// <c>kimi</c>. Every folder a test makes is named <c>testsToDelete-…</c> and removed in <see cref="Dispose"/>.</para>
/// <para>"The deleter's unlink recorder" is <c>GitScratch.AfterUnlink</c>: a Kimi home disposed junction-first never lets the generic deleter
/// meet its junction, so the recorder must stay empty.</para>
/// </remarks>
public sealed class AKimiConsultantCheckTests : IDisposable
{
    private readonly KimiFixture _person = new();
    private readonly TempDir _homes = TempDir.For("testsToDelete-kimi-check-homes-");
    private readonly string _data = Directory.CreateTempSubdirectory("testsToDelete-kimi-check-data-").FullName;
    private readonly string _temp = Directory.CreateTempSubdirectory("testsToDelete-kimi-check-temp-").FullName;
    private readonly List<string> _warned = [];
    private readonly List<string> _unlinkedByTheDeleter = [];

    public void Dispose()
    {
        GitScratch.AfterUnlink = null;
        _homes.Dispose();
        _person.Dispose();
        foreach (var dir in (string[])[_data, _temp])
        {
            try
            {
                Directory.Delete(dir, recursive: true);
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                // A leftover temp directory is not a failing test.
            }
        }
    }

    /// <summary>The panel's settings for a Kimi row <c>my-kimi</c> answering the <c>claude</c> caller; <paramref name="homesRoot"/> empty is a root-less check.</summary>
    private PanelSettings Settings(string homesRoot) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = TimeSpan.FromSeconds(60),
        ConsultEnabled = true,
        ConsultantHomesRoot = homesRoot,
        Consultants = new Dictionary<string, ConsultantChoice> { [CallerIdentity.Claude] = new("my-kimi", Runtime: "kimi") },
    };

    /// <summary>The deleter's own unlink recorder — a Kimi home disposed junction-first never lets the deleter meet its junction.</summary>
    private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;

    /// <summary>The person's folder, whole: the same names, bytes and read-only bits as <paramref name="before"/>.</summary>
    private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) =>
        _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");

    private void TheDeleterNeverMetTheJunction() =>
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");

    /// <summary>The value after <c>--home</c> on a shim request.</summary>
    private static string HomeOf(ProcessRequest request) => request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1];

    /// <summary>The check, in process: <c>--check-consultant --caller claude</c> over the given launcher, with the fake person's sign-in and the measured host standing in.</summary>
    private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played, CancellationToken ct)
    {
        // QWEN-FILL-BEGIN s55-check-helper test
        // Run the check as the Vibe check test does (`ConsultantCheckTests.Check`): `ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", "--caller", "claude"],
        //   played, _temp, _warned.Add, Noticing.None, ct)` returns `(int Code, string Out, string Err)`; parse `Out` with `JsonDocument.Parse(Out).RootElement.Clone()`
        //   (empty Out → `default`) and return `(Code, said)`.
        // It must run INSIDE the stand-ins (the same four as `AKimiConsultationScenarioTests.StandIn`, minus `CallingAs`):
        //   `using var _ = WindowsStandIn.Begin();`
        //   `using var _lock = KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks"));`
        //   `using var _seams = KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, [])));`
        // (the seams are async-local, so they reach the awaited call). Give each `using` its own distinct variable name.
        throw new NotImplementedException("s55-check-helper");
        // QWEN-FILL-END s55-check-helper
    }

    /// <summary>What the played agent answers: the marker read from the copy's CHECK.md, and the canary it was told not to read.</summary>
    private static ProcessResult AnswersFromTheCopy(ProcessRequest request)
    {
        // QWEN-FILL-BEGIN s55-answer test   <<< REGION s55-answer STARTS AFTER THIS LINE
        // The check's prompt wants two lines: `marker: <the marker>` and `canary: CANNOT`. The marker is the last word of the copy's `CHECK.md` with its
        // trailing '.' trimmed: `File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.')`
        // (the same read `ConsultantCheckTests` does). Return `PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT")`.
        throw new NotImplementedException("s55-answer");
        // QWEN-FILL-END s55-answer   <<< REGION s55-answer ENDS BEFORE THIS LINE
    }

    // ---------- S5.5.1 ----------

    [Fact]
    public async Task AKimiCheck_RunsInACopy_OnAOneShotHome()
    {
        // QWEN-FILL-BEGIN s551-copy-oneshot test
        // Arrange: `var played = new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => AnswersFromTheCopy(request) };`, `RecordingTheDeleter()`,
        //   `var before = _person.Hash();`.
        // Act: `var (code, said) = await CheckAsync(Settings(_homes), played, TestContext.Current.CancellationToken);` (`_homes` converts to its path string).
        // Assert: `code.Should().Be(0)`; `said.GetProperty("state").GetString().Should().Be("answered", said.ToString())`; `said.GetProperty("markerRead").GetBoolean()` true
        //   (the copy holds the scratch's CHECK.md); `played.Shims` holds exactly one launch (`.Should().ContainSingle().Subject.Request`): its `WorkingDirectory`
        //   `.Should().Contain(Path.Combine("own", "tree"))` (a copy in the check's own scratch, never the repository); `HomeOf(request)` `.Should().StartWith(
        //   Path.Combine(_homes, VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar)` and `Path.GetFileName(...)` `.Should().StartWith("kh-")` with 13 characters (`kh-` + 10 hex);
        //   the arguments hold no "--session"; `ThePersonsFolderIsWhole(before)`.
        //   `Directory.EnumerateDirectories(_temp, "coai-check-*")` `.Should().BeEmpty("the copy goes with the check's scratch")`.
        // Needs `using CoaiMcp.Runners.Vibe;` for `VibeHomes.OneShotFolder`. Before E5.4 the check refused the row ("cannot hold a consultation in this build"); after it only a wrong cwd or home breaks it.
        throw new NotImplementedException("s551-copy-oneshot");
        // QWEN-FILL-END s551-copy-oneshot
    }

    // ---------- S5.5.2 ----------

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task AfterTheCheck_TheHomeIsGone_JunctionFirst(bool theTurnFails)
    {
        _ = theTurnFails; // the parameter is read by the body below; this line only keeps the skeleton building
        // QWEN-FILL-BEGIN s552-home-gone test
        // Arrange: `RecordingTheDeleter()`, `var before = _person.Hash();`; `var played = new PlayedKimi(new ProcessLauncher())` whose `Turn` is `AnswersFromTheCopy(request)`,
        //   or — when `theTurnFails` — `PlayedKimi.Lost(PlayedKimi.SessionOf(request))` (exit 70, a played failure).
        // Act: `await CheckAsync(Settings(_homes), played, TestContext.Current.CancellationToken)`.
        // Assert: the shim was launched (`played.Shims.Should().ContainSingle()`); `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))`
        //   `.Should().BeEmpty("the home's folder goes when the check ends, whatever ended it")` — `coai-vh\<8>` gone; `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)`.
        // Needs `using CoaiMcp.Runners.Vibe;`. Fails before E5.3 g: "Expected the deleter's unlink recorder not to be invoked …".
        throw new NotImplementedException("s552-home-gone");
        // QWEN-FILL-END s552-home-gone
    }

    // ---------- S5.5.3 ----------

    [Fact]
    public async Task ACheckCancelledMidTurn_StillDisposesItsHome()
    {
        // QWEN-FILL-BEGIN s553-cancelled test
        // Arrange: `RecordingTheDeleter()`, `var before = _person.Hash();`, `using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);`,
        //   `var started = new TaskCompletionSource();`; `var played = new PlayedKimi(new ProcessLauncher())` whose `During` is
        //   `async (_, ct) => { started.TrySetResult(); await Task.Delay(Timeout.Infinite, ct); }` (the played shim blocks until cancelled; `During`'s token is the launch's).
        // Act: `var check = CheckAsync(Settings(_homes), played, cts.Token);` then `await started.Task.WaitAsync(TimeSpan.FromSeconds(30), TestContext.Current.CancellationToken);`
        //   then `await cts.CancelAsync();` then `var (_, said) = await check;`.
        // Assert: the record says cancelled — `said.GetProperty("state").GetString()` is not "answered" and `said.ToString()` contains "cancel" (case-insensitive; read the real word off the first run
        //   and write it down in the notes); `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))` is empty; `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)`.
        // If `CheckAsync` throws OperationCanceledException instead of returning a record, assert that with `await Assert.ThrowsAnyAsync<OperationCanceledException>(() => check)` and still check the three folder facts.
        throw new NotImplementedException("s553-cancelled");
        // QWEN-FILL-END s553-cancelled
    }

    // ---------- S5.5.4 ----------

    [Fact]
    public async Task ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst()
    {
        // QWEN-FILL-BEGIN s554-rootless test
        // Arrange: `RecordingTheDeleter()`, `var before = _person.Hash();`, `var played = new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => AnswersFromTheCopy(request) };`.
        // Act: `await CheckAsync(Settings(string.Empty), played, TestContext.Current.CancellationToken)` — settings built by hand, no homes root.
        // Assert: one shim launch; `HomeOf(request)` contains `Path.Combine("own", "kh-")` (a Kimi home under `<scratch>\own\kh-…`, E5.5 decision 2); after the check `Directory.EnumerateDirectories(_temp, "coai-check-*")`
        //   is empty (the scratch is gone); `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)`.
        // Needs the `home` path read from the request BEFORE the check ends (it is in `played.Shims`' request, which stays after the check).
        // Fails before E5.3 g: "Expected the deleter's unlink recorder not to be invoked …".
        throw new NotImplementedException("s554-rootless");
        // QWEN-FILL-END s554-rootless
    }
}

```
