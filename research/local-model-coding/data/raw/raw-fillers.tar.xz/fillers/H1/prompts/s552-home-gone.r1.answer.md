```csharp
RecordingTheDeleter();
var before = _person.Hash();

var played = theTurnFails
    ? new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => PlayedKimi.Lost(PlayedKimi.SessionOf(request)) }
    : new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => AnswersFromTheCopy(request) };

await CheckAsync(Settings(_homes), played, TestContext.Current.CancellationToken);

played.Shims.Should().ContainSingle();
Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))
    .Should().BeEmpty("the home's folder goes when the check ends, whatever ended it");
TheDeleterNeverMetTheJunction();
ThePersonsFolderIsWhole(before);
```

Note: add `using CoaiMcp.Runners.Vibe;` at the top of the file, or the code will not compile.