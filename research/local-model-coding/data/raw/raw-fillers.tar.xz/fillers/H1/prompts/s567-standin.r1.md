You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s567-standin — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
The same four stand-ins `AKimiConsultationScenarioTests.StandIn` composes (its private `Scopes` class is not reachable; write a small private nested `Scopes(params IDisposable[])`
that disposes in reverse): `WindowsStandIn.Begin()`, `KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks"))`,
`KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, [])))`. (No `CallingAs`: a question row needs no caller kind.)

## The exact existing types and members you may use (context pack)
# Region s567-standin - context pack

Context pack — GROUP C: the Kimi question row test (`src_mcp/tests/AKimiQuestionRowTests.cs`, class `AKimiQuestionRowTests : IAsyncLifetime`, namespace `CoaiMcp.Tests`).
Names are copied from the repository at commit 2aacf633. C# is .NET 10, FluentAssertions, xUnit v3 (`Xunit`). A body that needs a name not in this pack is a mistake:
write it down in your notes, do not invent it.

Usings in the file: System.Text.Json, CoaiMcp.Core.QuestionConsult, CoaiMcp.Core.Rounds, CoaiMcp.Runners.Files, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Platform,
CoaiMcp.Runners.Processes, CoaiMcp.Runners.Vibe, CoaiMcp.Server, FluentAssertions, Serilog.Core, Xunit.

## What the file already has

```csharp
private const string Advice = "Retry with a jittered backoff, three attempts.";
private readonly ProcessLauncher _launcher = new();                  // the real launcher (git runs for real)
private readonly TempDir _dir = TempDir.For("testsToDelete-qkimi-"); // `_dir.At("repo")` joins a sub-path; implicit string conversion
private readonly KimiFixture _person = new();
private readonly List<string> _unlinkedByTheDeleter = [];
private string Repo => _dir.At("repo");
private string Homes => _dir.At("homes");                             // created in InitializeAsync
public enum Ending { Answered, RefusedBeforeTheLaunch, CancelledMidTurn }
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files);   // FILL s567-repo-helper (InitializeAsync calls it for Repo)
private PanelService ServiceOn(PlayedKimi played, params string[] roots);                    // FILL s567-service
private IDisposable StandIn();                                                                // FILL s567-standin
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null);   // written: service.AskConsultantsAsync(Repo, question, context, ct: ...) parsed
private static JsonElement TheRow(JsonElement reply);                                           // written: the one answer of `reply.answers`
```

## The Vibe twin, copied whole (the model for the three helpers)

```csharp
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}

private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    vibe,                      // the launcher
    Logger.None,               // Serilog.Core.Logger.None
    Noticing.None);
// QuestionRow (namespace CoaiMcp.Core.QuestionConsult):
//   record QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "");
// the row id of a Kimi row: Id "kimi-disk", Vendor "my-kimi", Runtime "kimi", Model "" (the default model), Prompt "question-disk".
// PanelService ctor: (PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)
// PlayedKimi is an IProcessLauncher (below) — pass it as the launcher.
```

## The stand-ins a Kimi flow needs (as `AKimiConsultationScenarioTests.StandIn` composes them)

```csharp
private sealed class Scopes(params IDisposable[] scopes) : IDisposable
{
    public void Dispose()
    {
        foreach (var scope in scopes.Reverse())
        {
            scope.Dispose();
        }
    }
}

private static Scopes StandIn(KimiFixture person) => new(
    WindowsStandIn.Begin(),                                                   // internal static class in CoaiMcp.Tests
    KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),        // public static IDisposable, CoaiMcp.Runners.Kimi
    KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),   // internal static IDisposable; HostKind in CoaiMcp.Runners.Platform
    CallingAs("CLAUDE_CODE_SESSION_ID"));                                     // NOT needed here: a question row has no caller kind
// public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
```

## The played shim (`src_mcp/tests/PlayedKimi.cs`, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`)

```csharp
public const string Shim = "played-coai-mcp";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }            // one entry per shim launch, enqueued when it ENDS
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }                 // what the n-th shim launch prints
public Func<ProcessRequest, CancellationToken, Task> During { get; init; }          // runs while the shim is alive; may cancel and throw
public static string SessionOf(ProcessRequest request);
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
// `kimi --version` answers "kimi 2.1.1"; every non-shim process (git) runs for real through `inner`.
// public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { string StdIn; IReadOnlyDictionary<string,string?> Environment; ... }
```

## The Vibe row tests this one mirrors (same file `AVibeQuestionRowReadsACopyOfItsRootsTests`)

```csharp
// a plain folder outside any git work tree is refused at its copy, before any launch:
var plain = _dir.At("plain"); Directory.CreateDirectory(plain);
await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
// ... AskAsync(ServiceOn(vibe, Homes, plain)) → TheRow(reply).GetProperty("status") is RowOutcomes.Refused / Failed (read the real word off the first run)

// cancelled in flight:
using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var vibe = new PlayedVibe(_launcher, Advice)
{
    During = async ct =>
    {
        await caller.CancelAsync();
        ct.ThrowIfCancellationRequested();
    },
};
var asking = async () => await AskAsync(Service(vibe, Path.Combine(Repo, "src")), caller.Token);
await asking.Should().ThrowAsync<OperationCanceledException>();

// the row's home goes with its one-shot folder:
Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the row's folder under coai-vh is deleted on every way out");
// VibeHomes.OneShotFolder == "coai-vh" (namespace CoaiMcp.Runners.Vibe); the folder may not exist after the row: treat "absent" as empty.
// RowOutcomes (namespace CoaiMcp.Core.QuestionConsult) string constants: Answered = "answered", TimedOut, Failed = "failed", Refused = "refused", ...
// GitScratch.AfterUnlink is `internal static Action<string>?` (namespace CoaiMcp.Runners.Files): the deleter's unlink recorder; set `= _unlinkedByTheDeleter.Add`.
// `_person.Hash()` → IReadOnlyList<string>: the person's folder as names+bytes+attributes; `Should().Equal(before)` means whole.
```

A Kimi row's shim request (what `played.Shims` holds): argv `--ask-acp --profile kimi --model … --cwd <the row's tree copy> --home <Homes>\coai-vh\<8>\kh-<10 hex>`; no `--session`;
the prompt is `request.StdIn` and names the COPIES' paths (the `tree` folder inside the row's own folder — the parent of the `--home` value's parent... read it off
the `--cwd` value), never the granted root. `HomeOf` = the value after `"--home"`: `args[args.ToList().IndexOf("--home") + 1]`.


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Core.Rounds;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Platform;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Vibe;
using CoaiMcp.Server;
using FluentAssertions;
using Serilog.Core;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// A Kimi question-consultant row (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.6.7): a <c>disk</c> row reads COPIES of its granted roots
/// (the prompt names the copies' paths, never the roots), on a ONE-SHOT home under <c>&lt;root&gt;\coai-vh\&lt;8&gt;</c>, and after the row ends — answered,
/// refused before any launch, or cancelled mid-turn — its scratch and its home are gone, junction-first, with the person's folder whole.
/// </summary>
/// <remarks>
/// The whole <c>ask_consultants</c> flow through the service, git for real, the shim played in process (<see cref="PlayedKimi"/>) over a fake person's
/// sign-in (<see cref="KimiFixture"/>, a real junction on Windows, a symbolic link elsewhere through <see cref="WindowsStandIn"/>). No test starts a
/// real <c>kimi</c>. The shape is <c>AVibeQuestionRowReadsACopyOfItsRootsTests</c>; the junction-first teeth are <c>AOneShotKimiHomeIsDisposedJunctionFirstTests</c>'s.
/// </remarks>
public sealed class AKimiQuestionRowTests : IAsyncLifetime
{
    private const string Advice = "Retry with a jittered backoff, three attempts.";

    private readonly ProcessLauncher _launcher = new();
    private readonly TempDir _dir = TempDir.For("testsToDelete-qkimi-");
    private readonly KimiFixture _person = new();
    private readonly List<string> _unlinkedByTheDeleter = [];

    private string Repo => _dir.At("repo");

    private string Homes => _dir.At("homes");

    /// <summary>How a row's turn ends in S5.6.7's Theory.</summary>
    public enum Ending
    {
        Answered,
        RefusedBeforeTheLaunch,
        CancelledMidTurn,
    }

    public async ValueTask InitializeAsync()
    {
        Directory.CreateDirectory(Homes);
        await RepositoryAsync(Repo, ("src/Mailer.cs", "void Send() { }\n"), ("docs/notes.md", "not granted\n"));
    }

    public ValueTask DisposeAsync()
    {
        GitScratch.AfterUnlink = null;
        _person.Dispose();
        _dir.Dispose();

        return ValueTask.CompletedTask;
    }

    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        // QWEN-FILL-BEGIN s567-repo-helper test
        // Copy `AVibeQuestionRowReadsACopyOfItsRootsTests.RepositoryAsync` (the context pack has it whole): create each file under `at`, then run
        // `git init -b main`, `config user.email`, `config user.name`, `add .`, `commit -m base` with `_launcher`, each exit code 0.
        throw new NotImplementedException("s567-repo-helper");
        // QWEN-FILL-END s567-repo-helper
    }

    /// <summary>The service with the homes root and one <c>disk</c> Kimi row — <see cref="PlayedKimi"/> is its launcher; the fake person is NOT yet standing in (see <see cref="StandIn"/>).</summary>
    private PanelService ServiceOn(PlayedKimi played, params string[] roots)
    {
        // QWEN-FILL-BEGIN s567-service test
        // Copy `AVibeQuestionRowReadsACopyOfItsRootsTests.ServiceFor` (the context pack has it whole), with: `ConsultantHomesRoot = Homes`, `DataDir = _dir.At("data")`,
        //   the row `new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, string.Empty, string.Empty, "question-disk", Enabled: true)`, `Roots = roots`,
        //   and `played` as the launcher argument of `new PanelService(settings, VaultKeys.None("no vault in tests"), default, played, Logger.None, Noticing.None)`.
        throw new NotImplementedException("s567-service");
        // QWEN-FILL-END s567-service
    }

    /// <summary>The fake person's sign-in, the measured host and the lock root this flow's Kimi adapters see — set by a SYNCHRONOUS call so it reaches every awaited service call.</summary>
    private IDisposable StandIn()
    {
        // QWEN-FILL-BEGIN s567-standin test   <<< REGION s567-standin STARTS AFTER THIS LINE
        // The same four stand-ins `AKimiConsultationScenarioTests.StandIn` composes (its private `Scopes` class is not reachable; write a small private nested `Scopes(params IDisposable[])`
        // that disposes in reverse): `WindowsStandIn.Begin()`, `KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks"))`,
        // `KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, [])))`. (No `CallingAs`: a question row needs no caller kind.)
        throw new NotImplementedException("s567-standin");
        // QWEN-FILL-END s567-standin   <<< REGION s567-standin ENDS BEFORE THIS LINE
    }

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());

        return answers.EnumerateArray().Should().ContainSingle().Subject;
    }

    // ---------- S5.6.7 ----------

    [Theory]
    [InlineData(Ending.Answered)]
    [InlineData(Ending.RefusedBeforeTheLaunch)]
    [InlineData(Ending.CancelledMidTurn)]
    public async Task AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(Ending ending)
    {
        _ = ending; // the parameter is read by the body below; this line only keeps the skeleton building
        // QWEN-FILL-BEGIN s567-disk-row test
        // Arrange: `using var stood = StandIn();`, `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;`, `var before = _person.Hash();`, `var granted = Path.Combine(Repo, "src");`,
        //   `using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);`.
        //   `var played = new PlayedKimi(_launcher) { Turn = (_, request) => PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, Advice) }`; for `Ending.CancelledMidTurn`
        //   its `During` is `async (_, ct) => { await caller.CancelAsync(); ct.ThrowIfCancellationRequested(); }`.
        //   The roots: `[granted]`, except `Ending.RefusedBeforeTheLaunch` where the root is a plain folder outside any git work tree — `Directory.CreateDirectory(_dir.At("plain"))` with a
        //   file in it (the Vibe test `ARowRefusedAtItsCopy_GivesItsOneShotFolderBack` does this) — so the copy is refused and nothing launches.
        // Act: `var reply = await AskAsync(ServiceOn(played, roots), caller.Token)`; for the cancelled ending the call throws `OperationCanceledException`
        //   (`await asking.Should().ThrowAsync<OperationCanceledException>()` with `asking = async () => await AskAsync(...)`).
        // Assert, per ending: Answered → `TheRow(reply).GetProperty("status").GetString()` is `RowOutcomes.Answered`, one shim launch (`played.Shims`), whose stdin/argv prompt names the COPY's path
        //   (`request.StdIn` contains the row's `tree` folder `Path.Combine(<row folder>, "tree")` where the row folder is the parent of `--home`'s value) and NEVER `granted`; Refused → status
        //   `RowOutcomes.Refused` or `RowOutcomes.Failed` (read the real one off the first run and write it into the notes), `played.Shims` empty; Cancelled → the throw above, one launch.
        //   After EACH ending: `Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder))` is empty (the row's `coai-vh\<8>` is gone) — if the folder does not exist
        //   that counts as empty; for Answered/Cancelled the row folder (parent of the shim's `--home` value) does not exist; `_unlinkedByTheDeleter` is empty;
        //   `_person.Hash().Should().Equal(before)`.
        // Fails before E5.3 g: "Expected Directory.Exists(\"…\\coai-vh\\<8>\") to be False, but found True." or the recorder not empty.
        throw new NotImplementedException("s567-disk-row");
        // QWEN-FILL-END s567-disk-row
    }
}

```
