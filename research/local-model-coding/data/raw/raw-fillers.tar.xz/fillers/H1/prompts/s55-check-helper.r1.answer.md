```csharp
using var _ = WindowsStandIn.Begin();
using var _lock = KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks"));
using var _seams = KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, [])));

var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(
    settings, ["--check-consultant", "--caller", "claude"], played, _temp, _warned.Add, Noticing.None, ct);

return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default);
```