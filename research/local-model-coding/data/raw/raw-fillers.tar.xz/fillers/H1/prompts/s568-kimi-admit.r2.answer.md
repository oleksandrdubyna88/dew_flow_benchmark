```typescript
  const none = admit('kimi', 'none');

  assert.equal(none.admitted, true, none.reason);
  assert.equal(none.standing, 'unconfined');
  assert.equal(none.flag, 'unconfined');
  assert.match(none.caveat, /can read this machine/u);

  const disk = admit('kimi', 'disk');

  assert.equal(disk.admitted, true, disk.reason);
  assert.equal(disk.standing, 'unconfined');
  assert.equal(disk.flag, 'unconfined');
  assert.match(disk.caveat, /can read this machine/u);

  const refusal = admit('kimi', 'web');

  assert.equal(refusal.admitted, false);
  assert.match(refusal.reason, /not been measured/u);
  assert.match(refusal.reason, /RESULTS_kimi_confinement\.md/u);
  assert.ok(!refusal.reason.includes('RESULTS_question_consultant_capabilities.md'));
```