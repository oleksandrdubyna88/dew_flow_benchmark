You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s561-kimi-rows — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
For each of Capability.None and Capability.Disk: `var row = RuntimeCapabilities.Builtin.Of("kimi", capability);` → `row.Should().NotBeNull()`;
  `row!.Standing.Should().Be(CapabilityStanding.Unconfined)`; `row.MeasuredWith.Version.Should().Be("2.1.1")`;
  `row.MeasuredWith.Cells.Should().Contain("M-K6")`; `row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md")`.
  For Disk also `Cells.Should().Contain("M-K9")`.
For Capability.Web: Standing is `CapabilityStanding.Unmeasured` and Version "2.1.1".
Fails before the row exists: "Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.None) not to be <null>." (the context pack names the exact types).

## The exact existing types and members you may use (context pack)
# Region s561-kimi-rows - context pack

Context pack — GROUP A: the planner, the matrix, the Kimi question launch, the TS admission. All names below are copied from the repository at
commit 2aacf633 (branch exp/kimi-e56-skeleton-haiku-1). Namespace of each type is given. C# is .NET 10, latest C#, FluentAssertions, xUnit v3
(`Xunit`; `TestContext.Current.CancellationToken`). Never `dotnet test`: the tests are run as the MTP executable.

## Production types (namespace `CoaiMcp.Core.QuestionConsult`, file `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`)

```csharp
public enum CwdKind { Scratch, Root, Snapshot }

public abstract record Confinement
{
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,   // argv BEFORE the CLI's subcommand
        IReadOnlyList<string> Flags,     // the sandbox flags, complete
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];   // the roots read through COPIES (Snapshot cwd)
    }

    public sealed record Refused(string Reason) : Confinement;
}

// file src_mcp/core/QuestionConsult/Capability.cs
public enum Capability { None, Disk, Web }   // spelled none/disk/web
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    public static CapabilityGrant None { get; }                       // question alone
    public static CapabilityGrant Web { get; }
    public static CapabilityGrant Disk(params string[] roots);        // read-only under these roots
}

// file src_mcp/core/QuestionConsult/CapabilityMatrix.cs
public enum AdmissionFlag { None, Unconfined, DefaultDeny }           // (third member's exact name: DefaultDeny — spelled "default-deny")
// CapabilityMatrix.Admit(string runtime, string capability) and Admit(string runtime, Capability capability) return Admission:
//   Admission.Admitted { Standing, Flag } or Admission.Refused { Reason }

// the planner (same file as above)
public static class ConfinementPlanner
{
    public static Confinement Plan(string runtime, CapabilityGrant grant);   // asks CapabilityMatrix first; a refusal comes back as Confinement.Refused
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag), "codex" => Codex(grant, flag), "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),      // <- written; its body is the FILL region s56-planner-kimi
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
}
```

The model to follow for `Kimi(...)` (the existing Vibe arm, same file):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

`Kimi` has the SAME shape with `[]` instead of `VibeReadOnly` (no flags at all) and the runtime name `"kimi"`. Its skeleton is a block-bodied method
`private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag) { <FILL region> }` — so the filled body is `return grant.Capability switch { ... };`
(keep the region's comment lines; replace only the `throw`).

## The Kimi consultant (namespace `CoaiMcp.Runners.Kimi`, file `src_mcp/runners/Kimi/KimiConsultant.cs`)

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)          // for a planned launch (`launch.Confinement is LaunchConfinement.Planned planned`) calls MustCarryNoFlag(planned.Plan)
    private static void MustCarryNoFlag(Confinement.Planned plan)      // FILL region s56-kimi-noflags; throws ArgumentException(message, nameof(plan)) for a plan with Leading/Flags/AddDirs
}
// the launch (namespace CoaiMcp.Runners.Consultation)
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
{
    public LaunchConfinement Confinement { get; init; } = LaunchConfinement.AsShipped;
    public string ScratchDir { get; init; } = string.Empty;   // EMPTY folder for a planned launch standing in Scratch
    public string Workdir { get; init; } = string.Empty;      // the snapshot / the copy of the roots
}
public abstract record LaunchConfinement
{
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;       // pattern: `launch.Confinement is LaunchConfinement.Planned planned` then `planned.Plan`
    public static LaunchConfinement AsShipped { get; }
}
// namespace CoaiMcp.Runners.Reviewers
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, string SharedResource = "", ...);
// namespace CoaiMcp.Runners.Processes
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)
{ IReadOnlyDictionary<string,string?> Environment; string StdIn; bool InheritsEnvironment; ProcessEnvironment Passthrough; ... }
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut, bool Cancelled = false, bool Truncated = false, ...);
// ConsultantRoles.Question / ConsultantRoles.Consult are string constants (namespace CoaiMcp.Runners.Consultation) — `built.Role`.
```

## The test file `src_mcp/tests/ConfinementPlannerTests.cs` (namespace `CoaiMcp.Tests`; usings: CoaiMcp.Core.QuestionConsult, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Reviewers, FluentAssertions, Xunit)

Existing members you may call (all `private static`, in `public sealed class ConfinementPlannerTests`):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private const string Repo = "D:/rsd/some-checkout";
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{
    Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
    ScratchDir = Scratch,
    Workdir = RowTree,
};
private static Runners.Kimi.KimiConsultant KimiForQuestions();   // a consultant over a fake person's paths: builds, reads nothing of this machine
```

The Vibe test the Kimi launch test is modelled on (existing, in the same file):

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file").And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
    request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "...");
}
```

Kimi's request is the shim request: argv `--ask-acp --profile kimi --model kimi-code/k3-256k --cwd <cwd> --home <RowFolder>\kh-<10 hex>` (no `--session`; one shot),
the prompt on `StdIn`. The value after a flag: `args[args.ToList().IndexOf("--home") + 1]` (`AcpWords.HomeFlag` is `"--home"`, namespace `CoaiMcp.Runners.Acp`).

Refusal check of the built request (namespace `CoaiMcp.Runners.Kimi`; `KimiEnvironment` is a static class):

```csharp
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty string = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin);           // the places the SHIM knows
// How the existing consultant tests use it (KimiConsultantTests, with a `KimiFixture _person`):
//   KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("the one launch control admits exactly what the adapter builds");
// where `home` is the value after "--home". `KimiFixture` (namespace CoaiMcp.Tests, IDisposable, `new KimiFixture()`) has `PlacesAt(string ownedRoot)`.
// For s565 build the consultant with it, so the check is real:
//   using var person = new KimiFixture();
//   var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
//       new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
// (`KimiRuntime(string id, HostKind host, KimiSeams seams)`, `KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`.)
```

## The matrix tests (`src_mcp/tests/CapabilityMatrixTests.cs`, namespace `CoaiMcp.Tests`)

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability)   // -> RuntimeCapabilityRow? (null for a runtime the table does not know)
// existing test of the same shape (Vibe):
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

The kimi rows' data (already in `shared/runtime-capabilities.json`): none → `unconfined`, cells `M-K6, M-K3, M-K4`; disk → `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`;
web → `unmeasured`, no cells; version `2.1.1`; every `resultRef` names `research/RESULTS_kimi_confinement.md`.

## TypeScript (file `src_vs_code/src/test/capabilityAdmission.test.ts`; node:test + `node:assert/strict`)

```ts
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
export interface Admission { readonly admitted: boolean; readonly standing: CapabilityStanding | ''; readonly flag: AdmissionFlag; readonly reason: string; readonly caveat: string; }
// admit(runtime: string, capability: string): Admission
// A flagged caveat: unconfined -> 'unconfined: can read this machine — a shell is always there, and no flag removes it'
// An unmeasured refusal reads: "'<runtime>' has not been measured for '<cap>' (<note>) — a measured cell in <record> is what admits it; until then give this row a prompt of another capability"
// where <record> is the `research/RESULTS_*.md` file the row's resultRef cites.
// An existing test in the same file of the same shape:
test('an unmeasured pair names the record its row cites: ...', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
});
```


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The capability table is the file in <c>shared/</c>, and admission answers the shared vectors —
/// the C# half of <c>shared/capability-matrix-vectors.json</c>; <c>capabilityAdmission.test.ts</c> is
/// the other (PLAN_question_consultant.md, S1 acceptance 1).
/// </summary>
/// <remarks>
/// <para>Read from disk the way <see cref="BuiltinRoleCatalogTests"/> reads its seed: from the test
/// binary up to the repository root, so the comparison is against the checked-in file and not the
/// copy the build embedded a moment ago.</para>
/// <para>A3's "blocked in the UI AND refused by the server" is one rule only while both sides answer
/// one set of vectors; two self-consistent loaders cannot notice that they disagree.</para>
/// </remarks>
public sealed class CapabilityMatrixTests
{
    private sealed record Vector(string Runtime, string Capability, bool Admitted, string Standing, string Flag, string Why);

    private sealed record FileRow(string Runtime, string Capability, string Standing, string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

    private static readonly Vector[] Vectors = LoadVectors();

    private static readonly IReadOnlyList<FileRow> Seed = LoadSeed();

    private static string Shared(string file) => Path.GetFullPath(Path.Combine(
        AppContext.BaseDirectory, "..", "..", "..", "..", "..", "shared", file));

    private static Vector[] LoadVectors()
    {
        using var file = File.OpenRead(Shared("capability-matrix-vectors.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("vectors").EnumerateArray().Select(v => new Vector(
            v.GetProperty("runtime").GetString() ?? "",
            v.GetProperty("capability").GetString() ?? "",
            v.GetProperty("admitted").GetBoolean(),
            v.GetProperty("standing").GetString() ?? "",
            v.GetProperty("flag").GetString() ?? "",
            v.GetProperty("why").GetString() ?? ""))];
    }

    private static IReadOnlyList<FileRow> LoadSeed()
    {
        using var file = File.OpenRead(Shared("runtime-capabilities.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("rows").EnumerateArray().Select(r =>
        {
            var measured = r.GetProperty("measuredWith");
            return new FileRow(
                r.GetProperty("runtime").GetString() ?? "",
                r.GetProperty("capability").GetString() ?? "",
                r.GetProperty("standing").GetString() ?? "",
                measured.GetProperty("cli").GetString() ?? "",
                measured.GetProperty("version").GetString() ?? "",
                measured.GetProperty("date").GetString() ?? "",
                measured.GetProperty("resultRef").GetString() ?? "",
                [.. measured.GetProperty("cells").EnumerateArray().Select(c => c.GetString() ?? "")],
                measured.GetProperty("note").GetString() ?? "");
        })];
    }

    public static TheoryData<int> Cases()
    {
        var data = new TheoryData<int>();
        for (var i = 0; i < Vectors.Length; i++)
        {
            data.Add(i);
        }

        return data;
    }

    [Fact]
    public void TheVectorsActuallyLoaded_AndCoverEveryPairOfTheTable()
    {
        // Without this every assertion below would pass vacuously over an empty list.
        Vectors.Should().HaveCountGreaterThan(15, "fifteen pairs plus the refusals by name");
        foreach (var row in Seed)
        {
            Vectors.Should().Contain(v => v.Runtime == row.Runtime && v.Capability == row.Capability,
                $"the table's {row.Runtime} × {row.Capability} row must have a vector deciding it");
        }
    }

    [Theory]
    [MemberData(nameof(Cases))]
    public void EveryVector_IsAdmittedOrRefused_AsMeasured(int index)
    {
        var vector = Vectors[index];

        var admission = CapabilityMatrix.Admit(vector.Runtime, vector.Capability);

        switch (admission)
        {
            case Admission.Admitted admitted:
                vector.Admitted.Should().BeTrue($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                admitted.Standing.Spelled().Should().Be(vector.Standing, vector.Why);
                admitted.Flag.Spelled().Should().Be(vector.Flag, vector.Why);
                break;
            case Admission.Refused refused:
                vector.Admitted.Should().BeFalse($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                refused.Reason.Should().Contain(vector.Runtime).And.Contain(vector.Capability,
                    "a refusal names the pair it refused");
                break;
        }
    }

    [Fact]
    public void TheEmbeddedTable_IsTheFileInShared_RowForRow()
    {
        var loaded = RuntimeCapabilities.Builtin.Rows;

        loaded.Select(r => (r.Runtime, r.Capability.Spelled())).Should().Equal(
            Seed.Select(r => (r.Runtime, r.Capability)),
            "the loader keeps the file's rows in the file's order");
        foreach (var (row, expected) in loaded.Zip(Seed))
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            row.Standing.Spelled().Should().Be(expected.Standing, where);
            row.MeasuredWith.Cli.Should().Be(expected.Cli, where);
            row.MeasuredWith.Version.Should().Be(expected.Version, where);
            row.MeasuredWith.Date.Should().Be(expected.Date, where);
            row.MeasuredWith.ResultRef.Should().Be(expected.ResultRef, where);
            row.MeasuredWith.Cells.Should().Equal(expected.Cells, where);
            row.MeasuredWith.Note.Should().Be(expected.Note, where);
        }
    }

    [Fact]
    public void EveryRuntimeTimesCapability_HasExactlyOneRow_AndNoRowIsOutsideTheMatrix()
    {
        var pairs = RuntimeCapabilities.Builtin.Rows.Select(r => (r.Runtime, r.Capability)).ToList();

        pairs.Should().OnlyHaveUniqueItems("two rows for one pair would be two answers");
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var capability in Enum.GetValues<Capability>())
            {
                pairs.Should().Contain((runtime, capability), "every pair is decided by data, never by a default arm");
            }
        }

        pairs.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Enum.GetValues<Capability>().Length);
    }

    /// <summary>
    /// The records a row may cite, each with the day it was measured and the shape of its cell ids: the question
    /// consultant's full run for the first five runtimes, and the Vibe probe for vibe (S3 of
    /// todo/PLAN_vibe_and_kimi_runtimes.md) — whose cells are named <c>M-V…</c>, not numbered.
    /// </summary>
    private static readonly IReadOnlyList<(string Record, string Date, string CellPrefix)> Records =
    [
        ("RESULTS_question_consultant_capabilities.md", "2026-10-01", "01a0f8c7-18e4-"),
        ("RESULTS_vibe_confinement.md", "2026-10-12", "M-V"),
        ("RESULTS_kimi_confinement.md", "2026-10-13", "M-K"),
    ];

    [Fact]
    public void EveryRow_CitesTheRecord_AndACellOrSaysWhyThereIsNone()
    {
        foreach (var row in RuntimeCapabilities.Builtin.Rows)
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            var cited = Records.Where(record => row.MeasuredWith.ResultRef.Contains(record.Record, StringComparison.Ordinal)).ToList();
            cited.Should().ContainSingle($"{where}: a row cites exactly one record");
            var (record, date, prefix) = cited[0];
            row.MeasuredWith.Date.Should().Be(date, $"{where}: the day {record} was measured");
            (row.MeasuredWith.Cells.Count > 0 || row.MeasuredWith.Note.Length > 0).Should().BeTrue(
                $"{where}: a row with no cell says why — by construction, or not measured");
            foreach (var cell in row.MeasuredWith.Cells)
            {
                cell.Should().StartWith(prefix, $"{where}: every cell is one of {record}'s");
            }
        }
    }

    [Fact]
    public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
            row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
            CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
        }

        RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6",
            "denied writes do not prove bounded READS — the disk row rests on the read cell itself");
        CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured", "no Vibe cell exercises the web");
    }

    /// <summary>Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md, S5.6.1): `none` and `disk` are <c>unconfined</c> (`Grep`/`Glob` read the disk, M-K6), `web` is unmeasured.</summary>
    [Fact]
    public void KimiHasThreeRows_EachCitingItsCells()
    {
        // QWEN-FILL-BEGIN s561-kimi-rows test   <<< REGION s561-kimi-rows STARTS AFTER THIS LINE
        // For each of Capability.None and Capability.Disk: `var row = RuntimeCapabilities.Builtin.Of("kimi", capability);` → `row.Should().NotBeNull()`;
        //   `row!.Standing.Should().Be(CapabilityStanding.Unconfined)`; `row.MeasuredWith.Version.Should().Be("2.1.1")`;
        //   `row.MeasuredWith.Cells.Should().Contain("M-K6")`; `row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md")`.
        //   For Disk also `Cells.Should().Contain("M-K9")`.
        // For Capability.Web: Standing is `CapabilityStanding.Unmeasured` and Version "2.1.1".
        // Fails before the row exists: "Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.None) not to be <null>." (the context pack names the exact types).
        throw new NotImplementedException("s561-kimi-rows");
        // QWEN-FILL-END s561-kimi-rows   <<< REGION s561-kimi-rows ENDS BEFORE THIS LINE
    }

    /// <summary>S5.6.2: the vectors decide every pair of the table's kimi rows — the existing cover test names a missing pair, this one names kimi.</summary>
    [Fact]
    public void TheVectorsCoverKimi()
    {
        foreach (var capability in (string[])["none", "disk", "web"])
        {
            Vectors.Should().Contain(v => v.Runtime == "kimi" && v.Capability == capability, $"kimi × {capability} must have a vector deciding it");
        }
    }

    /// <summary>S5.6.4: both admitted kimi rows are FLAGGED unconfined — the row says it can read this machine.</summary>
    [Fact]
    public void AdmissionFlagsBothRows()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>().Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}");
        }
    }

    /// <summary>D13's two refusals kept apart: the flags are what the data says, never what a runtime name suggests.</summary>
    [Fact]
    public void TheFlags_AreD13s_CodexUnconfinedEverywhere_AgyDefaultDeny_NothingElseFlagged()
    {
        foreach (var capability in Enum.GetValues<Capability>())
        {
            CapabilityMatrix.Admit("codex", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"codex × {capability}: F2");
        }

        CapabilityMatrix.Admit("antigravity", Capability.Disk).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7");
        CapabilityMatrix.Admit("antigravity", Capability.None).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
        foreach (var runtime in (string[])["claude", "local", "api"])
        {
            CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"{runtime} × none is confined");
        }
    }

    [Fact]
    public void AnUnmeasuredPair_IsRefused_NamingTheRecordThatWouldAdmitIt()
    {
        var refused = CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("not been measured").And.Contain("RESULTS_question_consultant_capabilities.md",
            "the cure for an unmeasured pair is a measurement, and the sentence says where it goes");
    }

    /// <summary>
    /// An unmeasured pair names the record ITS row cites — the record a measurement would land in — so an unmeasured Vibe
    /// pair names the Vibe probe's record (S3 of todo/PLAN_vibe_and_kimi_runtimes.md), and the first five runtimes' sentences
    /// stay exactly what they were.
    /// </summary>
    [Fact]
    public void AnUnmeasuredVibePair_NamesTheVibeRecord_AndTheApiSentenceIsUnchanged()
    {
        var vibe = CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason;

        vibe.Should().Contain("a measured cell in research/RESULTS_vibe_confinement.md is what admits it")
            .And.NotContain("RESULTS_question_consultant_capabilities.md", "no cell of that run could admit a Vibe pair");
        CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason.Should().Be(
            "'api' has not been measured for 'web' (not measured; vendor-specific (a tails-plan item)) — a measured cell in "
            + "research/RESULTS_question_consultant_capabilities.md is what admits it; until then give this row a prompt of another capability");
    }

    [Fact]
    public void AnUnsupportedPair_IsRefused_WithTheRowsOwnReason()
    {
        var refused = CapabilityMatrix.Admit("antigravity", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("cannot fetch a page headless", "the row's note is the reason a person reads");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void ARowWithNoRuntime_IsRefused_AskingForAModel_NeverQuotingNothing(string runtime)
    {
        // research/PLAN_names_and_a_missing_root.md story 2.2: a row with no runtime used to be "'' is not a runtime …".
        var refused = CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Be("this row has no model to run on — pick one");
        // The words' overload too, with a capability that does not parse: its sentence used to say "asked for runtime ''".
        CapabilityMatrix.Admit(runtime, "shell").Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Be("this row has no model to run on — pick one");
    }

    [Fact]
    public void AnUnknownRuntimeOrCapability_IsRefused_NamingWhatIsKnown()
    {
        var runtime = CapabilityMatrix.Admit("gemini", "none").Should().BeOfType<Admission.Refused>().Which;
        runtime.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe",
            "an unknown name fails naming the legal values");

        var capability = CapabilityMatrix.Admit("claude", "shell").Should().BeOfType<Admission.Refused>().Which;
        capability.Reason.Should().Contain("shell").And.Contain("none, disk, web");
    }

    [Fact]
    public void TheWordsOfTheFile_RoundTripThroughTheTypes()
    {
        foreach (var standing in Enum.GetValues<CapabilityStanding>())
        {
            CapabilityStandings.Parse(standing.Spelled()).Should().Be(standing);
        }

        foreach (var capability in Enum.GetValues<Capability>())
        {
            Capabilities.TryParse(capability.Spelled(), out var parsed).Should().BeTrue();
            parsed.Should().Be(capability);
        }

        Capabilities.TryParse("Disk", out var cased).Should().BeTrue("the file's words are matched without case");
        cased.Should().Be(Capability.Disk);
        Capabilities.TryParse("shell", out _).Should().BeFalse();
        Capabilities.AllSpelled.Should().Be("none, disk, web");
    }

    /// <summary>A broken table is a broken BUILD, refused whole and loudly — the role seed's rule.</summary>
    /// <remarks>
    /// Written against a hand-built table rather than by corrupting the embedded file, because the
    /// validation is the unit under test and the resource is not reachable without rebuilding the
    /// assembly. Every fixture starts from the WHOLE matrix — every pair, well formed — and breaks one
    /// thing, so the refusal observed is for that thing and not for the other pairs a smaller
    /// fixture would also be missing.
    /// </remarks>
    public sealed class ABrokenTable
    {
        private static RuntimeCapabilityRowSeed Row(string runtime, string capability, string standing = "confined", IReadOnlyList<string>? cells = null, string note = "n") =>
            new(runtime, capability, standing, new MeasuredWithSeed("cli", "1", "2026-10-01", "ref", cells ?? ["01a0f8c7-18e4-0000-0000-000000000000"], note));

        /// <summary>Every pair of the matrix, well formed — the fixture the broken ones are cut from.</summary>
        private static List<RuntimeCapabilityRowSeed> Whole() =>
            [.. RuntimeCapabilities.Runtimes.SelectMany(runtime => Capabilities.All.Select(capability => Row(runtime, capability.Spelled())))];

        private static Action Loading(IEnumerable<RuntimeCapabilityRowSeed> rows) =>
            () => RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], [.. rows]));

        /// <summary>The whole matrix with ONE row replaced.</summary>
        private static IEnumerable<RuntimeCapabilityRowSeed> With(RuntimeCapabilityRowSeed replacement) =>
            Whole().Select(row => row.Runtime == replacement.Runtime && row.Capability == replacement.Capability ? replacement : row);

        [Fact]
        public void WithAPairMissing_IsRefused_NamingIt() =>
            Loading(Whole().Where(row => !(row.Runtime == "claude" && row.Capability == "disk")))
                .Should().Throw<InvalidOperationException>().WithMessage("*claude*disk*no row*",
                    "a pair with no row would be decided by nothing");

        [Fact]
        public void WithAPairTwice_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*twice*");

        [Fact]
        public void WithAnUnknownStanding_IsRefused_NamingIt() =>
            Loading(With(Row("claude", "none", standing: "sort of"))).Should().Throw<InvalidOperationException>()
                .WithMessage("*sort of*");

        [Fact]
        public void WithARowOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("gemini", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*gemini*");

        [Fact]
        public void WithACapabilityOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "shell")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*shell*none, disk, web*");

        [Fact]
        public void WithNeitherACellNorANote_IsRefused_NamingTheRow() =>
            Loading(With(Row("claude", "none", cells: [], note: ""))).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*cell*");

        [Fact]
        public void ThatIsWellFormed_Loads_EveryPairOnce()
        {
            var table = RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], Whole()));

            table.Rows.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Capabilities.All.Count).And.OnlyContain(row => row.Standing == CapabilityStanding.Confined);
            table.Of("codex", Capability.Web).Should().NotBeNull();
            table.Of("gemini", Capability.Web).Should().BeNull("a runtime outside the matrix has no row to answer with");
        }
    }
}

```
