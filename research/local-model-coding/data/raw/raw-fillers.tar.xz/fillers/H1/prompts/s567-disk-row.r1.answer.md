```csharp
        using var stood = StandIn();
        GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
        var before = _person.Hash();
        string granted = Path.Combine(Repo, "src");
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);

        string plain = _dir.At("plain");
        if (ending == Ending.RefusedBeforeTheLaunch)
        {
            Directory.CreateDirectory(plain);
            await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
        }

        string[] roots = ending == Ending.RefusedBeforeTheLaunch ? new[] { plain } : new[] { granted };

        Func<ProcessRequest, CancellationToken, Task> during = ending == Ending.CancelledMidTurn
            ? async (_, ct) => { await caller.CancelAsync(); ct.ThrowIfCancellationRequested(); }
            : (_, _) => Task.CompletedTask;
        var played = new PlayedKimi(_launcher)
        {
            Turn = (_, request) => PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, Advice),
            During = during,
        };

        JsonElement reply = default;
        if (ending == Ending.CancelledMidTurn)
        {
            var asking = async () => await AskAsync(ServiceOn(played, roots), caller.Token);
            await asking.Should().ThrowAsync<OperationCanceledException>();
        }
        else
        {
            reply = await AskAsync(ServiceOn(played, roots), caller.Token);
        }

        if (ending == Ending.RefusedBeforeTheLaunch)
        {
            // First run: read the real refusal word and keep only that one in the check below.
            string status = TheRow(reply).GetProperty("status").GetString() ?? string.Empty;
            (status == RowOutcomes.Refused || status == RowOutcomes.Failed).Should().BeTrue(status);
            played.Shims.Should().BeEmpty();
        }
        else
        {
            var launch = played.Shims.Should().ContainSingle("the shim is launched once").Subject;
            var args = launch.Request.Arguments;
            var rowFolder = Path.GetDirectoryName(args[args.ToList().IndexOf("--home") + 1])!;

            if (ending == Ending.Answered)
            {
                TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered);
                launch.Request.StdIn.Should().Contain(Path.Combine(rowFolder, "tree"));
                launch.Request.StdIn.Should().NotContain(granted);
            }

            Directory.Exists(rowFolder).Should().BeFalse("the row folder goes with its one-shot home");
        }

        var oneShot = Path.Combine(Homes, VibeHomes.OneShotFolder);
        if (Directory.Exists(oneShot))
        {
            Directory.EnumerateFileSystemEntries(oneShot).Should().BeEmpty("the row's folder under coai-vh is deleted on every way out");
        }

        _unlinkedByTheDeleter.Should().BeEmpty();
        _person.Hash().Should().Equal(before);
```