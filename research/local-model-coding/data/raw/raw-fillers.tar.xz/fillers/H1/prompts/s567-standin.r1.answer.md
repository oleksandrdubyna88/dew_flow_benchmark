```csharp
        return new Scopes(
            WindowsStandIn.Begin(),
            KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks")),
            KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, []))));
```

Note: A nested class cannot be declared inside a method. Add this class at class level, outside the region, so the body compiles:

```csharp
private sealed class Scopes(params IDisposable[] scopes) : IDisposable
{
    public void Dispose()
    {
        foreach (var scope in scopes.Reverse())
        {
            scope.Dispose();
        }
    }
}
```