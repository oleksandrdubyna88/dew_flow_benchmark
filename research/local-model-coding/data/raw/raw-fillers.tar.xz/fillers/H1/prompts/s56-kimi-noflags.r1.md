You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s56-kimi-noflags — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
`Build` calls this only for a planned launch (a conversation's launch never gets here). When `plan.Leading`, `plan.Flags` or `plan.AddDirs` is non-empty:
throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(plan)).
A flag-free plan: return without effect. (`Confinement.Planned` is in CoaiMcp.Core.QuestionConsult, already imported.)

## The exact existing types and members you may use (context pack)
# Region s56-kimi-noflags - context pack

Context pack — GROUP A: the planner, the matrix, the Kimi question launch, the TS admission. All names below are copied from the repository at
commit 2aacf633 (branch exp/kimi-e56-skeleton-haiku-1). Namespace of each type is given. C# is .NET 10, latest C#, FluentAssertions, xUnit v3
(`Xunit`; `TestContext.Current.CancellationToken`). Never `dotnet test`: the tests are run as the MTP executable.

## Production types (namespace `CoaiMcp.Core.QuestionConsult`, file `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`)

```csharp
public enum CwdKind { Scratch, Root, Snapshot }

public abstract record Confinement
{
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,   // argv BEFORE the CLI's subcommand
        IReadOnlyList<string> Flags,     // the sandbox flags, complete
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];   // the roots read through COPIES (Snapshot cwd)
    }

    public sealed record Refused(string Reason) : Confinement;
}

// file src_mcp/core/QuestionConsult/Capability.cs
public enum Capability { None, Disk, Web }   // spelled none/disk/web
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    public static CapabilityGrant None { get; }                       // question alone
    public static CapabilityGrant Web { get; }
    public static CapabilityGrant Disk(params string[] roots);        // read-only under these roots
}

// file src_mcp/core/QuestionConsult/CapabilityMatrix.cs
public enum AdmissionFlag { None, Unconfined, DefaultDeny }           // (third member's exact name: DefaultDeny — spelled "default-deny")
// CapabilityMatrix.Admit(string runtime, string capability) and Admit(string runtime, Capability capability) return Admission:
//   Admission.Admitted { Standing, Flag } or Admission.Refused { Reason }

// the planner (same file as above)
public static class ConfinementPlanner
{
    public static Confinement Plan(string runtime, CapabilityGrant grant);   // asks CapabilityMatrix first; a refusal comes back as Confinement.Refused
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag), "codex" => Codex(grant, flag), "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),      // <- written; its body is the FILL region s56-planner-kimi
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
}
```

The model to follow for `Kimi(...)` (the existing Vibe arm, same file):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

`Kimi` has the SAME shape with `[]` instead of `VibeReadOnly` (no flags at all) and the runtime name `"kimi"`. Its skeleton is a block-bodied method
`private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag) { <FILL region> }` — so the filled body is `return grant.Capability switch { ... };`
(keep the region's comment lines; replace only the `throw`).

## The Kimi consultant (namespace `CoaiMcp.Runners.Kimi`, file `src_mcp/runners/Kimi/KimiConsultant.cs`)

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)          // for a planned launch (`launch.Confinement is LaunchConfinement.Planned planned`) calls MustCarryNoFlag(planned.Plan)
    private static void MustCarryNoFlag(Confinement.Planned plan)      // FILL region s56-kimi-noflags; throws ArgumentException(message, nameof(plan)) for a plan with Leading/Flags/AddDirs
}
// the launch (namespace CoaiMcp.Runners.Consultation)
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
{
    public LaunchConfinement Confinement { get; init; } = LaunchConfinement.AsShipped;
    public string ScratchDir { get; init; } = string.Empty;   // EMPTY folder for a planned launch standing in Scratch
    public string Workdir { get; init; } = string.Empty;      // the snapshot / the copy of the roots
}
public abstract record LaunchConfinement
{
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;       // pattern: `launch.Confinement is LaunchConfinement.Planned planned` then `planned.Plan`
    public static LaunchConfinement AsShipped { get; }
}
// namespace CoaiMcp.Runners.Reviewers
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, string SharedResource = "", ...);
// namespace CoaiMcp.Runners.Processes
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)
{ IReadOnlyDictionary<string,string?> Environment; string StdIn; bool InheritsEnvironment; ProcessEnvironment Passthrough; ... }
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut, bool Cancelled = false, bool Truncated = false, ...);
// ConsultantRoles.Question / ConsultantRoles.Consult are string constants (namespace CoaiMcp.Runners.Consultation) — `built.Role`.
```

## The test file `src_mcp/tests/ConfinementPlannerTests.cs` (namespace `CoaiMcp.Tests`; usings: CoaiMcp.Core.QuestionConsult, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Reviewers, FluentAssertions, Xunit)

Existing members you may call (all `private static`, in `public sealed class ConfinementPlannerTests`):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private const string Repo = "D:/rsd/some-checkout";
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{
    Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
    ScratchDir = Scratch,
    Workdir = RowTree,
};
private static Runners.Kimi.KimiConsultant KimiForQuestions();   // a consultant over a fake person's paths: builds, reads nothing of this machine
```

The Vibe test the Kimi launch test is modelled on (existing, in the same file):

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file").And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
    request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "...");
}
```

Kimi's request is the shim request: argv `--ask-acp --profile kimi --model kimi-code/k3-256k --cwd <cwd> --home <RowFolder>\kh-<10 hex>` (no `--session`; one shot),
the prompt on `StdIn`. The value after a flag: `args[args.ToList().IndexOf("--home") + 1]` (`AcpWords.HomeFlag` is `"--home"`, namespace `CoaiMcp.Runners.Acp`).

Refusal check of the built request (namespace `CoaiMcp.Runners.Kimi`; `KimiEnvironment` is a static class):

```csharp
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty string = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin);           // the places the SHIM knows
// How the existing consultant tests use it (KimiConsultantTests, with a `KimiFixture _person`):
//   KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("the one launch control admits exactly what the adapter builds");
// where `home` is the value after "--home". `KimiFixture` (namespace CoaiMcp.Tests, IDisposable, `new KimiFixture()`) has `PlacesAt(string ownedRoot)`.
// For s565 build the consultant with it, so the check is real:
//   using var person = new KimiFixture();
//   var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
//       new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
// (`KimiRuntime(string id, HostKind host, KimiSeams seams)`, `KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`.)
```

## The matrix tests (`src_mcp/tests/CapabilityMatrixTests.cs`, namespace `CoaiMcp.Tests`)

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability)   // -> RuntimeCapabilityRow? (null for a runtime the table does not know)
// existing test of the same shape (Vibe):
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

The kimi rows' data (already in `shared/runtime-capabilities.json`): none → `unconfined`, cells `M-K6, M-K3, M-K4`; disk → `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`;
web → `unmeasured`, no cells; version `2.1.1`; every `resultRef` names `research/RESULTS_kimi_confinement.md`.

## TypeScript (file `src_vs_code/src/test/capabilityAdmission.test.ts`; node:test + `node:assert/strict`)

```ts
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
export interface Admission { readonly admitted: boolean; readonly standing: CapabilityStanding | ''; readonly flag: AdmissionFlag; readonly reason: string; readonly caveat: string; }
// admit(runtime: string, capability: string): Admission
// A flagged caveat: unconfined -> 'unconfined: can read this machine — a shell is always there, and no flag removes it'
// An unmeasured refusal reads: "'<runtime>' has not been measured for '<cap>' (<note>) — a measured cell in <record> is what admits it; until then give this row a prompt of another capability"
// where <record> is the `research/RESULTS_*.md` file the row's resultRef cites.
// An existing test in the same file of the same shape:
test('an unmeasured pair names the record its row cites: ...', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
});
```


## The whole file (the region is marked with <<<)
```csharp
using CoaiMcp.Core.Consultation;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Runners.Acp;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Reviewers;

namespace CoaiMcp.Runners.Kimi;

/// <summary>
/// Kimi Code as a consultant — the stuck consultant's conversation (E5.4 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>; S5 of
/// <c>todo/PLAN_vibe_and_kimi_runtimes.md</c>). Every launch is the reviewer's own shim request, composed from <see cref="KimiRuntime"/> and never
/// built a second time (decision 1): the executor then asks the one launch control (<see cref="KimiLaunch"/>) through that adapter — the host, the
/// tools, the model, the built environment, the sign-in, the home's shape, the gate on the sign-in, the version.
/// </summary>
/// <remarks>
/// <para><b>Never the checkout, and never a home of its own making</b> (decision 2): the cwd is the conversation's ONE stable snapshot
/// (<see cref="ConsultantLaunch.Workdir"/>, D6 — a loaded session resolves paths against the folder it was created in, M-K5), and the home is
/// <c>&lt;folder&gt;\kh-&lt;10 hex&gt;</c> under the coai-owned folder the caller hands in <see cref="ReviewerSettings.OwnedScratch"/> — never that
/// folder itself, whose turn the caller holds (E5.3 decision a), and never TEMP or the answers folder (D19). Both are required.</para>
/// <para><b>Memory is the vendor's</b> (decision 3): turn 1 starts a session, every later turn continues it with the shim's
/// <c>--session &lt;id&gt;</c> (E5.2), the id read off the report's <c>sessionId</c>. <b>Usage is cumulative</b> (decision 4, M-K5b): the service
/// bills each turn its share of the session's running total, guarded against a counter that restarted (decision 12).</para>
/// <para><b>A dropped session is the report's END word</b> (decisions 5 and 11): <c>session_lost</c>, never the agent's text — and the service
/// then REFUSES the turn with its cure; nothing here starts a fresh session in its place.</para>
/// </remarks>
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public string Vendor => vendor;

    public ConsultantMemory Memory => new ConsultantMemory.VendorRemembers();

    /// <summary>M-K5b (RESULTS §23), and three turns of one session in M-K16 (d): <c>/usage</c> is the session's running total.</summary>
    public bool UsageIsCumulative => true;

    /// <summary>D6: Kimi loads a project <c>.kimi-code</c>, <c>AGENTS.md</c>, skills and <c>.mcp.json</c> from its working folder.</summary>
    public bool NeedsASanitisedSnapshot => true;

    /// <summary>One coai-owned home per conversation, under <see cref="ConsultantHomes.Kimi"/> (J3), swept with it (D20).</summary>
    public string HomesFolder => ConsultantHomes.Kimi;

    /// <summary>Only what was observed working (decision 7): <c>Read</c> inside the copy (M-K6), <c>Grep</c> and <c>Glob</c> (RESULTS §17) — never claimed bounded.</summary>
    public string Toolbox =>
        "You read files with Read, by a path inside your working folder — a copy coai made of the checkout without its .git, .kimi-code/, "
        + ".agents/ skills and sub-agents, .mcp.json and AGENTS.md; Grep and Glob search files too. Every write and every shell command is refused.";

    public ReviewerInvocation Build(ConsultantLaunch launch)
    {
        ConsultantLaunches.MustBeLaunchable(launch);
        if (launch.Confinement is LaunchConfinement.Planned planned)
        {
            MustCarryNoFlag(planned.Plan);
        }

        var settings = launch.Settings with { OwnedScratch = OwnedFolder(launch), Model = ModelOf(launch.Settings) };
        var built = inner.Build(ConsultantLaunches.RoleOf(launch), launch.Prompt, Cwd(launch), string.Empty, launch.OutputDir, settings);
        var request = built.Request with { Arguments = [.. built.Request.Arguments, .. SessionOf(launch)] };
        ConsultantLaunches.MustCarryNoLineBreak(request.Arguments);

        return built with { Request = launch.Confinement is LaunchConfinement.Planned ? ConsultantLaunches.ForQuestion(request) : request };
    }

    /// <summary>E5.6 decision 3: a planned launch whose plan carries ANY flag (leading, trailing or an added directory) is not one coai made for kimi — refused.</summary>
    private static void MustCarryNoFlag(Confinement.Planned plan)
    {
        // QWEN-FILL-BEGIN s56-kimi-noflags prod   <<< REGION s56-kimi-noflags STARTS AFTER THIS LINE
        // `Build` calls this only for a planned launch (a conversation's launch never gets here). When `plan.Leading`, `plan.Flags` or `plan.AddDirs` is non-empty:
        // throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(plan)).
        // A flag-free plan: return without effect. (`Confinement.Planned` is in CoaiMcp.Core.QuestionConsult, already imported.)
        throw new NotImplementedException("s56-kimi-noflags");
        // QWEN-FILL-END s56-kimi-noflags   <<< REGION s56-kimi-noflags ENDS BEFORE THIS LINE
    }

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
            ? launch.Workdir
            : throw new ArgumentException(
                "a Kimi consultant stands in the conversation's sanitised snapshot (Workdir), and none was made — the checkout is never its working folder (D6)",
                nameof(launch));

    private static string OwnedFolder(ConsultantLaunch launch) =>
        launch.Settings.OwnedScratch.Length > 0
            ? launch.Settings.OwnedScratch
            : throw new ArgumentException(
                "a Kimi consultant keeps its home in a coai-owned folder of the conversation or the row (OwnedScratch), and none was given — never TEMP or the answers folder (D19)",
                nameof(launch));

    /// <summary>The report's <c>sessionId</c> when it is a well-formed handle — the shim names it on every exit that prints a report — or empty.</summary>
    public string ReadHandle(ProcessResult result) =>
        KimiReport.Parse(result.StdOut).SessionId is var id && ConsultantHandle.IsWellFormed(id) ? id : string.Empty;

    /// <summary>The shim's END word says the agent no longer holds the session <c>--session</c> named (E5.2) — read off the report, never its text.</summary>
    public bool DroppedTheConversation(ProcessResult result) => KimiReport.Parse(result.StdOut).End == AcpWords.SessionLostWord;
}

```
