```csharp
        var played = new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => AnswersFromTheCopy(request) };
        RecordingTheDeleter();
        var before = _person.Hash();

        var (code, said) = await CheckAsync(Settings(_homes), played, TestContext.Current.CancellationToken);

        code.Should().Be(0);
        said.GetProperty("state").GetString().Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");

        var request = played.Shims.Should().ContainSingle().Subject.Request;
        request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");

        var home = HomeOf(request);
        home.Should().StartWith(Path.Combine(_homes, CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar);
        Path.GetFileName(home).Should().StartWith("kh-").And.HaveLength(13);

        request.Arguments.Should().NotContain("--session");
        ThePersonsFolderIsWhole(before);
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
```