# Region s567-service - context pack

Context pack — GROUP C: the Kimi question row test (`src_mcp/tests/AKimiQuestionRowTests.cs`, class `AKimiQuestionRowTests : IAsyncLifetime`, namespace `CoaiMcp.Tests`).
Names are copied from the repository at commit 2aacf633. C# is .NET 10, FluentAssertions, xUnit v3 (`Xunit`). A body that needs a name not in this pack is a mistake:
write it down in your notes, do not invent it.

Usings in the file: System.Text.Json, CoaiMcp.Core.QuestionConsult, CoaiMcp.Core.Rounds, CoaiMcp.Runners.Files, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Platform,
CoaiMcp.Runners.Processes, CoaiMcp.Runners.Vibe, CoaiMcp.Server, FluentAssertions, Serilog.Core, Xunit.

## What the file already has

```csharp
private const string Advice = "Retry with a jittered backoff, three attempts.";
private readonly ProcessLauncher _launcher = new();                  // the real launcher (git runs for real)
private readonly TempDir _dir = TempDir.For("testsToDelete-qkimi-"); // `_dir.At("repo")` joins a sub-path; implicit string conversion
private readonly KimiFixture _person = new();
private readonly List<string> _unlinkedByTheDeleter = [];
private string Repo => _dir.At("repo");
private string Homes => _dir.At("homes");                             // created in InitializeAsync
public enum Ending { Answered, RefusedBeforeTheLaunch, CancelledMidTurn }
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files);   // FILL s567-repo-helper (InitializeAsync calls it for Repo)
private PanelService ServiceOn(PlayedKimi played, params string[] roots);                    // FILL s567-service
private IDisposable StandIn();                                                                // FILL s567-standin
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null);   // written: service.AskConsultantsAsync(Repo, question, context, ct: ...) parsed
private static JsonElement TheRow(JsonElement reply);                                           // written: the one answer of `reply.answers`
```

## The Vibe twin, copied whole (the model for the three helpers)

```csharp
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}

private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    vibe,                      // the launcher
    Logger.None,               // Serilog.Core.Logger.None
    Noticing.None);
// QuestionRow (namespace CoaiMcp.Core.QuestionConsult):
//   record QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "");
// the row id of a Kimi row: Id "kimi-disk", Vendor "my-kimi", Runtime "kimi", Model "" (the default model), Prompt "question-disk".
// PanelService ctor: (PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)
// PlayedKimi is an IProcessLauncher (below) — pass it as the launcher.
```

## The stand-ins a Kimi flow needs (as `AKimiConsultationScenarioTests.StandIn` composes them)

```csharp
private sealed class Scopes(params IDisposable[] scopes) : IDisposable
{
    public void Dispose()
    {
        foreach (var scope in scopes.Reverse())
        {
            scope.Dispose();
        }
    }
}

private static Scopes StandIn(KimiFixture person) => new(
    WindowsStandIn.Begin(),                                                   // internal static class in CoaiMcp.Tests
    KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),        // public static IDisposable, CoaiMcp.Runners.Kimi
    KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),   // internal static IDisposable; HostKind in CoaiMcp.Runners.Platform
    CallingAs("CLAUDE_CODE_SESSION_ID"));                                     // NOT needed here: a question row has no caller kind
// public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
```

## The played shim (`src_mcp/tests/PlayedKimi.cs`, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`)

```csharp
public const string Shim = "played-coai-mcp";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }            // one entry per shim launch, enqueued when it ENDS
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }                 // what the n-th shim launch prints
public Func<ProcessRequest, CancellationToken, Task> During { get; init; }          // runs while the shim is alive; may cancel and throw
public static string SessionOf(ProcessRequest request);
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
// `kimi --version` answers "kimi 2.1.1"; every non-shim process (git) runs for real through `inner`.
// public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { string StdIn; IReadOnlyDictionary<string,string?> Environment; ... }
```

## The Vibe row tests this one mirrors (same file `AVibeQuestionRowReadsACopyOfItsRootsTests`)

```csharp
// a plain folder outside any git work tree is refused at its copy, before any launch:
var plain = _dir.At("plain"); Directory.CreateDirectory(plain);
await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
// ... AskAsync(ServiceOn(vibe, Homes, plain)) → TheRow(reply).GetProperty("status") is RowOutcomes.Refused / Failed (read the real word off the first run)

// cancelled in flight:
using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var vibe = new PlayedVibe(_launcher, Advice)
{
    During = async ct =>
    {
        await caller.CancelAsync();
        ct.ThrowIfCancellationRequested();
    },
};
var asking = async () => await AskAsync(Service(vibe, Path.Combine(Repo, "src")), caller.Token);
await asking.Should().ThrowAsync<OperationCanceledException>();

// the row's home goes with its one-shot folder:
Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the row's folder under coai-vh is deleted on every way out");
// VibeHomes.OneShotFolder == "coai-vh" (namespace CoaiMcp.Runners.Vibe); the folder may not exist after the row: treat "absent" as empty.
// RowOutcomes (namespace CoaiMcp.Core.QuestionConsult) string constants: Answered = "answered", TimedOut, Failed = "failed", Refused = "refused", ...
// GitScratch.AfterUnlink is `internal static Action<string>?` (namespace CoaiMcp.Runners.Files): the deleter's unlink recorder; set `= _unlinkedByTheDeleter.Add`.
// `_person.Hash()` → IReadOnlyList<string>: the person's folder as names+bytes+attributes; `Should().Equal(before)` means whole.
```

A Kimi row's shim request (what `played.Shims` holds): argv `--ask-acp --profile kimi --model … --cwd <the row's tree copy> --home <Homes>\coai-vh\<8>\kh-<10 hex>`; no `--session`;
the prompt is `request.StdIn` and names the COPIES' paths (the `tree` folder inside the row's own folder — the parent of the `--home` value's parent... read it off
the `--cwd` value), never the granted root. `HomeOf` = the value after `"--home"`: `args[args.ToList().IndexOf("--home") + 1]`.
