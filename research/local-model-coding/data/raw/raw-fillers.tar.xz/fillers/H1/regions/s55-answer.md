# Region s55-answer - context pack

Context pack — GROUP B: the Kimi consultant check tests (`src_mcp/tests/AKimiConsultantCheckTests.cs`, class `AKimiConsultantCheckTests : IDisposable`,
namespace `CoaiMcp.Tests`). Names are copied from the repository at commit 2aacf633. C# is .NET 10, FluentAssertions, xUnit v3 (`Xunit`).
Usings already in the file: System.Text.Json, CoaiMcp.Runners.Consultation, CoaiMcp.Runners.Files, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Platform,
CoaiMcp.Runners.Processes, CoaiMcp.Server, FluentAssertions, Xunit. Add `using CoaiMcp.Runners.Vibe;` for `VibeHomes.OneShotFolder` (= "coai-vh") if the body needs it.
A body that needs a name not in this pack is a mistake: ask for it in your notes, do not invent it.

## What the file already has (private members of the class; do not redefine)

```csharp
private readonly KimiFixture _person = new();                                   // a fake person's ~/.kimi-code inside its own testsToDelete-kimi- folder
private readonly TempDir _homes = TempDir.For("testsToDelete-kimi-check-homes-"); // implicit conversion to string (its Path); `Path.Combine(_homes, "x")` works
private readonly string _data;    // PanelSettings.DataDir
private readonly string _temp;    // the check's temp root: the check makes `coai-check-*` folders here
private readonly List<string> _warned = [];
private readonly List<string> _unlinkedByTheDeleter = [];
private PanelSettings Settings(string homesRoot);          // Kimi row `my-kimi` (runtime kimi) for the `claude` caller; empty homesRoot = root-less check
private void RecordingTheDeleter();                         // GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before);   // asserts _person.Hash() equals `before`
private void TheDeleterNeverMetTheJunction();               // asserts _unlinkedByTheDeleter is empty
private static string HomeOf(ProcessRequest request);       // the value after `--home` on the shim request
private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played, CancellationToken ct);   // FILL s55-check-helper
private static ProcessResult AnswersFromTheCopy(ProcessRequest request);                                                       // FILL s55-answer
```

## Types the helper needs

```csharp
// namespace CoaiMcp.Server (src_mcp/src/Server/Consultation/ConsultantCheckMode.cs) — internal static, reachable from the tests:
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
// `Noticing.None` is the no-op notices value (namespace CoaiMcp.Server). Existing helper in ConsultantCheckTests, to copy:
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
// call it with args "--caller", "claude".

// the stand-ins (the seams are async-local: a SYNCHRONOUS call in the test's own flow reaches every awaited call below it)
internal static class WindowsStandIn { public static IDisposable Begin(); }                       // namespace CoaiMcp.Tests
public static IDisposable KimiCredentialsLock.RootFor(string folder);                             // namespace CoaiMcp.Runners.Kimi
internal static IDisposable KimiSeams.Using(HostKind host, KimiSeams seams);                      // namespace CoaiMcp.Runners.Kimi; HostKind is CoaiMcp.Runners.Platform
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
// the way AKimiConsultationScenarioTests composes them (its private nested `Scopes` disposes in reverse):
//   WindowsStandIn.Begin(),
//   KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
//   KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, [])))
// `_person.PlacesAt(string ownedRoot)` is `KimiPlaces PlacesAt(string)`; `_person.Folder` is the fixture's folder; `_person.Hash()` is `IReadOnlyList<string>`.
```

## The played shim (`src_mcp/tests/PlayedKimi.cs`, namespace `CoaiMcp.Tests`, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`)

```csharp
public const string Shim = "played-coai-mcp";            // the executable the seams name — recognised, never started
public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }            // one entry per shim launch, added when it ENDS
public int Peak { get; }
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }                 // what the n-th shim launch (0-based) prints; default: an answered turn
public Func<ProcessRequest, CancellationToken, Task> During { get; init; }          // runs while the shim is "alive" — a seam to block or to cancel
public static string SessionOf(ProcessRequest request);                             // the --session value, else Minted
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);   // exit 0
public static ProcessResult Uncaptured(string session, string answer = Advice);
public static ProcessResult Lost(string session);                                    // end session_lost, exit 70
public const string Advice = "...";
// `new PlayedKimi(new ProcessLauncher())` — every non-shim process (git) runs for real; `kimi --version` answers "kimi 2.1.1".
// A launch whose `During` throws OperationCanceledException (ct.ThrowIfCancellationRequested()) ends the launch cancelled; its `Launch` is still enqueued in a `finally`.
```

## How the Vibe check test reads (the model for S5.5.1; `ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself`)

```csharp
var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
{
    AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
};
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());          // Text(e, name) = e.GetProperty(name).GetString() ?? string.Empty
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
```

The check's result JSON has `state` (one of `answered`, `failed`, `unavailable`, `already-checking`, ... — `ConsultCheckStates` constants are public strings in namespace
`CoaiMcp.Server`: `Answered = "answered"`, `Failed = "failed"`, `Unavailable = "unavailable"`), `markerRead` (bool) and `canary` (a `CanaryReadings` word). A check
cancelled by its token may end with an exception instead of a record: handle both as the fill comment of s553 says, and write down which one you saw.

The shim request of a Kimi check: argv `--ask-acp --profile kimi --model … --cwd <copy of the scratch>\tree-like path under <scratch>\own\tree --home <root>\coai-vh\<8>\kh-<10 hex>`;
`request.WorkingDirectory` is the same cwd; the prompt rides `request.StdIn`. A root-less check keeps the home at `<scratch>\own\kh-<10 hex>` where `<scratch>` is a `coai-check-*` folder under `_temp`.

## Existing test with the same junction-first assertions (`AOneShotKimiHomeIsDisposedJunctionFirstTests`)

```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) => _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
private void TheDeleterNeverMetTheJunction() => _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
// and in the test:  using var standIn = WindowsStandIn.Begin();  var before = _person.Hash();  RecordingTheDeleter();  ...  home.Dispose();  Directory.Exists(home.Folder).Should().BeFalse(...)
```
