```csharp
        return new PlayedKimi(new ProcessLauncher())
        {
            Turn = (_, request) =>
            {
                var marker = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
                var answer = $"marker: {marker}{Environment.NewLine}canary: CANNOT";
                return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, answer);
            },
        };
```