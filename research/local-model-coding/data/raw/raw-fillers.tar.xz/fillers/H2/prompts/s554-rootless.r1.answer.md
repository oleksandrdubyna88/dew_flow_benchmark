```csharp
using var stood = AKimiConsultationScenarioTests.StandIn(_person);
var before = _person.Hash();
var played = Played();

var (_, said) = await CheckAsync(Settings(string.Empty), played, TestContext.Current.CancellationToken);

said.GetProperty("state").GetString().Should().Be("answered", said.ToString());

var shim = played.Shims.Should().ContainSingle().Subject.Request;
var args = shim.Arguments;
var home = args[args.ToList().IndexOf("--home") + 1];
Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
Path.GetFileName(Path.GetDirectoryName(home)).Should().Be(ConsultantCheck.OwnName);

Directory.EnumerateDirectories(Temp, "coai-check-*").Should().BeEmpty("the check's scratch goes whole");
_unlinkedByTheDeleter.Should().BeEmpty("KimiHome unlinks the junction first");
_person.Hash().Should().Equal(before, "the person's folder is whole");
```