```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var before = _person.Hash();
        var granted = Path.Combine(Repo, "src");
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);

        var kimi = new PlayedKimi(_launcher);
        string[] roots = [granted];
        if (ending == "refused before the launch")
        {
            var plain = Directory.CreateDirectory(_dir.At("plain")).FullName;
            await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
            roots = [plain];
        }
        else if (ending == "cancelled mid-turn")
        {
            kimi = new PlayedKimi(_launcher)
            {
                During = async (_, ct) =>
                {
                    await caller.CancelAsync();
                    ct.ThrowIfCancellationRequested();
                },
            };
        }

        var asking = () => AskAsync(Service(kimi, roots), caller.Token);
        if (ending == "cancelled mid-turn")
        {
            await asking.Should().ThrowAsync<OperationCanceledException>();
        }
        else
        {
            var reply = await asking();
            var row = reply.GetProperty("answers").EnumerateArray().Single();
            var status = row.GetProperty("status").GetString();
            if (ending == "answered")
            {
                status.Should().Be(RowOutcomes.Answered, reply.ToString());
                var request = kimi.Shims.Should().ContainSingle().Subject.Request;
                var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];
                request.StdIn.Should().Contain(cwd, "the prompt names the copy Kimi can read");
                request.StdIn.Should().NotContain(granted, "never the original, which it cannot read");
            }
            else
            {
                status.Should().Be(RowOutcomes.Refused, reply.ToString());
                row.GetProperty("reason").GetString().Should().Contain("not inside a Git work tree");
                kimi.Shims.Should().BeEmpty();
                kimi.Versions.Should().BeEmpty();
            }
        }

        foreach (var launch in kimi.Shims)
        {
            var args = launch.Request.Arguments.ToList();
            var home = args[args.IndexOf("--home") + 1];
            Directory.Exists(Path.GetDirectoryName(home)).Should().BeFalse("the row's one-shot folder is gone after the row ends");
        }

        var oneShot = Path.Combine(Homes, VibeHomes.OneShotFolder);
        if (Directory.Exists(oneShot))
        {
            Directory.EnumerateFileSystemEntries(oneShot).Should().BeEmpty("the row's folder under coai-vh is deleted on every way out");
        }

        _unlinkedByTheDeleter.Should().BeEmpty();
        _person.Hash().Should().Equal(before);
```