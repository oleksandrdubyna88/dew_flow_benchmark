```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var before = _person.Hash();
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        var played = new PlayedKimi(new ProcessLauncher())
        {
            During = async (_, ct) =>
            {
                await caller.CancelAsync();
                ct.ThrowIfCancellationRequested();
            },
        };

        var said = default(JsonElement);
        try
        {
            (_, said) = await CheckAsync(Settings(Homes), played, caller.Token);
        }
        catch (OperationCanceledException)
        {
            // The check may throw instead of answering a record. The asserts below still apply.
        }

        if (said.ValueKind == JsonValueKind.Object && said.TryGetProperty("state", out var state))
        {
            state.GetString().Should().NotBe("answered", said.ToString());
            if (said.TryGetProperty("failureKind", out var kind))
            {
                kind.GetString().Should().Be("cancelled", said.ToString());
            }
        }

        var oneShot = Path.Combine(Homes, VibeHomes.OneShotFolder);
        if (Directory.Exists(oneShot))
        {
            Directory.EnumerateFileSystemEntries(oneShot).Should().BeEmpty();
        }

        _unlinkedByTheDeleter.Should().BeEmpty();
        _person.Hash().Should().Equal(before);
```