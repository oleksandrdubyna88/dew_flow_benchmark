```csharp
using var person = new KimiFixture();
var consultant = new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("my-kimi", Runners.Platform.HostKind.Windows,
    new Runners.Kimi.KimiSeams(person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");

var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));

none.Request.WorkingDirectory.Should().Be(Scratch, "the row's empty folder");
disk.Request.WorkingDirectory.Should().Be(RowTree);

foreach (var invocation in new[] { none, disk })
{
    var request = invocation.Request;
    var args = request.Arguments.ToList();

    request.Arguments.Should().ContainInConsecutiveOrder("--ask-acp", "--profile", "kimi");
    request.Arguments.Should().NotContain("--session").And.NotContain(RootA).And.NotContain(RootB);

    args.Should().Contain("--home");
    var home = args[args.IndexOf("--home") + 1];
    home.Should().StartWith(RowFolder + Path.DirectorySeparatorChar);

    request.InheritsEnvironment.Should().BeFalse();
    Runners.Kimi.KimiEnvironment.Refusal(request, person.PlacesAt(home)).Should().BeEmpty();
    invocation.Role.Should().Be(ConsultantRoles.Question);
}
```