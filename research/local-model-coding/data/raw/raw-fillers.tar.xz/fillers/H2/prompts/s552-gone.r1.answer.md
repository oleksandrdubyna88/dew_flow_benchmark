```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var before = _person.Hash();
        var played = ending == "passed"
            ? Played()
            : new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => PlayedKimi.Lost(PlayedKimi.SessionOf(request)) };

        var (_, said) = await CheckAsync(Settings(Homes), played, TestContext.Current.CancellationToken);

        var oneShot = Path.Combine(Homes, VibeHomes.OneShotFolder);
        (Directory.Exists(oneShot) ? Directory.EnumerateFileSystemEntries(oneShot) : Enumerable.Empty<string>())
            .Should().BeEmpty("coai-vh\\<8> is gone; the folder coai-vh itself may exist");
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
        _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");

        if (ending == "passed")
        {
            said.GetProperty("state").GetString().Should().Be("answered");
        }
```