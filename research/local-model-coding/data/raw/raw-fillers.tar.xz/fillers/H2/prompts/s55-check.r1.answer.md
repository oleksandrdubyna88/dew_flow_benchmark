```csharp
var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", "--caller", "claude"], launcher, Temp, _warned.Add, Noticing.None, ct);
return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default);
```