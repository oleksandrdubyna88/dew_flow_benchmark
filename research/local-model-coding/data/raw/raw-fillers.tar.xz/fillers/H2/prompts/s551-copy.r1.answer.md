```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var played = Played();

        var (code, said) = await CheckAsync(Settings(Homes), played, TestContext.Current.CancellationToken);

        code.Should().Be(0);
        said.GetProperty("state").GetString().Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");

        var shim = played.Shims.Should().ContainSingle().Subject.Request;
        var args = shim.Arguments.ToList();

        var cwd = args[args.IndexOf("--cwd") + 1];
        cwd.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
        Path.GetFullPath(cwd).Should().StartWith(Path.GetFullPath(Temp), StringComparison.OrdinalIgnoreCase);

        var home = args[args.IndexOf("--home") + 1];
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        Path.GetDirectoryName(Path.GetDirectoryName(home)).Should().Be(Path.Combine(Homes, VibeHomes.OneShotFolder));

        Directory.EnumerateDirectories(Temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
```