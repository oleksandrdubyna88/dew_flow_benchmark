```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}");
            CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Standing.Should().Be(CapabilityStanding.Unconfined, $"kimi × {capability}");
        }
```