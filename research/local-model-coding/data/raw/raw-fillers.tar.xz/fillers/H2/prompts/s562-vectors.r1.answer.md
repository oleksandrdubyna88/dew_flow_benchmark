```csharp
        foreach (var capability in new[] { "none", "disk", "web" })
        {
            Vectors.Should().ContainSingle(v => v.Runtime == "kimi" && v.Capability == capability, $"kimi × {capability} must have a vector");
            var vector = Vectors.Single(v => v.Runtime == "kimi" && v.Capability == capability);

            if (capability == "web")
            {
                vector.Admitted.Should().BeFalse($"kimi × {capability}: {vector.Why}");
                vector.Standing.Should().Be("unmeasured", $"kimi × {capability}: {vector.Why}");
            }
            else
            {
                vector.Admitted.Should().BeTrue($"kimi × {capability}: {vector.Why}");
                vector.Standing.Should().Be("unconfined", $"kimi × {capability}: {vector.Why}");
                vector.Flag.Should().Be("unconfined", $"kimi × {capability}: {vector.Why}");
            }
        }
```