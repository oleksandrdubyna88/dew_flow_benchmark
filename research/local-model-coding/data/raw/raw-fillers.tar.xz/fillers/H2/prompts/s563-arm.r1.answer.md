```csharp
var none = Plan("kimi", CapabilityGrant.None);
none.Cwd.Should().Be(CwdKind.Scratch, "a none row stands in an empty folder");
none.Flags.Should().BeEmpty("kimi has no sandbox flag; the shim confines it (D15)");
none.Leading.Should().BeEmpty();
none.AddDirs.Should().BeEmpty();
none.SnapshotSources.Should().BeEmpty();
none.Flag.Should().Be(AdmissionFlag.Unconfined);

var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));
disk.Cwd.Should().Be(CwdKind.Snapshot, "a disk row stands in a snapshot of its roots (D6)");
disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
disk.Flags.Should().BeEmpty("kimi has no sandbox flag; the shim confines it (D15)");
disk.Leading.Should().BeEmpty();
disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and kimi is never given --add-dir");
disk.Flag.Should().Be(AdmissionFlag.Unconfined);

ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>()
    .Which.Reason.Should().Contain("not been measured")
    .And.Contain("RESULTS_kimi_confinement.md");
```