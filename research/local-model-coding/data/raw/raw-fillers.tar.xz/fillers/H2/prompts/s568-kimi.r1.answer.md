```typescript
  for (const capability of ['none', 'disk']) {
    const admission = admit('kimi', capability);

    assert.equal(admission.admitted, true, admission.reason);
    assert.equal(admission.standing, 'unconfined', 'kimi × ' + capability + ' is unconfined');
    assert.equal(admission.flag, 'unconfined', 'D13: an unconfined pair is flagged');
    assert.match(admission.caveat, /can read this machine/u);
  }

  const refused = admit('kimi', 'web');

  assert.equal(refused.admitted, false, 'kimi × web is not admitted until measured');
  assert.match(refused.reason, /not been measured/u);
  assert.match(refused.reason, /RESULTS_kimi_confinement\.md/u);
  assert.ok(!refused.reason.includes('RESULTS_question_consultant_capabilities.md'), refused.reason);
```