```csharp
var none = RuntimeCapabilities.Builtin.Of("kimi", Capability.None);
var disk = RuntimeCapabilities.Builtin.Of("kimi", Capability.Disk);
var web = RuntimeCapabilities.Builtin.Of("kimi", Capability.Web);

none.Should().NotBeNull("kimi × none must have a row; without it the table has no kimi row");
disk.Should().NotBeNull("kimi × disk must have a row");
web.Should().NotBeNull("kimi × web must have a row");

none!.Standing.Should().Be(CapabilityStanding.Unconfined, "kimi × none: Grep and Glob read the disk");
none.MeasuredWith.Cells.Should().Contain("M-K6", "kimi × none stands on the measured cell M-K6");

disk!.Standing.Should().Be(CapabilityStanding.Unconfined, "kimi × disk: Grep and Glob read the disk");
disk.MeasuredWith.Cells.Should().Contain("M-K6", "kimi × disk stands on the measured cell M-K6");
disk.MeasuredWith.Cells.Should().Contain("M-K9", "kimi × disk stands on the measured cell M-K9");

web!.Standing.Should().Be(CapabilityStanding.Unmeasured, "kimi × web has not been measured");
web.MeasuredWith.Cells.Should().BeEmpty("kimi × web has no measured cells");
web.MeasuredWith.Note.Should().NotBeEmpty("kimi × web says why it is unmeasured");

foreach (var row in new[] { none, disk, web })
{
    row!.MeasuredWith.Version.Should().Be("2.1.1", $"kimi × {row.Capability} was measured with CLI 2.1.1");
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md", $"kimi × {row.Capability} cites the Kimi record");
}
```