You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s561-rows — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Arrange/Act: `RuntimeCapabilities.Builtin.Of("kimi", Capability.None)`, `(…, Capability.Disk)`, `(…, Capability.Web)`.
Assert (FluentAssertions): each row `.Should().NotBeNull()`; none.Standing == CapabilityStanding.Unconfined and none.MeasuredWith.Cells
contains "M-K6"; disk.Standing == Unconfined and its Cells contain "M-K6" and "M-K9"; web.Standing == CapabilityStanding.Unmeasured
(its Cells are empty and its MeasuredWith.Note is not empty); all three rows' MeasuredWith.Version == "2.1.1" and
MeasuredWith.ResultRef contains "RESULTS_kimi_confinement.md".
Fails before the change: Of("kimi", None) is null (the table has no kimi row).

## The exact existing types and members you may use (context pack)
# s561-rows (test) — src_mcp/tests/CapabilityMatrixTests.cs, `KimiHasThreeRows_EachCitingItsCells`

Usings already in that file: `CoaiMcp.Core.QuestionConsult`, `FluentAssertions`, `Xunit`. Namespace `CoaiMcp.Tests`.

```csharp
// CoaiMcp.Core.QuestionConsult
public sealed record RuntimeCapabilities {
    public static RuntimeCapabilities Builtin { get; }
    public RuntimeCapabilityRow? Of(string runtime, Capability capability);
}
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public enum Capability { None, Disk, Web }
```

The data (already in `shared/runtime-capabilities.json`): kimi × none `unconfined`, cells `M-K6, M-K3, M-K4`; kimi × disk `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`; kimi × web `unmeasured`, no cells, a note; every row `version` `2.1.1`, `resultRef` begins `research/RESULTS_kimi_confinement.md`.

Similar test in the same file (the Vibe one), for the style:

```csharp
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

Assert as the comment in the file says. Use `because` messages that name the pair.


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The capability table is the file in <c>shared/</c>, and admission answers the shared vectors —
/// the C# half of <c>shared/capability-matrix-vectors.json</c>; <c>capabilityAdmission.test.ts</c> is
/// the other (PLAN_question_consultant.md, S1 acceptance 1).
/// </summary>
/// <remarks>
/// <para>Read from disk the way <see cref="BuiltinRoleCatalogTests"/> reads its seed: from the test
/// binary up to the repository root, so the comparison is against the checked-in file and not the
/// copy the build embedded a moment ago.</para>
/// <para>A3's "blocked in the UI AND refused by the server" is one rule only while both sides answer
/// one set of vectors; two self-consistent loaders cannot notice that they disagree.</para>
/// </remarks>
public sealed class CapabilityMatrixTests
{
    private sealed record Vector(string Runtime, string Capability, bool Admitted, string Standing, string Flag, string Why);

    private sealed record FileRow(string Runtime, string Capability, string Standing, string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

    private static readonly Vector[] Vectors = LoadVectors();

    private static readonly IReadOnlyList<FileRow> Seed = LoadSeed();

    private static string Shared(string file) => Path.GetFullPath(Path.Combine(
        AppContext.BaseDirectory, "..", "..", "..", "..", "..", "shared", file));

    private static Vector[] LoadVectors()
    {
        using var file = File.OpenRead(Shared("capability-matrix-vectors.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("vectors").EnumerateArray().Select(v => new Vector(
            v.GetProperty("runtime").GetString() ?? "",
            v.GetProperty("capability").GetString() ?? "",
            v.GetProperty("admitted").GetBoolean(),
            v.GetProperty("standing").GetString() ?? "",
            v.GetProperty("flag").GetString() ?? "",
            v.GetProperty("why").GetString() ?? ""))];
    }

    private static IReadOnlyList<FileRow> LoadSeed()
    {
        using var file = File.OpenRead(Shared("runtime-capabilities.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("rows").EnumerateArray().Select(r =>
        {
            var measured = r.GetProperty("measuredWith");
            return new FileRow(
                r.GetProperty("runtime").GetString() ?? "",
                r.GetProperty("capability").GetString() ?? "",
                r.GetProperty("standing").GetString() ?? "",
                measured.GetProperty("cli").GetString() ?? "",
                measured.GetProperty("version").GetString() ?? "",
                measured.GetProperty("date").GetString() ?? "",
                measured.GetProperty("resultRef").GetString() ?? "",
                [.. measured.GetProperty("cells").EnumerateArray().Select(c => c.GetString() ?? "")],
                measured.GetProperty("note").GetString() ?? "");
        })];
    }

    public static TheoryData<int> Cases()
    {
        var data = new TheoryData<int>();
        for (var i = 0; i < Vectors.Length; i++)
        {
            data.Add(i);
        }

        return data;
    }

    [Fact]
    public void TheVectorsActuallyLoaded_AndCoverEveryPairOfTheTable()
    {
        // Without this every assertion below would pass vacuously over an empty list.
        Vectors.Should().HaveCountGreaterThan(15, "fifteen pairs plus the refusals by name");
        foreach (var row in Seed)
        {
            Vectors.Should().Contain(v => v.Runtime == row.Runtime && v.Capability == row.Capability,
                $"the table's {row.Runtime} × {row.Capability} row must have a vector deciding it");
        }
    }

    [Theory]
    [MemberData(nameof(Cases))]
    public void EveryVector_IsAdmittedOrRefused_AsMeasured(int index)
    {
        var vector = Vectors[index];

        var admission = CapabilityMatrix.Admit(vector.Runtime, vector.Capability);

        switch (admission)
        {
            case Admission.Admitted admitted:
                vector.Admitted.Should().BeTrue($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                admitted.Standing.Spelled().Should().Be(vector.Standing, vector.Why);
                admitted.Flag.Spelled().Should().Be(vector.Flag, vector.Why);
                break;
            case Admission.Refused refused:
                vector.Admitted.Should().BeFalse($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                refused.Reason.Should().Contain(vector.Runtime).And.Contain(vector.Capability,
                    "a refusal names the pair it refused");
                break;
        }
    }

    [Fact]
    public void TheEmbeddedTable_IsTheFileInShared_RowForRow()
    {
        var loaded = RuntimeCapabilities.Builtin.Rows;

        loaded.Select(r => (r.Runtime, r.Capability.Spelled())).Should().Equal(
            Seed.Select(r => (r.Runtime, r.Capability)),
            "the loader keeps the file's rows in the file's order");
        foreach (var (row, expected) in loaded.Zip(Seed))
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            row.Standing.Spelled().Should().Be(expected.Standing, where);
            row.MeasuredWith.Cli.Should().Be(expected.Cli, where);
            row.MeasuredWith.Version.Should().Be(expected.Version, where);
            row.MeasuredWith.Date.Should().Be(expected.Date, where);
            row.MeasuredWith.ResultRef.Should().Be(expected.ResultRef, where);
            row.MeasuredWith.Cells.Should().Equal(expected.Cells, where);
            row.MeasuredWith.Note.Should().Be(expected.Note, where);
        }
    }

    [Fact]
    public void EveryRuntimeTimesCapability_HasExactlyOneRow_AndNoRowIsOutsideTheMatrix()
    {
        var pairs = RuntimeCapabilities.Builtin.Rows.Select(r => (r.Runtime, r.Capability)).ToList();

        pairs.Should().OnlyHaveUniqueItems("two rows for one pair would be two answers");
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var capability in Enum.GetValues<Capability>())
            {
                pairs.Should().Contain((runtime, capability), "every pair is decided by data, never by a default arm");
            }
        }

        pairs.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Enum.GetValues<Capability>().Length);
    }

    /// <summary>
    /// The records a row may cite, each with the day it was measured and the shape of its cell ids: the question
    /// consultant's full run for the first five runtimes, and the Vibe probe for vibe (S3 of
    /// todo/PLAN_vibe_and_kimi_runtimes.md) — whose cells are named <c>M-V…</c>, not numbered.
    /// </summary>
    private static readonly IReadOnlyList<(string Record, string Date, string CellPrefix)> Records =
    [
        ("RESULTS_question_consultant_capabilities.md", "2026-10-01", "01a0f8c7-18e4-"),
        ("RESULTS_vibe_confinement.md", "2026-10-12", "M-V"),
        ("RESULTS_kimi_confinement.md", "2026-10-13", "M-K"),
    ];

    [Fact]
    public void EveryRow_CitesTheRecord_AndACellOrSaysWhyThereIsNone()
    {
        foreach (var row in RuntimeCapabilities.Builtin.Rows)
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            var cited = Records.Where(record => row.MeasuredWith.ResultRef.Contains(record.Record, StringComparison.Ordinal)).ToList();
            cited.Should().ContainSingle($"{where}: a row cites exactly one record");
            var (record, date, prefix) = cited[0];
            row.MeasuredWith.Date.Should().Be(date, $"{where}: the day {record} was measured");
            (row.MeasuredWith.Cells.Count > 0 || row.MeasuredWith.Note.Length > 0).Should().BeTrue(
                $"{where}: a row with no cell says why — by construction, or not measured");
            foreach (var cell in row.MeasuredWith.Cells)
            {
                cell.Should().StartWith(prefix, $"{where}: every cell is one of {record}'s");
            }
        }
    }

    [Fact]
    public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
            row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
            CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
        }

        RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6",
            "denied writes do not prove bounded READS — the disk row rests on the read cell itself");
        CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured", "no Vibe cell exercises the web");
    }

    // ---------- Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md) ----------

    /// <summary>S5.6.1 — each Kimi row stands on its measured cells; `none` and `disk` are unconfined (Grep and Glob read the disk), `web` unmeasured.</summary>
    [Fact]
    public void KimiHasThreeRows_EachCitingItsCells()
    {
        // QWEN-FILL-BEGIN s561-rows test   <<< REGION s561-rows STARTS AFTER THIS LINE
        // Arrange/Act: `RuntimeCapabilities.Builtin.Of("kimi", Capability.None)`, `(…, Capability.Disk)`, `(…, Capability.Web)`.
        // Assert (FluentAssertions): each row `.Should().NotBeNull()`; none.Standing == CapabilityStanding.Unconfined and none.MeasuredWith.Cells
        // contains "M-K6"; disk.Standing == Unconfined and its Cells contain "M-K6" and "M-K9"; web.Standing == CapabilityStanding.Unmeasured
        // (its Cells are empty and its MeasuredWith.Note is not empty); all three rows' MeasuredWith.Version == "2.1.1" and
        // MeasuredWith.ResultRef contains "RESULTS_kimi_confinement.md".
        // Fails before the change: Of("kimi", None) is null (the table has no kimi row).
        throw new NotImplementedException("s561-rows");
        // QWEN-FILL-END s561-rows   <<< REGION s561-rows ENDS BEFORE THIS LINE
    }

    /// <summary>S5.6.2 — the golden vectors decide every Kimi pair, so the other half (the extension) answers the same three.</summary>
    [Fact]
    public void TheVectorsCoverKimi()
    {
        // QWEN-FILL-BEGIN s562-vectors test
        // Use the class's `Vectors` array (elements have Runtime, Capability, Admitted, Standing, Flag, Why — see the context pack).
        // For each capability in ["none", "disk", "web"] (the vector's `Capability` is a STRING, not the enum): `Vectors` must hold exactly one vector with
        // Runtime == "kimi" and that Capability (`Vectors.Should().ContainSingle(v => v.Runtime == "kimi" && v.Capability == capability, $"kimi × {capability} must have a vector")`).
        // Then: none and disk vectors are Admitted with Standing "unconfined" and Flag "unconfined"; the web vector is not Admitted, Standing "unmeasured".
        // Fails before the change: no kimi vectors in shared/capability-matrix-vectors.json (the file is data written in the skeleton, so this
        // test is green once the body is filled; its red is the missing-vector message when the data is reverted).
        throw new NotImplementedException("s562-vectors");
        // QWEN-FILL-END s562-vectors
    }

    /// <summary>S5.6.4 — the matrix admits both readable Kimi rows FLAGGED (D13): it can read this machine.</summary>
    [Fact]
    public void AdmissionFlagsBothRows()
    {
        // QWEN-FILL-BEGIN s564-admit test
        // For capability in [Capability.None, Capability.Disk]:
        //   `CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>().Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}")`
        // Also Standing: `.Which.Standing.Should().Be(CapabilityStanding.Unconfined)` on each.
        // Fails before the change: Admit returns Admission.Refused "'kimi' is not a runtime the question consultant can launch …".
        throw new NotImplementedException("s564-admit");
        // QWEN-FILL-END s564-admit
    }

    /// <summary>D13's two refusals kept apart: the flags are what the data says, never what a runtime name suggests.</summary>
    [Fact]
    public void TheFlags_AreD13s_CodexUnconfinedEverywhere_AgyDefaultDeny_NothingElseFlagged()
    {
        foreach (var capability in Enum.GetValues<Capability>())
        {
            CapabilityMatrix.Admit("codex", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"codex × {capability}: F2");
        }

        CapabilityMatrix.Admit("antigravity", Capability.Disk).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7");
        CapabilityMatrix.Admit("antigravity", Capability.None).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
        foreach (var runtime in (string[])["claude", "local", "api"])
        {
            CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"{runtime} × none is confined");
        }
    }

    [Fact]
    public void AnUnmeasuredPair_IsRefused_NamingTheRecordThatWouldAdmitIt()
    {
        var refused = CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("not been measured").And.Contain("RESULTS_question_consultant_capabilities.md",
            "the cure for an unmeasured pair is a measurement, and the sentence says where it goes");
    }

    /// <summary>
    /// An unmeasured pair names the record ITS row cites — the record a measurement would land in — so an unmeasured Vibe
    /// pair names the Vibe probe's record (S3 of todo/PLAN_vibe_and_kimi_runtimes.md), and the first five runtimes' sentences
    /// stay exactly what they were.
    /// </summary>
    [Fact]
    public void AnUnmeasuredVibePair_NamesTheVibeRecord_AndTheApiSentenceIsUnchanged()
    {
        var vibe = CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason;

        vibe.Should().Contain("a measured cell in research/RESULTS_vibe_confinement.md is what admits it")
            .And.NotContain("RESULTS_question_consultant_capabilities.md", "no cell of that run could admit a Vibe pair");
        CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason.Should().Be(
            "'api' has not been measured for 'web' (not measured; vendor-specific (a tails-plan item)) — a measured cell in "
            + "research/RESULTS_question_consultant_capabilities.md is what admits it; until then give this row a prompt of another capability");
    }

    [Fact]
    public void AnUnsupportedPair_IsRefused_WithTheRowsOwnReason()
    {
        var refused = CapabilityMatrix.Admit("antigravity", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("cannot fetch a page headless", "the row's note is the reason a person reads");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void ARowWithNoRuntime_IsRefused_AskingForAModel_NeverQuotingNothing(string runtime)
    {
        // research/PLAN_names_and_a_missing_root.md story 2.2: a row with no runtime used to be "'' is not a runtime …".
        var refused = CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Be("this row has no model to run on — pick one");
        // The words' overload too, with a capability that does not parse: its sentence used to say "asked for runtime ''".
        CapabilityMatrix.Admit(runtime, "shell").Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Be("this row has no model to run on — pick one");
    }

    [Fact]
    public void AnUnknownRuntimeOrCapability_IsRefused_NamingWhatIsKnown()
    {
        var runtime = CapabilityMatrix.Admit("gemini", "none").Should().BeOfType<Admission.Refused>().Which;
        runtime.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe, kimi",
            "an unknown name fails naming the legal values");

        var capability = CapabilityMatrix.Admit("claude", "shell").Should().BeOfType<Admission.Refused>().Which;
        capability.Reason.Should().Contain("shell").And.Contain("none, disk, web");
    }

    [Fact]
    public void TheWordsOfTheFile_RoundTripThroughTheTypes()
    {
        foreach (var standing in Enum.GetValues<CapabilityStanding>())
        {
            CapabilityStandings.Parse(standing.Spelled()).Should().Be(standing);
        }

        foreach (var capability in Enum.GetValues<Capability>())
        {
            Capabilities.TryParse(capability.Spelled(), out var parsed).Should().BeTrue();
            parsed.Should().Be(capability);
        }

        Capabilities.TryParse("Disk", out var cased).Should().BeTrue("the file's words are matched without case");
        cased.Should().Be(Capability.Disk);
        Capabilities.TryParse("shell", out _).Should().BeFalse();
        Capabilities.AllSpelled.Should().Be("none, disk, web");
    }

    /// <summary>A broken table is a broken BUILD, refused whole and loudly — the role seed's rule.</summary>
    /// <remarks>
    /// Written against a hand-built table rather than by corrupting the embedded file, because the
    /// validation is the unit under test and the resource is not reachable without rebuilding the
    /// assembly. Every fixture starts from the WHOLE matrix — every pair, well formed — and breaks one
    /// thing, so the refusal observed is for that thing and not for the other pairs a smaller
    /// fixture would also be missing.
    /// </remarks>
    public sealed class ABrokenTable
    {
        private static RuntimeCapabilityRowSeed Row(string runtime, string capability, string standing = "confined", IReadOnlyList<string>? cells = null, string note = "n") =>
            new(runtime, capability, standing, new MeasuredWithSeed("cli", "1", "2026-10-01", "ref", cells ?? ["01a0f8c7-18e4-0000-0000-000000000000"], note));

        /// <summary>Every pair of the matrix, well formed — the fixture the broken ones are cut from.</summary>
        private static List<RuntimeCapabilityRowSeed> Whole() =>
            [.. RuntimeCapabilities.Runtimes.SelectMany(runtime => Capabilities.All.Select(capability => Row(runtime, capability.Spelled())))];

        private static Action Loading(IEnumerable<RuntimeCapabilityRowSeed> rows) =>
            () => RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], [.. rows]));

        /// <summary>The whole matrix with ONE row replaced.</summary>
        private static IEnumerable<RuntimeCapabilityRowSeed> With(RuntimeCapabilityRowSeed replacement) =>
            Whole().Select(row => row.Runtime == replacement.Runtime && row.Capability == replacement.Capability ? replacement : row);

        [Fact]
        public void WithAPairMissing_IsRefused_NamingIt() =>
            Loading(Whole().Where(row => !(row.Runtime == "claude" && row.Capability == "disk")))
                .Should().Throw<InvalidOperationException>().WithMessage("*claude*disk*no row*",
                    "a pair with no row would be decided by nothing");

        [Fact]
        public void WithAPairTwice_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*twice*");

        [Fact]
        public void WithAnUnknownStanding_IsRefused_NamingIt() =>
            Loading(With(Row("claude", "none", standing: "sort of"))).Should().Throw<InvalidOperationException>()
                .WithMessage("*sort of*");

        [Fact]
        public void WithARowOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("gemini", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*gemini*");

        [Fact]
        public void WithACapabilityOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "shell")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*shell*none, disk, web*");

        [Fact]
        public void WithNeitherACellNorANote_IsRefused_NamingTheRow() =>
            Loading(With(Row("claude", "none", cells: [], note: ""))).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*cell*");

        [Fact]
        public void ThatIsWellFormed_Loads_EveryPairOnce()
        {
            var table = RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], Whole()));

            table.Rows.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Capabilities.All.Count).And.OnlyContain(row => row.Standing == CapabilityStanding.Confined);
            table.Of("codex", Capability.Web).Should().NotBeNull();
            table.Of("gemini", Capability.Web).Should().BeNull("a runtime outside the matrix has no row to answer with");
        }
    }
}

```
