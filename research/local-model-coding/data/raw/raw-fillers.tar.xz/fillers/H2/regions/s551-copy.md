# s551-copy (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `AKimiCheck_RunsInACopy_OnAOneShotHome`

Everything the class already has (read the file; the helpers are filled by their own regions): `Homes`, `Temp`, `Settings(string homesRoot)`, `Played()`, `CheckAsync(settings, played, ct)` returning `(int Code, JsonElement Said)`, fields `_person`, `_unlinkedByTheDeleter`.

Stand-in (exact, from `AKimiConsultationScenarioTests`, made `internal` for this): 

```csharp
internal static Scopes StandIn(KimiFixture person) => new(WindowsStandIn.Begin(), KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
    KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))), CallingAs("CLAUDE_CODE_SESSION_ID"));
internal sealed class Scopes(params IDisposable[] scopes) : IDisposable
```
Use it as `using var stood = AKimiConsultationScenarioTests.StandIn(_person);` BEFORE `CheckAsync`. (`AKimiConsultationScenarioTests` is public sealed in namespace `CoaiMcp.Tests`.)

Constants: `VibeHomes.OneShotFolder == "coai-vh"` (`CoaiMcp.Runners.Vibe`, file has the using), `ConsultantCheck.OwnName == "own"` (`CoaiMcp.Server`). The shim argv (from `KimiRuntime.Build`): `--ask-acp --profile kimi --model … --cwd <tree> --home <owned root> …`; take a value with `args[args.ToList().IndexOf("--home") + 1]` (helper `After(...)` in `KimiConsultantTests`).

`PlayedKimi.Shims` is a `ConcurrentQueue<PlayedKimi.Launch>`; `Launch.Request` is the `ProcessRequest` (`Arguments`, `WorkingDirectory`, `StdIn`).

The `<8 hex>` one-shot folder is `VibeHomes.OneShotIn(root, id)` = `<root>/coai-vh/<id>`; the home inside it is `kh-<10 hex>`.

Model of the assertions (the Vibe check test):

```csharp
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
```
(`Text(said, "state")` is `said.GetProperty("state").GetString()`.)
