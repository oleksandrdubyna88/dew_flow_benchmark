# s554-rootless (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst`

Read the packs of `s551-copy` and `s552-gone` first (same class, helpers, stand-in, recorder, `Hash()`).

With settings built by hand — `Settings(string.Empty)`, no homes root — `ConsultantCheck.TurnAsync` reserves no one-shot folder: `VibeHomes.ReserveOneShot(settings.ConsultantHomesRoot, warn)` with an empty root answers `OneShotReservation.None`, and the consultant's home folder is the place's folder — `<scratch>\own` (`ConsultantCheck.OwnName == "own"`, namespace `CoaiMcp.Server`). So the shim's `--home` value is `<scratch>\own\kh-<10 hex>` where `<scratch>` is `Temp\coai-check-<id>`. The scratch is deleted by `ConsultCheckScratch.Delete(scratch, warn)` (internal, `CoaiMcp.Server`), which disposes a Kimi home junction-first (E5.3 decision g).

Helper to read an argument value: `args[args.ToList().IndexOf("--home") + 1]` where `args = shim.Request.Arguments` and `shim = played.Shims.Should().ContainSingle().Subject.Request`.

Model for the rootless fallback, from `AOneShotKimiHomeIsDisposedJunctionFirstTests.TheRootlessFallback_DisposesJunctionFirst`:

```csharp
ConsultCheckScratch.Delete(scratch, _warned.Add);
Directory.Exists(scratch).Should().BeFalse($"the {site}'s scratch goes whole");
TheDeleterNeverMetTheJunction();   // _unlinkedByTheDeleter.Should().BeEmpty("…")
ThePersonsFolderIsWhole(before);   // _person.Hash().Should().Equal(before, "…")
```
After the check: `Directory.EnumerateDirectories(Temp, "coai-check-*")` is empty.
