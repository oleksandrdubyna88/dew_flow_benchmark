# s56-planner-kimi (prod) — src_mcp/core/QuestionConsult/ConfinementPlanner.cs

Namespace `CoaiMcp.Core.QuestionConsult`. The method to fill, already declared in the file (and already registered by `"kimi" => Kimi(grant, flag),` in `Fragments`):

```csharp
private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag)
```

Types it uses (all in the same namespace, exact):

```csharp
public enum CwdKind { Scratch, Root, Snapshot }
public abstract record Confinement {
    public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags,
        CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement
    { public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
    public sealed record Refused(string Reason) : Confinement;
}
public enum Capability { None, Disk, Web }            // Capability.cs
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
```

The sibling to copy (same file, already there):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

The Kimi method is a block body (`{ ... }`) in the skeleton, with the FILL region inside. Fill it with a `return` of the same shape as Vibe's switch, but `"kimi"` and `[]` instead of `VibeReadOnly` (no flags, ever). Keep the existing doc comment. Complexity ≤ 4.
