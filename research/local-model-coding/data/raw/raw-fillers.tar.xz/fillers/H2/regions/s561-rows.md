# s561-rows (test) — src_mcp/tests/CapabilityMatrixTests.cs, `KimiHasThreeRows_EachCitingItsCells`

Usings already in that file: `CoaiMcp.Core.QuestionConsult`, `FluentAssertions`, `Xunit`. Namespace `CoaiMcp.Tests`.

```csharp
// CoaiMcp.Core.QuestionConsult
public sealed record RuntimeCapabilities {
    public static RuntimeCapabilities Builtin { get; }
    public RuntimeCapabilityRow? Of(string runtime, Capability capability);
}
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public enum Capability { None, Disk, Web }
```

The data (already in `shared/runtime-capabilities.json`): kimi × none `unconfined`, cells `M-K6, M-K3, M-K4`; kimi × disk `unconfined`, cells `M-K6, M-K3, M-K4, M-K9, M-K9 (e)`; kimi × web `unmeasured`, no cells, a note; every row `version` `2.1.1`, `resultRef` begins `research/RESULTS_kimi_confinement.md`.

Similar test in the same file (the Vibe one), for the style:

```csharp
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
```

Assert as the comment in the file says. Use `because` messages that name the pair.
