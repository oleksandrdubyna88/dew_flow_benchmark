# s568-kimi (test) — src_vs_code/src/test/capabilityAdmission.test.ts, `kimi rows admit flagged, web refuses naming its record`

Node's test runner with `node:assert/strict` (already imported in the file: `assert`, `test`; `admit`, `CAPABILITIES`, `isCapability`, `STANDINGS` from `../capabilityAdmission`; `RUNTIME_CAPABILITIES`, `RUNTIMES` from `../runtimeCapabilities.generated`).

```ts
// src/capabilityAdmission.ts
export function admit(runtime: string, capability: string): Admission;
interface Admission { admitted: boolean; standing: CapabilityStanding | ''; flag: AdmissionFlag; reason: string; caveat: string }
// CAVEATS.unconfined === 'unconfined: can read this machine — a shell is always there, and no flag removes it'
```
Neighbouring tests, for the call shape:

```ts
test('a flagged admission carries the caveat a person must acknowledge (D13)', () => {
  assert.match(admit('codex', 'web').caveat, /can read this machine/u);
  assert.equal(admit('claude', 'web').caveat, '', 'a confined pair has nothing to acknowledge');
});
test('an unmeasured pair names the record its row cites: …', () => {
  const vibe = admit('vibe', 'web').reason;
  assert.ok(vibe.includes('a measured cell in research/RESULTS_vibe_confinement.md is what admits it'), vibe);
  assert.ok(!vibe.includes('RESULTS_question_consultant_capabilities.md'), '…');
});
```
Data (already generated in `runtimeCapabilities.generated.ts`): kimi × none/disk `unconfined`, kimi × web `unmeasured`, its `resultRef` begins `research/RESULTS_kimi_confinement.md`.

Keep the body ≤ ~25 lines; use a `for (const capability of ['none', 'disk'])` loop and the strict asserts. Style: the file has single quotes, 2-space indent, trailing commas, `/u` regexes.
