# s55-played (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `Played()`

Namespace `CoaiMcp.Tests`; usings include `CoaiMcp.Runners.Processes`. `PlayedKimi` is `src_mcp/tests/PlayedKimi.cs` (internal sealed class, same assembly) — exact surface:

```csharp
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }
    public ConcurrentQueue<ProcessRequest> Versions { get; }
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }          // what the n-th shim launch prints; default = an answered turn
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }   // runs while a shim is "alive"
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                              // end session_lost, exit 70
}
```

`ProcessLauncher` (CoaiMcp.Runners.Processes) is the real launcher (`new ProcessLauncher()`); every non-shim process (git, `kimi --version` is answered by PlayedKimi itself) goes to it.

The check's scratch repository holds a `CHECK.md` whose last word (before a trailing '.') is the marker the consultant must report. The shim's request has `WorkingDirectory` = the copy's tree (`<scratch>\own\tree`), which holds `CHECK.md`. The check judges the answer text: it wants a line `marker: <the marker>` and `canary: CANNOT`.

Model from the Vibe check test (`ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself`):

```csharp
var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
{
    AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
};
```
