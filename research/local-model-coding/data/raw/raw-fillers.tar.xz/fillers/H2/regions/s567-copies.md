# s567-copies (test) — src_mcp/tests/AKimiQuestionRowTests.cs, `AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(string ending)` (Theory)

Read the packs `s567-service`, `s567-ask`, `s567-repo` (helpers `Service(kimi, roots)`, `AskAsync(service, ct)`, `Homes`, `Repo`, `_launcher`, `_person`, `_dir`, `_unlinkedByTheDeleter` all exist in the class). Stand-in as in `s551-copy`: `using var stood = AKimiConsultationScenarioTests.StandIn(_person);` (BEFORE `Service(...)` is asked; `Scopes` is `IDisposable`).

Surface used:

```csharp
// PlayedKimi (tests): Shims : ConcurrentQueue<Launch>; Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
//   Versions : ConcurrentQueue<ProcessRequest>; During : Func<ProcessRequest, CancellationToken, Task> { get; init; }
// ProcessRequest: Arguments (IReadOnlyList<string>), WorkingDirectory, StdIn (the prompt rides stdin)
// CoaiMcp.Core.QuestionConsult.RowOutcomes: Answered = "answered", Refused = "refused", Failed = "failed"
// CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder == "coai-vh"; recorder: GitScratch.AfterUnlink (set by the class), list _unlinkedByTheDeleter
```
The shim's argv holds `--cwd <value>` and `--home <value>`; read a value with `args[args.ToList().IndexOf("--home") + 1]`. For a `disk` row the cwd is `<row folder>\tree` (the copy dir) — the shim's `--cwd` — and the prompt (`request.StdIn`) names the copies' paths. The `--home` is `<homes>\coai-vh\<8>\kh-<10 hex>`; the row's one-shot folder is its parent.

Models from the Vibe row tests (same repo, `AVibeQuestionRowReadsACopyOfItsRootsTests`):

```csharp
TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());
turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy Vibe can read");
turn.Request.StdIn.Should().NotContain(granted, "never the original, which it cannot read (M-V11)");
// refused before the launch (a plain folder outside git):
var plain = Directory.CreateDirectory(_dir.At("plain")).FullName;
await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
row.GetProperty("status").GetString().Should().Be(RowOutcomes.Refused, reply.ToString());
row.GetProperty("reason").GetString().Should().Contain("not inside a Git work tree");
// cancelled:
var asking = async () => await AskAsync(Service(vibe, Path.Combine(Repo, "src")), caller.Token);
await asking.Should().ThrowAsync<OperationCanceledException>();
// homes folder empty (the Vibe class helper): 
Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the row's folder under coai-vh is deleted on every way out");
```
Note the "refused" arm reserves the one-shot folder before the copy is refused, so `coai-vh` exists and must be empty; in the "answered" and "cancelled" arms too. Use `Directory.Exists` guard only if an arm may never create it. `_person.Hash()` is taken before the row and compared after (`Should().Equal(before)`).

`Assert.SkipUnless` is NOT needed: the launch control is stood in as Windows by `StandIn` on every host (the E5.4 scenarios run on Linux the same way).
