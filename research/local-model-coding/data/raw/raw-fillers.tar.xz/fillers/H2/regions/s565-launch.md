# s565-launch (test) — src_mcp/tests/ConfinementPlannerTests.cs, `AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome`

Namespace `CoaiMcp.Tests`. File usings: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit` — NOT `CoaiMcp.Runners.Kimi` / `Platform` / `Processes` (write full names `Runners.Kimi.…`, as the Vibe test beside it does; `Runners` resolves because the namespace is `CoaiMcp.Tests`).

In the class (private static, exact):

```csharp
private const string RootA = "D:/projects/alpha"; private const string RootB = "D:/projects/beta";
private static readonly string Scratch, Answers, RowFolder, RowTree;   // RowTree = Path.Combine(RowFolder, "tree")
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{ Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)), ScratchDir = Scratch, Workdir = RowTree };
```

Types:

```csharp
// CoaiMcp.Runners.Kimi
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime { public ReviewerInvocation Build(ConsultantLaunch launch); }
public sealed class KimiRuntime(string id, HostKind host, KimiSeams seams, Serilog.ILogger log) : IReviewerRuntime   // plus ctor (string id, HostKind host, KimiSeams seams)
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)
public static class KimiEnvironment { public static string Refusal(ProcessRequest request, KimiPlaces places); }   // empty string = admitted
// CoaiMcp.Runners.Platform: enum HostKind { Windows, ... }   // HostKind.Windows
// CoaiMcp.Runners.Processes: record ProcessRequest(...) with Executable, Arguments (IReadOnlyList<string>), WorkingDirectory, StdIn, InheritsEnvironment (bool), Environment, Passthrough
// CoaiMcp.Runners.Consultation: ReviewerInvocation(Request, Role, Model, Adapter ...): .Request (ProcessRequest), .Role (string)
public static class ConsultantRoles { public const string Question = "question"; public const string Consult = "consult"; }   // CoaiMcp.Core.Consultation or Runners.Consultation — in the Vibe test beside it `ConsultantRoles.Question` compiles with this file's usings
```

KimiFixture (src_mcp/tests/KimiFixture.cs, `internal sealed class KimiFixture : IDisposable`): `public KimiPlaces PlacesAt(string ownedRoot)` resolves the fake person's places for an owned root; `string Folder`; `IReadOnlyList<string> Hash()`.

Same construction, from `KimiConsultantTests` (E5.4):

```csharp
private KimiConsultant Consultant() =>
    new(new KimiRuntime("my-kimi", HostKind.Windows, new KimiSeams(_person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");
private static string After(IReadOnlyList<string> args, string flag) => args[args.ToList().IndexOf(flag) + 1];
```
and its assertions: `request.Arguments.Should().ContainInConsecutiveOrder("--ask-acp", "--profile", "kimi", "--model", KimiModels.Default, "--cwd", Tree);`, `var home = After(request.Arguments, "--home");`, `KimiEnvironment.Refusal(request, _person.PlacesAt(home)).Should().BeEmpty("…")`.

Similar Vibe test just below the fill: `AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome` — `Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"))`, `.Request.WorkingDirectory.Should().Be(Scratch, …)`, `request.InheritsEnvironment.Should().BeFalse()`.

Note: on the home the Vibe test asserts `StartWith(RowFolder + Path.DirectorySeparatorChar)`; for Kimi the `--home` value is `<RowFolder>\kh-<10 hex>` (OwnedScratch = RowFolder). `KimiPlaces` resolution does not touch disk for `Build`.
