# s553-cancel (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `ACheckCancelledMidTurn_StillDisposesItsHome`

Read the packs of `s551-copy` and `s552-gone` first (same class, helpers, stand-in, recorder, `Hash()`).

The cancellation seam: `PlayedKimi.During` is `Func<ProcessRequest, CancellationToken, Task>`, run while the shim is "alive". The Vibe row test cancels like this (`AVibeQuestionRowReadsACopyOfItsRootsTests.ARowCancelledInFlight_LeavesNoHomeAndNoCopy`):

```csharp
using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var vibe = new PlayedVibe(_launcher, Advice)
{
    During = async ct =>
    {
        await caller.CancelAsync();
        ct.ThrowIfCancellationRequested();
    },
};
```
(the Kimi seam has two parameters: `async (_, ct) => { … }`). The token handed to `CheckAsync` is `caller.Token`.

What the check does when the CALLER cancels (`ConsultantCheck.RunAsync`): `catch (OperationCanceledException) when (caller.IsCancellationRequested) { return Failed(checking, row, new ConsultFailure.Cancelled(), …); }` — so the mode normally answers a record (state not "answered", `failureKind` "cancelled" or similar) rather than throwing; but if `CheckAsync` throws `OperationCanceledException` instead, catch it in the test and go on to the asserts — the point is the disposal, in the check's `finally` (`held.Home.Dispose()` for the reservation).

Folder to check: `Path.Combine(Homes, VibeHomes.OneShotFolder)` (may exist, must be empty). `_unlinkedByTheDeleter` empty; `_person.Hash()` equal to the one taken before.
