# s552-gone (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `AfterTheCheck_TheHomeIsGone_JunctionFirst(string ending)` (Theory: "passed", "exit 70")

Read the pack of `s551-copy` first (same class, same helpers, same `StandIn`, same constants). The method already starts with `ending.Should().NotBeNullOrEmpty(...)`.

The recorder: the class constructor sets `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` (`GitScratch` is `CoaiMcp.Runners.Files`; `AfterUnlink` is a static `Action<string>?`) and `Dispose` clears it. A Kimi home disposed junction-first never lets the shared deleter meet its junction, so `_unlinkedByTheDeleter` stays empty.

`_person.Hash()` is `IReadOnlyList<string>` — every entry of the fake person's folder: relative path, attributes, SHA-256. "Whole" is `_person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before")`.

The failing arm: `PlayedKimi.Lost(PlayedKimi.SessionOf(request))` is `new ProcessResult(70, <a session_lost report>, stderr, TimedOut: false)`; give it as `Turn = (_, request) => PlayedKimi.Lost(PlayedKimi.SessionOf(request))` in the `PlayedKimi` object initializer (`new PlayedKimi(new ProcessLauncher()) { Turn = … }`). The check then ends not answered; `said` still carries a record. The folder to check is `Path.Combine(Homes, VibeHomes.OneShotFolder)` — it may exist and must hold no entries; guard with `Directory.Exists` if you want it robust.

Model from `AOneShotKimiHomeIsDisposedJunctionFirstTests`:

```csharp
Directory.Exists(home.Folder).Should().BeFalse("the owner takes its folder whole when it ends");
_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
_person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
```
