# s563-arm (test) — src_mcp/tests/ConfinementPlannerTests.cs, `ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb`

Namespace `CoaiMcp.Tests`; usings in the file: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit`.

In the class (private, exact):

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
```

Types: `CapabilityGrant.None`, `CapabilityGrant.Web` (static properties), `CapabilityGrant.Disk(params string[] roots)`; `Confinement.Planned` has `Leading`, `Flags`, `Cwd` (`CwdKind.Scratch|Root|Snapshot`), `AddDirs`, `Flag` (`AdmissionFlag`), `SnapshotSources` (all `IReadOnlyList<string>` but `Cwd`/`Flag`); `Confinement.Refused(string Reason)`. `ConfinementPlanner.Plan(string runtime, CapabilityGrant grant)` returns `Confinement`.

The web refusal (from the matrix, already data): `'kimi' has not been measured for 'web' (not measured: …) — a measured cell in research/RESULTS_kimi_confinement.md is what admits it; …`.

Same-file model (Vibe):

```csharp
var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
disk.Cwd.Should().Be(CwdKind.Snapshot, "...");
disk.AddDirs.Should().BeEmpty("...");
disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
```
and for refusals: `ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>().Which.Reason.Should().Contain(says, "...")`.
