# s566-flags (test) — src_mcp/tests/ConfinementPlannerTests.cs, `APlanWithFlags_IsRefusedForKimi`

Same file, usings and helpers as the pack of `s565-launch` (read it: `Planned(...)`, `Scratch`, `RowFolder`, `RowTree`, the `Runners.Kimi.*` full names, `KimiFixture`, how a `KimiConsultant` is built over a fake person).

The hand-made plan (exact constructor; namespace `CoaiMcp.Core.QuestionConsult`):

```csharp
new Confinement.Planned("kimi", CapabilityGrant.None, [], ["--yolo"], CwdKind.Scratch, [], AdmissionFlag.Unconfined)
```

The launch: `Planned("kimi", CapabilityGrant.None) with { Confinement = new LaunchConfinement.Planned(plan) }` — `ConsultantLaunch` is a `sealed record`, so `with` works; `LaunchConfinement.Planned(Confinement.Planned Plan)` is in `CoaiMcp.Runners.Consultation`.

Careful: the `Planned(...)` helper itself calls `Plan("kimi", grant)` — which needs the planner arm (`s56-planner-kimi`). That is fine, the arm is filled in the same run.

Assertion (FluentAssertions): `FluentActions.Invoking(() => consultant.Build(launch)).Should().Throw<ArgumentException>().WithMessage("*shim*")`.
The production check is `KimiConsultant.MustCarryNoFlags` (region `s56-no-flags`): throws `ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", …)`.
