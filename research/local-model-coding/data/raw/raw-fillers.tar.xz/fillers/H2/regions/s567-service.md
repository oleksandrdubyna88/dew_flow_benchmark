# s567-service (test) — src_mcp/tests/AKimiQuestionRowTests.cs, `Service(PlayedKimi kimi, params string[] roots)`

Namespace `CoaiMcp.Tests`; usings in the file: `System.Text.Json`, `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Core.Rounds`, `CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Server`, `FluentAssertions`, `Serilog.Core` (for `Logger.None`), `Xunit`. Class members: `Homes` (the homes root folder), `_dir` (`TempDir`, `.At(...)`).

Exact signatures:

```csharp
// CoaiMcp.Server
public PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)
// CoaiMcp.Core.QuestionConsult
public sealed record QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")
public sealed record QuestionConsultSettings { IReadOnlyList<QuestionRow> Rows; IReadOnlyList<string> Roots; TimeSpan RowBudget; ... }   // init properties
// CoaiMcp.Core.Rounds
PanelConfig.Uniform(3, 2, StagePolicy.Human)
```
`PlayedKimi : IProcessLauncher` (src_mcp/tests/PlayedKimi.cs) — pass it as the `launcher` (4th argument).

Exact model — `AVibeQuestionRowReadsACopyOfItsRootsTests.ServiceFor`:

```csharp
private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    vibe,
    Logger.None,
    Noticing.None);
```
For Kimi: row id `kimi-disk`, vendor `moonshot`, runtime `kimi`, model empty (the adapter's default `KimiModels.Default`), `ExecutablePath` empty (the Kimi runtime finds its shim and person through `KimiSeams`, stood in by `AKimiConsultationScenarioTests.StandIn(person)` in the test), `ConsultantHomesRoot = Homes`.
