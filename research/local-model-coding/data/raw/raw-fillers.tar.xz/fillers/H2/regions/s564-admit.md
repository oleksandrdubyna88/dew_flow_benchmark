# s564-admit (test) — src_mcp/tests/CapabilityMatrixTests.cs, `AdmissionFlagsBothRows`

Usings in the file: `CoaiMcp.Core.QuestionConsult`, `FluentAssertions`, `Xunit`.

```csharp
// CoaiMcp.Core.QuestionConsult
public static class CapabilityMatrix { public static Admission Admit(string runtime, Capability capability); }   // also an overload by words
public abstract record Admission {
    public sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag) : Admission;
    public sealed record Refused(string Reason) : Admission;
}
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public enum Capability { None, Disk, Web }
```

Same-file model (the Vibe test):

```csharp
CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
    .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
```

Loop over `(Capability[])[Capability.None, Capability.Disk]` and assert Flag `Unconfined` and Standing `Unconfined` for kimi.
