# s567-ask (test) — src_mcp/tests/AKimiQuestionRowTests.cs, `AskAsync(PanelService service, CancellationToken? ct = null)`

Namespace `CoaiMcp.Tests`; usings include `System.Text.Json`. The class has `private string Repo => _dir.At("repo");`.

```csharp
// CoaiMcp.Server.PanelService
public Task<string> AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)
```
It returns the reply as a JSON string; a row's answer is in `reply.answers[]` (each with `status`, `reason`).

Exact model — `AVibeQuestionRowReadsACopyOfItsRootsTests.AskAsync`:

```csharp
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
    JsonDocument.Parse(await service.AskConsultantsAsync(
        Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;
```
and its companion (write it inside the test body, not as a new method):

```csharp
private static JsonElement TheRow(JsonElement reply)
{
    reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
    return answers.EnumerateArray().Should().ContainSingle().Subject;
}
```
