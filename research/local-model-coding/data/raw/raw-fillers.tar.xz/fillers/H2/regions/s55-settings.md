# s55-settings (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `Settings(string homesRoot)`

Namespace `CoaiMcp.Tests`; file usings: `System.Text.Json`, `CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Server`, `FluentAssertions`, `Xunit`. Class fields: `_person` (KimiFixture), `_dir` (`TempDir`, `.At(params string[] parts)` gives a path inside it; implicit `string`), `_warned`, `_unlinkedByTheDeleter`.

`PanelSettings` (namespace `CoaiMcp.Server`, a record with `init` properties, all with defaults):
`IReadOnlyList<ProviderSettings> Providers`, `TimeSpan ReviewerTimeout`, `string DataDir`, `string ConsultantHomesRoot`, `bool ConsultEnabled`, `IReadOnlyDictionary<string, ConsultantChoice> Consultants`.

```csharp
public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "")
public static class CallerIdentity { public const string Claude = "claude"; ... }   // CoaiMcp.Server
```

Model (from `ConsultantCheckTests`, same assembly):

```csharp
private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
{
    Providers = [],
    DataDir = _data,
    ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
    ConsultEnabled = enabled,
    Consultants = new Dictionary<string, ConsultantChoice>
    {
        [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe),
    },
};
```
and the Kimi row from `AKimiConsultationScenarioTests`: `[CallerIdentity.Claude] = new("my-kimi", Runtime: "kimi")` (no ExecutablePath: the Kimi runtime is built BY NAME and finds its shim and person through `KimiSeams`, stood in by `AKimiConsultationScenarioTests.StandIn`).

`homesRoot` may be `string.Empty` (the rootless arm). `DataDir` is `_dir.At("data")`.
