# s55-check (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `CheckAsync(PanelSettings settings, PlayedKimi launcher, CancellationToken ct)`

Namespace `CoaiMcp.Tests`; the class has `_warned` (`List<string>`) and a `Temp` property (a folder inside the test's own `testsToDelete-` folder).

```csharp
// CoaiMcp.Server, internal static class ConsultantCheckMode (tests see internals)
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct)
public sealed class Noticing { public static Noticing None { get; } ... }   // CoaiMcp.Server
```
`PlayedKimi : IProcessLauncher`, so it can be passed as `launcher`.

Model, the `Check` helper of `ConsultantCheckTests`:

```csharp
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
```
The args are `["--check-consultant", "--caller", "claude"]`. The printed JSON has the properties `state` ("answered" …), `markerRead` (bool), `failureWhat`, `failureKind`. Return a 2-tuple `(Code, Said)`.
