# s567-repo (test) — src_mcp/tests/AKimiQuestionRowTests.cs, `RepositoryAsync(string at, params (string Path, string Text)[] files)`

Namespace `CoaiMcp.Tests`; usings include `CoaiMcp.Runners.Processes` (`ProcessLauncher`, `ProcessRequest`, `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`), `FluentAssertions`, `Xunit`. The class has `private readonly ProcessLauncher _launcher = new();` and implements `IAsyncLifetime` (xUnit v3: `ValueTask InitializeAsync()`), so `TestContext.Current.CancellationToken` is available.

Exact copy source — `AVibeQuestionRowReadsACopyOfItsRootsTests.RepositoryAsync`:

```csharp
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}
```
Caution: inside the tuple deconstruction the name `Path` hides `System.IO.Path` in the lambda-free scope only if you use `path` (lower case) — the copy uses `path`, as above; keep it. No more than ~20 lines; one region, no helper.
