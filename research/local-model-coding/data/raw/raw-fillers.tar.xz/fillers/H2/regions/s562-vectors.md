# s562-vectors (test) — src_mcp/tests/CapabilityMatrixTests.cs, `TheVectorsCoverKimi`

Already in the class (private, same file):

```csharp
private sealed record Vector(string Runtime, string Capability, bool Admitted, string Standing, string Flag, string Why);
private static readonly Vector[] Vectors = LoadVectors();     // from shared/capability-matrix-vectors.json
```

`Capability` is a STRING ("none" / "disk" / "web"), `Standing` is the file's word ("unconfined", "unmeasured"), `Flag` is "unconfined" or "".

The data (already written in the JSON):
- kimi none: admitted true, standing "unconfined", flag "unconfined"
- kimi disk: admitted true, standing "unconfined", flag "unconfined"
- kimi web: admitted false, standing "unmeasured", flag ""

Existing sibling test in the same class (style to follow):

```csharp
[Fact]
public void TheVectorsActuallyLoaded_AndCoverEveryPairOfTheTable()
{
    Vectors.Should().HaveCountGreaterThan(15, "fifteen pairs plus the refusals by name");
    foreach (var row in Seed)
    {
        Vectors.Should().Contain(v => v.Runtime == row.Runtime && v.Capability == row.Capability,
            $"the table's {row.Runtime} × {row.Capability} row must have a vector deciding it");
    }
}
```

Fill the body with a loop over `new[] { "none", "disk", "web" }` and the asserts the in-file comment says. Because-messages must name `kimi × <capability>`.
