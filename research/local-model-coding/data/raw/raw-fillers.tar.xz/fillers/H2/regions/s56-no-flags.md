# s56-no-flags (prod) — src_mcp/runners/Kimi/KimiConsultant.cs

Namespace `CoaiMcp.Runners.Kimi`. File already has `using CoaiMcp.Core.QuestionConsult;` (where `Confinement` lives). The method to fill (already declared, already called from `Build` for a `LaunchConfinement.Planned` launch only):

```csharp
private static void MustCarryNoFlags(Confinement.Planned plan)
```

`Confinement.Planned` (namespace `CoaiMcp.Core.QuestionConsult`):

```csharp
public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags,
    CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement
```

Body: `if (plan.Flags.Count > 0 || plan.Leading.Count > 0) { throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(plan)); }`.

Why: E5.6 decision 3; a plan with flags would put sandbox flags on the shim's argv. Test: `ConfinementPlannerTests.APlanWithFlags_IsRefusedForKimi` expects `Throw<ArgumentException>().WithMessage("*shim*")`. `QuestionRowLaunch.RunAsync` already catches `ArgumentException` from `Build` and ends the row `failed` with `e.Message`.

Existing neighbour style (same file): `private static string OwnedFolder(ConsultantLaunch launch) => ... throw new ArgumentException("...", nameof(launch));`
