```csharp
        return grant.Capability switch
        {
            Capability.Disk => new Confinement.Planned("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
            _ => new Confinement.Planned("kimi", grant, [], [], CwdKind.Scratch, [], flag),
        };
```