You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s566-noflags — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
When launch.Confinement is LaunchConfinement.Planned planned and planned.Plan.Flags.Count > 0 OR planned.Plan.Leading.Count > 0
throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch)).
Otherwise return. (Confinement.Planned is CoaiMcp.Core.QuestionConsult.Confinement.Planned; its Flags and Leading are IReadOnlyList<string>.)

## The exact existing types and members you may use (context pack)
# Context pack — region `s566-noflags` (prod)

File: `src_mcp/runners/Kimi/KimiConsultant.cs` — the region sits between `QWEN-FILL-BEGIN s566-noflags prod` and `QWEN-FILL-END s566-noflags`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## Capability table types (namespace CoaiMcp.Core.QuestionConsult) — copied from the repository
```csharp
public enum Capability { None, Disk, Web }
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability) -> RuntimeCapabilityRow?   // null for a pair not in the table
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
public abstract record Admission { sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag); sealed record Refused(string Reason); }
CapabilityMatrix.Admit(string runtime, Capability capability) -> Admission
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots) { static None; static Web; static Disk(params string[] roots); }
public enum CwdKind { Scratch, Root, Snapshot }
ConfinementPlanner.Plan(string runtime, CapabilityGrant grant) -> Confinement   // Confinement.Planned or Confinement.Refused(string Reason)
public sealed record Confinement.Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag)
{ public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
```
The Kimi rows now in shared/runtime-capabilities.json (the skeleton wrote them): kimi × none and × disk are `unconfined`, cli "kimi", version "2.1.1", date "2026-10-13", resultRef citing research/RESULTS_kimi_confinement.md; none's cells: M-K6, M-K3, M-K4; disk's: M-K6, M-K3, M-K4, M-K9; kimi × web is `unmeasured` with no cell. The unmeasured sentence of the matrix: "'kimi' has not been measured for 'web' (...) — a measured cell in research/RESULTS_kimi_confinement.md is what admits it; ...".

## Context
The method is `private static void MustCarryNoPlanFlags(ConsultantLaunch launch)` in `KimiConsultant` (namespace CoaiMcp.Runners.Kimi), called first in `Build`. `launch.Confinement` is a `LaunchConfinement`: `LaunchConfinement.Shipped` (a consultation) or `LaunchConfinement.Planned(Confinement.Planned Plan)` (a question row). `using CoaiMcp.Core.QuestionConsult;` and `using CoaiMcp.Runners.Consultation;` are already in the file.
The sibling guards in the same file throw like this:
```csharp

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
```
The plan the Kimi planner arm makes has EMPTY `Flags` and `Leading`; a hand-made plan with `Flags: ["--yolo"]` must be refused with an `ArgumentException` whose message names the shim ("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi"). Cyclomatic complexity <= 4.


## The whole file (the region is marked with <<<)
```csharp
using CoaiMcp.Core.Consultation;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Runners.Acp;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Reviewers;

namespace CoaiMcp.Runners.Kimi;

/// <summary>
/// Kimi Code as a consultant — the stuck consultant's conversation (E5.4 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>; S5 of
/// <c>todo/PLAN_vibe_and_kimi_runtimes.md</c>). Every launch is the reviewer's own shim request, composed from <see cref="KimiRuntime"/> and never
/// built a second time (decision 1): the executor then asks the one launch control (<see cref="KimiLaunch"/>) through that adapter — the host, the
/// tools, the model, the built environment, the sign-in, the home's shape, the gate on the sign-in, the version.
/// </summary>
/// <remarks>
/// <para><b>Never the checkout, and never a home of its own making</b> (decision 2): the cwd is the conversation's ONE stable snapshot
/// (<see cref="ConsultantLaunch.Workdir"/>, D6 — a loaded session resolves paths against the folder it was created in, M-K5), and the home is
/// <c>&lt;folder&gt;\kh-&lt;10 hex&gt;</c> under the coai-owned folder the caller hands in <see cref="ReviewerSettings.OwnedScratch"/> — never that
/// folder itself, whose turn the caller holds (E5.3 decision a), and never TEMP or the answers folder (D19). Both are required.</para>
/// <para><b>Memory is the vendor's</b> (decision 3): turn 1 starts a session, every later turn continues it with the shim's
/// <c>--session &lt;id&gt;</c> (E5.2), the id read off the report's <c>sessionId</c>. <b>Usage is cumulative</b> (decision 4, M-K5b): the service
/// bills each turn its share of the session's running total, guarded against a counter that restarted (decision 12).</para>
/// <para><b>A dropped session is the report's END word</b> (decisions 5 and 11): <c>session_lost</c>, never the agent's text — and the service
/// then REFUSES the turn with its cure; nothing here starts a fresh session in its place.</para>
/// </remarks>
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public string Vendor => vendor;

    public ConsultantMemory Memory => new ConsultantMemory.VendorRemembers();

    /// <summary>M-K5b (RESULTS §23), and three turns of one session in M-K16 (d): <c>/usage</c> is the session's running total.</summary>
    public bool UsageIsCumulative => true;

    /// <summary>D6: Kimi loads a project <c>.kimi-code</c>, <c>AGENTS.md</c>, skills and <c>.mcp.json</c> from its working folder.</summary>
    public bool NeedsASanitisedSnapshot => true;

    /// <summary>One coai-owned home per conversation, under <see cref="ConsultantHomes.Kimi"/> (J3), swept with it (D20).</summary>
    public string HomesFolder => ConsultantHomes.Kimi;

    /// <summary>Only what was observed working (decision 7): <c>Read</c> inside the copy (M-K6), <c>Grep</c> and <c>Glob</c> (RESULTS §17) — never claimed bounded.</summary>
    public string Toolbox =>
        "You read files with Read, by a path inside your working folder — a copy coai made of the checkout without its .git, .kimi-code/, "
        + ".agents/ skills and sub-agents, .mcp.json and AGENTS.md; Grep and Glob search files too. Every write and every shell command is refused.";

    public ReviewerInvocation Build(ConsultantLaunch launch)
    {
        ConsultantLaunches.MustBeLaunchable(launch);
        MustCarryNoPlanFlags(launch);
        var settings = launch.Settings with { OwnedScratch = OwnedFolder(launch), Model = ModelOf(launch.Settings) };
        var built = inner.Build(ConsultantLaunches.RoleOf(launch), launch.Prompt, Cwd(launch), string.Empty, launch.OutputDir, settings);
        var request = built.Request with { Arguments = [.. built.Request.Arguments, .. SessionOf(launch)] };
        ConsultantLaunches.MustCarryNoLineBreak(request.Arguments);

        return built with { Request = launch.Confinement is LaunchConfinement.Planned ? ConsultantLaunches.ForQuestion(request) : request };
    }

    /// <summary>Kimi's confinement is the shim's, never its argv (E5.6 decision 3): a plan that carries a flag is not one coai made for kimi.</summary>
    private static void MustCarryNoPlanFlags(ConsultantLaunch launch)
    {
        // QWEN-FILL-BEGIN s566-noflags prod   <<< REGION s566-noflags STARTS AFTER THIS LINE
        // When launch.Confinement is LaunchConfinement.Planned planned and planned.Plan.Flags.Count > 0 OR planned.Plan.Leading.Count > 0
        // throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch)).
        // Otherwise return. (Confinement.Planned is CoaiMcp.Core.QuestionConsult.Confinement.Planned; its Flags and Leading are IReadOnlyList<string>.)
        throw new NotImplementedException("s566-noflags");
        // QWEN-FILL-END s566-noflags   <<< REGION s566-noflags ENDS BEFORE THIS LINE
    }

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
            ? launch.Workdir
            : throw new ArgumentException(
                "a Kimi consultant stands in the conversation's sanitised snapshot (Workdir), and none was made — the checkout is never its working folder (D6)",
                nameof(launch));

    private static string OwnedFolder(ConsultantLaunch launch) =>
        launch.Settings.OwnedScratch.Length > 0
            ? launch.Settings.OwnedScratch
            : throw new ArgumentException(
                "a Kimi consultant keeps its home in a coai-owned folder of the conversation or the row (OwnedScratch), and none was given — never TEMP or the answers folder (D19)",
                nameof(launch));

    /// <summary>The report's <c>sessionId</c> when it is a well-formed handle — the shim names it on every exit that prints a report — or empty.</summary>
    public string ReadHandle(ProcessResult result) =>
        KimiReport.Parse(result.StdOut).SessionId is var id && ConsultantHandle.IsWellFormed(id) ? id : string.Empty;

    /// <summary>The shim's END word says the agent no longer holds the session <c>--session</c> named (E5.2) — read off the report, never its text.</summary>
    public bool DroppedTheConversation(ProcessResult result) => KimiReport.Parse(result.StdOut).End == AcpWords.SessionLostWord;
}

```
