```csharp
        private sealed class Scopes(params IDisposable[] scopes) : IDisposable
        {
            public void Dispose()
            {
                foreach (var scope in scopes.Reverse())
                {
                    scope.Dispose();
                }
            }
        }

        return new Scopes(
            WindowsStandIn.Begin(),
            KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
            KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, [])))
        );
```