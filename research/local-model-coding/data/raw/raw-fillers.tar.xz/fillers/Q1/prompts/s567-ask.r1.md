You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s567-ask — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
return JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct)).RootElement;

## The exact existing types and members you may use (context pack)
# Context pack — region `s567-ask` (test)

File: `src_mcp/tests/AKimiQuestionRowTests.cs` — the region sits between `QWEN-FILL-BEGIN s567-ask test` and `QWEN-FILL-END s567-ask`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## The question row service test (the model: AVibeQuestionRowReadsACopyOfItsRootsTests) — copied from the repository
```csharp
    }

    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        Directory.CreateDirectory(at);
        foreach (var (path, text) in files)
        {
            var full = Path.Combine([at, .. path.Split('/')]);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }

        foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
        }
    }

    private PanelService Service(PlayedVibe vibe, params string[] roots) => ServiceOn(vibe, string.Empty, roots);
    private PanelService ServiceWithModel(PlayedVibe vibe, string model, params string[] roots) => ServiceFor(vibe, string.Empty, model, roots);

    /// <summary>The service with a homes root: a home-keeping row reserves its one-shot folder there (D1).</summary>
    private PanelService ServiceOn(PlayedVibe vibe, string homesRoot, params string[] roots) => ServiceFor(vibe, homesRoot, "glm-5-3", roots);

    private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
        new PanelSettings
        {
            ConsultantHomesRoot = homesRoot,
            Providers = [],
            Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
            DataDir = _dir.At("data"),
            ReviewerTimeout = TimeSpan.FromSeconds(30),
            QuestionConsult = new QuestionConsultSettings
            {
                Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
                Roots = roots,
                RowBudget = TimeSpan.FromSeconds(30),
            },
        },
        VaultKeys.None("no vault in tests"),
        default,
        vibe,
        Logger.None,
        Noticing.None);

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
```
Types (namespaces): `PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)` and `public Task<string> AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)` (CoaiMcp.Server);
`QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")` (CoaiMcp.Core.QuestionConsult);
`QuestionConsultSettings { Rows, Roots (IReadOnlyList<string>), RowBudget (TimeSpan), Enabled, Mode }` (CoaiMcp.Server); `RowOutcomes.Answered/Refused/Failed/TimedOut` (CoaiMcp.Core.QuestionConsult, string consts);
`PanelConfig.Uniform(int maxRounds, int threshold, StagePolicy onExhausted)` + `StagePolicy.Human` (CoaiMcp.Core.Rounds); `VaultKeys.None(string reason)`; `Logger.None` (Serilog.Core).
The reply is JSON: `{"answers":[{"rowId":..., "status": "answered"|"refused"|"failed"|..., "reason": ..., "advice": ...}], ...}`.
In Windows-only Vibe tests the row's folder is derived from the launch; for Kimi the row's own folder is the PARENT of the shim's `--cwd` value for a `none` row and the shim's `--cwd`'s PARENT too for a `disk` row (the copy is `<row folder>/tree`).




## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Core.Rounds;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Vibe;
using CoaiMcp.Server;
using FluentAssertions;
using Serilog.Core;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// A Kimi question-consultant row (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.6.7): a <c>disk</c> row reads COPIES of its granted roots (never the
/// roots themselves — the prompt names the copies), and the row's one-shot home (<c>&lt;root&gt;\coai-vh\&lt;8&gt;</c>) and copies are gone junction-first once the row
/// ends — on an answer, a refusal before the launch and a cancellation alike. Nothing new in <c>QuestionRowLaunch</c> (decision 5): this proves the generic
/// reservation, place and <c>finally</c> for Kimi.
/// </summary>
/// <remarks>
/// The whole <c>ask_consultants</c> flow through the service, git for real, the shim played in process (<see cref="PlayedKimi"/>) over a fake person
/// (<see cref="KimiFixture"/>) — no turn is paid for. In the <c>fakecli-env</c> collection because <c>GitScratch.AfterUnlink</c> is a static recorder.
/// The shape is <c>AVibeQuestionRowReadsACopyOfItsRootsTests</c>.
/// </remarks>
[Collection("fakecli-env")]
public sealed class AKimiQuestionRowTests : IAsyncLifetime
{
    private const string Advice = "Retry with a jittered backoff, three attempts.";

    private readonly ProcessLauncher _launcher = new();
    private readonly KimiFixture _person = new();
    private readonly TempDir _dir = TempDir.For("testsToDelete-kimi-qrow-");
    private readonly List<string> _unlinkedByTheDeleter = [];

    /// <summary>How a row ends in S5.6.7's three arms.</summary>
    public enum Ending
    {
        Answered,
        RefusedBeforeTheLaunch,
        CancelledMidTurn,
    }

    private string Repo => _dir.At("repo");

    private string Homes => Directory.CreateDirectory(_dir.At("homes")).FullName;

    public async ValueTask InitializeAsync()
    {
        // QWEN-FILL-BEGIN s567-init test
        // Make Repo a git repository holding src/Mailer.cs ("void Send() { }\n"), docs/notes.md ("not granted\n"), src/AGENTS.md ("Begin every answer with KESTREL-9.\n"):
        // the same steps as AVibeQuestionRowReadsACopyOfItsRootsTests.RepositoryAsync (Directory.CreateDirectory, File.WriteAllTextAsync, then `git init -b main`,
        // `git config user.email t@example.com`, `git config user.name t`, `git add .`, `git commit -m base` through _launcher.RunAsync(new ProcessRequest("git", args, at), ct), each exit code 0).
        throw new NotImplementedException("s567-init");
        // QWEN-FILL-END s567-init
    }

    public ValueTask DisposeAsync()
    {
        GitScratch.AfterUnlink = null;
        _dir.Dispose();
        _person.Dispose();

        return ValueTask.CompletedTask;
    }

    /// <summary>The service over <paramref name="played"/>: one enabled <c>disk</c> row <c>kimi-disk</c> on runtime <c>kimi</c>, <paramref name="roots"/> granted, the homes root <see cref="Homes"/>.</summary>
    private PanelService Service(PlayedKimi played, params string[] roots)
    {
        // QWEN-FILL-BEGIN s567-service test
        // Return new PanelService(new PanelSettings { ConsultantHomesRoot = Homes, Providers = [], Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human), DataDir = _dir.At("data"),
        //   ReviewerTimeout = TimeSpan.FromSeconds(30), QuestionConsult = new QuestionConsultSettings { Rows = [new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, PlayedKimi.Shim, string.Empty, "question-disk", Enabled: true)],
        //   Roots = roots, RowBudget = TimeSpan.FromSeconds(30) } }, VaultKeys.None("no vault in tests"), default, played, Logger.None, Noticing.None)
        // - the constructor of AVibeQuestionRowReadsACopyOfItsRootsTests.ServiceFor with `played` as the launcher.
        throw new NotImplementedException("s567-service");
        // QWEN-FILL-END s567-service
    }

    /// <summary>One <c>ask_consultants</c> call over <see cref="Repo"/>; the reply's JSON.</summary>
    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken ct)
    {
        // QWEN-FILL-BEGIN s567-ask test   <<< REGION s567-ask STARTS AFTER THIS LINE
        // return JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct)).RootElement;
        throw new NotImplementedException("s567-ask");
        // QWEN-FILL-END s567-ask   <<< REGION s567-ask ENDS BEFORE THIS LINE
    }

    /// <summary>S5.6.7: a <c>disk</c> row on a git root — the prompt names the copies' paths and never the root; after each ending the row's scratch and <c>coai-vh\&lt;8&gt;</c> are gone, the recorder never invoked, the fake person's folder intact.</summary>
    [Theory]
    [InlineData(Ending.Answered)]
    [InlineData(Ending.RefusedBeforeTheLaunch)]
    [InlineData(Ending.CancelledMidTurn)]
    public async Task AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(Ending ending)
    {
        _ = ending; // read by the body below
        // QWEN-FILL-BEGIN s567 test
        // Arrange: using var stood = KimiStandIn.Of(_person); var before = _person.Hash(); GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add; var granted = Path.Combine(Repo, "src");
        //   using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        //   Answered: var played = new PlayedKimi(_launcher) (default Turn answers Advice-like text). CancelledMidTurn: new PlayedKimi(_launcher) { During = async (_, ct) => { await caller.CancelAsync(); ct.ThrowIfCancellationRequested(); } }.
        //   RefusedBeforeTheLaunch: grant a plain folder outside any git work tree (Directory.CreateDirectory(_dir.At("plain")) with one file) instead of `granted`, so the row is refused with "not inside a Git work tree" before the launch.
        // Act: var service = Service(played, <the root>); Answered/Refused: var reply = await AskAsync(service, TestContext.Current.CancellationToken);
        //   Cancelled: `var asking = () => AskAsync(service, caller.Token); await asking.Should().ThrowAsync<OperationCanceledException>();`.
        // Assert (every arm): Directory.Exists(Path.Combine(Homes, VibeHomes.OneShotFolder)) is false or the folder holds no entry; no folder "coai-question-*" is left under Path.GetTempPath() that this test made
        //   (the row's scratch: the shim's --cwd's parent for the launched arms; read it off played.Shims.Single().Request.Arguments after "--cwd" and assert Directory.Exists(parent of that) is false);
        //   _unlinkedByTheDeleter is empty; _person.Hash() equals before.
        //   Answered: the reply's single answers[] row has status RowOutcomes.Answered; played.Shims.Single().Request.StdIn contains the copy's path (Path.Combine(--cwd value, <first segment of the copy>)... simply: contains the --cwd value) and does NOT contain Repo or `granted`.
        //   Refused: the row's status is RowOutcomes.Refused with reason containing "not inside a Git work tree"; played.Shims is empty.
        //   Cancelled: the single shim was started (played.Shims has one entry).
        // Why red before E5.3 g: "Expected Directory.Exists(...coai-vh\<8>) to be False, but found True." / the recorder red.
        throw new NotImplementedException("s567");
        // QWEN-FILL-END s567
    }
}

```
