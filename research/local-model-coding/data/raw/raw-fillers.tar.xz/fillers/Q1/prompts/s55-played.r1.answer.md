```csharp
        var played = new PlayedKimi(inner)
        {
            Turn = (_, request) =>
            {
                var content = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md"));
                var marker = content.Trim().Split(' ')[^1].TrimEnd('.');
                if (exit != 0)
                {
                    return new ProcessResult(exit, KimiShimScripts.Report(AcpEnd.AgentFailed, string.Empty, "the agent failed", tokens: false), "the agent failed", TimedOut: false);
                }
                return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 100, 10, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
            }
        };
        return played;
```