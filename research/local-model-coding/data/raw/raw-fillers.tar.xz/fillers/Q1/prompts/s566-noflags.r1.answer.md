```csharp
        if (launch.Confinement is LaunchConfinement.Planned planned && (planned.Plan.Flags.Count > 0 || planned.Plan.Leading.Count > 0))
        {
            throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch));
        }
```