```csharp
        var arguments = played.Shims.Should().ContainSingle().Subject.Request.Arguments.ToList();
        return arguments[arguments.IndexOf(flag) + 1];
```