You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s55-check — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", "--caller", "claude"], played, _temp.Path, _warned.Add, Noticing.None, ct);
return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);   (the same helper as ConsultantCheckTests.Check)

## The exact existing types and members you may use (context pack)
# Context pack — region `s55-check` (test)

File: `src_mcp/tests/AKimiConsultantCheckTests.cs` — the region sits between `QWEN-FILL-BEGIN s55-check test` and `QWEN-FILL-END s55-check`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## The check mode (namespace CoaiMcp.Server, src_mcp/src/Server/Consultation/ConsultantCheckMode.cs)
```csharp
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
```
`Noticing.None` is the null notice sink (namespace CoaiMcp.Server). Stdout is one JSON object: `state` (one of ConsultCheckStates: "answered", "failed", "unavailable", ... ), `markerRead` (bool), the canary reading, ... (see ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself for the asserted fields: `Text(said, "state")`, `said.GetProperty("markerRead").GetBoolean()`).
`ConsultCheckStates` (public static class, namespace CoaiMcp.Server): const strings `Checking`, `Answered`, `Failed`, `Unavailable`, and more below it (grep the file src_mcp/src/Server/Consultation/ConsultCheckState.cs for the cancelled word: it is the record's state for a cancelled check).
The check's scratch is `<tempRoot>/coai-check-<id>`; inside it `own/tree` is the COPY of the scratch repository the turn stands in, and with no homes root the home is `own/kh-<10 hex>`. With a homes root the home is `<root>/coai-vh/<8 hex>/kh-<10 hex>` (`VibeHomes.OneShotFolder == "coai-vh"`, namespace CoaiMcp.Runners.Vibe).
`PanelSettings` (record, namespace CoaiMcp.Server): init props used here: `Providers` (= []), `DataDir`, `ReviewerTimeout` (TimeSpan), `ConsultEnabled` (bool), `ConsultantHomesRoot` (string, empty = none), `Consultants` (IReadOnlyDictionary<string, ConsultantChoice>), `Rounds`, `QuestionConsult`.
`public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "")`; `CallerIdentity.Claude` is the key of the "claude" caller.
The existing model test (ConsultantCheckTests.cs), shaped for Vibe:
```csharp
    private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
        ConsultEnabled = enabled,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe),
        },
    };

    private Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, params string[] args) =>
        Check(settings, new ProcessLauncher(), TestContext.Current.CancellationToken, args);

    private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
    {
        var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

        return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
    }

    private static string Text(JsonElement element, string name) => element.GetProperty(name).GetString() ?? string.Empty;

```
```csharp
    private PanelSettings VibeSettings(string homesRoot) => Settings() with
    {
        ConsultantHomesRoot = homesRoot,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new("mistral", Model: "glm-5-3", Runtime: "vibe", ExecutablePath: PlayedVibe.Exe),
        },
    };
```

## PlayedKimi (namespace CoaiMcp.Tests, src_mcp/tests/PlayedKimi.cs) — copied from the repository
```csharp
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";                       // the shim's executable as the seams name it
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666"; // the session a first turn mints
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                        // every shim launch, in order
    public ConcurrentQueue<ProcessRequest> Versions { get; }             // every `kimi --version`
    public int Peak { get; }
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }  // what the n-th (0-based) shim prints; default = Answered(SessionOf(request), 19973, 31)
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } // runs while a shim is "alive"
    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default); // git etc. run for real through `inner`
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```
Note: a shim launch is only RECORDED in `Shims` in its `finally`, after `During` ran. When `During` throws (cancellation) the launch is still enqueued.
`ProcessRequest` (namespace CoaiMcp.Runners.Processes) has `Executable`, `Arguments` (IReadOnlyList<string>), `WorkingDirectory`, `StdIn`, `Environment`, `InheritsEnvironment`, `Passthrough`. `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`.
The shim's argv (what `KimiRuntime.Build` makes) holds `--ask-acp --profile kimi --model <model> --cwd <dir> --home <dir>`; the flag spellings are constants: `AcpWords.HomeFlag = "--home"`, `AcpWords.SessionFlag = "--session"` (namespace CoaiMcp.Runners.Acp).




## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Runners.Acp;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Vibe;
using CoaiMcp.Server;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// <c>--check-consultant</c> for a Kimi row (E5.5 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.5.1–S5.5.4): the check runs one turn as a consultation
/// makes it — in a COPY of its scratch repository, on a ONE-SHOT owned home (<c>&lt;root&gt;\coai-vh\&lt;8&gt;\kh-&lt;10 hex&gt;</c>), disposed junction-first
/// whatever ended it. Nothing new in the check itself (decision 1): this proves the path <c>KimiConsultant</c> opens (<c>NeedsASanitisedSnapshot</c>,
/// <c>HomesFolder</c>).
/// </summary>
/// <remarks>
/// The check's own code runs for real (<c>ConsultantCheckMode.AnswerAsync</c>, git for real); the shim is played (<see cref="PlayedKimi"/>) over a
/// fake person (<see cref="KimiFixture"/>) — no turn is paid for and the real <c>kimi</c> is never started. Every folder is a
/// <c>testsToDelete-</c> folder of this test. In the <c>fakecli-env</c> collection because <c>GitScratch.AfterUnlink</c> is a static recorder.
/// </remarks>
[Collection("fakecli-env")]
public sealed class AKimiConsultantCheckTests : IDisposable
{
    private readonly KimiFixture _person = new();
    private readonly TempDir _homes = TempDir.For("testsToDelete-kimi-check-homes-");
    private readonly TempDir _data = TempDir.For("testsToDelete-kimi-check-data-");
    private readonly TempDir _temp = TempDir.For("testsToDelete-kimi-check-temp-");
    private readonly List<string> _warned = [];
    private readonly List<string> _unlinkedByTheDeleter = [];

    public void Dispose()
    {
        GitScratch.AfterUnlink = null;
        _temp.Dispose();
        _data.Dispose();
        _homes.Dispose();
        _person.Dispose();
    }

    /// <summary>Settings for the caller <c>claude</c> consulting <c>my-kimi</c> (runtime <c>kimi</c>); <paramref name="homesRoot"/> empty is the hand-built, root-less case.</summary>
    private PanelSettings Settings(string homesRoot)
    {
        // QWEN-FILL-BEGIN s55-settings test
        // Return new PanelSettings { Providers = [], DataDir = _data.Path, ReviewerTimeout = TimeSpan.FromSeconds(60), ConsultEnabled = true,
        //   ConsultantHomesRoot = homesRoot,
        //   Consultants = new Dictionary<string, ConsultantChoice> { [CallerIdentity.Claude] = new("my-kimi", Runtime: "kimi") } }.
        // (ConsultantChoice's first positional parameter is the vendor id; a row with no ExecutablePath is what AKimiConsultationScenarioTests.OnKimi uses.)
        throw new NotImplementedException("s55-settings");
        // QWEN-FILL-END s55-settings
    }

    /// <summary>Runs <c>--check-consultant --caller claude</c> through <c>ConsultantCheckMode.AnswerAsync</c> with <paramref name="played"/> as the launcher.</summary>
    private async Task<(int Code, JsonElement Said, string Err)> CheckAsync(PanelSettings settings, PlayedKimi played, CancellationToken ct)
    {
        // QWEN-FILL-BEGIN s55-check test   <<< REGION s55-check STARTS AFTER THIS LINE
        // var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", "--caller", "claude"], played, _temp.Path, _warned.Add, Noticing.None, ct);
        // return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);   (the same helper as ConsultantCheckTests.Check)
        throw new NotImplementedException("s55-check");
        // QWEN-FILL-END s55-check   <<< REGION s55-check ENDS BEFORE THIS LINE
    }

    /// <summary>A played Kimi whose answer reads the marker out of the CHECK.md of the cwd it was given — the check's own question — and says it cannot read the canary.</summary>
    private static PlayedKimi PlayedThatReadsTheMarker(IProcessLauncher inner, int exit = 0)
    {
        // QWEN-FILL-BEGIN s55-played test
        // Return new PlayedKimi(inner) { Turn = (_, request) => ... } whose Turn reads File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")),
        // takes its last space-separated word without the trailing '.' as the marker (ConsultantCheckTests's PlayedVibe.AnswerFor does `Trim().Split(' ')[^1].TrimEnd('.')`),
        // and answers PlayedKimi.Answered(PlayedKimi.SessionOf(request), 100, 10, $"marker: {marker}{Environment.NewLine}canary: CANNOT").
        // When exit != 0 the turn FAILS instead: return new ProcessResult(exit, KimiShimScripts.Report(AcpEnd.AgentFailed, string.Empty, "the agent failed", tokens: false), "the agent failed", TimedOut: false).
        throw new NotImplementedException("s55-played");
        // QWEN-FILL-END s55-played
    }

    /// <summary>The shim's argument after <paramref name="flag"/> (<c>--cwd</c>, <c>--home</c>) of the one launch the played Kimi saw.</summary>
    private static string ArgumentAfter(PlayedKimi played, string flag)
    {
        // QWEN-FILL-BEGIN s55-arg test
        // var arguments = played.Shims.Should().ContainSingle().Subject.Request.Arguments.ToList(); return arguments[arguments.IndexOf(flag) + 1];
        throw new NotImplementedException("s55-arg");
        // QWEN-FILL-END s55-arg
    }

    /// <summary>S5.5.1: the check passes in a copy, on a one-shot home under <c>&lt;root&gt;\coai-vh\&lt;8&gt;\kh-&lt;10 hex&gt;</c>, and leaves the scratch repository and its canary as they were.</summary>
    [Fact]
    public async Task AKimiCheck_RunsInACopy_OnAOneShotHome()
    {
        // QWEN-FILL-BEGIN s551 test
        // Arrange: using var stood = KimiStandIn.Of(_person); var played = PlayedThatReadsTheMarker(new ProcessLauncher()); var settings = Settings(_homes.Path).
        // Act: var (code, said, _) = await CheckAsync(settings, played, TestContext.Current.CancellationToken).
        // Assert: code 0; said.GetProperty("state").GetString() is "answered" (and "markerRead" true, as ConsultantCheckTests); ArgumentAfter(played, "--cwd") contains
        //   Path.Combine("own", "tree") (a copy in the check's own scratch, never the repository); ArgumentAfter(played, "--home") matches
        //   ^<_homes.Path>[/\\]coai-vh[/\\][0-9a-f]{8}[/\\]kh-[0-9a-f]{10}$ (Regex.Escape the root; VibeHomes.OneShotFolder is "coai-vh");
        //   Directory.EnumerateDirectories(_temp.Path, "coai-check-*") is empty; the check's own invariant (the scratch repository unchanged, the canary untouched)
        //   is already in the "state" and the "canary" fields the check reports - assert the reported canary reading is not "read".
        // Why red before E5.4: the check failed with "the vendor 'my-kimi' runs on 'kimi', which cannot hold a consultation in this build".
        throw new NotImplementedException("s551");
        // QWEN-FILL-END s551
    }

    /// <summary>S5.5.2: the check ends (passed; and a second arm where the turn fails exit 70) — the one-shot folder is gone, the deleter met no link, the person's folder is whole.</summary>
    [Theory]
    [InlineData(0)]
    [InlineData(70)]
    public async Task AfterTheCheck_TheHomeIsGone_JunctionFirst(int turnExit)
    {
        _ = turnExit; // read by the body below
        // QWEN-FILL-BEGIN s552 test
        // Arrange: using var stood = KimiStandIn.Of(_person); var before = _person.Hash(); GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
        //   var played = PlayedThatReadsTheMarker(new ProcessLauncher(), turnExit); settings = Settings(_homes.Path).
        // Act: await CheckAsync(settings, played, TestContext.Current.CancellationToken) (a failed turn is a reported state, not an exception; do not assert code for exit 70).
        // Assert: Directory.Exists(Path.Combine(_homes.Path, VibeHomes.OneShotFolder, <the 8 hex folder>)) is false - read the 8-hex folder name off ArgumentAfter(played, "--home")
        //   (its parent) BEFORE asserting, and also assert the coai-vh folder holds no entry (Directory.EnumerateFileSystemEntries(Path.Combine(_homes.Path, VibeHomes.OneShotFolder)) empty
        //   when it exists); _unlinkedByTheDeleter is empty; _person.Hash() equals before (bytes and ReadOnly bit of the fake person's folder).
        // Why red before E5.3 g: "Expected the deleter's unlink recorder not to be invoked".
        throw new NotImplementedException("s552");
        // QWEN-FILL-END s552
    }

    /// <summary>S5.5.3: the played shim blocks, the token is cancelled — the record says cancelled, and the home is gone junction-first (pins the check's <c>finally</c>).</summary>
    [Fact]
    public async Task ACheckCancelledMidTurn_StillDisposesItsHome()
    {
        // QWEN-FILL-BEGIN s553 test
        // Arrange: using var stood = KimiStandIn.Of(_person); using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        //   GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add; var played = new PlayedKimi(new ProcessLauncher()) { During = async (_, ct) => { await cts.CancelAsync(); ct.ThrowIfCancellationRequested(); } };
        //   (PlayedKimi.During is Func<ProcessRequest, CancellationToken, Task>, run while the shim is alive.)
        // Act: var (code, said, _) = await CheckAsync(Settings(_homes.Path), played, cts.Token) - if the check lets OperationCanceledException out, catch it with
        //   `var running = () => CheckAsync(...); await running.Should().ThrowAsync<OperationCanceledException>();` and then read the state file instead:
        //   Path.Combine(_data.Path, "consultations", "health", "claude.check.json") whose "state" is ConsultCheckStates.Cancelled when such a constant exists (grep ConsultCheckStates).
        // Assert: the record (the reply's "state" or the state file) says cancelled; the one-shot folder under Path.Combine(_homes.Path, VibeHomes.OneShotFolder) holds no entry;
        //   _unlinkedByTheDeleter is empty.
        throw new NotImplementedException("s553");
        // QWEN-FILL-END s553
    }

    /// <summary>S5.5.4: settings built by hand have no homes root — the home stays in the check's scratch (<c>&lt;scratch&gt;\own\kh-…</c>) and goes with it, junction-first.</summary>
    [Fact]
    public async Task ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst()
    {
        // QWEN-FILL-BEGIN s554 test
        // Arrange: using var stood = KimiStandIn.Of(_person); GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add; var before = _person.Hash();
        //   var played = PlayedThatReadsTheMarker(new ProcessLauncher()); var settings = Settings(string.Empty).
        // Act: await CheckAsync(settings, played, TestContext.Current.CancellationToken).
        // Assert: ArgumentAfter(played, "--home") contains Path.Combine("own", "kh-") (under <scratch>\own); after the check the home's parent folder (the check's scratch, <_temp>/coai-check-*)
        //   no longer exists: Directory.EnumerateDirectories(_temp.Path, "coai-check-*") empty; Directory.Exists(<the --home value>) false; _unlinkedByTheDeleter empty; _person.Hash() equals before.
        // Why red before E5.3 g: "Expected the deleter's unlink recorder not to be invoked".
        throw new NotImplementedException("s554");
        // QWEN-FILL-END s554
    }
}

```
