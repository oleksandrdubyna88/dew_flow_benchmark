# Context pack — region `s567-service` (test)

File: `src_mcp/tests/AKimiQuestionRowTests.cs` — the region sits between `QWEN-FILL-BEGIN s567-service test` and `QWEN-FILL-END s567-service`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## The question row service test (the model: AVibeQuestionRowReadsACopyOfItsRootsTests) — copied from the repository
```csharp
    }

    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        Directory.CreateDirectory(at);
        foreach (var (path, text) in files)
        {
            var full = Path.Combine([at, .. path.Split('/')]);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }

        foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
        }
    }

    private PanelService Service(PlayedVibe vibe, params string[] roots) => ServiceOn(vibe, string.Empty, roots);
    private PanelService ServiceWithModel(PlayedVibe vibe, string model, params string[] roots) => ServiceFor(vibe, string.Empty, model, roots);

    /// <summary>The service with a homes root: a home-keeping row reserves its one-shot folder there (D1).</summary>
    private PanelService ServiceOn(PlayedVibe vibe, string homesRoot, params string[] roots) => ServiceFor(vibe, homesRoot, "glm-5-3", roots);

    private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
        new PanelSettings
        {
            ConsultantHomesRoot = homesRoot,
            Providers = [],
            Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
            DataDir = _dir.At("data"),
            ReviewerTimeout = TimeSpan.FromSeconds(30),
            QuestionConsult = new QuestionConsultSettings
            {
                Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
                Roots = roots,
                RowBudget = TimeSpan.FromSeconds(30),
            },
        },
        VaultKeys.None("no vault in tests"),
        default,
        vibe,
        Logger.None,
        Noticing.None);

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
```
Types (namespaces): `PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)` and `public Task<string> AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)` (CoaiMcp.Server);
`QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")` (CoaiMcp.Core.QuestionConsult);
`QuestionConsultSettings { Rows, Roots (IReadOnlyList<string>), RowBudget (TimeSpan), Enabled, Mode }` (CoaiMcp.Server); `RowOutcomes.Answered/Refused/Failed/TimedOut` (CoaiMcp.Core.QuestionConsult, string consts);
`PanelConfig.Uniform(int maxRounds, int threshold, StagePolicy onExhausted)` + `StagePolicy.Human` (CoaiMcp.Core.Rounds); `VaultKeys.None(string reason)`; `Logger.None` (Serilog.Core).
The reply is JSON: `{"answers":[{"rowId":..., "status": "answered"|"refused"|"failed"|..., "reason": ..., "advice": ...}], ...}`.
In Windows-only Vibe tests the row's folder is derived from the launch; for Kimi the row's own folder is the PARENT of the shim's `--cwd` value for a `none` row and the shim's `--cwd`'s PARENT too for a `disk` row (the copy is `<row folder>/tree`).

## TempDir (namespace CoaiMcp.Tests, src_mcp/tests/TempDir.cs)
```csharp
public sealed class TempDir : IDisposable {
    public string Path { get; }
    public static TempDir For(string prefix);               // a fresh folder under the OS temp
    public static implicit operator string(TempDir directory); // = directory.Path
    public string At(params string[] parts);                // Path.Combine(Path, parts...)
    public void Dispose();
}
```

## PlayedKimi (namespace CoaiMcp.Tests, src_mcp/tests/PlayedKimi.cs) — copied from the repository
```csharp
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";                       // the shim's executable as the seams name it
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666"; // the session a first turn mints
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                        // every shim launch, in order
    public ConcurrentQueue<ProcessRequest> Versions { get; }             // every `kimi --version`
    public int Peak { get; }
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }  // what the n-th (0-based) shim prints; default = Answered(SessionOf(request), 19973, 31)
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } // runs while a shim is "alive"
    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default); // git etc. run for real through `inner`
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```
Note: a shim launch is only RECORDED in `Shims` in its `finally`, after `During` ran. When `During` throws (cancellation) the launch is still enqueued.
`ProcessRequest` (namespace CoaiMcp.Runners.Processes) has `Executable`, `Arguments` (IReadOnlyList<string>), `WorkingDirectory`, `StdIn`, `Environment`, `InheritsEnvironment`, `Passthrough`. `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`.
The shim's argv (what `KimiRuntime.Build` makes) holds `--ask-acp --profile kimi --model <model> --cwd <dir> --home <dir>`; the flag spellings are constants: `AcpWords.HomeFlag = "--home"`, `AcpWords.SessionFlag = "--session"` (namespace CoaiMcp.Runners.Acp).

Usings already in the file: System.Text.Json, CoaiMcp.Core.QuestionConsult, CoaiMcp.Core.Rounds, CoaiMcp.Runners.Files/Processes/Vibe, CoaiMcp.Server, FluentAssertions, Serilog.Core, Xunit. `Homes` is a private property of the class (the homes root).
