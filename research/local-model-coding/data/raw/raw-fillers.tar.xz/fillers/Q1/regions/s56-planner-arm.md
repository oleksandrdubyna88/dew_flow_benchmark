# Context pack — region `s56-planner-arm` (prod)

File: `src_mcp/core/QuestionConsult/ConfinementPlanner.cs` — the region sits between `QWEN-FILL-BEGIN s56-planner-arm prod` and `QWEN-FILL-END s56-planner-arm`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## Capability table types (namespace CoaiMcp.Core.QuestionConsult) — copied from the repository
```csharp
public enum Capability { None, Disk, Web }
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability) -> RuntimeCapabilityRow?   // null for a pair not in the table
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
public abstract record Admission { sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag); sealed record Refused(string Reason); }
CapabilityMatrix.Admit(string runtime, Capability capability) -> Admission
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots) { static None; static Web; static Disk(params string[] roots); }
public enum CwdKind { Scratch, Root, Snapshot }
ConfinementPlanner.Plan(string runtime, CapabilityGrant grant) -> Confinement   // Confinement.Planned or Confinement.Refused(string Reason)
public sealed record Confinement.Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag)
{ public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
```
The Kimi rows now in shared/runtime-capabilities.json (the skeleton wrote them): kimi × none and × disk are `unconfined`, cli "kimi", version "2.1.1", date "2026-10-13", resultRef citing research/RESULTS_kimi_confinement.md; none's cells: M-K6, M-K3, M-K4; disk's: M-K6, M-K3, M-K4, M-K9; kimi × web is `unmeasured` with no cell. The unmeasured sentence of the matrix: "'kimi' has not been measured for 'web' (...) — a measured cell in research/RESULTS_kimi_confinement.md is what admits it; ...".

## Existing sibling to copy (same file)
```csharp
        _ => new("antigravity", grant, [], ["--mode", "plan"], CwdKind.Scratch, [], flag),
    };

    /// <remarks>
    /// D2's pair on every capability, never <c>--trust</c> or <c>--add-dir</c> (D3: a trusted folder runs its hooks, and
    /// <c>--add-dir</c> trusts its folder). Vibe reads only its working folder (M-V11, 6 of 6), so a disk row's roots are
    /// COPIED into the snapshot it stands in (D6) and named to it there; a none row stands in an empty folder.
    /// </remarks>
    private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
```
`Kimi(...)` is the skeleton's private static method, called from `Fragments` as `"kimi" => Kimi(grant, flag)`. Its summary says: no flags, ever; a disk row stands in a COPY of its roots (`CwdKind.Snapshot`, `SnapshotSources = grant.Roots`), a none row in an empty folder (`CwdKind.Scratch`).
