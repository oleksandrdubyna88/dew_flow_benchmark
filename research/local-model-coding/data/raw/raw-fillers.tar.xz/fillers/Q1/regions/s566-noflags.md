# Context pack — region `s566-noflags` (prod)

File: `src_mcp/runners/Kimi/KimiConsultant.cs` — the region sits between `QWEN-FILL-BEGIN s566-noflags prod` and `QWEN-FILL-END s566-noflags`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## Capability table types (namespace CoaiMcp.Core.QuestionConsult) — copied from the repository
```csharp
public enum Capability { None, Disk, Web }
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
RuntimeCapabilities.Builtin.Of(string runtime, Capability capability) -> RuntimeCapabilityRow?   // null for a pair not in the table
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
public abstract record Admission { sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag); sealed record Refused(string Reason); }
CapabilityMatrix.Admit(string runtime, Capability capability) -> Admission
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots) { static None; static Web; static Disk(params string[] roots); }
public enum CwdKind { Scratch, Root, Snapshot }
ConfinementPlanner.Plan(string runtime, CapabilityGrant grant) -> Confinement   // Confinement.Planned or Confinement.Refused(string Reason)
public sealed record Confinement.Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag)
{ public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
```
The Kimi rows now in shared/runtime-capabilities.json (the skeleton wrote them): kimi × none and × disk are `unconfined`, cli "kimi", version "2.1.1", date "2026-10-13", resultRef citing research/RESULTS_kimi_confinement.md; none's cells: M-K6, M-K3, M-K4; disk's: M-K6, M-K3, M-K4, M-K9; kimi × web is `unmeasured` with no cell. The unmeasured sentence of the matrix: "'kimi' has not been measured for 'web' (...) — a measured cell in research/RESULTS_kimi_confinement.md is what admits it; ...".

## Context
The method is `private static void MustCarryNoPlanFlags(ConsultantLaunch launch)` in `KimiConsultant` (namespace CoaiMcp.Runners.Kimi), called first in `Build`. `launch.Confinement` is a `LaunchConfinement`: `LaunchConfinement.Shipped` (a consultation) or `LaunchConfinement.Planned(Confinement.Planned Plan)` (a question row). `using CoaiMcp.Core.QuestionConsult;` and `using CoaiMcp.Runners.Consultation;` are already in the file.
The sibling guards in the same file throw like this:
```csharp

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
```
The plan the Kimi planner arm makes has EMPTY `Flags` and `Leading`; a hand-made plan with `Flags: ["--yolo"]` must be refused with an `ArgumentException` whose message names the shim ("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi"). Cyclomatic complexity <= 4.
