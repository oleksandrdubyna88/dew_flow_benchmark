# Context pack — region `s567-ask` (test)

File: `src_mcp/tests/AKimiQuestionRowTests.cs` — the region sits between `QWEN-FILL-BEGIN s567-ask test` and `QWEN-FILL-END s567-ask`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## The question row service test (the model: AVibeQuestionRowReadsACopyOfItsRootsTests) — copied from the repository
```csharp
    }

    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        Directory.CreateDirectory(at);
        foreach (var (path, text) in files)
        {
            var full = Path.Combine([at, .. path.Split('/')]);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }

        foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
        }
    }

    private PanelService Service(PlayedVibe vibe, params string[] roots) => ServiceOn(vibe, string.Empty, roots);
    private PanelService ServiceWithModel(PlayedVibe vibe, string model, params string[] roots) => ServiceFor(vibe, string.Empty, model, roots);

    /// <summary>The service with a homes root: a home-keeping row reserves its one-shot folder there (D1).</summary>
    private PanelService ServiceOn(PlayedVibe vibe, string homesRoot, params string[] roots) => ServiceFor(vibe, homesRoot, "glm-5-3", roots);

    private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
        new PanelSettings
        {
            ConsultantHomesRoot = homesRoot,
            Providers = [],
            Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
            DataDir = _dir.At("data"),
            ReviewerTimeout = TimeSpan.FromSeconds(30),
            QuestionConsult = new QuestionConsultSettings
            {
                Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
                Roots = roots,
                RowBudget = TimeSpan.FromSeconds(30),
            },
        },
        VaultKeys.None("no vault in tests"),
        default,
        vibe,
        Logger.None,
        Noticing.None);

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
```
Types (namespaces): `PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)` and `public Task<string> AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)` (CoaiMcp.Server);
`QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")` (CoaiMcp.Core.QuestionConsult);
`QuestionConsultSettings { Rows, Roots (IReadOnlyList<string>), RowBudget (TimeSpan), Enabled, Mode }` (CoaiMcp.Server); `RowOutcomes.Answered/Refused/Failed/TimedOut` (CoaiMcp.Core.QuestionConsult, string consts);
`PanelConfig.Uniform(int maxRounds, int threshold, StagePolicy onExhausted)` + `StagePolicy.Human` (CoaiMcp.Core.Rounds); `VaultKeys.None(string reason)`; `Logger.None` (Serilog.Core).
The reply is JSON: `{"answers":[{"rowId":..., "status": "answered"|"refused"|"failed"|..., "reason": ..., "advice": ...}], ...}`.
In Windows-only Vibe tests the row's folder is derived from the launch; for Kimi the row's own folder is the PARENT of the shim's `--cwd` value for a `none` row and the shim's `--cwd`'s PARENT too for a `disk` row (the copy is `<row folder>/tree`).


