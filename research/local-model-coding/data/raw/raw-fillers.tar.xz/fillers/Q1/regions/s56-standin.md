# Context pack — region `s56-standin` (test)

File: `src_mcp/tests/KimiStandIn.cs` — the region sits between `QWEN-FILL-BEGIN s56-standin test` and `QWEN-FILL-END s56-standin`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## KimiFixture (namespace CoaiMcp.Tests, src_mcp/tests/KimiFixture.cs) — the fake person
```csharp
internal sealed class KimiFixture : IDisposable {
    public KimiFixture(string? config = null);   // builds a fake ~/.kimi-code INSIDE its own testsToDelete-kimi- folder
    public string Folder { get; }                // the folder everything lives in
    public string PersonsHome { get; }           // the fake person's ~/.kimi-code
    public string Credentials { get; }
    public string PersonsConfig { get; }
    public KimiPlaces PlacesAt(string ownedRoot); // places for an owned root ANYWHERE (what a runtime picks: kh-<hash>)
    public IReadOnlyList<string> Hash();          // every entry of the person's folder: relative path, attributes, SHA-256 — "whole" means unchanged
    public void Dispose();
}
```
Other test helpers: `WindowsStandIn.Begin()` (IDisposable; on non-Windows it stands in a symlink for a junction); `KimiStandIn.Of(KimiFixture person)` (this skeleton, src_mcp/tests/KimiStandIn.cs) puts the fake person, the Windows host and the lock root in scope for adapters built BY NAME.
`GitScratch.AfterUnlink` (namespace CoaiMcp.Runners.Files, `internal static Action<string>? AfterUnlink { get; set; }`) is the test-only recorder of the SHARED DELETER meeting a link: a home disposed junction-first by `KimiHome` never lets the deleter meet its junction, so the recorder must stay empty. Always set it to `list.Add` and reset it to `null` (the class's Dispose does reset it).

## PlayedKimi (namespace CoaiMcp.Tests, src_mcp/tests/PlayedKimi.cs) — copied from the repository
```csharp
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";                       // the shim's executable as the seams name it
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666"; // the session a first turn mints
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                        // every shim launch, in order
    public ConcurrentQueue<ProcessRequest> Versions { get; }             // every `kimi --version`
    public int Peak { get; }
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }  // what the n-th (0-based) shim prints; default = Answered(SessionOf(request), 19973, 31)
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } // runs while a shim is "alive"
    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default); // git etc. run for real through `inner`
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```
Note: a shim launch is only RECORDED in `Shims` in its `finally`, after `During` ran. When `During` throws (cancellation) the launch is still enqueued.
`ProcessRequest` (namespace CoaiMcp.Runners.Processes) has `Executable`, `Arguments` (IReadOnlyList<string>), `WorkingDirectory`, `StdIn`, `Environment`, `InheritsEnvironment`, `Passthrough`. `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`.
The shim's argv (what `KimiRuntime.Build` makes) holds `--ask-acp --profile kimi --model <model> --cwd <dir> --home <dir>`; the flag spellings are constants: `AcpWords.HomeFlag = "--home"`, `AcpWords.SessionFlag = "--session"` (namespace CoaiMcp.Runners.Acp).

## The existing private helper to copy (AKimiConsultationScenarioTests, minus CallingAs)
```csharp

    /// <summary>The homes root, inside the scenario's data directory — removed with it, and never the machine's own local data.</summary>
    private string Homes => Directory.CreateDirectory(Path.Combine(_data, "homes")).FullName;

    private string FolderOf(string id) => ConsultantHomes.ConversationFolder(Homes, ConsultantHomes.Kimi, id);

    /// <summary>Several scopes, given back in reverse.</summary>
    private sealed class Scopes(params IDisposable[] scopes) : IDisposable
    {
        public void Dispose()
        {
            foreach (var scope in scopes.Reverse())
            {
                scope.Dispose();
            }
        }
    }

    /// <summary>
    /// The person, the host and the lock root this flow's Kimi adapters see — set by a SYNCHRONOUS call, so the values reach the test's own flow
    /// and every service call it awaits.
    /// </summary>
    private static Scopes StandIn(KimiFixture person) => new(
        WindowsStandIn.Begin(),
        KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
        KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),
        CallingAs("CLAUDE_CODE_SESSION_ID"));
```
Usings you need in KimiStandIn.cs: the file already has `CoaiMcp.Runners.Kimi` and `CoaiMcp.Runners.Platform`. `KimiSeams.Using(HostKind host, KimiSeams seams)` and `KimiCredentialsLock.RootFor(string folder)` both return IDisposable (the first is `internal`, visible to the tests). Define the `Scopes` class as a private nested class of `KimiStandIn` (inside the FILL region you may not add members outside the method; a local sealed class declared inside the method body is fine, or a local function that disposes in reverse).
