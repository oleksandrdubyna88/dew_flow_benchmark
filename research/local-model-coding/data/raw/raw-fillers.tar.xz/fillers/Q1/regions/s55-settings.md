# Context pack — region `s55-settings` (test)

File: `src_mcp/tests/AKimiConsultantCheckTests.cs` — the region sits between `QWEN-FILL-BEGIN s55-settings test` and `QWEN-FILL-END s55-settings`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## The check mode (namespace CoaiMcp.Server, src_mcp/src/Server/Consultation/ConsultantCheckMode.cs)
```csharp
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
```
`Noticing.None` is the null notice sink (namespace CoaiMcp.Server). Stdout is one JSON object: `state` (one of ConsultCheckStates: "answered", "failed", "unavailable", ... ), `markerRead` (bool), the canary reading, ... (see ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself for the asserted fields: `Text(said, "state")`, `said.GetProperty("markerRead").GetBoolean()`).
`ConsultCheckStates` (public static class, namespace CoaiMcp.Server): const strings `Checking`, `Answered`, `Failed`, `Unavailable`, and more below it (grep the file src_mcp/src/Server/Consultation/ConsultCheckState.cs for the cancelled word: it is the record's state for a cancelled check).
The check's scratch is `<tempRoot>/coai-check-<id>`; inside it `own/tree` is the COPY of the scratch repository the turn stands in, and with no homes root the home is `own/kh-<10 hex>`. With a homes root the home is `<root>/coai-vh/<8 hex>/kh-<10 hex>` (`VibeHomes.OneShotFolder == "coai-vh"`, namespace CoaiMcp.Runners.Vibe).
`PanelSettings` (record, namespace CoaiMcp.Server): init props used here: `Providers` (= []), `DataDir`, `ReviewerTimeout` (TimeSpan), `ConsultEnabled` (bool), `ConsultantHomesRoot` (string, empty = none), `Consultants` (IReadOnlyDictionary<string, ConsultantChoice>), `Rounds`, `QuestionConsult`.
`public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "")`; `CallerIdentity.Claude` is the key of the "claude" caller.
The existing model test (ConsultantCheckTests.cs), shaped for Vibe:
```csharp
    private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
        ConsultEnabled = enabled,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe),
        },
    };

    private Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, params string[] args) =>
        Check(settings, new ProcessLauncher(), TestContext.Current.CancellationToken, args);

    private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
    {
        var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

        return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
    }

    private static string Text(JsonElement element, string name) => element.GetProperty(name).GetString() ?? string.Empty;

```
```csharp
    private PanelSettings VibeSettings(string homesRoot) => Settings() with
    {
        ConsultantHomesRoot = homesRoot,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new("mistral", Model: "glm-5-3", Runtime: "vibe", ExecutablePath: PlayedVibe.Exe),
        },
    };
```

## TempDir (namespace CoaiMcp.Tests, src_mcp/tests/TempDir.cs)
```csharp
public sealed class TempDir : IDisposable {
    public string Path { get; }
    public static TempDir For(string prefix);               // a fresh folder under the OS temp
    public static implicit operator string(TempDir directory); // = directory.Path
    public string At(params string[] parts);                // Path.Combine(Path, parts...)
    public void Dispose();
}
```


