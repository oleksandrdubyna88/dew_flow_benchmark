# Context pack — region `s55-arg` (test)

File: `src_mcp/tests/AKimiConsultantCheckTests.cs` — the region sits between `QWEN-FILL-BEGIN s55-arg test` and `QWEN-FILL-END s55-arg`. Read the comment inside the region: it is the spec of the body.

## Rules of this repository that matter for the body
- C# 14 / .NET 10, file-scoped namespaces, 4-space indent, braces always, blank line before a `return` that follows other statements. Tests: xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`) and FluentAssertions (`.Should()`).
- Cyclomatic complexity <= 4 per method. No new public API beyond what the skeleton declares. Match the surrounding comment density: a short sentence, not a paragraph.
- Anything a test makes outside its process is named `testsToDelete-<what>-`: use `TempDir.For("testsToDelete-...")`. Never touch the developer's real ~/.kimi-code; the fake person is `KimiFixture`. Never run a real `kimi`.
- Keep every line of the skeleton outside the FILL region exactly as it is. Replace ONLY the lines between QWEN-FILL-BEGIN and QWEN-FILL-END (the `throw new NotImplementedException(...)` goes away).

## PlayedKimi (namespace CoaiMcp.Tests, src_mcp/tests/PlayedKimi.cs) — copied from the repository
```csharp
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";                       // the shim's executable as the seams name it
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666"; // the session a first turn mints
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                        // every shim launch, in order
    public ConcurrentQueue<ProcessRequest> Versions { get; }             // every `kimi --version`
    public int Peak { get; }
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }  // what the n-th (0-based) shim prints; default = Answered(SessionOf(request), 19973, 31)
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } // runs while a shim is "alive"
    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default); // git etc. run for real through `inner`
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```
Note: a shim launch is only RECORDED in `Shims` in its `finally`, after `During` ran. When `During` throws (cancellation) the launch is still enqueued.
`ProcessRequest` (namespace CoaiMcp.Runners.Processes) has `Executable`, `Arguments` (IReadOnlyList<string>), `WorkingDirectory`, `StdIn`, `Environment`, `InheritsEnvironment`, `Passthrough`. `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`.
The shim's argv (what `KimiRuntime.Build` makes) holds `--ask-acp --profile kimi --model <model> --cwd <dir> --home <dir>`; the flag spellings are constants: `AcpWords.HomeFlag = "--home"`, `AcpWords.SessionFlag = "--session"` (namespace CoaiMcp.Runners.Acp).


