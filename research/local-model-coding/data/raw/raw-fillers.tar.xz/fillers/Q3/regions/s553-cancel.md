# Region `s553-cancel` (test) — `src_mcp/tests/AKimiConsultantCheckTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

Same helpers as `s551-check`. A cancelled check answers a record with `state` "failed" and `failureKind` "cancelled" (see the cancelled test below), not an exception.

### The check mode and the existing test harness — `src_mcp/tests/ConsultantCheckTests.cs:56-90`

```csharp
            try
            {
                Directory.Delete(dir, recursive: true);
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                // A leftover temp directory is not a failing test.
            }
        }
    }

    private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
        ConsultEnabled = enabled,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe),
        },
    };

    private Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, params string[] args) =>
        Check(settings, new ProcessLauncher(), TestContext.Current.CancellationToken, args);

    private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
    {
        var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

        return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
    }

    private static string Text(JsonElement element, string name) => element.GetProperty(name).GetString() ?? string.Empty;
```
### AnswerAsync — `src_mcp/src/Server/Consultation/ConsultantCheckMode.cs:94-103`

```csharp
    /// <summary>The exit code, what goes to stdout and what goes to stderr — the whole mode, with no console in it.</summary>
    /// <param name="tempRoot">Where the scratch repository is made — the temp directory, a test's own in a test.</param>
    /// <param name="warn">Where a problem that does not change the outcome is said — stderr.</param>
    internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
        PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct)
        => await AnswerAsync(settings, args, launcher, tempRoot, warn, noticing, ct, VaultKeys.None("no vault was read"));

    /// <param name="keys">The vault, for a consultant on an api row or somebody else's endpoint.</param>
    internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
        PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct, VaultKeys keys)
```
### The Vibe check test — the model — `src_mcp/tests/ConsultantCheckTests.cs:494-526`

```csharp
    [Fact]
    public async Task AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself()
    {
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Vibe is refused on every host but Windows");
        using var noBudget = CoaiMcp.Runners.Vibe.VibePathBudget.Using(CoaiMcp.Runners.Vibe.VibePathBudget.None);
        var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
        {
            AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
        };
        using var homes = TempDir.For("testsToDelete-vh-check-");
        var settings = Settings() with
        {
            ConsultantHomesRoot = homes,
            Consultants = new Dictionary<string, ConsultantChoice>
            {
                [CallerIdentity.Claude] = new("mistral", Model: "glm-5-3", Runtime: "vibe", ExecutablePath: PlayedVibe.Exe),
            },
        };

        var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");

        code.Should().Be(0);
        Text(said, "state").Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
        var turn = vibe.Turns.Should().ContainSingle().Subject;
        turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
        var home = turn.Request.Environment[Runners.Vibe.VibeLaunch.HomeVariable]!;
        home.Should().StartWith(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar, "D1: under the short homes root, never under TEMP");
        Path.GetFileName(home).Should().Be("h");
        (home.Length - homes.Path.Length).Should().BeLessThanOrEqualTo(19, "A10: what the check's layout costs beyond the root (`/coai-vh/<8>/h`) fits the Windows budget at the default root");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
        Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
    }
```
### The cancelled check test — `src_mcp/tests/ConsultantCheckTests.cs:460-473`

```csharp
    [Fact]
    public async Task ACheckCancelledWhileItsScratchIsMade_IsCancelled_NotUnavailable()
    {
        CodexAnswers("marker: x");
        using var cancelled = new CancellationTokenSource();
        await cancelled.CancelAsync();

        var (code, said, _) = await Check(Settings(), new ProcessLauncher(), cancelled.Token, "--caller", "claude");

        code.Should().Be(0);
        Text(said, "state").Should().Be("failed", said.ToString());
        Text(said, "failureKind").Should().Be("cancelled");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty();
    }
```

### PlayedKimi (the played shim; namespace CoaiMcp.Tests) — `src_mcp/tests/PlayedKimi.cs:14-106`

```csharp
/// Each shim launch is kept with the moment it started and ended, and the number of shims alive at once is counted — what the scenarios of one
/// sign-in assert (decision k of E5.3). Shaped like <c>PlayedVibe</c>; no turn is paid for.
/// </remarks>
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    /// <summary>The shim's executable as the seams name it — never started, only recognised.</summary>
    public const string Shim = "played-coai-mcp";

    /// <summary>The session the played agent mints on a first turn.</summary>
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";

    private int _started;
    private int _running;
    private int _peak;

    /// <summary>One shim launch: what it was asked, and when it ran.</summary>
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);

    public ConcurrentQueue<Launch> Shims { get; } = new();

    public ConcurrentQueue<ProcessRequest> Versions { get; } = new();

    /// <summary>The most shims ever running at once.</summary>
    public int Peak => _peak;

    /// <summary>What the n-th shim launch (0-based) prints — by default an answered turn of the default totals.</summary>
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; } = static (_, request) => Answered(SessionOf(request), 19973, 31);

    /// <summary>Runs while a shim is "alive", after its start is stamped — a test's seam for what holds at that moment.</summary>
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } = static (_, _) => Task.CompletedTask;

    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default)
    {
        if (request.Arguments is ["--version"])
        {
            Versions.Enqueue(request);

            return new ProcessResult(0, "kimi 2.1.1\r\n", string.Empty, TimedOut: false);
        }

        return string.Equals(request.Executable, Shim, StringComparison.Ordinal) ? await ShimAsync(request, ct) : await inner.RunAsync(request, ct);
    }

    private async Task<ProcessResult> ShimAsync(ProcessRequest request, CancellationToken ct)
    {
        var index = Interlocked.Increment(ref _started) - 1;
        var start = DateTime.UtcNow;
        InterlockedMax(Interlocked.Increment(ref _running));
        try
        {
            await During(request, ct);

            return Turn(index, request);
        }
        finally
        {
            Interlocked.Decrement(ref _running);
            Shims.Enqueue(new Launch(request, start, DateTime.UtcNow));
        }
    }

    private void InterlockedMax(int value)
    {
        int seen;
        while ((seen = Volatile.Read(ref _peak)) < value && Interlocked.CompareExchange(ref _peak, value, seen) != seen)
        {
        }
    }

    /// <summary>The session a launch continues (<c>--session</c>), else the one the played agent mints.</summary>
    public static string SessionOf(ProcessRequest request)
    {
        var at = request.Arguments.ToList().IndexOf(AcpWords.SessionFlag);

        return at >= 0 ? request.Arguments[at + 1] : Minted;
    }

    /// <summary>An answered turn whose <c>/usage</c> gave the session's CUMULATIVE totals.</summary>
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, session: session, tokensIn: tokensIn, tokensOut: tokensOut), string.Empty, TimedOut: false);

    /// <summary>An answered turn whose <c>/usage</c> said nothing parseable: <c>notCaptured</c>.</summary>
    public static ProcessResult Uncaptured(string session, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, tokens: false, session: session), string.Empty, TimedOut: false);

    /// <summary>A continued turn whose session the agent no longer holds: end <c>session_lost</c>, exit 70 (E5.2).</summary>
    public static ProcessResult Lost(string session) =>
        new(70, KimiShimScripts.Report(AcpEnd.SessionLost, string.Empty, $"the agent could not load session {session}: -32602 Unknown sessionId: <id>", tokens: false, session: session),
            $"the agent could not load session {session}\r\n", TimedOut: false);

    /// <summary>The advice every answered turn gives unless told otherwise.</summary>
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```

### KimiFixture members (namespace CoaiMcp.Tests, internal sealed, IDisposable) — `src_mcp/tests/KimiFixture.cs:15-58`

```csharp
internal sealed class KimiFixture : IDisposable
{
    /// <summary>The refresh-token canary: lives in the fake <c>credentials</c> file and must never appear in anything coai writes (decision 12).</summary>
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";

    /// <summary>The api-key canary: lives in the fake <c>config.toml</c>'s <c>moonshot-ai</c> row.</summary>
    public const string ApiKeyCanary = "CANARY-APIKEY-2b91e4";

    public const string SlotKey = "oauth/kimi-code-env-x";

    public const string BaseUrl = "https://api.kimi.com/coding/v1";

    public const string OauthHost = "https://auth.kimi.com";

    private readonly TempDir _dir = TempDir.For("testsToDelete-kimi-");

    public KimiFixture(string? config = null)
    {
        Directory.CreateDirectory(Credentials);
        Directory.CreateDirectory(Bin);
        File.WriteAllText(PersonsConfig, config ?? OwnerConfig());
        ReadOnly(Path.Combine(Credentials, "kimi-code-env-x.json"), $$"""{"refresh_token": "{{RefreshCanary}}", "access_token": "not-a-real-one"}""");
        ReadOnly(Path.Combine(Credentials, "kimi-code.json"), """{"refresh_token": "not-a-real-one-either"}""");
        foreach (var tool in (string[])["kimi.exe", "rg.exe", "fd.exe"])
        {
            File.WriteAllBytes(Path.Combine(Bin, tool), []);
        }
    }

    /// <summary>The folder every part of the fixture lives in.</summary>
    public string Folder => _dir.Path;

    /// <summary>The fake person's <c>~/.kimi-code</c>.</summary>
    public string PersonsHome => _dir.At("persons", ".kimi-code");

    public string Credentials => Path.Combine(PersonsHome, "credentials");

    public string PersonsConfig => Path.Combine(PersonsHome, "config.toml");

    public string Bin => Path.Combine(PersonsHome, "bin");

    /// <summary>The fake profile folder — what <c>KimiPlaces.Resolve</c> is given as the real profile.</summary>
    public string Profile => _dir.At("persons");

```

`Hash()` returns `IReadOnlyList<string>` — the names, attributes and SHA-256 of every entry of the person's folder (`PersonsHome`); two lists are equal when nothing was touched. `PlacesAt(string ownedRoot)` returns `KimiPlaces`.

### The stand-in the Kimi scenario tests use (internal, reachable from this class as `AKimiConsultationScenarioTests.StandIn(KimiFixture)`; it returns `AKimiConsultationScenarioTests.Scopes`, an IDisposable — use it in a `using var stood = ...;`) — `src_mcp/tests/AKimiConsultationScenarioTests.cs:36-63`

```csharp

    /// <summary>The homes root, inside the scenario's data directory — removed with it, and never the machine's own local data.</summary>
    private string Homes => Directory.CreateDirectory(Path.Combine(_data, "homes")).FullName;

    private string FolderOf(string id) => ConsultantHomes.ConversationFolder(Homes, ConsultantHomes.Kimi, id);

    /// <summary>Several scopes, given back in reverse.</summary>
    internal sealed class Scopes(params IDisposable[] scopes) : IDisposable
    {
        public void Dispose()
        {
            foreach (var scope in scopes.Reverse())
            {
                scope.Dispose();
            }
        }
    }

    /// <summary>
    /// The person, the host and the lock root this flow's Kimi adapters see — set by a SYNCHRONOUS call, so the values reach the test's own flow
    /// and every service call it awaits.
    /// </summary>
    internal static Scopes StandIn(KimiFixture person) => new(
        WindowsStandIn.Begin(),
        KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
        KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),
        CallingAs("CLAUDE_CODE_SESSION_ID"));

```

`CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder == "coai-vh"`; `VibeHomes.OneShotIn(string root, string id)`. `CoaiMcp.Runners.Files.GitScratch.AfterUnlink` is `internal static Action<string>? AfterUnlink` (settable from tests; reset to null in Dispose). `CoaiMcp.Runners.Acp.AcpWords.HomeFlag == "--home"`, `AcpWords.SessionFlag == "--session"`.

### TempDir (namespace CoaiMcp.Tests) — `src_mcp/tests/TempDir.cs:23-45`

```csharp
public sealed class TempDir : IDisposable
{
    private TempDir(string path) => Path = path;

    /// <summary>Where it is. Also what an implicit conversion to <see cref="string"/> gives you.</summary>
    public string Path { get; }

    /// <summary>A fresh directory under the system temp root, named for the test that wanted it.</summary>
    public static TempDir For(string prefix) =>
        new(Directory.CreateTempSubdirectory(prefix).FullName);

    /// <summary>So it can be passed anywhere a path is taken, without <c>.Path</c> at every call.</summary>
    public static implicit operator string(TempDir directory) => directory.Path;

    /// <summary>A path inside it.</summary>
    public string At(params string[] parts) =>
        System.IO.Path.Combine([Path, .. parts]);

    public void Dispose()
    {
        try
        {
            // The product's deleter: read-only files AND folders (a Vibe home's plugin folders, research/RESULTS_vibe_confinement.md
```
