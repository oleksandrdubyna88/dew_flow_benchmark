# Region `s566-flags` (test) — `src_mcp/tests/ConfinementPlannerTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

The guard `MustCarryNoFlags` is already written in `KimiConsultant`; `Confinement.Planned` is a record, so `plan with { Flags = ["--yolo"] }` is legal (`Flags` is `IReadOnlyList<string>`). `LaunchConfinement.Planned(Confinement.Planned Plan)` wraps it.

### KimiConsultant (production) — `src_mcp/runners/Kimi/KimiConsultant.cs:30-110`

```csharp

    public ConsultantMemory Memory => new ConsultantMemory.VendorRemembers();

    /// <summary>M-K5b (RESULTS §23), and three turns of one session in M-K16 (d): <c>/usage</c> is the session's running total.</summary>
    public bool UsageIsCumulative => true;

    /// <summary>D6: Kimi loads a project <c>.kimi-code</c>, <c>AGENTS.md</c>, skills and <c>.mcp.json</c> from its working folder.</summary>
    public bool NeedsASanitisedSnapshot => true;

    /// <summary>One coai-owned home per conversation, under <see cref="ConsultantHomes.Kimi"/> (J3), swept with it (D20).</summary>
    public string HomesFolder => ConsultantHomes.Kimi;

    /// <summary>Only what was observed working (decision 7): <c>Read</c> inside the copy (M-K6), <c>Grep</c> and <c>Glob</c> (RESULTS §17) — never claimed bounded.</summary>
    public string Toolbox =>
        "You read files with Read, by a path inside your working folder — a copy coai made of the checkout without its .git, .kimi-code/, "
        + ".agents/ skills and sub-agents, .mcp.json and AGENTS.md; Grep and Glob search files too. Every write and every shell command is refused.";

    public ReviewerInvocation Build(ConsultantLaunch launch)
    {
        ConsultantLaunches.MustBeLaunchable(launch);
        MustCarryNoFlags(launch);
        var settings = launch.Settings with { OwnedScratch = OwnedFolder(launch), Model = ModelOf(launch.Settings) };
        var built = inner.Build(ConsultantLaunches.RoleOf(launch), launch.Prompt, Cwd(launch), string.Empty, launch.OutputDir, settings);
        var request = built.Request with { Arguments = [.. built.Request.Arguments, .. SessionOf(launch)] };
        ConsultantLaunches.MustCarryNoLineBreak(request.Arguments);

        return built with { Request = launch.Confinement is LaunchConfinement.Planned ? ConsultantLaunches.ForQuestion(request) : request };
    }

    /// <summary>A planned row's confinement is the shim's (D15), never the argv's: a plan that carries any flag is not one coai made for kimi (decision 3 of E5.6).</summary>
    private static void MustCarryNoFlags(ConsultantLaunch launch)
    {
        if (launch.Confinement is LaunchConfinement.Planned { Plan: { Flags.Count: > 0 } or { Leading.Count: > 0 } })
        {
            throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch));
        }
    }

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
            ? launch.Workdir
            : throw new ArgumentException(
                "a Kimi consultant stands in the conversation's sanitised snapshot (Workdir), and none was made — the checkout is never its working folder (D6)",
                nameof(launch));

    private static string OwnedFolder(ConsultantLaunch launch) =>
        launch.Settings.OwnedScratch.Length > 0
            ? launch.Settings.OwnedScratch
            : throw new ArgumentException(
                "a Kimi consultant keeps its home in a coai-owned folder of the conversation or the row (OwnedScratch), and none was given — never TEMP or the answers folder (D19)",
                nameof(launch));

    /// <summary>The report's <c>sessionId</c> when it is a well-formed handle — the shim names it on every exit that prints a report — or empty.</summary>
    public string ReadHandle(ProcessResult result) =>
        KimiReport.Parse(result.StdOut).SessionId is var id && ConsultantHandle.IsWellFormed(id) ? id : string.Empty;

    /// <summary>The shim's END word says the agent no longer holds the session <c>--session</c> named (E5.2) — read off the report, never its text.</summary>
    public bool DroppedTheConversation(ProcessResult result) => KimiReport.Parse(result.StdOut).End == AcpWords.SessionLostWord;
}

```
### The Adapters() helper and the consult launch test (this class) — `src_mcp/tests/ConfinementPlannerTests.cs:519-530`

```csharp
    private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters() =>
    [
        ("claude", new ClaudeConsultant(new ClaudeRuntime())),
        ("codex", new CodexConsultant(new CodexRuntime())),
        ("antigravity", new AntigravityConsultant(new AntigravityRuntime())),
        ("vibe", new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows))),
        // A fake person's paths, so building reads nothing of this machine: the request names the places, it does not open them.
        ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
            new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))))),
    ];
}

```
### The Vibe question launch test — the shape for S5.6.5 — `src_mcp/tests/ConfinementPlannerTests.cs:368-402`

```csharp
    /// <summary>
    /// A Vibe question row (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): the plan's read-only pair, a none row in its EMPTY
    /// scratch and a disk row in the copy of its roots — never a root, never the checkout — on the row's own home in the
    /// built environment: <c>VIBE_CLI=python</c> and the model in the EXPLICIT environment, which is all a question row's
    /// minimal child gets (M-V12, 3 of 3).
    /// </summary>
    [Fact]
    public void AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));

        var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file")
            .And.ContainInConsecutiveOrder("--workdir", Scratch)
            .And.NotContain("--trust").And.NotContain("--add-dir").And.NotContain("--resume", "one shot");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-V11: Vibe reads its cwd only — the copy of the roots (D6)");
        disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.InheritsEnvironment.Should().BeFalse();
            request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
            request.Environment.Should().Contain(Runners.Vibe.VibeLaunch.CliVariable, "python").And.Contain(Runners.Vibe.VibeLaunch.ModelVariable, "glm-5-3");
            request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");
            Runners.Vibe.VibeLaunch.EnvironmentRefusal(request).Should().BeEmpty("the one launch control admits it (D17)");
        }
    }

    /// <summary>No Vibe launch carries <c>--add-dir</c>, whatever the grant (D3: <c>--add-dir</c> trusts its folder).</summary>
    [Fact]
```
### KimiEnvironment.Refusal — `src_mcp/runners/Kimi/KimiEnvironment.cs:80-95`

```csharp
    }

    /// <summary>
    /// D19: the launch is the built one. A path that built a Kimi launch any other way is refused here rather than started — the
    /// FIRST of: the structure (nothing inherited, the minimal names, exactly the seven), then each value, then — when the argv
    /// carries them — the two place flags. Each sentence names the value it found.
    /// </summary>
    public static string Refusal(ProcessRequest request, KimiPlaces places) =>
        new Func<string>[]
        {
            () => Structure(request),
            () => Same(request, HomeVariable, places.Home, "the owned home"),
            () => Same(request, ProfileVariable, places.Os, "coai's own os/ folder (the OS-home redirect)"),
            () => Same(request, HomeNameVariable, places.Os, "coai's own os/ folder (the OS-home redirect)"),
            () => DrivePath(request, places),
            () => Pinned(request),
```
### KimiPlaces — `src_mcp/runners/Kimi/KimiPlaces.cs:20-75`

```csharp
/// </remarks>
/// <param name="OwnedRoot">The coai-owned root: holds <c>home/</c> (the owned <c>KIMI_CODE_HOME</c>) and <c>os/</c> (the empty OS home).</param>
/// <param name="PersonsHome">The person's data folder; empty for the shim, which learns the sign-in folder from the owned junction's own reparse data.</param>
/// <param name="PersonsBin">The folder the person's tools live in; the built <c>PATH</c> begins with it.</param>
/// <param name="ToolFolders">The other folders <c>rg</c> and <c>fd</c> were found in (<see cref="KimiTools.FoldersFor"/>).</param>
/// <param name="ToolsRefusal">Why <c>rg</c> and <c>fd</c> were not both found, or empty.</param>
/// <param name="Executable">The absolute <c>kimi</c> — or the bare name, which fails the launch with the install cure; empty for the shim.</param>
public sealed record KimiPlaces(string OwnedRoot, string PersonsHome, string PersonsBin, IReadOnlyList<string> ToolFolders, string ToolsRefusal, string Executable)
{
    private const string Bare = "kimi";

    /// <summary>The owned <c>KIMI_CODE_HOME</c>.</summary>
    public string Home => Path.Combine(OwnedRoot, "home");

    /// <summary>The empty OS home the redirected <c>USERPROFILE</c>/<c>HOME</c> point at.</summary>
    public string Os => Path.Combine(OwnedRoot, "os");

    /// <summary>The junction to the person's <c>credentials</c>, inside the owned home.</summary>
    public string Link => Path.Combine(Home, "credentials");

    /// <summary>The one <c>config.toml</c> coai writes.</summary>
    public string Config => Path.Combine(Home, "config.toml");

    /// <summary>The person's <c>credentials</c> folder — the junction's target; empty when the person's home is not known (the shim).</summary>
    public string Credentials => PersonsHome.Length == 0 ? string.Empty : Path.Combine(PersonsHome, "credentials");

    /// <summary>The person's own <c>config.toml</c>, read for the OAuth slot and the model block; empty for the shim.</summary>
    public string PersonsConfig => PersonsHome.Length == 0 ? string.Empty : Path.Combine(PersonsHome, "config.toml");

    /// <summary>The places for a launch of the real <c>kimi</c>, from the parent's own environment and the REAL profile.</summary>
    public static KimiPlaces Resolve(string ownedRoot, HostKind host, Func<string, string?> env, string userProfile, Func<string, bool> fileExists)
    {
        var windows = host == HostKind.Windows;
        var installer = Join(windows, userProfile, ".kimi-code");
        var home = NonEmpty(env("KIMI_CODE_HOME"), installer);
        var bin = Join(windows, NonEmpty(env("KIMI_INSTALL_DIR"), installer), "bin");

        return new KimiPlaces(
            ownedRoot,
            home,
            bin,
            KimiTools.FoldersFor(windows, bin, env("PATH"), env("PATHEXT"), fileExists),
            KimiTools.Refusal(windows, bin, env("PATH"), env("PATHEXT"), fileExists),
            ExecutableOf(host, bin, userProfile, env("PATH"), fileExists));
    }

    /// <summary>The places the SHIM knows: the owned root and the person's bin it was handed — nothing read from any environment.</summary>
    public static KimiPlaces ForShim(string ownedRoot, string personsBin) =>
        new(ownedRoot, string.Empty, personsBin, [], string.Empty, string.Empty);

    /// <summary>The installed <c>kimi</c> by absolute path: the person's bin, then the installer's default, then wherever <c>PATH</c> finds it — else the bare name.</summary>
    private static string ExecutableOf(HostKind host, string bin, string userProfile, string? path, Func<string, bool> fileExists)
    {
        var windows = host == HostKind.Windows;
        var inBin = windows ? Join(true, bin, "kimi.exe") : string.Empty;
        Func<string>[] ways =
```
### KimiConsultantTests — how a launch and the places are built there — `src_mcp/tests/KimiConsultantTests.cs:25-80`

```csharp
    private readonly KimiFixture _person = new();

    public void Dispose() => _person.Dispose();

    private string Repo => Path.Combine(_person.Folder, "checkout");

    private string Answers => Path.Combine(_person.Folder, "data", "coai-answers");

    /// <summary>The conversation's folder under the homes root: <c>coai-kimi\&lt;id&gt;</c>.</summary>
    private string Folder => ConsultantHomes.ConversationFolder(Path.Combine(_person.Folder, "homes"), ConsultantHomes.Kimi, new string('a', 32));

    private string Tree => Path.Combine(Folder, "tree");

    private KimiConsultant Consultant() =>
        new(new KimiRuntime("my-kimi", HostKind.Windows, new KimiSeams(_person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");

    private ConsultantLaunch Turn(string handle = "", string model = "") =>
        new(Repo, "why is the count wrong\nsee the diff", handle, Answers,
            new ReviewerSettings("my-kimi") { Model = model, Timeout = TimeSpan.FromMinutes(5), OwnedScratch = Folder })
        {
            Workdir = Tree,
        };

    private static string After(IReadOnlyList<string> args, string flag) => args[args.ToList().IndexOf(flag) + 1];

    // ---------- S5.4.1 ----------

    [Fact]
    public void AKimiRow_IsAConsultant_AndAnAnsweringRuntime()
    {
        var row = new VendorIdentity("my-kimi", "kimi", string.Empty);

        var consultant = ConsultantResolution.For(row);

        consultant.Should().NotBeNull("features.consultant names kimi (decision 9), and OnACli resolves it (decision 10)");
        consultant.Should().BeOfType<KimiConsultant>().Which.Vendor.Should().Be("my-kimi");
        ConsultantResolution.Consulting.Should().Contain("kimi");
        QuestionResolution.Answering.Should().Contain("kimi", "Answering follows Consulting by itself (decision 10)");
    }

    // ---------- S5.4.2 ----------

    [Fact]
    public void TheFirstTurn_IsTheShimRequest_InTheSnapshot_OnTheConversationsHome()
    {
        var invocation = Consultant().Build(Turn());
        var request = invocation.Request;

        request.WorkingDirectory.Should().Be(Tree, "D6: the conversation's one stable snapshot — never the checkout, never the answers folder");
        request.Arguments.Should().ContainInConsecutiveOrder("--ask-acp", "--profile", "kimi", "--model", KimiModels.Default, "--cwd", Tree);
        var home = After(request.Arguments, AcpWords.HomeFlag);
        Path.GetDirectoryName(home).Should().Be(Folder, "the home is a CHILD of the conversation folder (E5.3 decision a)");
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        request.Arguments.Should().NotContain("--session", "a first turn continues nothing");
        request.StdIn.Should().Be("why is the count wrong\nsee the diff", "the prompt rides stdin, never the argv");
        request.Arguments.Should().NotContain(argument => argument.Contains('\n') || argument.Contains('\r'));
```

### ConfinementPlannerTests helpers (this class) — `src_mcp/tests/ConfinementPlannerTests.cs:21-30`

```csharp
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------
```
### The Vibe planner test — the shape — `src_mcp/tests/ConfinementPlannerTests.cs:126-148`

```csharp
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    // ---------- Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md) ----------

    /// <summary>S5.6.3: the planner's Kimi arm carries NO flags (decision 1) — a copy of the roots for disk, an empty folder for none, a refusal for web.</summary>
```
### Planned launch helper, constants — `src_mcp/tests/ConfinementPlannerTests.cs:270-290`

```csharp
    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
```
### Confinement.Planned and CwdKind — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:10-52`

```csharp
public enum CwdKind
{
    Scratch,

    Root,

    /// <summary>
    /// A coai-owned SANITISED SNAPSHOT of the granted roots, made by the launch (D6 of todo/PLAN_vibe_and_kimi_runtimes.md)
    /// — for a CLI that reads only its working folder and loads its configuration from it (Vibe, M-V11), whose roots
    /// therefore can be neither its cwd nor an added directory.
    /// </summary>
    Snapshot,
}

/// <summary>What the planner decided for one runtime × grant: the fragments to compose, or a refusal.</summary>
public abstract record Confinement
{
    /// <param name="Leading">Argv BEFORE the CLI's subcommand — codex's top-level <c>--search</c> (F1); empty everywhere else.</param>
    /// <param name="Flags">The sandbox flags, in order, complete — an adapter splices them and adds none of its own.</param>
    /// <param name="Cwd">Where the process stands.</param>
    /// <param name="AddDirs">The roots the flags grant as LAUNCH FLAGS (<c>--add-dir</c>), for the record; the flags already spell them the runtime's way — never a copy's sources.</param>
    /// <param name="Flag">D13's caveat on an admitted pair — shown beside every answer the row produces.</param>
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,
        IReadOnlyList<string> Flags,
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        /// <summary>
        /// The folders the launch reads through COPIES (<see cref="CwdKind.Snapshot"/>, D6) — never a launch flag. Its own field,
        /// not <see cref="AddDirs"/>: there a root is something the CLI is told to read, and Vibe is never given one (D3, the
        /// #811 checkpoint round).
        /// </summary>
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }

    public sealed record Refused(string Reason) : Confinement;

    private Confinement() { }
}
```
### The planner arm (already written) — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:151-160`

```csharp
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag),
        "codex" => Codex(grant, flag),
        "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),
        // A completion has no tools, so it has no sandbox flag: the question alone, from nowhere.
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
```

### LaunchConfinement — `src_mcp/runners/Consultation/LaunchConfinement.cs:19-30`

```csharp
public abstract record LaunchConfinement
{
    /// <summary>The adapter's shipped argv: the stuck consultant in the live checkout, resumable.</summary>
    public sealed record Shipped : LaunchConfinement;

    /// <summary>A question row: the plan's fragments, a scratch or root cwd, one shot.</summary>
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;

    public static LaunchConfinement AsShipped { get; } = new Shipped();

    private LaunchConfinement() { }
}
```
