# Region `s563-planner` (test) — `src_mcp/tests/ConfinementPlannerTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

`ConfinementPlanner.Plan(string runtime, CapabilityGrant grant)` returns `Confinement` (`Confinement.Planned` or `Confinement.Refused(string Reason)`). The Kimi arm is already in the production code; the scenario says it was red against the default arm.

### ConfinementPlannerTests helpers (this class) — `src_mcp/tests/ConfinementPlannerTests.cs:21-30`

```csharp
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------
```
### The Vibe planner test — the shape — `src_mcp/tests/ConfinementPlannerTests.cs:126-148`

```csharp
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    // ---------- Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md) ----------

    /// <summary>S5.6.3: the planner's Kimi arm carries NO flags (decision 1) — a copy of the roots for disk, an empty folder for none, a refusal for web.</summary>
```
### Planned launch helper, constants — `src_mcp/tests/ConfinementPlannerTests.cs:270-290`

```csharp
    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
```
### Confinement.Planned and CwdKind — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:10-52`

```csharp
public enum CwdKind
{
    Scratch,

    Root,

    /// <summary>
    /// A coai-owned SANITISED SNAPSHOT of the granted roots, made by the launch (D6 of todo/PLAN_vibe_and_kimi_runtimes.md)
    /// — for a CLI that reads only its working folder and loads its configuration from it (Vibe, M-V11), whose roots
    /// therefore can be neither its cwd nor an added directory.
    /// </summary>
    Snapshot,
}

/// <summary>What the planner decided for one runtime × grant: the fragments to compose, or a refusal.</summary>
public abstract record Confinement
{
    /// <param name="Leading">Argv BEFORE the CLI's subcommand — codex's top-level <c>--search</c> (F1); empty everywhere else.</param>
    /// <param name="Flags">The sandbox flags, in order, complete — an adapter splices them and adds none of its own.</param>
    /// <param name="Cwd">Where the process stands.</param>
    /// <param name="AddDirs">The roots the flags grant as LAUNCH FLAGS (<c>--add-dir</c>), for the record; the flags already spell them the runtime's way — never a copy's sources.</param>
    /// <param name="Flag">D13's caveat on an admitted pair — shown beside every answer the row produces.</param>
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,
        IReadOnlyList<string> Flags,
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        /// <summary>
        /// The folders the launch reads through COPIES (<see cref="CwdKind.Snapshot"/>, D6) — never a launch flag. Its own field,
        /// not <see cref="AddDirs"/>: there a root is something the CLI is told to read, and Vibe is never given one (D3, the
        /// #811 checkpoint round).
        /// </summary>
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }

    public sealed record Refused(string Reason) : Confinement;

    private Confinement() { }
}
```
### The planner arm (already written) — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:151-160`

```csharp
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag),
        "codex" => Codex(grant, flag),
        "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),
        // A completion has no tools, so it has no sandbox flag: the question alone, from nowhere.
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
```

### Capability / grant / admission types — `src_mcp/core/QuestionConsult/Capability.cs:64-73`

```csharp
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    /// <summary>The question alone.</summary>
    public static CapabilityGrant None { get; } = new(Capability.None, []);

    /// <summary>The web alone.</summary>
    public static CapabilityGrant Web { get; } = new(Capability.Web, []);

    /// <summary>Read-only reads under these roots.</summary>
    public static CapabilityGrant Disk(params string[] roots) => new(Capability.Disk, [.. roots]);
```
### RuntimeCapabilityRow, MeasuredWith, CapabilityStanding — `src_mcp/core/QuestionConsult/RuntimeCapabilities.cs:9-56`

```csharp
public enum CapabilityStanding
{
    /// <summary>The CLI's own enforced mechanism stops what the capability does not grant.</summary>
    Confined,

    /// <summary>The runtime can do the capability and cannot be held to it — a shell is always there (F2).</summary>
    Unconfined,

    /// <summary>Held only by a headless permission DEFAULT nobody configured; hand-checked, not instrument-confirmed (F7).</summary>
    DefaultDeny,

    /// <summary>The runtime cannot do the capability at all.</summary>
    Unsupported,

    /// <summary>No cell says either way.</summary>
    Unmeasured,
}

/// <summary>The standing words as the file spells them, and the parse that refuses the rest.</summary>
public static class CapabilityStandings
{
    public static string Spelled(this CapabilityStanding standing) => standing switch
    {
        CapabilityStanding.Confined => "confined",
        CapabilityStanding.Unconfined => "unconfined",
        CapabilityStanding.DefaultDeny => "default-deny",
        CapabilityStanding.Unsupported => "unsupported",
        CapabilityStanding.Unmeasured => "unmeasured",
        _ => throw new ArgumentOutOfRangeException(nameof(standing), standing, "a standing this build does not spell — map it here"),
    };

    /// <summary>The standing a file word names; throws for a word the table may not carry (a broken build).</summary>
    public static CapabilityStanding Parse(string word) =>
        Enum.GetValues<CapabilityStanding>().Cast<CapabilityStanding?>()
            .FirstOrDefault(s => string.Equals(s!.Value.Spelled(), word.Trim(), StringComparison.OrdinalIgnoreCase))
        ?? throw new ArgumentException(
            $"'{word}' is not a capability standing — the table spells: {string.Join(", ", Enum.GetValues<CapabilityStanding>().Select(s => s.Spelled()))}",
            nameof(word));
}

/// <summary>Which probe cells a row rests on: the CLI and its build, the day, where the record says it, and the cell ids.</summary>
/// <param name="ResultRef">The section of <c>research/RESULTS_question_consultant_capabilities.md</c> the row cites.</param>
/// <param name="Cells">Cell ids of the full run; empty only when <paramref name="Note"/> says why.</param>
/// <param name="Note">How the standing was read — by construction, hand-checked, not measured.</param>
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

/// <summary>One row of the table: a runtime, a capability, what was measured, and where.</summary>
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
```
### CapabilityMatrix.Admit and Admission — `src_mcp/core/QuestionConsult/CapabilityMatrix.cs:7-72`

```csharp
public enum AdmissionFlag
{
    /// <summary>Confined by a measured mechanism; nothing to acknowledge.</summary>
    None,

    /// <summary>The runtime can read this machine whatever it is told — allowed and flagged.</summary>
    Unconfined,

    /// <summary>Held only by the CLI's headless default, which nobody configured — allowed, flagged.</summary>
    DefaultDeny,
}

/// <summary>The flag words as the shared vectors spell them.</summary>
public static class AdmissionFlags
{
    public static string Spelled(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.None => string.Empty,
        AdmissionFlag.Unconfined => "unconfined",
        AdmissionFlag.DefaultDeny => "default-deny",
        _ => throw new ArgumentOutOfRangeException(nameof(flag), flag, "a flag this build does not spell — map it here"),
    };

    /// <summary>The sentence a flagged row is shown beside — in the settings, the sidebar and the log (D13).</summary>
    public static string Caveat(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.Unconfined => "unconfined: can read this machine — a shell is always there, and no flag removes it",
        AdmissionFlag.DefaultDeny => "held only by the CLI's headless permission default, which nobody configured",
        _ => string.Empty,
    };
}

/// <summary>What the matrix decided for one pair: admitted with its standing and flag, or refused with a sentence.</summary>
public abstract record Admission
{
    public sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag) : Admission;

    public sealed record Refused(string Reason) : Admission;

    private Admission() { }
}

/// <summary>
/// The one rule that turns a table row into a decision: confined admits; unconfined and default-deny
/// admit FLAGGED; unsupported and unmeasured refuse; a pair the table does not know refuses by name.
/// </summary>
/// <remarks>
/// A3's "blocked in the UI and refused by the server" is one rule because the extension's
/// <c>capabilityAdmission.ts</c> is this function over the same file, and both answer
/// <c>shared/capability-matrix-vectors.json</c>.
/// </remarks>
public static class CapabilityMatrix
{
    /// <summary>The decision for a pair given by its words — what a settings row or a vector carries.</summary>
    public static Admission Admit(string runtime, string capability) =>
        string.IsNullOrWhiteSpace(runtime) ? NoRuntime
        : Capabilities.TryParse(capability, out var parsed)
            ? Admit(runtime, parsed)
            : new Admission.Refused($"'{capability}' is not a capability a prompt can declare — a prompt needs one of: {Capabilities.AllSpelled} (asked for runtime '{runtime}')");

    /// <summary>The decision for a pair, from the embedded table.</summary>
    public static Admission Admit(string runtime, Capability capability) => Admit(RuntimeCapabilities.Builtin, runtime, capability);

    /// <summary>The decision from a given table — the embedded one in the product, a hand-built one in a test.</summary>
    public static Admission Admit(RuntimeCapabilities table, string runtime, Capability capability)
    {
```
