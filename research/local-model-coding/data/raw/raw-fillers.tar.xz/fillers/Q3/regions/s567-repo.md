# Region `s567-repo` (test) — `src_mcp/tests/AKimiQuestionRowTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

Copy the body of the Vibe class's `RepositoryAsync` (below) with this class's `_launcher` (`ProcessLauncher`) and no other change.

### RepositoryAsync in the Vibe class — `src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs:49-64`

```csharp
    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        Directory.CreateDirectory(at);
        foreach (var (path, text) in files)
        {
            var full = Path.Combine([at, .. path.Split('/')]);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }

        foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
        }
    }
```

### ProcessRequest — `src_mcp/runners/Processes/ProcessLauncher.cs:5-12`

```csharp
public sealed record ProcessRequest(
    string Executable,
    IReadOnlyList<string> Arguments,
    string WorkingDirectory)
{
    public IReadOnlyDictionary<string, string?> Environment { get; init; } =
        new Dictionary<string, string?>();

```
