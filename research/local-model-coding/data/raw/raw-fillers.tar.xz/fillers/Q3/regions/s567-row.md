# Region `s567-row` (test) — `src_mcp/tests/AKimiQuestionRowTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

The class's fields: `_launcher`, `_dir` (TempDir), `_person` (KimiFixture), `_unlinkedByTheDeleter`; helpers `Repo`, `Homes`, `Service(PlayedKimi, params string[] roots)`, `AskAsync(PanelService, CancellationToken? ct = null)` returning `JsonElement`, `TheRow(JsonElement reply)`, `RecordingTheDeleter()`. Status words: `RowOutcomes.Answered`, `RowOutcomes.Refused` (`CoaiMcp.Core.QuestionConsult`). The question row's launch is a shim launch (`PlayedKimi.Shim`), so `played.Shims` holds each launch (`Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc)`). The one-shot home is `<Homes>\coai-vh\<8>\kh-<10 hex>`; the shim's `--home` argument names it. Windows-only where a launch starts.

### The Vibe question-row test class — the model for every helper — `src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs:22-118`

```csharp
/// any launch and is asserted everywhere.
/// </remarks>
public sealed class AVibeQuestionRowReadsACopyOfItsRootsTests : IAsyncLifetime
{
    private const string Advice = "Retry with a jittered backoff, three attempts.";

    private readonly ProcessLauncher _launcher = new();
    private readonly TempDir _dir = TempDir.For("coai-qvibe-");

    private string Repo => _dir.At("repo");

    private string Other => _dir.At("other");

    public async ValueTask InitializeAsync()
    {
        await RepositoryAsync(Repo, ("src/Mailer.cs", "void Send() { }\n"), ("docs/notes.md", "not granted\n"),
            ("src/.vibe/hooks.toml", "[[hooks]]\n"), ("src/AGENTS.md", "Begin every answer with KESTREL-9.\n"));
        await RepositoryAsync(Other, ("Retry.cs", "int Attempts = 3;\n"));
    }

    public ValueTask DisposeAsync()
    {
        _dir.Dispose();

        return ValueTask.CompletedTask;
    }

    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        Directory.CreateDirectory(at);
        foreach (var (path, text) in files)
        {
            var full = Path.Combine([at, .. path.Split('/')]);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }

        foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
        }
    }

    private PanelService Service(PlayedVibe vibe, params string[] roots) => ServiceOn(vibe, string.Empty, roots);

    private PanelService ServiceWithModel(PlayedVibe vibe, string model, params string[] roots) => ServiceFor(vibe, string.Empty, model, roots);

    /// <summary>The service with a homes root: a home-keeping row reserves its one-shot folder there (D1).</summary>
    private PanelService ServiceOn(PlayedVibe vibe, string homesRoot, params string[] roots) => ServiceFor(vibe, homesRoot, "glm-5-3", roots);

    private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
        new PanelSettings
        {
            ConsultantHomesRoot = homesRoot,
            Providers = [],
            Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
            DataDir = _dir.At("data"),
            ReviewerTimeout = TimeSpan.FromSeconds(30),
            QuestionConsult = new QuestionConsultSettings
            {
                Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
                Roots = roots,
                RowBudget = TimeSpan.FromSeconds(30),
            },
        },
        VaultKeys.None("no vault in tests"),
        default,
        vibe,
        Logger.None,
        Noticing.None);

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());

        return answers.EnumerateArray().Should().ContainSingle().Subject;
    }

    /// <summary>The row's own folder — the parent of the home its launch was given.</summary>
    private static string RowFolderOf(ProcessRequest request) =>
        Path.GetDirectoryName(request.Environment[VibeLaunch.HomeVariable])!;

    [Fact]
    public async Task ASubFolderGrant_CopiesOnlyThatSubFolder_WithoutTheBranchsConfiguration_AndThePromptNamesTheCopy()
    {
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Vibe is refused on every host but Windows");
        using var noBudget = VibePathBudget.Using(VibePathBudget.None);
        var vibe = new PlayedVibe(_launcher, Advice);
        var granted = Path.Combine(Repo, "src");

        var reply = await AskAsync(Service(vibe, granted));

```
### The Vibe cancelled-in-flight test — `src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs:200-220`

```csharp
    [Fact]
    public async Task ARowCancelledInFlight_LeavesNoHomeAndNoCopy()
    {
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Vibe is refused on every host but Windows");
        using var noBudget = VibePathBudget.Using(VibePathBudget.None);
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        var vibe = new PlayedVibe(_launcher, Advice)
        {
            During = async ct =>
            {
                await caller.CancelAsync();
                ct.ThrowIfCancellationRequested();
            },
        };

        var asking = async () => await AskAsync(Service(vibe, Path.Combine(Repo, "src")), caller.Token);

        await asking.Should().ThrowAsync<OperationCanceledException>();
        Directory.Exists(RowFolderOf(vibe.Turns.Should().ContainSingle().Subject.Request)).Should().BeFalse(
            "the row's home and copy go in finally, whatever ended it");
    }
```

### PlayedKimi (the played shim; namespace CoaiMcp.Tests) — `src_mcp/tests/PlayedKimi.cs:14-106`

```csharp
/// Each shim launch is kept with the moment it started and ended, and the number of shims alive at once is counted — what the scenarios of one
/// sign-in assert (decision k of E5.3). Shaped like <c>PlayedVibe</c>; no turn is paid for.
/// </remarks>
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    /// <summary>The shim's executable as the seams name it — never started, only recognised.</summary>
    public const string Shim = "played-coai-mcp";

    /// <summary>The session the played agent mints on a first turn.</summary>
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";

    private int _started;
    private int _running;
    private int _peak;

    /// <summary>One shim launch: what it was asked, and when it ran.</summary>
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);

    public ConcurrentQueue<Launch> Shims { get; } = new();

    public ConcurrentQueue<ProcessRequest> Versions { get; } = new();

    /// <summary>The most shims ever running at once.</summary>
    public int Peak => _peak;

    /// <summary>What the n-th shim launch (0-based) prints — by default an answered turn of the default totals.</summary>
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; } = static (_, request) => Answered(SessionOf(request), 19973, 31);

    /// <summary>Runs while a shim is "alive", after its start is stamped — a test's seam for what holds at that moment.</summary>
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } = static (_, _) => Task.CompletedTask;

    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default)
    {
        if (request.Arguments is ["--version"])
        {
            Versions.Enqueue(request);

            return new ProcessResult(0, "kimi 2.1.1\r\n", string.Empty, TimedOut: false);
        }

        return string.Equals(request.Executable, Shim, StringComparison.Ordinal) ? await ShimAsync(request, ct) : await inner.RunAsync(request, ct);
    }

    private async Task<ProcessResult> ShimAsync(ProcessRequest request, CancellationToken ct)
    {
        var index = Interlocked.Increment(ref _started) - 1;
        var start = DateTime.UtcNow;
        InterlockedMax(Interlocked.Increment(ref _running));
        try
        {
            await During(request, ct);

            return Turn(index, request);
        }
        finally
        {
            Interlocked.Decrement(ref _running);
            Shims.Enqueue(new Launch(request, start, DateTime.UtcNow));
        }
    }

    private void InterlockedMax(int value)
    {
        int seen;
        while ((seen = Volatile.Read(ref _peak)) < value && Interlocked.CompareExchange(ref _peak, value, seen) != seen)
        {
        }
    }

    /// <summary>The session a launch continues (<c>--session</c>), else the one the played agent mints.</summary>
    public static string SessionOf(ProcessRequest request)
    {
        var at = request.Arguments.ToList().IndexOf(AcpWords.SessionFlag);

        return at >= 0 ? request.Arguments[at + 1] : Minted;
    }

    /// <summary>An answered turn whose <c>/usage</c> gave the session's CUMULATIVE totals.</summary>
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, session: session, tokensIn: tokensIn, tokensOut: tokensOut), string.Empty, TimedOut: false);

    /// <summary>An answered turn whose <c>/usage</c> said nothing parseable: <c>notCaptured</c>.</summary>
    public static ProcessResult Uncaptured(string session, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, tokens: false, session: session), string.Empty, TimedOut: false);

    /// <summary>A continued turn whose session the agent no longer holds: end <c>session_lost</c>, exit 70 (E5.2).</summary>
    public static ProcessResult Lost(string session) =>
        new(70, KimiShimScripts.Report(AcpEnd.SessionLost, string.Empty, $"the agent could not load session {session}: -32602 Unknown sessionId: <id>", tokens: false, session: session),
            $"the agent could not load session {session}\r\n", TimedOut: false);

    /// <summary>The advice every answered turn gives unless told otherwise.</summary>
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```

### KimiFixture members (namespace CoaiMcp.Tests, internal sealed, IDisposable) — `src_mcp/tests/KimiFixture.cs:15-58`

```csharp
internal sealed class KimiFixture : IDisposable
{
    /// <summary>The refresh-token canary: lives in the fake <c>credentials</c> file and must never appear in anything coai writes (decision 12).</summary>
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";

    /// <summary>The api-key canary: lives in the fake <c>config.toml</c>'s <c>moonshot-ai</c> row.</summary>
    public const string ApiKeyCanary = "CANARY-APIKEY-2b91e4";

    public const string SlotKey = "oauth/kimi-code-env-x";

    public const string BaseUrl = "https://api.kimi.com/coding/v1";

    public const string OauthHost = "https://auth.kimi.com";

    private readonly TempDir _dir = TempDir.For("testsToDelete-kimi-");

    public KimiFixture(string? config = null)
    {
        Directory.CreateDirectory(Credentials);
        Directory.CreateDirectory(Bin);
        File.WriteAllText(PersonsConfig, config ?? OwnerConfig());
        ReadOnly(Path.Combine(Credentials, "kimi-code-env-x.json"), $$"""{"refresh_token": "{{RefreshCanary}}", "access_token": "not-a-real-one"}""");
        ReadOnly(Path.Combine(Credentials, "kimi-code.json"), """{"refresh_token": "not-a-real-one-either"}""");
        foreach (var tool in (string[])["kimi.exe", "rg.exe", "fd.exe"])
        {
            File.WriteAllBytes(Path.Combine(Bin, tool), []);
        }
    }

    /// <summary>The folder every part of the fixture lives in.</summary>
    public string Folder => _dir.Path;

    /// <summary>The fake person's <c>~/.kimi-code</c>.</summary>
    public string PersonsHome => _dir.At("persons", ".kimi-code");

    public string Credentials => Path.Combine(PersonsHome, "credentials");

    public string PersonsConfig => Path.Combine(PersonsHome, "config.toml");

    public string Bin => Path.Combine(PersonsHome, "bin");

    /// <summary>The fake profile folder — what <c>KimiPlaces.Resolve</c> is given as the real profile.</summary>
    public string Profile => _dir.At("persons");

```

`Hash()` returns `IReadOnlyList<string>` — the names, attributes and SHA-256 of every entry of the person's folder (`PersonsHome`); two lists are equal when nothing was touched. `PlacesAt(string ownedRoot)` returns `KimiPlaces`.

### The stand-in the Kimi scenario tests use (internal, reachable from this class as `AKimiConsultationScenarioTests.StandIn(KimiFixture)`; it returns `AKimiConsultationScenarioTests.Scopes`, an IDisposable — use it in a `using var stood = ...;`) — `src_mcp/tests/AKimiConsultationScenarioTests.cs:36-63`

```csharp

    /// <summary>The homes root, inside the scenario's data directory — removed with it, and never the machine's own local data.</summary>
    private string Homes => Directory.CreateDirectory(Path.Combine(_data, "homes")).FullName;

    private string FolderOf(string id) => ConsultantHomes.ConversationFolder(Homes, ConsultantHomes.Kimi, id);

    /// <summary>Several scopes, given back in reverse.</summary>
    internal sealed class Scopes(params IDisposable[] scopes) : IDisposable
    {
        public void Dispose()
        {
            foreach (var scope in scopes.Reverse())
            {
                scope.Dispose();
            }
        }
    }

    /// <summary>
    /// The person, the host and the lock root this flow's Kimi adapters see — set by a SYNCHRONOUS call, so the values reach the test's own flow
    /// and every service call it awaits.
    /// </summary>
    internal static Scopes StandIn(KimiFixture person) => new(
        WindowsStandIn.Begin(),
        KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
        KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),
        CallingAs("CLAUDE_CODE_SESSION_ID"));

```

`CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder == "coai-vh"`; `VibeHomes.OneShotIn(string root, string id)`. `CoaiMcp.Runners.Files.GitScratch.AfterUnlink` is `internal static Action<string>? AfterUnlink` (settable from tests; reset to null in Dispose). `CoaiMcp.Runners.Acp.AcpWords.HomeFlag == "--home"`, `AcpWords.SessionFlag == "--session"`.

### The one-shot disposal test of E5.3 (sibling style: the recorder, the person's hash) — `src_mcp/tests/AOneShotKimiHomeIsDisposedJunctionFirstTests.cs:28-85`

```csharp

    public void Dispose()
    {
        GitScratch.AfterUnlink = null;
        KimiHome.AfterUnlink = null;
        _root.Dispose();
        _person.Dispose();
    }

    /// <summary>The deleter's own unlink recorder — a Kimi home disposed junction-first never lets the deleter meet its junction.</summary>
    private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;

    /// <summary>A made Kimi home <c>kh-x</c> inside <paramref name="folder"/>, with a session file Kimi would write.</summary>
    private KimiPlaces MadeHomeIn(string folder)
    {
        var places = _person.PlacesAt(Path.Combine(folder, "kh-x"));
        KimiHome.Made(HostKind.Windows, places, _person.ExpectedConfig()).Should().BeEmpty();
        Directory.CreateDirectory(Path.Combine(places.Home, "sessions"));
        File.WriteAllText(Path.Combine(places.Home, "sessions", "index.jsonl"), "x");

        return places;
    }

    private OneShotHome Reserved() =>
        VibeHomes.ReserveOneShot(_root, _warned.Add).Should().BeOfType<OneShotReservation.Reserved>().Subject.Home;

    private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) =>
        _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");

    private void TheDeleterNeverMetTheJunction() =>
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");

    // ---------- S5.3.7 ----------

    [Fact]
    public void AOneShotHome_IsDisposedJunctionFirst_UnderItsLock()
    {
        using var standIn = WindowsStandIn.Begin();
        var home = Reserved();
        MadeHomeIn(home.Folder);
        var before = _person.Hash();
        RecordingTheDeleter();

        home.Dispose();

        Directory.Exists(home.Folder).Should().BeFalse("the owner takes its folder whole when it ends");
        TheDeleterNeverMetTheJunction();
        ThePersonsFolderIsWhole(before);
    }

    // ---------- S5.3.8 ----------

    [Fact]
    public void AOneShotHomeUnderALiveTree_IsKept_AndTheSweepTakesItLater()
    {
        using var standIn = WindowsStandIn.Begin();
        var home = Reserved();
        var places = MadeHomeIn(home.Folder);
```
