# Region `s561-rows` (test) — `src_mcp/tests/CapabilityMatrixTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

The three seeded rows live in `shared/runtime-capabilities.json` (already written): kimi × none/disk = `unconfined`, kimi × web = `unmeasured` with empty cells; every row `version` "2.1.1", `resultRef` starting "research/RESULTS_kimi_confinement.md". The sibling test below is the shape to copy.

### Capability / grant / admission types — `src_mcp/core/QuestionConsult/Capability.cs:64-73`

```csharp
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    /// <summary>The question alone.</summary>
    public static CapabilityGrant None { get; } = new(Capability.None, []);

    /// <summary>The web alone.</summary>
    public static CapabilityGrant Web { get; } = new(Capability.Web, []);

    /// <summary>Read-only reads under these roots.</summary>
    public static CapabilityGrant Disk(params string[] roots) => new(Capability.Disk, [.. roots]);
```
### RuntimeCapabilityRow, MeasuredWith, CapabilityStanding — `src_mcp/core/QuestionConsult/RuntimeCapabilities.cs:9-56`

```csharp
public enum CapabilityStanding
{
    /// <summary>The CLI's own enforced mechanism stops what the capability does not grant.</summary>
    Confined,

    /// <summary>The runtime can do the capability and cannot be held to it — a shell is always there (F2).</summary>
    Unconfined,

    /// <summary>Held only by a headless permission DEFAULT nobody configured; hand-checked, not instrument-confirmed (F7).</summary>
    DefaultDeny,

    /// <summary>The runtime cannot do the capability at all.</summary>
    Unsupported,

    /// <summary>No cell says either way.</summary>
    Unmeasured,
}

/// <summary>The standing words as the file spells them, and the parse that refuses the rest.</summary>
public static class CapabilityStandings
{
    public static string Spelled(this CapabilityStanding standing) => standing switch
    {
        CapabilityStanding.Confined => "confined",
        CapabilityStanding.Unconfined => "unconfined",
        CapabilityStanding.DefaultDeny => "default-deny",
        CapabilityStanding.Unsupported => "unsupported",
        CapabilityStanding.Unmeasured => "unmeasured",
        _ => throw new ArgumentOutOfRangeException(nameof(standing), standing, "a standing this build does not spell — map it here"),
    };

    /// <summary>The standing a file word names; throws for a word the table may not carry (a broken build).</summary>
    public static CapabilityStanding Parse(string word) =>
        Enum.GetValues<CapabilityStanding>().Cast<CapabilityStanding?>()
            .FirstOrDefault(s => string.Equals(s!.Value.Spelled(), word.Trim(), StringComparison.OrdinalIgnoreCase))
        ?? throw new ArgumentException(
            $"'{word}' is not a capability standing — the table spells: {string.Join(", ", Enum.GetValues<CapabilityStanding>().Select(s => s.Spelled()))}",
            nameof(word));
}

/// <summary>Which probe cells a row rests on: the CLI and its build, the day, where the record says it, and the cell ids.</summary>
/// <param name="ResultRef">The section of <c>research/RESULTS_question_consultant_capabilities.md</c> the row cites.</param>
/// <param name="Cells">Cell ids of the full run; empty only when <paramref name="Note"/> says why.</param>
/// <param name="Note">How the standing was read — by construction, hand-checked, not measured.</param>
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

/// <summary>One row of the table: a runtime, a capability, what was measured, and where.</summary>
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
```
### CapabilityMatrix.Admit and Admission — `src_mcp/core/QuestionConsult/CapabilityMatrix.cs:7-72`

```csharp
public enum AdmissionFlag
{
    /// <summary>Confined by a measured mechanism; nothing to acknowledge.</summary>
    None,

    /// <summary>The runtime can read this machine whatever it is told — allowed and flagged.</summary>
    Unconfined,

    /// <summary>Held only by the CLI's headless default, which nobody configured — allowed, flagged.</summary>
    DefaultDeny,
}

/// <summary>The flag words as the shared vectors spell them.</summary>
public static class AdmissionFlags
{
    public static string Spelled(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.None => string.Empty,
        AdmissionFlag.Unconfined => "unconfined",
        AdmissionFlag.DefaultDeny => "default-deny",
        _ => throw new ArgumentOutOfRangeException(nameof(flag), flag, "a flag this build does not spell — map it here"),
    };

    /// <summary>The sentence a flagged row is shown beside — in the settings, the sidebar and the log (D13).</summary>
    public static string Caveat(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.Unconfined => "unconfined: can read this machine — a shell is always there, and no flag removes it",
        AdmissionFlag.DefaultDeny => "held only by the CLI's headless permission default, which nobody configured",
        _ => string.Empty,
    };
}

/// <summary>What the matrix decided for one pair: admitted with its standing and flag, or refused with a sentence.</summary>
public abstract record Admission
{
    public sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag) : Admission;

    public sealed record Refused(string Reason) : Admission;

    private Admission() { }
}

/// <summary>
/// The one rule that turns a table row into a decision: confined admits; unconfined and default-deny
/// admit FLAGGED; unsupported and unmeasured refuse; a pair the table does not know refuses by name.
/// </summary>
/// <remarks>
/// A3's "blocked in the UI and refused by the server" is one rule because the extension's
/// <c>capabilityAdmission.ts</c> is this function over the same file, and both answer
/// <c>shared/capability-matrix-vectors.json</c>.
/// </remarks>
public static class CapabilityMatrix
{
    /// <summary>The decision for a pair given by its words — what a settings row or a vector carries.</summary>
    public static Admission Admit(string runtime, string capability) =>
        string.IsNullOrWhiteSpace(runtime) ? NoRuntime
        : Capabilities.TryParse(capability, out var parsed)
            ? Admit(runtime, parsed)
            : new Admission.Refused($"'{capability}' is not a capability a prompt can declare — a prompt needs one of: {Capabilities.AllSpelled} (asked for runtime '{runtime}')");

    /// <summary>The decision for a pair, from the embedded table.</summary>
    public static Admission Admit(string runtime, Capability capability) => Admit(RuntimeCapabilities.Builtin, runtime, capability);

    /// <summary>The decision from a given table — the embedded one in the product, a hand-built one in a test.</summary>
    public static Admission Admit(RuntimeCapabilities table, string runtime, Capability capability)
    {
```

### The Vibe rows test (sibling, same class) — `src_mcp/tests/CapabilityMatrixTests.cs:182-199`

```csharp
    [Fact]
    public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
            row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
            CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
        }

        RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6",
            "denied writes do not prove bounded READS — the disk row rests on the read cell itself");
        CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured", "no Vibe cell exercises the web");
    }

```
