You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s552-gone — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Arrange: as S5.5.1 (stand-in, `Played(...)`); `var before = _person.Hash();` `RecordingTheDeleter();`. When `theTurnFails`, the played turn is
`request => new ProcessResult(70, string.Empty, "the played shim failed" + Environment.NewLine, TimedOut: false)` (exit 70, as the shim's
`agent_failed`); else the default answering turn. Windows only: `Assert.SkipUnless(OperatingSystem.IsWindows(), ...)` first.
Act: `await Check(Settings(_homes), played, TestContext.Current.CancellationToken)`. In the failing arm do NOT assert the state is answered.
Assert: `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))` Should().BeEmpty("the home's folder goes when the check
ends, whatever ended it"); `_unlinkedByTheDeleter` Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the
junction first"); `_person.Hash()` Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before").
Fails before E5.3 g with: Expected the deleter's unlink recorder not to be invoked …

## The exact existing types and members you may use (context pack)
# Region `s552-gone` (test) — `src_mcp/tests/AKimiConsultantCheckTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

Same helpers as `s551-check`. Exit 70 is the shim's `agent_failed` exit.

### The check mode and the existing test harness — `src_mcp/tests/ConsultantCheckTests.cs:56-90`

```csharp
            try
            {
                Directory.Delete(dir, recursive: true);
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                // A leftover temp directory is not a failing test.
            }
        }
    }

    private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
        ConsultEnabled = enabled,
        Consultants = new Dictionary<string, ConsultantChoice>
        {
            [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe),
        },
    };

    private Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, params string[] args) =>
        Check(settings, new ProcessLauncher(), TestContext.Current.CancellationToken, args);

    private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
    {
        var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

        return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
    }

    private static string Text(JsonElement element, string name) => element.GetProperty(name).GetString() ?? string.Empty;
```
### AnswerAsync — `src_mcp/src/Server/Consultation/ConsultantCheckMode.cs:94-103`

```csharp
    /// <summary>The exit code, what goes to stdout and what goes to stderr — the whole mode, with no console in it.</summary>
    /// <param name="tempRoot">Where the scratch repository is made — the temp directory, a test's own in a test.</param>
    /// <param name="warn">Where a problem that does not change the outcome is said — stderr.</param>
    internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
        PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct)
        => await AnswerAsync(settings, args, launcher, tempRoot, warn, noticing, ct, VaultKeys.None("no vault was read"));

    /// <param name="keys">The vault, for a consultant on an api row or somebody else's endpoint.</param>
    internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
        PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct, VaultKeys keys)
```
### The Vibe check test — the model — `src_mcp/tests/ConsultantCheckTests.cs:494-526`

```csharp
    [Fact]
    public async Task AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself()
    {
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Vibe is refused on every host but Windows");
        using var noBudget = CoaiMcp.Runners.Vibe.VibePathBudget.Using(CoaiMcp.Runners.Vibe.VibePathBudget.None);
        var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
        {
            AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
        };
        using var homes = TempDir.For("testsToDelete-vh-check-");
        var settings = Settings() with
        {
            ConsultantHomesRoot = homes,
            Consultants = new Dictionary<string, ConsultantChoice>
            {
                [CallerIdentity.Claude] = new("mistral", Model: "glm-5-3", Runtime: "vibe", ExecutablePath: PlayedVibe.Exe),
            },
        };

        var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");

        code.Should().Be(0);
        Text(said, "state").Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
        var turn = vibe.Turns.Should().ContainSingle().Subject;
        turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
        var home = turn.Request.Environment[Runners.Vibe.VibeLaunch.HomeVariable]!;
        home.Should().StartWith(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar, "D1: under the short homes root, never under TEMP");
        Path.GetFileName(home).Should().Be("h");
        (home.Length - homes.Path.Length).Should().BeLessThanOrEqualTo(19, "A10: what the check's layout costs beyond the root (`/coai-vh/<8>/h`) fits the Windows budget at the default root");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
        Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
    }
```
### The cancelled check test — `src_mcp/tests/ConsultantCheckTests.cs:460-473`

```csharp
    [Fact]
    public async Task ACheckCancelledWhileItsScratchIsMade_IsCancelled_NotUnavailable()
    {
        CodexAnswers("marker: x");
        using var cancelled = new CancellationTokenSource();
        await cancelled.CancelAsync();

        var (code, said, _) = await Check(Settings(), new ProcessLauncher(), cancelled.Token, "--caller", "claude");

        code.Should().Be(0);
        Text(said, "state").Should().Be("failed", said.ToString());
        Text(said, "failureKind").Should().Be("cancelled");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty();
    }
```

### PlayedKimi (the played shim; namespace CoaiMcp.Tests) — `src_mcp/tests/PlayedKimi.cs:14-106`

```csharp
/// Each shim launch is kept with the moment it started and ended, and the number of shims alive at once is counted — what the scenarios of one
/// sign-in assert (decision k of E5.3). Shaped like <c>PlayedVibe</c>; no turn is paid for.
/// </remarks>
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    /// <summary>The shim's executable as the seams name it — never started, only recognised.</summary>
    public const string Shim = "played-coai-mcp";

    /// <summary>The session the played agent mints on a first turn.</summary>
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";

    private int _started;
    private int _running;
    private int _peak;

    /// <summary>One shim launch: what it was asked, and when it ran.</summary>
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);

    public ConcurrentQueue<Launch> Shims { get; } = new();

    public ConcurrentQueue<ProcessRequest> Versions { get; } = new();

    /// <summary>The most shims ever running at once.</summary>
    public int Peak => _peak;

    /// <summary>What the n-th shim launch (0-based) prints — by default an answered turn of the default totals.</summary>
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; } = static (_, request) => Answered(SessionOf(request), 19973, 31);

    /// <summary>Runs while a shim is "alive", after its start is stamped — a test's seam for what holds at that moment.</summary>
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; } = static (_, _) => Task.CompletedTask;

    public async Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default)
    {
        if (request.Arguments is ["--version"])
        {
            Versions.Enqueue(request);

            return new ProcessResult(0, "kimi 2.1.1\r\n", string.Empty, TimedOut: false);
        }

        return string.Equals(request.Executable, Shim, StringComparison.Ordinal) ? await ShimAsync(request, ct) : await inner.RunAsync(request, ct);
    }

    private async Task<ProcessResult> ShimAsync(ProcessRequest request, CancellationToken ct)
    {
        var index = Interlocked.Increment(ref _started) - 1;
        var start = DateTime.UtcNow;
        InterlockedMax(Interlocked.Increment(ref _running));
        try
        {
            await During(request, ct);

            return Turn(index, request);
        }
        finally
        {
            Interlocked.Decrement(ref _running);
            Shims.Enqueue(new Launch(request, start, DateTime.UtcNow));
        }
    }

    private void InterlockedMax(int value)
    {
        int seen;
        while ((seen = Volatile.Read(ref _peak)) < value && Interlocked.CompareExchange(ref _peak, value, seen) != seen)
        {
        }
    }

    /// <summary>The session a launch continues (<c>--session</c>), else the one the played agent mints.</summary>
    public static string SessionOf(ProcessRequest request)
    {
        var at = request.Arguments.ToList().IndexOf(AcpWords.SessionFlag);

        return at >= 0 ? request.Arguments[at + 1] : Minted;
    }

    /// <summary>An answered turn whose <c>/usage</c> gave the session's CUMULATIVE totals.</summary>
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, session: session, tokensIn: tokensIn, tokensOut: tokensOut), string.Empty, TimedOut: false);

    /// <summary>An answered turn whose <c>/usage</c> said nothing parseable: <c>notCaptured</c>.</summary>
    public static ProcessResult Uncaptured(string session, string answer = Advice) =>
        new(0, KimiShimScripts.Report(AcpEnd.Answered, answer, tokens: false, session: session), string.Empty, TimedOut: false);

    /// <summary>A continued turn whose session the agent no longer holds: end <c>session_lost</c>, exit 70 (E5.2).</summary>
    public static ProcessResult Lost(string session) =>
        new(70, KimiShimScripts.Report(AcpEnd.SessionLost, string.Empty, $"the agent could not load session {session}: -32602 Unknown sessionId: <id>", tokens: false, session: session),
            $"the agent could not load session {session}\r\n", TimedOut: false);

    /// <summary>The advice every answered turn gives unless told otherwise.</summary>
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
```

### KimiFixture members (namespace CoaiMcp.Tests, internal sealed, IDisposable) — `src_mcp/tests/KimiFixture.cs:15-58`

```csharp
internal sealed class KimiFixture : IDisposable
{
    /// <summary>The refresh-token canary: lives in the fake <c>credentials</c> file and must never appear in anything coai writes (decision 12).</summary>
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";

    /// <summary>The api-key canary: lives in the fake <c>config.toml</c>'s <c>moonshot-ai</c> row.</summary>
    public const string ApiKeyCanary = "CANARY-APIKEY-2b91e4";

    public const string SlotKey = "oauth/kimi-code-env-x";

    public const string BaseUrl = "https://api.kimi.com/coding/v1";

    public const string OauthHost = "https://auth.kimi.com";

    private readonly TempDir _dir = TempDir.For("testsToDelete-kimi-");

    public KimiFixture(string? config = null)
    {
        Directory.CreateDirectory(Credentials);
        Directory.CreateDirectory(Bin);
        File.WriteAllText(PersonsConfig, config ?? OwnerConfig());
        ReadOnly(Path.Combine(Credentials, "kimi-code-env-x.json"), $$"""{"refresh_token": "{{RefreshCanary}}", "access_token": "not-a-real-one"}""");
        ReadOnly(Path.Combine(Credentials, "kimi-code.json"), """{"refresh_token": "not-a-real-one-either"}""");
        foreach (var tool in (string[])["kimi.exe", "rg.exe", "fd.exe"])
        {
            File.WriteAllBytes(Path.Combine(Bin, tool), []);
        }
    }

    /// <summary>The folder every part of the fixture lives in.</summary>
    public string Folder => _dir.Path;

    /// <summary>The fake person's <c>~/.kimi-code</c>.</summary>
    public string PersonsHome => _dir.At("persons", ".kimi-code");

    public string Credentials => Path.Combine(PersonsHome, "credentials");

    public string PersonsConfig => Path.Combine(PersonsHome, "config.toml");

    public string Bin => Path.Combine(PersonsHome, "bin");

    /// <summary>The fake profile folder — what <c>KimiPlaces.Resolve</c> is given as the real profile.</summary>
    public string Profile => _dir.At("persons");

```

`Hash()` returns `IReadOnlyList<string>` — the names, attributes and SHA-256 of every entry of the person's folder (`PersonsHome`); two lists are equal when nothing was touched. `PlacesAt(string ownedRoot)` returns `KimiPlaces`.

### The stand-in the Kimi scenario tests use (internal, reachable from this class as `AKimiConsultationScenarioTests.StandIn(KimiFixture)`; it returns `AKimiConsultationScenarioTests.Scopes`, an IDisposable — use it in a `using var stood = ...;`) — `src_mcp/tests/AKimiConsultationScenarioTests.cs:36-63`

```csharp

    /// <summary>The homes root, inside the scenario's data directory — removed with it, and never the machine's own local data.</summary>
    private string Homes => Directory.CreateDirectory(Path.Combine(_data, "homes")).FullName;

    private string FolderOf(string id) => ConsultantHomes.ConversationFolder(Homes, ConsultantHomes.Kimi, id);

    /// <summary>Several scopes, given back in reverse.</summary>
    internal sealed class Scopes(params IDisposable[] scopes) : IDisposable
    {
        public void Dispose()
        {
            foreach (var scope in scopes.Reverse())
            {
                scope.Dispose();
            }
        }
    }

    /// <summary>
    /// The person, the host and the lock root this flow's Kimi adapters see — set by a SYNCHRONOUS call, so the values reach the test's own flow
    /// and every service call it awaits.
    /// </summary>
    internal static Scopes StandIn(KimiFixture person) => new(
        WindowsStandIn.Begin(),
        KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
        KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),
        CallingAs("CLAUDE_CODE_SESSION_ID"));

```

`CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder == "coai-vh"`; `VibeHomes.OneShotIn(string root, string id)`. `CoaiMcp.Runners.Files.GitScratch.AfterUnlink` is `internal static Action<string>? AfterUnlink` (settable from tests; reset to null in Dispose). `CoaiMcp.Runners.Acp.AcpWords.HomeFlag == "--home"`, `AcpWords.SessionFlag == "--session"`.

### TempDir (namespace CoaiMcp.Tests) — `src_mcp/tests/TempDir.cs:23-45`

```csharp
public sealed class TempDir : IDisposable
{
    private TempDir(string path) => Path = path;

    /// <summary>Where it is. Also what an implicit conversion to <see cref="string"/> gives you.</summary>
    public string Path { get; }

    /// <summary>A fresh directory under the system temp root, named for the test that wanted it.</summary>
    public static TempDir For(string prefix) =>
        new(Directory.CreateTempSubdirectory(prefix).FullName);

    /// <summary>So it can be passed anywhere a path is taken, without <c>.Path</c> at every call.</summary>
    public static implicit operator string(TempDir directory) => directory.Path;

    /// <summary>A path inside it.</summary>
    public string At(params string[] parts) =>
        System.IO.Path.Combine([Path, .. parts]);

    public void Dispose()
    {
        try
        {
            // The product's deleter: read-only files AND folders (a Vibe home's plugin folders, research/RESULTS_vibe_confinement.md
```


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Runners.Acp;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Vibe;
using CoaiMcp.Server;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// <c>--check-consultant</c> for a Kimi row (E5.5 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.5.1–S5.5.4): one turn as a consultation makes
/// it — in a COPY of the check's scratch repository, on a ONE-SHOT owned home (junction and all) under <c>&lt;root&gt;\coai-vh\&lt;8&gt;\kh-&lt;10 hex&gt;</c>,
/// disposed junction-first whatever ended the check; and the check's own invariant (the scratch repository unchanged, the canary untouched) holds.
/// </summary>
/// <remarks>
/// The check mode runs in process (<see cref="ConsultantCheckMode.AnswerAsync"/>), git for real, the Kimi shim played (<see cref="PlayedKimi"/>) over a
/// fake person's sign-in (<see cref="KimiFixture"/>); no turn is paid for and the real <c>kimi</c> never starts. Shaped like the Vibe checks of
/// <see cref="ConsultantCheckTests"/>. The person's folder and the homes root are test folders named <c>testsToDelete-…</c>.
/// </remarks>
public sealed class AKimiConsultantCheckTests : IDisposable
{
    private readonly string _data = Directory.CreateTempSubdirectory("testsToDelete-kimi-check-data-").FullName;
    private readonly string _temp = Directory.CreateTempSubdirectory("testsToDelete-kimi-check-temp-").FullName;
    private readonly TempDir _homes = TempDir.For("testsToDelete-kimi-check-homes-");
    private readonly KimiFixture _person = new();
    private readonly List<string> _warned = [];
    private readonly List<string> _unlinkedByTheDeleter = [];

    public void Dispose()
    {
        GitScratch.AfterUnlink = null;
        _homes.Dispose();
        _person.Dispose();
        foreach (var dir in (string[])[_data, _temp])
        {
            Directory.Delete(dir, recursive: true);
        }
    }

    /// <summary>The deleter's own unlink recorder — a Kimi home disposed junction-first never lets the deleter meet its junction.</summary>
    private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;

    /// <summary>The settings of a check of one Kimi row; <paramref name="homesRoot"/> empty is a hand-built, root-less one (S5.5.4).</summary>
    private PanelSettings Settings(string homesRoot, TimeSpan? timeout = null) => new()
    {
        Providers = [],
        DataDir = _data,
        ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60),
        ConsultEnabled = true,
        ConsultantHomesRoot = homesRoot,
        Consultants = new Dictionary<string, ConsultantChoice> { [CallerIdentity.Claude] = new("my-kimi", Runtime: "kimi") },
    };

    private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct)
    {
        var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", "--caller", "claude"], launcher, _temp, _warned.Add, Noticing.None, ct);

        return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
    }

    private static string Text(JsonElement element, string name) => element.GetProperty(name).GetString() ?? string.Empty;

    /// <summary>The value after <paramref name="flag"/> in a shim request's arguments.</summary>
    private static string After(ProcessRequest request, string flag) => request.Arguments[request.Arguments.ToList().IndexOf(flag) + 1];

    /// <summary>A played Kimi whose answer reads the check's marker in the folder the shim stood in — what a consultation's turn does (see <c>AVibeCheck_…</c>).</summary>
    private PlayedKimi Played(Func<ProcessRequest, ProcessResult>? turn = null)
    {
        // QWEN-FILL-BEGIN s55-played test
        // Return `new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => ... }` where, when `turn` is null, the turn reads the marker:
        // `File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.')` and answers
        // `PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT")`; when `turn` is not null the
        // Turn is `(_, request) => turn(request)`.
        throw new NotImplementedException("s55-played");
        // QWEN-FILL-END s55-played
    }

    // ---------- S5.5.1 ----------

    [Fact]
    public async Task AKimiCheck_RunsInACopy_OnAOneShotHome()
    {
        // QWEN-FILL-BEGIN s551-check test
        // Arrange: `using var stood = AKimiConsultationScenarioTests.StandIn(_person);` (the fake person, the host and the lock root the adapter sees);
        // `var played = Played();`. Windows only: `Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Kimi is refused on every host but Windows");` first.
        // Act: `var (code, said, _) = await Check(Settings(_homes), played, TestContext.Current.CancellationToken);` (TempDir converts to string implicitly, as
        // the Vibe check test passes `homes`).
        // Assert: code Should().Be(0); Text(said, "state") Should().Be("answered", said.ToString()); said.GetProperty("markerRead").GetBoolean() Should().BeTrue();
        // `var turn = played.Shims.Should().ContainSingle().Subject.Request;` turn.Arguments: `After(turn, "--cwd")` Should().Contain(Path.Combine("own", "tree"));
        // `var home = After(turn, AcpWords.HomeFlag);` home Should().StartWith(Path.Combine(_homes, VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar);
        // Path.GetFileName(home) Should().MatchRegex("^kh-[0-9a-f]{10}$"); the home's grandparent folder is `coai-vh` (Path.GetDirectoryName twice) — the `<8>` folder is its child.
        // The scratch repository and its canary unchanged: the mode's own invariant — `said` carries `canaryTouched`/`treeChanged` style fields; READ the Vibe check
        // test and ConsultantCheckTests.ACanaryTheConsultantChanged_IsATreeChange_NotAnAnswer in the pack and assert the "answered" state is enough if no field exists.
        // Fails before E5.4 with: Expected the check of my-kimi to pass, but it failed: the vendor 'my-kimi' runs on 'kimi', which cannot hold a consultation in this build.
        throw new NotImplementedException("s551-check");
        // QWEN-FILL-END s551-check
    }

    // ---------- S5.5.2 ----------

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task AfterTheCheck_TheHomeIsGone_JunctionFirst(bool theTurnFails)
    {
        // QWEN-FILL-BEGIN s552-gone test   <<< REGION s552-gone STARTS AFTER THIS LINE
        // Arrange: as S5.5.1 (stand-in, `Played(...)`); `var before = _person.Hash();` `RecordingTheDeleter();`. When `theTurnFails`, the played turn is
        // `request => new ProcessResult(70, string.Empty, "the played shim failed" + Environment.NewLine, TimedOut: false)` (exit 70, as the shim's
        // `agent_failed`); else the default answering turn. Windows only: `Assert.SkipUnless(OperatingSystem.IsWindows(), ...)` first.
        // Act: `await Check(Settings(_homes), played, TestContext.Current.CancellationToken)`. In the failing arm do NOT assert the state is answered.
        // Assert: `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))` Should().BeEmpty("the home's folder goes when the check
        // ends, whatever ended it"); `_unlinkedByTheDeleter` Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the
        // junction first"); `_person.Hash()` Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before").
        // Fails before E5.3 g with: Expected the deleter's unlink recorder not to be invoked …
        throw new NotImplementedException("s552-gone " + theTurnFails);
        // QWEN-FILL-END s552-gone   <<< REGION s552-gone ENDS BEFORE THIS LINE
    }

    // ---------- S5.5.3 ----------

    [Fact]
    public async Task ACheckCancelledMidTurn_StillDisposesItsHome()
    {
        // QWEN-FILL-BEGIN s553-cancel test
        // Arrange: stand-in as S5.5.1; `RecordingTheDeleter();` `var before = _person.Hash();` `using var caller = CancellationTokenSource.CreateLinkedTokenSource(
        // TestContext.Current.CancellationToken);` a PlayedKimi built with `new PlayedKimi(new ProcessLauncher()) { During = async (_, ct) => { await caller.CancelAsync();
        // ct.ThrowIfCancellationRequested(); } }` (so the shim "blocks" until cancelled). Windows only: SkipUnless first.
        // Act: `var (_, said, _) = await Check(Settings(_homes), played, caller.Token);` — the check answers a cancelled RECORD rather than throwing (see
        // ConsultantCheckTests.ACheckCancelledWhileItsScratchIsMade_IsCancelled_NotUnavailable in the pack for the exact state word and the call shape).
        // Assert: Text(said, "state") Should().Be("failed", said.ToString()) and Text(said, "failureKind") Should().Be("cancelled") (the words the existing cancelled
        // check test uses); `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder))`
        // Should().BeEmpty(); `_unlinkedByTheDeleter` Should().BeEmpty(); `_person.Hash()` Should().Equal(before).
        // Green after E5.3 g (it pins the `finally`); not red against the present tree.
        throw new NotImplementedException("s553-cancel");
        // QWEN-FILL-END s553-cancel
    }

    // ---------- S5.5.4 ----------

    [Fact]
    public async Task ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst()
    {
        // QWEN-FILL-BEGIN s554-rootless test
        // Arrange: stand-in as S5.5.1; `RecordingTheDeleter();` `var before = _person.Hash();` `var played = Played();` settings built by hand with NO root:
        // `Settings(string.Empty)`. Windows only: SkipUnless first.
        // Act: `var (code, said, _) = await Check(Settings(string.Empty), played, TestContext.Current.CancellationToken);`
        // Assert: code Should().Be(0); `var turn = played.Shims.Should().ContainSingle().Subject.Request;` `After(turn, AcpWords.HomeFlag)` Should().Contain(Path.Combine("own", "kh-"))
        // (the home is `<scratch>\own\kh-<10 hex>`) — and Path.GetFileName(home) MatchRegex("^kh-[0-9a-f]{10}$"); after the check
        // `Directory.EnumerateDirectories(_temp, "coai-check-*")` Should().BeEmpty("the scratch is gone"); `_unlinkedByTheDeleter` Should().BeEmpty();
        // `_person.Hash()` Should().Equal(before).
        // Fails before E5.3 g with: Expected the deleter's unlink recorder not to be invoked …
        throw new NotImplementedException("s554-rootless");
        // QWEN-FILL-END s554-rootless
    }
}

```
