```csharp
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Kimi is refused on every host but Windows");
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var before = _person.Hash();
        RecordingTheDeleter();
        var granted = Path.Combine(Repo, "src");
        if (ending == "refused")
        {
            var plain = _dir.At("plain");
            Directory.CreateDirectory(plain);
            File.WriteAllText(Path.Combine(plain, "file.txt"), "x");
            granted = Directory.CreateDirectory(plain).FullName;
        }
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        var played = new PlayedKimi(_launcher)
        {
            During = ending == "cancelled"
                ? async (_, ct) => { await caller.CancelAsync(); ct.ThrowIfCancellationRequested(); }
                : (_, _) => Task.CompletedTask,
        };
        if (ending == "cancelled")
        {
            var asking = async () => await AskAsync(Service(played, granted), caller.Token);
            await asking.Should().ThrowAsync<OperationCanceledException>();
        }
        else
        {
            var reply = await AskAsync(Service(played, granted));
            if (ending == "answered")
            {
                TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());
                played.Shims.Should().ContainSingle();
                var shim = played.Shims.Dequeue();
                shim.Request.StdIn.Should().Contain(shim.Request.WorkingDirectory);
                shim.Request.StdIn.Should().NotContain(granted);
            }
            else
            {
                TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Refused, reply.ToString());
                played.Shims.Should().BeEmpty();
            }
        }
        var oneShot = Path.Combine(Homes, VibeHomes.OneShotFolder);
        (Directory.Exists(oneShot) ? Directory.EnumerateFileSystemEntries(oneShot) : Enumerable.Empty<string>()).Should().BeEmpty();
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
        _person.Hash().Should().Equal(before);
        if (ending == "answered" || ending == "cancelled")
        {
            var shim = played.Shims.Dequeue();
            var args = shim.Request.Arguments.ToList();
            var homeIdx = args.IndexOf(AcpWords.HomeFlag);
            homeIdx.Should().BeGreaterOrEqualTo(0);
            var home = args[homeIdx + 1];
            Directory.Exists(home).Should().BeFalse();
            Directory.Exists(Path.GetDirectoryName(home)!).Should().BeFalse();
        }
```