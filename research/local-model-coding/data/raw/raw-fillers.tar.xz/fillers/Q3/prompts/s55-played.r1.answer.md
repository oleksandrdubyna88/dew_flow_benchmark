```csharp
        return new PlayedKimi(new ProcessLauncher()) { Turn = turn is null ? (_, request) =>
        {
            var marker = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
            return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
        } : (_, request) => turn(request) };
```