```csharp
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Kimi is refused on every host but Windows");
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var played = Played();
        var (code, said, _) = await Check(Settings(_homes), played, TestContext.Current.CancellationToken);
        code.Should().Be(0);
        Text(said, "state").Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue();
        var turn = played.Shims.Should().ContainSingle().Subject.Request;
        After(turn, "--cwd").Should().Contain(Path.Combine("own", "tree"));
        var home = After(turn, AcpWords.HomeFlag);
        home.Should().StartWith(Path.Combine(_homes, VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar);
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        Path.GetDirectoryName(Path.GetDirectoryName(home)).Should().Be(Path.Combine(_homes, VibeHomes.OneShotFolder));
        if (said.TryGetProperty("canaryTouched", out var canaryTouched) && canaryTouched.GetBoolean())
        {
            Assert.Fail("Expected the check of my-kimi to pass, but it failed: the vendor 'my-kimi' runs on 'kimi', which cannot hold a consultation in this build.");
        }
        if (said.TryGetProperty("treeChanged", out var treeChanged) && treeChanged.GetBoolean())
        {
            Assert.Fail("Expected the check of my-kimi to pass, but it failed: the vendor 'my-kimi' runs on 'kimi', which cannot hold a consultation in this build.");
        }
```