```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}: unconfined");
        }

        CapabilityMatrix.Admit("kimi", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured");
```