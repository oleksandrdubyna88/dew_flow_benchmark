You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s565-launch — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Arrange: `var consultant = KimiConsultant();` (this class's helper, above); the launches are `Planned("kimi", CapabilityGrant.None)` and
`Planned("kimi", CapabilityGrant.Disk(RootA, RootB))` (this class's `Planned(runtime, grant, model = "")` helper: OwnedScratch = RowFolder,
ScratchDir = Scratch, Workdir = RowTree).
Act: `var none = consultant.Build(...)` and `var disk = consultant.Build(...)` (both ReviewerInvocation).
Assert: none.Request.WorkingDirectory Should().Be(Scratch); disk.Request.WorkingDirectory Should().Be(RowTree).
  For each of none.Request and disk.Request: Arguments Should().NotContain("--session") and Should().NotContain(RootA) and Should().NotContain(RootB);
  the value after "--home" (find with `request.Arguments.ToList().IndexOf("--home") + 1`; the constant is CoaiMcp.Runners.Acp.AcpWords.HomeFlag)
  Should().StartWith(RowFolder + Path.DirectorySeparatorChar); request.InheritsEnvironment Should().BeFalse();
  Runners.Kimi.KimiEnvironment.Refusal(request, <the places of the home>) Should().BeEmpty() — see the pack for how the existing KimiConsultantTests
  build `places`; if that cannot be done inside this class without a KimiFixture, skip that single assertion and say so in a comment.
  none.Role Should().Be(ConsultantRoles.Question).
Fails before the change: against a stub that ignores the plan, WorkingDirectory is the checkout, not Scratch / RowTree.

## The exact existing types and members you may use (context pack)
# Region `s565-launch` (test) — `src_mcp/tests/ConfinementPlannerTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

The helper `KimiConsultant()` (this class) gives the consultant on a fake person's paths (`KimiSeams` over `KimiPlaces.ForShim`). `Planned(runtime, grant, model = "")` gives a planned launch with `OwnedScratch = RowFolder`, `ScratchDir = Scratch`, `Workdir = RowTree`. `Build` returns `ReviewerInvocation` with `.Request` (`ProcessRequest`) and `.Role`.

### KimiConsultant (production) — `src_mcp/runners/Kimi/KimiConsultant.cs:30-110`

```csharp

    public ConsultantMemory Memory => new ConsultantMemory.VendorRemembers();

    /// <summary>M-K5b (RESULTS §23), and three turns of one session in M-K16 (d): <c>/usage</c> is the session's running total.</summary>
    public bool UsageIsCumulative => true;

    /// <summary>D6: Kimi loads a project <c>.kimi-code</c>, <c>AGENTS.md</c>, skills and <c>.mcp.json</c> from its working folder.</summary>
    public bool NeedsASanitisedSnapshot => true;

    /// <summary>One coai-owned home per conversation, under <see cref="ConsultantHomes.Kimi"/> (J3), swept with it (D20).</summary>
    public string HomesFolder => ConsultantHomes.Kimi;

    /// <summary>Only what was observed working (decision 7): <c>Read</c> inside the copy (M-K6), <c>Grep</c> and <c>Glob</c> (RESULTS §17) — never claimed bounded.</summary>
    public string Toolbox =>
        "You read files with Read, by a path inside your working folder — a copy coai made of the checkout without its .git, .kimi-code/, "
        + ".agents/ skills and sub-agents, .mcp.json and AGENTS.md; Grep and Glob search files too. Every write and every shell command is refused.";

    public ReviewerInvocation Build(ConsultantLaunch launch)
    {
        ConsultantLaunches.MustBeLaunchable(launch);
        MustCarryNoFlags(launch);
        var settings = launch.Settings with { OwnedScratch = OwnedFolder(launch), Model = ModelOf(launch.Settings) };
        var built = inner.Build(ConsultantLaunches.RoleOf(launch), launch.Prompt, Cwd(launch), string.Empty, launch.OutputDir, settings);
        var request = built.Request with { Arguments = [.. built.Request.Arguments, .. SessionOf(launch)] };
        ConsultantLaunches.MustCarryNoLineBreak(request.Arguments);

        return built with { Request = launch.Confinement is LaunchConfinement.Planned ? ConsultantLaunches.ForQuestion(request) : request };
    }

    /// <summary>A planned row's confinement is the shim's (D15), never the argv's: a plan that carries any flag is not one coai made for kimi (decision 3 of E5.6).</summary>
    private static void MustCarryNoFlags(ConsultantLaunch launch)
    {
        if (launch.Confinement is LaunchConfinement.Planned { Plan: { Flags.Count: > 0 } or { Leading.Count: > 0 } })
        {
            throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch));
        }
    }

    /// <summary>The row's model, or Kimi's default when it names none — resolved here so the shim and the ledger name the same one.</summary>
    private static string ModelOf(ReviewerSettings settings) => settings.Model.Length > 0 ? settings.Model : KimiModels.Default;

    /// <summary>The session a later turn continues — the shim's own flag (E5.2), last on the argv — or nothing for a first turn.</summary>
    private static string[] SessionOf(ConsultantLaunch launch) =>
        launch.Handle.Length > 0 ? [AcpWords.SessionFlag, launch.Handle] : [];

    /// <summary>The conversation's snapshot, or the planned row's cwd — never the checkout, and never a guess.</summary>
    private static string Cwd(ConsultantLaunch launch) =>
        launch.Confinement is LaunchConfinement.Planned planned ? ConsultantLaunches.Cwd(launch, planned.Plan) : SnapshotOf(launch);

    private static string SnapshotOf(ConsultantLaunch launch) =>
        launch.Workdir.Length > 0
            ? launch.Workdir
            : throw new ArgumentException(
                "a Kimi consultant stands in the conversation's sanitised snapshot (Workdir), and none was made — the checkout is never its working folder (D6)",
                nameof(launch));

    private static string OwnedFolder(ConsultantLaunch launch) =>
        launch.Settings.OwnedScratch.Length > 0
            ? launch.Settings.OwnedScratch
            : throw new ArgumentException(
                "a Kimi consultant keeps its home in a coai-owned folder of the conversation or the row (OwnedScratch), and none was given — never TEMP or the answers folder (D19)",
                nameof(launch));

    /// <summary>The report's <c>sessionId</c> when it is a well-formed handle — the shim names it on every exit that prints a report — or empty.</summary>
    public string ReadHandle(ProcessResult result) =>
        KimiReport.Parse(result.StdOut).SessionId is var id && ConsultantHandle.IsWellFormed(id) ? id : string.Empty;

    /// <summary>The shim's END word says the agent no longer holds the session <c>--session</c> named (E5.2) — read off the report, never its text.</summary>
    public bool DroppedTheConversation(ProcessResult result) => KimiReport.Parse(result.StdOut).End == AcpWords.SessionLostWord;
}

```
### The Adapters() helper and the consult launch test (this class) — `src_mcp/tests/ConfinementPlannerTests.cs:519-530`

```csharp
    private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters() =>
    [
        ("claude", new ClaudeConsultant(new ClaudeRuntime())),
        ("codex", new CodexConsultant(new CodexRuntime())),
        ("antigravity", new AntigravityConsultant(new AntigravityRuntime())),
        ("vibe", new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows))),
        // A fake person's paths, so building reads nothing of this machine: the request names the places, it does not open them.
        ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
            new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))))),
    ];
}

```
### The Vibe question launch test — the shape for S5.6.5 — `src_mcp/tests/ConfinementPlannerTests.cs:368-402`

```csharp
    /// <summary>
    /// A Vibe question row (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): the plan's read-only pair, a none row in its EMPTY
    /// scratch and a disk row in the copy of its roots — never a root, never the checkout — on the row's own home in the
    /// built environment: <c>VIBE_CLI=python</c> and the model in the EXPLICIT environment, which is all a question row's
    /// minimal child gets (M-V12, 3 of 3).
    /// </summary>
    [Fact]
    public void AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));

        var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file")
            .And.ContainInConsecutiveOrder("--workdir", Scratch)
            .And.NotContain("--trust").And.NotContain("--add-dir").And.NotContain("--resume", "one shot");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-V11: Vibe reads its cwd only — the copy of the roots (D6)");
        disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.InheritsEnvironment.Should().BeFalse();
            request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
            request.Environment.Should().Contain(Runners.Vibe.VibeLaunch.CliVariable, "python").And.Contain(Runners.Vibe.VibeLaunch.ModelVariable, "glm-5-3");
            request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");
            Runners.Vibe.VibeLaunch.EnvironmentRefusal(request).Should().BeEmpty("the one launch control admits it (D17)");
        }
    }

    /// <summary>No Vibe launch carries <c>--add-dir</c>, whatever the grant (D3: <c>--add-dir</c> trusts its folder).</summary>
    [Fact]
```
### KimiEnvironment.Refusal — `src_mcp/runners/Kimi/KimiEnvironment.cs:80-95`

```csharp
    }

    /// <summary>
    /// D19: the launch is the built one. A path that built a Kimi launch any other way is refused here rather than started — the
    /// FIRST of: the structure (nothing inherited, the minimal names, exactly the seven), then each value, then — when the argv
    /// carries them — the two place flags. Each sentence names the value it found.
    /// </summary>
    public static string Refusal(ProcessRequest request, KimiPlaces places) =>
        new Func<string>[]
        {
            () => Structure(request),
            () => Same(request, HomeVariable, places.Home, "the owned home"),
            () => Same(request, ProfileVariable, places.Os, "coai's own os/ folder (the OS-home redirect)"),
            () => Same(request, HomeNameVariable, places.Os, "coai's own os/ folder (the OS-home redirect)"),
            () => DrivePath(request, places),
            () => Pinned(request),
```
### KimiPlaces — `src_mcp/runners/Kimi/KimiPlaces.cs:20-75`

```csharp
/// </remarks>
/// <param name="OwnedRoot">The coai-owned root: holds <c>home/</c> (the owned <c>KIMI_CODE_HOME</c>) and <c>os/</c> (the empty OS home).</param>
/// <param name="PersonsHome">The person's data folder; empty for the shim, which learns the sign-in folder from the owned junction's own reparse data.</param>
/// <param name="PersonsBin">The folder the person's tools live in; the built <c>PATH</c> begins with it.</param>
/// <param name="ToolFolders">The other folders <c>rg</c> and <c>fd</c> were found in (<see cref="KimiTools.FoldersFor"/>).</param>
/// <param name="ToolsRefusal">Why <c>rg</c> and <c>fd</c> were not both found, or empty.</param>
/// <param name="Executable">The absolute <c>kimi</c> — or the bare name, which fails the launch with the install cure; empty for the shim.</param>
public sealed record KimiPlaces(string OwnedRoot, string PersonsHome, string PersonsBin, IReadOnlyList<string> ToolFolders, string ToolsRefusal, string Executable)
{
    private const string Bare = "kimi";

    /// <summary>The owned <c>KIMI_CODE_HOME</c>.</summary>
    public string Home => Path.Combine(OwnedRoot, "home");

    /// <summary>The empty OS home the redirected <c>USERPROFILE</c>/<c>HOME</c> point at.</summary>
    public string Os => Path.Combine(OwnedRoot, "os");

    /// <summary>The junction to the person's <c>credentials</c>, inside the owned home.</summary>
    public string Link => Path.Combine(Home, "credentials");

    /// <summary>The one <c>config.toml</c> coai writes.</summary>
    public string Config => Path.Combine(Home, "config.toml");

    /// <summary>The person's <c>credentials</c> folder — the junction's target; empty when the person's home is not known (the shim).</summary>
    public string Credentials => PersonsHome.Length == 0 ? string.Empty : Path.Combine(PersonsHome, "credentials");

    /// <summary>The person's own <c>config.toml</c>, read for the OAuth slot and the model block; empty for the shim.</summary>
    public string PersonsConfig => PersonsHome.Length == 0 ? string.Empty : Path.Combine(PersonsHome, "config.toml");

    /// <summary>The places for a launch of the real <c>kimi</c>, from the parent's own environment and the REAL profile.</summary>
    public static KimiPlaces Resolve(string ownedRoot, HostKind host, Func<string, string?> env, string userProfile, Func<string, bool> fileExists)
    {
        var windows = host == HostKind.Windows;
        var installer = Join(windows, userProfile, ".kimi-code");
        var home = NonEmpty(env("KIMI_CODE_HOME"), installer);
        var bin = Join(windows, NonEmpty(env("KIMI_INSTALL_DIR"), installer), "bin");

        return new KimiPlaces(
            ownedRoot,
            home,
            bin,
            KimiTools.FoldersFor(windows, bin, env("PATH"), env("PATHEXT"), fileExists),
            KimiTools.Refusal(windows, bin, env("PATH"), env("PATHEXT"), fileExists),
            ExecutableOf(host, bin, userProfile, env("PATH"), fileExists));
    }

    /// <summary>The places the SHIM knows: the owned root and the person's bin it was handed — nothing read from any environment.</summary>
    public static KimiPlaces ForShim(string ownedRoot, string personsBin) =>
        new(ownedRoot, string.Empty, personsBin, [], string.Empty, string.Empty);

    /// <summary>The installed <c>kimi</c> by absolute path: the person's bin, then the installer's default, then wherever <c>PATH</c> finds it — else the bare name.</summary>
    private static string ExecutableOf(HostKind host, string bin, string userProfile, string? path, Func<string, bool> fileExists)
    {
        var windows = host == HostKind.Windows;
        var inBin = windows ? Join(true, bin, "kimi.exe") : string.Empty;
        Func<string>[] ways =
```
### KimiConsultantTests — how a launch and the places are built there — `src_mcp/tests/KimiConsultantTests.cs:25-80`

```csharp
    private readonly KimiFixture _person = new();

    public void Dispose() => _person.Dispose();

    private string Repo => Path.Combine(_person.Folder, "checkout");

    private string Answers => Path.Combine(_person.Folder, "data", "coai-answers");

    /// <summary>The conversation's folder under the homes root: <c>coai-kimi\&lt;id&gt;</c>.</summary>
    private string Folder => ConsultantHomes.ConversationFolder(Path.Combine(_person.Folder, "homes"), ConsultantHomes.Kimi, new string('a', 32));

    private string Tree => Path.Combine(Folder, "tree");

    private KimiConsultant Consultant() =>
        new(new KimiRuntime("my-kimi", HostKind.Windows, new KimiSeams(_person.PlacesAt, () => ("coai-mcp", []))), "my-kimi");

    private ConsultantLaunch Turn(string handle = "", string model = "") =>
        new(Repo, "why is the count wrong\nsee the diff", handle, Answers,
            new ReviewerSettings("my-kimi") { Model = model, Timeout = TimeSpan.FromMinutes(5), OwnedScratch = Folder })
        {
            Workdir = Tree,
        };

    private static string After(IReadOnlyList<string> args, string flag) => args[args.ToList().IndexOf(flag) + 1];

    // ---------- S5.4.1 ----------

    [Fact]
    public void AKimiRow_IsAConsultant_AndAnAnsweringRuntime()
    {
        var row = new VendorIdentity("my-kimi", "kimi", string.Empty);

        var consultant = ConsultantResolution.For(row);

        consultant.Should().NotBeNull("features.consultant names kimi (decision 9), and OnACli resolves it (decision 10)");
        consultant.Should().BeOfType<KimiConsultant>().Which.Vendor.Should().Be("my-kimi");
        ConsultantResolution.Consulting.Should().Contain("kimi");
        QuestionResolution.Answering.Should().Contain("kimi", "Answering follows Consulting by itself (decision 10)");
    }

    // ---------- S5.4.2 ----------

    [Fact]
    public void TheFirstTurn_IsTheShimRequest_InTheSnapshot_OnTheConversationsHome()
    {
        var invocation = Consultant().Build(Turn());
        var request = invocation.Request;

        request.WorkingDirectory.Should().Be(Tree, "D6: the conversation's one stable snapshot — never the checkout, never the answers folder");
        request.Arguments.Should().ContainInConsecutiveOrder("--ask-acp", "--profile", "kimi", "--model", KimiModels.Default, "--cwd", Tree);
        var home = After(request.Arguments, AcpWords.HomeFlag);
        Path.GetDirectoryName(home).Should().Be(Folder, "the home is a CHILD of the conversation folder (E5.3 decision a)");
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        request.Arguments.Should().NotContain("--session", "a first turn continues nothing");
        request.StdIn.Should().Be("why is the count wrong\nsee the diff", "the prompt rides stdin, never the argv");
        request.Arguments.Should().NotContain(argument => argument.Contains('\n') || argument.Contains('\r'));
```

### ConfinementPlannerTests helpers (this class) — `src_mcp/tests/ConfinementPlannerTests.cs:21-30`

```csharp
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------
```
### The Vibe planner test — the shape — `src_mcp/tests/ConfinementPlannerTests.cs:126-148`

```csharp
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    // ---------- Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md) ----------

    /// <summary>S5.6.3: the planner's Kimi arm carries NO flags (decision 1) — a copy of the roots for disk, an empty folder for none, a refusal for web.</summary>
```
### Planned launch helper, constants — `src_mcp/tests/ConfinementPlannerTests.cs:270-290`

```csharp
    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
```
### Confinement.Planned and CwdKind — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:10-52`

```csharp
public enum CwdKind
{
    Scratch,

    Root,

    /// <summary>
    /// A coai-owned SANITISED SNAPSHOT of the granted roots, made by the launch (D6 of todo/PLAN_vibe_and_kimi_runtimes.md)
    /// — for a CLI that reads only its working folder and loads its configuration from it (Vibe, M-V11), whose roots
    /// therefore can be neither its cwd nor an added directory.
    /// </summary>
    Snapshot,
}

/// <summary>What the planner decided for one runtime × grant: the fragments to compose, or a refusal.</summary>
public abstract record Confinement
{
    /// <param name="Leading">Argv BEFORE the CLI's subcommand — codex's top-level <c>--search</c> (F1); empty everywhere else.</param>
    /// <param name="Flags">The sandbox flags, in order, complete — an adapter splices them and adds none of its own.</param>
    /// <param name="Cwd">Where the process stands.</param>
    /// <param name="AddDirs">The roots the flags grant as LAUNCH FLAGS (<c>--add-dir</c>), for the record; the flags already spell them the runtime's way — never a copy's sources.</param>
    /// <param name="Flag">D13's caveat on an admitted pair — shown beside every answer the row produces.</param>
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,
        IReadOnlyList<string> Flags,
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        /// <summary>
        /// The folders the launch reads through COPIES (<see cref="CwdKind.Snapshot"/>, D6) — never a launch flag. Its own field,
        /// not <see cref="AddDirs"/>: there a root is something the CLI is told to read, and Vibe is never given one (D3, the
        /// #811 checkpoint round).
        /// </summary>
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }

    public sealed record Refused(string Reason) : Confinement;

    private Confinement() { }
}
```
### The planner arm (already written) — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:151-160`

```csharp
    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag),
        "codex" => Codex(grant, flag),
        "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),
        // A completion has no tools, so it has no sandbox flag: the question alone, from nowhere.
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };
```

### ProcessRequest — `src_mcp/runners/Processes/ProcessLauncher.cs:5-40`

```csharp
public sealed record ProcessRequest(
    string Executable,
    IReadOnlyList<string> Arguments,
    string WorkingDirectory)
{
    public IReadOnlyDictionary<string, string?> Environment { get; init; } =
        new Dictionary<string, string?>();

    /// <summary>
    /// Written to the child's stdin, then closed. Empty means "close immediately".
    /// </summary>
    /// <remarks>
    /// This is how every long or multi-line input travels. On Windows the vendor CLIs are npm
    /// <c>.cmd</c> shims, which cmd.exe parses — and cmd.exe truncates an argument at its first
    /// newline. The first real run (2026-08-31) passed a full review prompt in argv and the model
    /// answered "No implementation plan was provided": it had received the first line and nothing
    /// else, silently. stdin has no such parser between us and the process.
    /// </remarks>
    public string StdIn { get; init; } = string.Empty;

    public TimeSpan Timeout { get; init; } = TimeSpan.FromMinutes(10);

    /// <summary>
    /// How much of each stream is kept. Past it the rest is dropped and the text says so.
    /// </summary>
    /// <remarks>
    /// <para>CHARACTERS rather than bytes, and the difference is not pedantry: what is bounded is the
    /// memory of a .NET string, which is two bytes per character. The default is therefore
    /// 8 Mi characters — <b>16 MiB</b> per stream, which is the number the plan named.</para>
    /// <para>It has to be enforced while the stream is READ, not per line. A child can write two
    /// hundred megabytes without a single newline; a line-based reader delivers none of it until the
    /// stream closes, so a ceiling checked in a line callback fires only after the allocation it
    /// exists to prevent has already happened. (codex, plan round.)</para>
    /// <para>The child is not killed for reaching it — the rest is read and discarded, so a runaway
    /// cannot block on a pipe nobody is draining either. Its exit code and the head of what it said
    /// are still returned.</para>
```

`CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder == "coai-vh"`; `VibeHomes.OneShotIn(string root, string id)`. `CoaiMcp.Runners.Files.GitScratch.AfterUnlink` is `internal static Action<string>? AfterUnlink` (settable from tests; reset to null in Dispose). `CoaiMcp.Runners.Acp.AcpWords.HomeFlag == "--home"`, `AcpWords.SessionFlag == "--session"`.


## The whole file (the region is marked with <<<)
```csharp
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Reviewers;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The confinement planner is the ONE place a question row's sandbox flags are decided, and every
/// adapter composes them rather than choosing its own (PLAN_question_consultant.md, D4; S1 acceptance 2).
/// </summary>
/// <remarks>
/// <para>Every fragment below is a fact from the probe run of 2026-10-01 (F1–F7 of the plan, cited by
/// row in <c>shared/runtime-capabilities.json</c>): claude's <c>--tools</c> allow-list and
/// <c>--restricted</c>, codex's top-level <c>--search</c>, agy's <c>--mode plan</c>. The goldens are
/// asserted as WHOLE argv lists, so an adapter that adds a sandbox flag of its own — or drops one the
/// planner gave it — fails here rather than reading past its roots with nothing in the output to say so.</para>
/// <para><c>--disallowedTools</c> appears in no plan and no planned launch: the shipped deny lists are
/// offered the user environment's whole tool set and leaked the canary 6 of 6 (F5).</para>
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------

    [Fact]
    public void Claude_None_OffersNoToolAtAll_InAScratchCwd()
    {
        var plan = Plan("claude", CapabilityGrant.None);

        plan.Leading.Should().BeEmpty();
        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "");
        plan.Cwd.Should().Be(CwdKind.Scratch);
        plan.AddDirs.Should().BeEmpty();
        plan.Flag.Should().Be(AdmissionFlag.None);
    }

    [Fact]
    public void Claude_Disk_IsRestricted_WithTheThreeReadTools_AndEveryRootAdded()
    {
        var plan = Plan("claude", CapabilityGrant.Disk(RootA, RootB));

        plan.Flags.Should().Equal(
            "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB);
        plan.Cwd.Should().Be(CwdKind.Root, "the first root is the working directory (F4: --restricted confines to the working directories)");
        plan.AddDirs.Should().Equal(RootA, RootB);
        plan.Flags.Should().NotContain("Bash").And.NotContain("PowerShell", "no shell tool is offered to a disk row");
    }

    [Fact]
    public void Claude_Web_OffersTheTwoWebTools_AndNoDirectory()
    {
        var plan = Plan("claude", CapabilityGrant.Web);

        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "WebSearch,WebFetch");
        plan.Flags.Should().NotContain("--add-dir", "a web row has no directory to read (A2)");
        plan.Flags.Should().NotContain("--restricted", "nothing file-capable is offered, so there is nothing to restrict");
        plan.Cwd.Should().Be(CwdKind.Scratch);
    }

    [Fact]
    public void Codex_EveryCapability_IsReadOnlyEphemeral_AndFlaggedUnconfined()
    {
        var none = Plan("codex", CapabilityGrant.None);
        none.Leading.Should().BeEmpty();
        none.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        none.Cwd.Should().Be(CwdKind.Scratch);

        var disk = Plan("codex", CapabilityGrant.Disk(RootA));
        disk.Flags.Should().Equal("-s", "read-only", "--ephemeral", "-C", RootA);
        disk.Cwd.Should().Be(CwdKind.Root);

        var web = Plan("codex", CapabilityGrant.Web);
        // The expectation is an ARRAY: `Equal("--search", "because…")` would assert the reason as a
        // second expected item — the trap ConsultantArgvTests already names.
        web.Leading.Should().Equal(["--search"], "F1: `--search` is a TOP-LEVEL flag; `codex exec --search` is a usage error (exit 2)");
        web.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        web.Cwd.Should().Be(CwdKind.Scratch);

        foreach (var plan in (Confinement.Planned[])[none, disk, web])
        {
            plan.Flag.Should().Be(AdmissionFlag.Unconfined, "F2: codex reads anywhere and no flag removes the shell (D13)");
        }
    }

    [Fact]
    public void Antigravity_None_IsPlanMode_AndDisk_AddsTheRoots_BothFlaggedDefaultDeny()
    {
        var none = Plan("antigravity", CapabilityGrant.None);
        none.Flags.Should().Equal("--mode", "plan");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.Flag.Should().Be(AdmissionFlag.DefaultDeny);

        var disk = Plan("antigravity", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--mode", "plan", "--add-dir", RootA, "--add-dir", RootB);
        disk.Cwd.Should().Be(CwdKind.Root);
        disk.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
    }

    [Fact]
    public void LocalAndApi_None_HaveNoFlagToSend_AndAScratchCwd()
    {
        foreach (var runtime in (string[])["local", "api"])
        {
            var plan = Plan(runtime, CapabilityGrant.None);

            plan.Leading.Should().BeEmpty(runtime);
            plan.Flags.Should().BeEmpty($"{runtime}: a completion has no sandbox flag — it has no tools");
            plan.Cwd.Should().Be(CwdKind.Scratch, runtime);
            plan.Flag.Should().Be(AdmissionFlag.None, runtime);
        }
    }

    /// <summary>
    /// Vibe (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): D2's two flags, both, on every capability — and no
    /// <c>--trust</c> or <c>--add-dir</c> ever (D3). A none row stands in an EMPTY scratch folder; a disk row stands in a
    /// SNAPSHOT of its roots (D6), because Vibe reads only its working folder (M-V11) — so its roots are never its cwd.
    /// </summary>
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    // ---------- Kimi (E5.6 of todo/PLAN_vibe_and_kimi_runtimes_E5.md) ----------

    /// <summary>S5.6.3: the planner's Kimi arm carries NO flags (decision 1) — a copy of the roots for disk, an empty folder for none, a refusal for web.</summary>
    [Fact]
    public void ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb()
    {
        // QWEN-FILL-BEGIN s563-planner test
        // Arrange: nothing (RootA and RootB are this class's constants; `Plan(runtime, grant)` is this class's helper and asserts Planned).
        // Act/Assert:
        //   none = Plan("kimi", CapabilityGrant.None): none.Cwd Should().Be(CwdKind.Scratch); none.Leading and none.Flags and none.AddDirs and
        //   none.SnapshotSources Should().BeEmpty(); none.Flag Should().Be(AdmissionFlag.Unconfined) (D13: the none row is unconfined too).
        //   disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB)): disk.Cwd Should().Be(CwdKind.Snapshot); disk.SnapshotSources Should().Equal([RootA, RootB]);
        //   disk.Leading, disk.Flags, disk.AddDirs Should().BeEmpty(); disk.Flag Should().Be(AdmissionFlag.Unconfined).
        //   web = ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>().Which.Reason: Should().Contain("not been measured")
        //   and Should().Contain("RESULTS_kimi_confinement.md").
        // Fails before the change: the default arm of ConfinementPlanner.Fragments gives an unknown runtime a Scratch cwd and the matrix refuses
        // kimi by name ("'kimi' is not a runtime the question consultant can launch ..."), so the first `Plan("kimi", ...)` fails its BeOfType<Planned>.
        throw new NotImplementedException("s563-planner");
        // QWEN-FILL-END s563-planner
    }

    private static Runners.Kimi.KimiConsultant KimiConsultant() => (Runners.Kimi.KimiConsultant)Adapters().Single(a => a.Runtime == "kimi").Consultant;

    /// <summary>S5.6.5: a Kimi question launch is the shim's request, in the row's folder or its copy, on the row's own home, one shot (the Vibe launch's shape).</summary>
    [Fact]
    public void AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome()
    {
        // QWEN-FILL-BEGIN s565-launch test   <<< REGION s565-launch STARTS AFTER THIS LINE
        // Arrange: `var consultant = KimiConsultant();` (this class's helper, above); the launches are `Planned("kimi", CapabilityGrant.None)` and
        // `Planned("kimi", CapabilityGrant.Disk(RootA, RootB))` (this class's `Planned(runtime, grant, model = "")` helper: OwnedScratch = RowFolder,
        // ScratchDir = Scratch, Workdir = RowTree).
        // Act: `var none = consultant.Build(...)` and `var disk = consultant.Build(...)` (both ReviewerInvocation).
        // Assert: none.Request.WorkingDirectory Should().Be(Scratch); disk.Request.WorkingDirectory Should().Be(RowTree).
        //   For each of none.Request and disk.Request: Arguments Should().NotContain("--session") and Should().NotContain(RootA) and Should().NotContain(RootB);
        //   the value after "--home" (find with `request.Arguments.ToList().IndexOf("--home") + 1`; the constant is CoaiMcp.Runners.Acp.AcpWords.HomeFlag)
        //   Should().StartWith(RowFolder + Path.DirectorySeparatorChar); request.InheritsEnvironment Should().BeFalse();
        //   Runners.Kimi.KimiEnvironment.Refusal(request, <the places of the home>) Should().BeEmpty() — see the pack for how the existing KimiConsultantTests
        //   build `places`; if that cannot be done inside this class without a KimiFixture, skip that single assertion and say so in a comment.
        //   none.Role Should().Be(ConsultantRoles.Question).
        // Fails before the change: against a stub that ignores the plan, WorkingDirectory is the checkout, not Scratch / RowTree.
        throw new NotImplementedException("s565-launch");
        // QWEN-FILL-END s565-launch   <<< REGION s565-launch ENDS BEFORE THIS LINE
    }

    /// <summary>S5.6.6: a plan that carries any flag is not one coai made for kimi (decision 3) — refused naming the shim.</summary>
    [Fact]
    public void APlanWithFlags_IsRefusedForKimi()
    {
        // QWEN-FILL-BEGIN s566-flags test
        // Arrange: `var plan = Plan("kimi", CapabilityGrant.None) with { Flags = ["--yolo"] };` and
        // `var launch = Planned("kimi", CapabilityGrant.None) with { Confinement = new LaunchConfinement.Planned(plan) };`.
        // Act: `var build = () => KimiConsultant().Build(launch);`.
        // Assert: `build.Should().Throw<ArgumentException>().WithMessage("*the shim's*")`.
        // Fails before the change: no exception is thrown (Build ignores the flags).
        throw new NotImplementedException("s566-flags");
        // QWEN-FILL-END s566-flags
    }

    // ---------- refusals ----------

    [Theory]
    [InlineData("antigravity", Capability.Web, "cannot fetch a page headless")]
    [InlineData("api", Capability.Disk, "cannot do 'disk'")]
    [InlineData("api", Capability.Web, "not been measured")]
    [InlineData("local", Capability.Disk, "cannot do 'disk'")]
    [InlineData("local", Capability.Web, "cannot do 'web'")]
    [InlineData("vibe", Capability.Web, "not been measured")]
    public void APairTheMatrixRefuses_IsRefusedByThePlannerToo_WithTheMatrixsOwnSentence(string runtime, Capability capability, string says)
    {
        var grant = capability == Capability.Disk ? CapabilityGrant.Disk(RootA) : new CapabilityGrant(capability, []);

        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain(says, "the planner asks the matrix first and never re-decides it");
    }

    [Fact]
    public void AnUnknownRuntime_IsRefused_NamingTheOnesItKnows()
    {
        ConfinementPlanner.Plan("gemini", CapabilityGrant.None).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe");
    }

    [Fact]
    public void ADiskGrantWithNoRoot_IsRefused_AndARootOnANoneOrWebGrant_IsRefused()
    {
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Disk, [])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("at least one root", "a disk row with nowhere to read would read its cwd — which is nowhere");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.None, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a root on a none row is a leak path");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Web, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a web row is given the question and nothing of this machine (A2)");
    }

    [Theory]
    [InlineData("projects/alpha")]
    [InlineData("./alpha")]
    [InlineData("")]
    [InlineData("  ")]
    public void ARootThatIsNotAnAbsolutePath_IsRefused(string root)
    {
        ConfinementPlanner.Plan("claude", CapabilityGrant.Disk(root)).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("absolute", "a relative root resolves against whatever the cwd happens to be");
    }

    [Fact]
    public void DisallowedTools_AppearsInNoPlan()
    {
        // F3/F5: the shipped deny lists leaked the canary 6 of 6 through PowerShell, which no deny
        // list names. A question row is confined by an ALLOW list or by `--restricted`, never by naming
        // what it may not do.
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is Confinement.Planned plan)
                {
                    plan.Flags.Concat(plan.Leading).Should().NotContain(ConfinementPlanner.NeverSent, $"{runtime} × {grant.Capability}");
                }
            }
        }
    }

    // ---------- the adapters compose the plan and nothing of their own ----------

    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
    {
        var none = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.None, "sonnet"));
        none.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "", NoMcpServers.ClaudeFlag, "--model", "sonnet");
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty directory, never the checkout");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB, NoMcpServers.ClaudeFlag);
        disk.Request.WorkingDirectory.Should().Be(RootA);

        var web = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Web));
        web.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "WebSearch,WebFetch", NoMcpServers.ClaudeFlag);
        web.Request.Arguments.Should().NotContain("--add-dir").And.NotContain(Repo, "a web row sees nothing of the checkout");
        web.Request.WorkingDirectory.Should().Be(Scratch);
    }

    [Fact]
    public void ACodexQuestionLaunch_PutsSearchBeforeExec_AndStaysEphemeral()
    {
        var web = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Web, "gpt-6-astra"));
        var args = web.Request.Arguments.ToList();
        var output = args[args.IndexOf("-o") + 1];

        args.Should().Equal(
            "--search", "exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check", "--color", "never",
            // The row's fast mode, Off by default (research/PLAN_fast_mode.md), before the instructions on stdin.
            "--json", "-o", output, "-m", "gpt-6-astra", "-c", "service_tier=default", "-");
        Path.GetDirectoryName(Path.GetFullPath(output)).Should().Be(Path.GetFullPath(Answers));
        web.Request.WorkingDirectory.Should().Be(Scratch);

        var none = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.None));
        none.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check"])
            .And.NotContain("--search").And.NotContain("-C");

        var disk = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "-C", RootA]);
        disk.Request.WorkingDirectory.Should().Be(RootA);
    }

    [Fact]
    public void AnAgyQuestionLaunch_IsTheMeasuredStreamLaunch_WithThePlansFlags()
    {
        var none = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.None, "gemini-3.1-pro-high"));
        // Both run as the reader agent from the read-only folder, never from the root or the scratch directory
        // (research/PLAN_agy_cannot_write_its_roots.md); a disk row still reaches its root through the plan's --add-dir.
        none.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "gemini-3.1-pro-high");
        none.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
        none.Request.StdIn.Should().Contain("the question").And.StartWith("{", "the prompt rides the stream, serialised");

        var disk = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--add-dir", RootA,
            "--agent", "coai-reader");
        disk.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
    }

    [Fact]
    public void ALocalQuestionLaunch_RunsTheShimInTheScratchDirectory()
    {
        Directory.CreateDirectory(Answers);
        var schema = Path.Combine(Answers, "schema.json");
        File.WriteAllText(schema, "{}");
        var launch = Planned("local", CapabilityGrant.None) with { AnswerSchemaFile = schema };

        var built = new LocalConsultant(new LocalRuntime("local", "http://127.0.0.1:11434/v1"), "local").Build(launch);

        built.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands nowhere near the checkout");
        built.Request.Arguments.Should().Contain("--ask-local");
        built.Role.Should().Be(ConsultantRoles.Question);
    }

    /// <summary>
    /// A Vibe question row (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): the plan's read-only pair, a none row in its EMPTY
    /// scratch and a disk row in the copy of its roots — never a root, never the checkout — on the row's own home in the
    /// built environment: <c>VIBE_CLI=python</c> and the model in the EXPLICIT environment, which is all a question row's
    /// minimal child gets (M-V12, 3 of 3).
    /// </summary>
    [Fact]
    public void AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));

        var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file")
            .And.ContainInConsecutiveOrder("--workdir", Scratch)
            .And.NotContain("--trust").And.NotContain("--add-dir").And.NotContain("--resume", "one shot");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-V11: Vibe reads its cwd only — the copy of the roots (D6)");
        disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.InheritsEnvironment.Should().BeFalse();
            request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
            request.Environment.Should().Contain(Runners.Vibe.VibeLaunch.CliVariable, "python").And.Contain(Runners.Vibe.VibeLaunch.ModelVariable, "glm-5-3");
            request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");
            Runners.Vibe.VibeLaunch.EnvironmentRefusal(request).Should().BeEmpty("the one launch control admits it (D17)");
        }
    }

    /// <summary>No Vibe launch carries <c>--add-dir</c>, whatever the grant (D3: <c>--add-dir</c> trusts its folder).</summary>
    [Fact]
    public void NoVibeLaunch_CarriesAddDir_WhateverTheGrant()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
        foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Disk(RootA, RootB), CapabilityGrant.Web])
        {
            if (ConfinementPlanner.Plan("vibe", grant) is not Confinement.Planned plan)
            {
                continue;
            }

            plan.AddDirs.Should().BeEmpty($"vibe × {grant.Capability}");
            consultant.Build(Planned("vibe", grant)).Request.Arguments.Should().NotContain("--add-dir", $"vibe × {grant.Capability}")
                .And.NotContain(RootA).And.NotContain(RootB);
        }
    }

    [Fact]
    public void ASnapshotCwd_NeedsAWorkdir_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("vibe", CapabilityGrant.Disk(RootA)) with { Workdir = string.Empty };

        var build = () => new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*Workdir*",
            "falling back to a root would hand Vibe the branch's own .vibe/ and AGENTS.md (D6)");
    }

    /// <summary>The structural half of acceptance 2: whatever a planned launch sends of the sandbox vocabulary, the plan gave it.</summary>
    [Fact]
    public void NoAdapter_SendsASandboxFlag_ThePlanDidNotGiveIt()
    {
        foreach (var (runtime, consultant) in Adapters())
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is not Confinement.Planned plan)
                {
                    continue;
                }

                var argv = consultant.Build(Planned(runtime, grant)).Request.Arguments.ToList();
                var ownFlags = argv.Except(plan.Flags.Concat(plan.Leading)).Where(ConfinementPlanner.IsSandboxVocabulary);

                ownFlags.Should().BeEmpty($"{runtime} × {grant.Capability}: the planner is the one place");
            }
        }
    }

    [Fact]
    public void APlannedLaunch_IsOneShot_SoAHandleIsAContractViolation()
    {
        var resumed = Planned("claude", CapabilityGrant.None) with { Handle = "67289235-65f7-40b5-9532-e63515d90f30" };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(resumed);

        build.Should().Throw<ArgumentException>().WithMessage("*one-shot*");
    }

    [Fact]
    public void AScratchCwd_NeedsAScratchDirectory_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("claude", CapabilityGrant.None) with { ScratchDir = string.Empty };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*ScratchDir*",
            "falling back to the checkout would hand a none row the very directory it must not see");
    }

    /// <summary>The regression guard (acceptance 5): today's argv, byte for byte, with the defaulted confinement.</summary>
    /// <remarks>
    /// The claude row moved when PLAN_the_consultant_works_on_every_vendor.md merged second, as that plan's §7 said it
    /// must: the stuck consultant is confined by the planner's own disk allowlist (<see cref="ConfinementPlanner.ClaudeDiskTools"/>)
    /// plus <c>--restricted</c> where the installed CLI declares it — never the deny list. Its launch is PREPARED first
    /// (<c>IConsultantRuntime.PrepareAsync</c> reads the CLI's help), which is what <c>ClaudeCli</c> stands for here;
    /// the CLI without the flag is <c>ClaudeConsultantArgvTests</c>' business.
    /// </remarks>
    [Fact]
    public void TheShippedConsultants_StillBuildTodaysArgv_ByteForByte()
    {
        var launch = new ConsultantLaunch(Repo, "help me", string.Empty, Answers, new ReviewerSettings("v") { Model = "m", ClaudeCli = ClaudeCapability.WithRestricted });
        launch.Confinement.Should().Be(LaunchConfinement.AsShipped, "the default is the stuck consultant as it ships");

        new ClaudeConsultant(new ClaudeRuntime()).Build(launch).Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan",
            "--restricted", "--tools", string.Join(',', ConfinementPlanner.ClaudeDiskTools),
            NoMcpServers.ClaudeFlag, "--add-dir", Repo, "--model", "m");

        var codex = new CodexConsultant(new CodexRuntime()).Build(launch).Request.Arguments.ToList();
        codex.Should().Equal(
            "exec", "-s", "read-only", "--skip-git-repo-check", "--color", "never", "-C", Repo, "--json", "-o", codex[codex.IndexOf("-o") + 1], "-m", "m",
            "-c", "service_tier=default", "-");

        // agy's argv CHANGED on purpose (research/PLAN_agy_cannot_write_its_roots.md): it runs as the reader agent, from the
        // read-only folder, and reaches the checkout through --add-dir — plan mode alone let it write there.
        var agy = new AntigravityConsultant(new AntigravityRuntime()).Build(launch).Request;
        agy.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "m", "--add-dir", Repo);
        agy.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());

        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is not "local" and not "antigravity" and not "vibe" and not "kimi"))
        {
            consultant.Build(launch).Request.WorkingDirectory.Should().Be(Repo, consultant.Vendor);
            consultant.Build(launch).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }

        // Vibe and Kimi never stand in the checkout (D6): the conversation's snapshot, which the service makes (S5.4.13 for Kimi).
        var inTheSnapshot = launch with { Workdir = RowTree, Settings = launch.Settings with { OwnedScratch = RowFolder } };
        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is "vibe" or "kimi"))
        {
            consultant.Build(inTheSnapshot).Request.WorkingDirectory.Should().Be(RowTree, consultant.Vendor);
            consultant.Build(inTheSnapshot).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }
    }

    private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters() =>
    [
        ("claude", new ClaudeConsultant(new ClaudeRuntime())),
        ("codex", new CodexConsultant(new CodexRuntime())),
        ("antigravity", new AntigravityConsultant(new AntigravityRuntime())),
        ("vibe", new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows))),
        // A fake person's paths, so building reads nothing of this machine: the request names the places, it does not open them.
        ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
            new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))))),
    ];
}

```
