```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        RecordingTheDeleter();
        var before = _person.Hash();
        var played = Played();
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Kimi is refused on every host but Windows");
        var (code, said, _) = await Check(Settings(string.Empty), played, TestContext.Current.CancellationToken);
        code.Should().Be(0);
        var turn = played.Shims.Should().ContainSingle().Subject.Request;
        var home = After(turn, AcpWords.HomeFlag);
        home.Should().Contain(Path.Combine("own", "kh-"));
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the scratch is gone");
        _unlinkedByTheDeleter.Should().BeEmpty();
        _person.Hash().Should().Equal(before);
```