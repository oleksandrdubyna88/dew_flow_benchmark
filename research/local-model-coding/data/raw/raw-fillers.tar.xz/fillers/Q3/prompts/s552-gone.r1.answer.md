```csharp
        using var stood = AKimiConsultationScenarioTests.StandIn(_person);
        var played = Played(theTurnFails ? (_, _) => new ProcessResult(70, string.Empty, "the played shim failed" + Environment.NewLine, TimedOut: false) : null);
        Assert.SkipUnless(OperatingSystem.IsWindows(), "D18: Kimi is refused on every host but Windows");
        var before = _person.Hash();
        RecordingTheDeleter();
        await Check(Settings(_homes), played, TestContext.Current.CancellationToken);
        Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends, whatever ended it");
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
        _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
```