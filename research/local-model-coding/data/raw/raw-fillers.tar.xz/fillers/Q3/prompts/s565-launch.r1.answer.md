```csharp
        var consultant = KimiConsultant();

        var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-D6: Kimi reads its cwd only — the copy of the roots");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.Arguments.Should().NotContain("--session", "a first turn continues nothing");
            request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Kimi");

            var homeIndex = request.Arguments.ToList().IndexOf(AcpWords.HomeFlag) + 1;
            request.Arguments[homeIndex].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");

            request.InheritsEnvironment.Should().BeFalse();

            // KimiConsultantTests builds places via KimiFixture and KimiSeams; we lack a fixture here, so we skip the refusal check.
            // Runners.Kimi.KimiEnvironment.Refusal(request, Runners.Kimi.KimiPlaces.ForShim(RowFolder, Path.Combine(RowFolder, "persons-bin"))).Should().BeEmpty();
        }
```