```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk, Capability.Web])
        {
            var row = RuntimeCapabilities.Builtin.Of("kimi", capability);
            row.Should().NotBeNull();
            if (capability == Capability.None)
            {
                row.Standing.Should().Be(CapabilityStanding.Unconfined);
                row.MeasuredWith.Cells.Should().Contain("M-K6");
            }
            else if (capability == Capability.Disk)
            {
                row.Standing.Should().Be(CapabilityStanding.Unconfined);
                row.MeasuredWith.Cells.Should().Contain("M-K6").And.Contain("M-K9");
            }
            else
            {
                row.Standing.Should().Be(CapabilityStanding.Unmeasured);
                row.MeasuredWith.Cells.Should().BeEmpty();
            }
            row.MeasuredWith.Version.Should().Be("2.1.1");
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md");
        }
```