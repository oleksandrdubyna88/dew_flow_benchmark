```csharp
        var none = Plan("kimi", CapabilityGrant.None);
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.Leading.Should().BeEmpty();
        none.Flags.Should().BeEmpty();
        none.AddDirs.Should().BeEmpty();
        none.SnapshotSources.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.Unconfined);

        var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));
        disk.Cwd.Should().Be(CwdKind.Snapshot);
        disk.SnapshotSources.Should().Equal([RootA, RootB]);
        disk.Leading.Should().BeEmpty();
        disk.Flags.Should().BeEmpty();
        disk.AddDirs.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.Unconfined);

        var web = ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>().Which.Reason;
        web.Should().Contain("not been measured");
        web.Should().Contain("RESULTS_kimi_confinement.md");
```