```csharp
        var plan = Plan("kimi", CapabilityGrant.None) with { Flags = ["--yolo"] };
        var launch = Planned("kimi", CapabilityGrant.None) with { Confinement = new LaunchConfinement.Planned(plan) };
        var build = () => KimiConsultant().Build(launch);
        build.Should().Throw<ArgumentException>().WithMessage("*the shim's*");
```