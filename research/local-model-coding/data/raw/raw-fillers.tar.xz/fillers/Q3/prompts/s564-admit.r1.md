You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s564-admit — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Act/Assert: for each capability of (Capability[])[Capability.None, Capability.Disk]:
  `CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>().Which.Flag.Should().Be(AdmissionFlag.Unconfined, ...)`
and `CapabilityMatrix.Admit("kimi", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason.Should().Contain("not been measured")`.
Fails before the change: Refused "'kimi' is not a runtime the question consultant can launch ...".

## The exact existing types and members you may use (context pack)
# Region `s564-admit` (test) — `src_mcp/tests/CapabilityMatrixTests.cs`

Read the FILL region's comment in the file first: it is the spec. This pack holds the existing code the body may call; what is not here or in the file does not exist. Namespaces: tests are in `CoaiMcp.Tests`; production types are in `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Runners.Files`, `CoaiMcp.Server`. Style: FluentAssertions (`.Should()`), xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`), `TestContext.Current.CancellationToken`, braces on every block, one assertion per line.

Sibling test shape below. `AdmissionFlag.Unconfined` is the flag; `Admission.Admitted(Standing, Flag)` and `Admission.Refused(Reason)`.

### Capability / grant / admission types — `src_mcp/core/QuestionConsult/Capability.cs:64-73`

```csharp
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{
    /// <summary>The question alone.</summary>
    public static CapabilityGrant None { get; } = new(Capability.None, []);

    /// <summary>The web alone.</summary>
    public static CapabilityGrant Web { get; } = new(Capability.Web, []);

    /// <summary>Read-only reads under these roots.</summary>
    public static CapabilityGrant Disk(params string[] roots) => new(Capability.Disk, [.. roots]);
```
### RuntimeCapabilityRow, MeasuredWith, CapabilityStanding — `src_mcp/core/QuestionConsult/RuntimeCapabilities.cs:9-56`

```csharp
public enum CapabilityStanding
{
    /// <summary>The CLI's own enforced mechanism stops what the capability does not grant.</summary>
    Confined,

    /// <summary>The runtime can do the capability and cannot be held to it — a shell is always there (F2).</summary>
    Unconfined,

    /// <summary>Held only by a headless permission DEFAULT nobody configured; hand-checked, not instrument-confirmed (F7).</summary>
    DefaultDeny,

    /// <summary>The runtime cannot do the capability at all.</summary>
    Unsupported,

    /// <summary>No cell says either way.</summary>
    Unmeasured,
}

/// <summary>The standing words as the file spells them, and the parse that refuses the rest.</summary>
public static class CapabilityStandings
{
    public static string Spelled(this CapabilityStanding standing) => standing switch
    {
        CapabilityStanding.Confined => "confined",
        CapabilityStanding.Unconfined => "unconfined",
        CapabilityStanding.DefaultDeny => "default-deny",
        CapabilityStanding.Unsupported => "unsupported",
        CapabilityStanding.Unmeasured => "unmeasured",
        _ => throw new ArgumentOutOfRangeException(nameof(standing), standing, "a standing this build does not spell — map it here"),
    };

    /// <summary>The standing a file word names; throws for a word the table may not carry (a broken build).</summary>
    public static CapabilityStanding Parse(string word) =>
        Enum.GetValues<CapabilityStanding>().Cast<CapabilityStanding?>()
            .FirstOrDefault(s => string.Equals(s!.Value.Spelled(), word.Trim(), StringComparison.OrdinalIgnoreCase))
        ?? throw new ArgumentException(
            $"'{word}' is not a capability standing — the table spells: {string.Join(", ", Enum.GetValues<CapabilityStanding>().Select(s => s.Spelled()))}",
            nameof(word));
}

/// <summary>Which probe cells a row rests on: the CLI and its build, the day, where the record says it, and the cell ids.</summary>
/// <param name="ResultRef">The section of <c>research/RESULTS_question_consultant_capabilities.md</c> the row cites.</param>
/// <param name="Cells">Cell ids of the full run; empty only when <paramref name="Note"/> says why.</param>
/// <param name="Note">How the standing was read — by construction, hand-checked, not measured.</param>
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

/// <summary>One row of the table: a runtime, a capability, what was measured, and where.</summary>
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
```
### CapabilityMatrix.Admit and Admission — `src_mcp/core/QuestionConsult/CapabilityMatrix.cs:7-72`

```csharp
public enum AdmissionFlag
{
    /// <summary>Confined by a measured mechanism; nothing to acknowledge.</summary>
    None,

    /// <summary>The runtime can read this machine whatever it is told — allowed and flagged.</summary>
    Unconfined,

    /// <summary>Held only by the CLI's headless default, which nobody configured — allowed, flagged.</summary>
    DefaultDeny,
}

/// <summary>The flag words as the shared vectors spell them.</summary>
public static class AdmissionFlags
{
    public static string Spelled(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.None => string.Empty,
        AdmissionFlag.Unconfined => "unconfined",
        AdmissionFlag.DefaultDeny => "default-deny",
        _ => throw new ArgumentOutOfRangeException(nameof(flag), flag, "a flag this build does not spell — map it here"),
    };

    /// <summary>The sentence a flagged row is shown beside — in the settings, the sidebar and the log (D13).</summary>
    public static string Caveat(this AdmissionFlag flag) => flag switch
    {
        AdmissionFlag.Unconfined => "unconfined: can read this machine — a shell is always there, and no flag removes it",
        AdmissionFlag.DefaultDeny => "held only by the CLI's headless permission default, which nobody configured",
        _ => string.Empty,
    };
}

/// <summary>What the matrix decided for one pair: admitted with its standing and flag, or refused with a sentence.</summary>
public abstract record Admission
{
    public sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag) : Admission;

    public sealed record Refused(string Reason) : Admission;

    private Admission() { }
}

/// <summary>
/// The one rule that turns a table row into a decision: confined admits; unconfined and default-deny
/// admit FLAGGED; unsupported and unmeasured refuse; a pair the table does not know refuses by name.
/// </summary>
/// <remarks>
/// A3's "blocked in the UI and refused by the server" is one rule because the extension's
/// <c>capabilityAdmission.ts</c> is this function over the same file, and both answer
/// <c>shared/capability-matrix-vectors.json</c>.
/// </remarks>
public static class CapabilityMatrix
{
    /// <summary>The decision for a pair given by its words — what a settings row or a vector carries.</summary>
    public static Admission Admit(string runtime, string capability) =>
        string.IsNullOrWhiteSpace(runtime) ? NoRuntime
        : Capabilities.TryParse(capability, out var parsed)
            ? Admit(runtime, parsed)
            : new Admission.Refused($"'{capability}' is not a capability a prompt can declare — a prompt needs one of: {Capabilities.AllSpelled} (asked for runtime '{runtime}')");

    /// <summary>The decision for a pair, from the embedded table.</summary>
    public static Admission Admit(string runtime, Capability capability) => Admit(RuntimeCapabilities.Builtin, runtime, capability);

    /// <summary>The decision from a given table — the embedded one in the product, a hand-built one in a test.</summary>
    public static Admission Admit(RuntimeCapabilities table, string runtime, Capability capability)
    {
```

### The Vibe rows test (sibling, same class) — `src_mcp/tests/CapabilityMatrixTests.cs:182-199`

```csharp
    [Fact]
    public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
            row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
            CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
        }

        RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6",
            "denied writes do not prove bounded READS — the disk row rests on the read cell itself");
        CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured", "no Vibe cell exercises the web");
    }

```


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The capability table is the file in <c>shared/</c>, and admission answers the shared vectors —
/// the C# half of <c>shared/capability-matrix-vectors.json</c>; <c>capabilityAdmission.test.ts</c> is
/// the other (PLAN_question_consultant.md, S1 acceptance 1).
/// </summary>
/// <remarks>
/// <para>Read from disk the way <see cref="BuiltinRoleCatalogTests"/> reads its seed: from the test
/// binary up to the repository root, so the comparison is against the checked-in file and not the
/// copy the build embedded a moment ago.</para>
/// <para>A3's "blocked in the UI AND refused by the server" is one rule only while both sides answer
/// one set of vectors; two self-consistent loaders cannot notice that they disagree.</para>
/// </remarks>
public sealed class CapabilityMatrixTests
{
    private sealed record Vector(string Runtime, string Capability, bool Admitted, string Standing, string Flag, string Why);

    private sealed record FileRow(string Runtime, string Capability, string Standing, string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);

    private static readonly Vector[] Vectors = LoadVectors();

    private static readonly IReadOnlyList<FileRow> Seed = LoadSeed();

    private static string Shared(string file) => Path.GetFullPath(Path.Combine(
        AppContext.BaseDirectory, "..", "..", "..", "..", "..", "shared", file));

    private static Vector[] LoadVectors()
    {
        using var file = File.OpenRead(Shared("capability-matrix-vectors.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("vectors").EnumerateArray().Select(v => new Vector(
            v.GetProperty("runtime").GetString() ?? "",
            v.GetProperty("capability").GetString() ?? "",
            v.GetProperty("admitted").GetBoolean(),
            v.GetProperty("standing").GetString() ?? "",
            v.GetProperty("flag").GetString() ?? "",
            v.GetProperty("why").GetString() ?? ""))];
    }

    private static IReadOnlyList<FileRow> LoadSeed()
    {
        using var file = File.OpenRead(Shared("runtime-capabilities.json"));
        using var parsed = JsonDocument.Parse(file);

        return [.. parsed.RootElement.GetProperty("rows").EnumerateArray().Select(r =>
        {
            var measured = r.GetProperty("measuredWith");
            return new FileRow(
                r.GetProperty("runtime").GetString() ?? "",
                r.GetProperty("capability").GetString() ?? "",
                r.GetProperty("standing").GetString() ?? "",
                measured.GetProperty("cli").GetString() ?? "",
                measured.GetProperty("version").GetString() ?? "",
                measured.GetProperty("date").GetString() ?? "",
                measured.GetProperty("resultRef").GetString() ?? "",
                [.. measured.GetProperty("cells").EnumerateArray().Select(c => c.GetString() ?? "")],
                measured.GetProperty("note").GetString() ?? "");
        })];
    }

    public static TheoryData<int> Cases()
    {
        var data = new TheoryData<int>();
        for (var i = 0; i < Vectors.Length; i++)
        {
            data.Add(i);
        }

        return data;
    }

    [Fact]
    public void TheVectorsActuallyLoaded_AndCoverEveryPairOfTheTable()
    {
        // Without this every assertion below would pass vacuously over an empty list.
        Vectors.Should().HaveCountGreaterThan(15, "fifteen pairs plus the refusals by name");
        foreach (var row in Seed)
        {
            Vectors.Should().Contain(v => v.Runtime == row.Runtime && v.Capability == row.Capability,
                $"the table's {row.Runtime} × {row.Capability} row must have a vector deciding it");
        }
    }

    [Theory]
    [MemberData(nameof(Cases))]
    public void EveryVector_IsAdmittedOrRefused_AsMeasured(int index)
    {
        var vector = Vectors[index];

        var admission = CapabilityMatrix.Admit(vector.Runtime, vector.Capability);

        switch (admission)
        {
            case Admission.Admitted admitted:
                vector.Admitted.Should().BeTrue($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                admitted.Standing.Spelled().Should().Be(vector.Standing, vector.Why);
                admitted.Flag.Spelled().Should().Be(vector.Flag, vector.Why);
                break;
            case Admission.Refused refused:
                vector.Admitted.Should().BeFalse($"{vector.Runtime} × {vector.Capability}: {vector.Why}");
                refused.Reason.Should().Contain(vector.Runtime).And.Contain(vector.Capability,
                    "a refusal names the pair it refused");
                break;
        }
    }

    [Fact]
    public void TheEmbeddedTable_IsTheFileInShared_RowForRow()
    {
        var loaded = RuntimeCapabilities.Builtin.Rows;

        loaded.Select(r => (r.Runtime, r.Capability.Spelled())).Should().Equal(
            Seed.Select(r => (r.Runtime, r.Capability)),
            "the loader keeps the file's rows in the file's order");
        foreach (var (row, expected) in loaded.Zip(Seed))
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            row.Standing.Spelled().Should().Be(expected.Standing, where);
            row.MeasuredWith.Cli.Should().Be(expected.Cli, where);
            row.MeasuredWith.Version.Should().Be(expected.Version, where);
            row.MeasuredWith.Date.Should().Be(expected.Date, where);
            row.MeasuredWith.ResultRef.Should().Be(expected.ResultRef, where);
            row.MeasuredWith.Cells.Should().Equal(expected.Cells, where);
            row.MeasuredWith.Note.Should().Be(expected.Note, where);
        }
    }

    [Fact]
    public void EveryRuntimeTimesCapability_HasExactlyOneRow_AndNoRowIsOutsideTheMatrix()
    {
        var pairs = RuntimeCapabilities.Builtin.Rows.Select(r => (r.Runtime, r.Capability)).ToList();

        pairs.Should().OnlyHaveUniqueItems("two rows for one pair would be two answers");
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var capability in Enum.GetValues<Capability>())
            {
                pairs.Should().Contain((runtime, capability), "every pair is decided by data, never by a default arm");
            }
        }

        pairs.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Enum.GetValues<Capability>().Length);
    }

    /// <summary>
    /// The records a row may cite, each with the day it was measured and the shape of its cell ids: the question
    /// consultant's full run for the first five runtimes, and the Vibe probe for vibe (S3 of
    /// todo/PLAN_vibe_and_kimi_runtimes.md) — whose cells are named <c>M-V…</c>, not numbered.
    /// </summary>
    private static readonly IReadOnlyList<(string Record, string Date, string CellPrefix)> Records =
    [
        ("RESULTS_question_consultant_capabilities.md", "2026-10-01", "01a0f8c7-18e4-"),
        ("RESULTS_vibe_confinement.md", "2026-10-12", "M-V"),
    ];

    [Fact]
    public void EveryRow_CitesTheRecord_AndACellOrSaysWhyThereIsNone()
    {
        foreach (var row in RuntimeCapabilities.Builtin.Rows)
        {
            var where = $"{row.Runtime} × {row.Capability.Spelled()}";
            var cited = Records.Where(record => row.MeasuredWith.ResultRef.Contains(record.Record, StringComparison.Ordinal)).ToList();
            cited.Should().ContainSingle($"{where}: a row cites exactly one record");
            var (record, date, prefix) = cited[0];
            row.MeasuredWith.Date.Should().Be(date, $"{where}: the day {record} was measured");
            (row.MeasuredWith.Cells.Count > 0 || row.MeasuredWith.Note.Length > 0).Should().BeTrue(
                $"{where}: a row with no cell says why — by construction, or not measured");
            foreach (var cell in row.MeasuredWith.Cells)
            {
                cell.Should().StartWith(prefix, $"{where}: every cell is one of {record}'s");
            }
        }
    }

    [Fact]
    public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
    {
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
            row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
            CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: read_file reads its working folder only (M-V6, M-V11)");
        }

        RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6",
            "denied writes do not prove bounded READS — the disk row rests on the read cell itself");
        CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Contain("not been measured", "no Vibe cell exercises the web");
    }

    /// <summary>S5.6.1 (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>): kimi has its three rows, each citing its own cells of the Kimi record.</summary>
    [Fact]
    public void KimiHasThreeRows_EachCitingItsCells()
    {
        // QWEN-FILL-BEGIN s561-rows test
        // Arrange: nothing — `RuntimeCapabilities.Builtin.Of("kimi", Capability.None)` is `RuntimeCapabilityRow?`.
        // Act/Assert: for none, disk, web take `row = RuntimeCapabilities.Builtin.Of("kimi", capability)`; `row.Should().NotBeNull()` first (the red:
        // "Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.None) not to be <null>.").
        //   none: row.Standing Should().Be(CapabilityStanding.Unconfined); row.MeasuredWith.Cells Should().Contain("M-K6").
        //   disk: Standing Unconfined; Cells Should().Contain("M-K6").And.Contain("M-K9").
        //   web: Standing Should().Be(CapabilityStanding.Unmeasured); Cells Should().BeEmpty() (its note says why).
        //   every row: row.MeasuredWith.Version Should().Be("2.1.1"); row.MeasuredWith.ResultRef Should().Contain("RESULTS_kimi_confinement.md").
        throw new NotImplementedException("s561-rows");
        // QWEN-FILL-END s561-rows
    }

    /// <summary>S5.6.4: both admitted Kimi rows are FLAGGED unconfined — they can read this machine (D13).</summary>
    [Fact]
    public void AdmissionFlagsBothRows()
    {
        // QWEN-FILL-BEGIN s564-admit test   <<< REGION s564-admit STARTS AFTER THIS LINE
        // Act/Assert: for each capability of (Capability[])[Capability.None, Capability.Disk]:
        //   `CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>().Which.Flag.Should().Be(AdmissionFlag.Unconfined, ...)`
        // and `CapabilityMatrix.Admit("kimi", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason.Should().Contain("not been measured")`.
        // Fails before the change: Refused "'kimi' is not a runtime the question consultant can launch ...".
        throw new NotImplementedException("s564-admit");
        // QWEN-FILL-END s564-admit   <<< REGION s564-admit ENDS BEFORE THIS LINE
    }

    /// <summary>D13's two refusals kept apart: the flags are what the data says, never what a runtime name suggests.</summary>
    [Fact]
    public void TheFlags_AreD13s_CodexUnconfinedEverywhere_AgyDefaultDeny_NothingElseFlagged()
    {
        foreach (var capability in Enum.GetValues<Capability>())
        {
            CapabilityMatrix.Admit("codex", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"codex × {capability}: F2");
        }

        CapabilityMatrix.Admit("antigravity", Capability.Disk).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7");
        CapabilityMatrix.Admit("antigravity", Capability.None).Should().BeOfType<Admission.Admitted>()
            .Which.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
        foreach (var runtime in (string[])["claude", "local", "api"])
        {
            CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.None, $"{runtime} × none is confined");
        }
    }

    [Fact]
    public void AnUnmeasuredPair_IsRefused_NamingTheRecordThatWouldAdmitIt()
    {
        var refused = CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("not been measured").And.Contain("RESULTS_question_consultant_capabilities.md",
            "the cure for an unmeasured pair is a measurement, and the sentence says where it goes");
    }

    /// <summary>
    /// An unmeasured pair names the record ITS row cites — the record a measurement would land in — so an unmeasured Vibe
    /// pair names the Vibe probe's record (S3 of todo/PLAN_vibe_and_kimi_runtimes.md), and the first five runtimes' sentences
    /// stay exactly what they were.
    /// </summary>
    [Fact]
    public void AnUnmeasuredVibePair_NamesTheVibeRecord_AndTheApiSentenceIsUnchanged()
    {
        var vibe = CapabilityMatrix.Admit("vibe", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason;

        vibe.Should().Contain("a measured cell in research/RESULTS_vibe_confinement.md is what admits it")
            .And.NotContain("RESULTS_question_consultant_capabilities.md", "no cell of that run could admit a Vibe pair");
        CapabilityMatrix.Admit("api", Capability.Web).Should().BeOfType<Admission.Refused>().Which.Reason.Should().Be(
            "'api' has not been measured for 'web' (not measured; vendor-specific (a tails-plan item)) — a measured cell in "
            + "research/RESULTS_question_consultant_capabilities.md is what admits it; until then give this row a prompt of another capability");
    }

    [Fact]
    public void AnUnsupportedPair_IsRefused_WithTheRowsOwnReason()
    {
        var refused = CapabilityMatrix.Admit("antigravity", Capability.Web).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Contain("cannot fetch a page headless", "the row's note is the reason a person reads");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void ARowWithNoRuntime_IsRefused_AskingForAModel_NeverQuotingNothing(string runtime)
    {
        // research/PLAN_names_and_a_missing_root.md story 2.2: a row with no runtime used to be "'' is not a runtime …".
        var refused = CapabilityMatrix.Admit(runtime, Capability.None).Should().BeOfType<Admission.Refused>().Which;

        refused.Reason.Should().Be("this row has no model to run on — pick one");
        // The words' overload too, with a capability that does not parse: its sentence used to say "asked for runtime ''".
        CapabilityMatrix.Admit(runtime, "shell").Should().BeOfType<Admission.Refused>()
            .Which.Reason.Should().Be("this row has no model to run on — pick one");
    }

    [Fact]
    public void AnUnknownRuntimeOrCapability_IsRefused_NamingWhatIsKnown()
    {
        var runtime = CapabilityMatrix.Admit("gemini", "none").Should().BeOfType<Admission.Refused>().Which;
        runtime.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe",
            "an unknown name fails naming the legal values");

        var capability = CapabilityMatrix.Admit("claude", "shell").Should().BeOfType<Admission.Refused>().Which;
        capability.Reason.Should().Contain("shell").And.Contain("none, disk, web");
    }

    [Fact]
    public void TheWordsOfTheFile_RoundTripThroughTheTypes()
    {
        foreach (var standing in Enum.GetValues<CapabilityStanding>())
        {
            CapabilityStandings.Parse(standing.Spelled()).Should().Be(standing);
        }

        foreach (var capability in Enum.GetValues<Capability>())
        {
            Capabilities.TryParse(capability.Spelled(), out var parsed).Should().BeTrue();
            parsed.Should().Be(capability);
        }

        Capabilities.TryParse("Disk", out var cased).Should().BeTrue("the file's words are matched without case");
        cased.Should().Be(Capability.Disk);
        Capabilities.TryParse("shell", out _).Should().BeFalse();
        Capabilities.AllSpelled.Should().Be("none, disk, web");
    }

    /// <summary>A broken table is a broken BUILD, refused whole and loudly — the role seed's rule.</summary>
    /// <remarks>
    /// Written against a hand-built table rather than by corrupting the embedded file, because the
    /// validation is the unit under test and the resource is not reachable without rebuilding the
    /// assembly. Every fixture starts from the WHOLE matrix — every pair, well formed — and breaks one
    /// thing, so the refusal observed is for that thing and not for the other pairs a smaller
    /// fixture would also be missing.
    /// </remarks>
    public sealed class ABrokenTable
    {
        private static RuntimeCapabilityRowSeed Row(string runtime, string capability, string standing = "confined", IReadOnlyList<string>? cells = null, string note = "n") =>
            new(runtime, capability, standing, new MeasuredWithSeed("cli", "1", "2026-10-01", "ref", cells ?? ["01a0f8c7-18e4-0000-0000-000000000000"], note));

        /// <summary>Every pair of the matrix, well formed — the fixture the broken ones are cut from.</summary>
        private static List<RuntimeCapabilityRowSeed> Whole() =>
            [.. RuntimeCapabilities.Runtimes.SelectMany(runtime => Capabilities.All.Select(capability => Row(runtime, capability.Spelled())))];

        private static Action Loading(IEnumerable<RuntimeCapabilityRowSeed> rows) =>
            () => RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], [.. rows]));

        /// <summary>The whole matrix with ONE row replaced.</summary>
        private static IEnumerable<RuntimeCapabilityRowSeed> With(RuntimeCapabilityRowSeed replacement) =>
            Whole().Select(row => row.Runtime == replacement.Runtime && row.Capability == replacement.Capability ? replacement : row);

        [Fact]
        public void WithAPairMissing_IsRefused_NamingIt() =>
            Loading(Whole().Where(row => !(row.Runtime == "claude" && row.Capability == "disk")))
                .Should().Throw<InvalidOperationException>().WithMessage("*claude*disk*no row*",
                    "a pair with no row would be decided by nothing");

        [Fact]
        public void WithAPairTwice_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*twice*");

        [Fact]
        public void WithAnUnknownStanding_IsRefused_NamingIt() =>
            Loading(With(Row("claude", "none", standing: "sort of"))).Should().Throw<InvalidOperationException>()
                .WithMessage("*sort of*");

        [Fact]
        public void WithARowOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("gemini", "none")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*gemini*");

        [Fact]
        public void WithACapabilityOutsideTheMatrix_IsRefused_NamingIt() =>
            Loading([.. Whole(), Row("claude", "shell")]).Should().Throw<InvalidOperationException>()
                .WithMessage("*shell*none, disk, web*");

        [Fact]
        public void WithNeitherACellNorANote_IsRefused_NamingTheRow() =>
            Loading(With(Row("claude", "none", cells: [], note: ""))).Should().Throw<InvalidOperationException>()
                .WithMessage("*claude*none*cell*");

        [Fact]
        public void ThatIsWellFormed_Loads_EveryPairOnce()
        {
            var table = RuntimeCapabilities.FromSeed(new RuntimeCapabilitySeed(["x"], [.. RuntimeCapabilities.Runtimes], ["none", "disk", "web"], Whole()));

            table.Rows.Should().HaveCount(RuntimeCapabilities.Runtimes.Count * Capabilities.All.Count).And.OnlyContain(row => row.Standing == CapabilityStanding.Confined);
            table.Of("codex", Capability.Web).Should().NotBeNull();
            table.Of("gemini", Capability.Web).Should().BeNull("a runtime outside the matrix has no row to answer with");
        }
    }
}

```
