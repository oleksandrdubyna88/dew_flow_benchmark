```csharp
        Directory.CreateDirectory(Homes);
        var files = new (string Path, string Text)[]
        {
            (@"src\Mailer.cs", "void Send() { }\n"),
            (@"docs\notes.md", ""),
        };
        foreach (var (path, text) in files)
        {
            var full = Path.Combine(Repo, path);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }
        var args = new string[][]
        {
            new[] { "init", "-b", "main" },
            new[] { "config", "user.email", "t@example.com" },
            new[] { "config", "user.name", "t" },
            new[] { "add", "." },
            new[] { "commit", "-m", "base" },
        };
        foreach (var a in args)
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", a, Repo), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', a) + ": " + result.StdErr);
        }
```