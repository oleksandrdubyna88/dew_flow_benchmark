```csharp
        var played = PlayedThatReadsTheMarker();
        var settings = Settings(_homes.Path);
        RecordingTheDeleter();
        var (code, said) = await CheckAsync(settings, played, TestContext.Current.CancellationToken);
        code.Should().Be(0);
        said.GetProperty("state").GetString().Should().Be(ConsultCheckStates.Answered, said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue();
        var turn = played.Shims.Should().ContainSingle().Subject.Request;
        After(turn, "--cwd").Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
        var home = After(turn, AcpWords.HomeFlag);
        home.Should().StartWith(Path.Combine(_homes.Path, VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar);
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        Path.GetFileName(Path.GetDirectoryName(home)!).Should().HaveLength(8);
        Directory.EnumerateDirectories(_temp.Path, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
        said.GetProperty("canary").GetString().Should().Be(ConsultCheckStates.NotAttempted);
```