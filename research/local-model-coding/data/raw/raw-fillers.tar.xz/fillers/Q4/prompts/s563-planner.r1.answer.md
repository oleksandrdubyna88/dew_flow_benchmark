```csharp
        var none = Plan("kimi", CapabilityGrant.None);
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.Flags.Should().BeEmpty();
        none.Leading.Should().BeEmpty();
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.Unconfined);

        var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));
        disk.Cwd.Should().Be(CwdKind.Snapshot, "the shim's copy of the roots");
        disk.SnapshotSources.Should().Equal([RootA, RootB]);
        disk.Flags.Should().BeEmpty();
        disk.AddDirs.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.Unconfined);

        ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>().Which.Reason
            .Should().Contain("not been measured").And.Contain("RESULTS_kimi_confinement.md");
```