```csharp
        var consultant = AKimiConsultant();

        var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
        none.Request.WorkingDirectory.Should().Be(Scratch);
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--cwd", Scratch);
        none.Request.Arguments.Should().NotContain("--session").And.NotContain(RootA).And.NotContain(RootB);
        none.Request.InheritsEnvironment.Should().BeFalse();
        Runners.Kimi.KimiEnvironment.Refusal(none.Request, KimiPlaces.ForShim(RowFolder, Path.Combine(RowFolder, "persons-bin"))).Should().BeEmpty();
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.WorkingDirectory.Should().Be(RowTree);
        disk.Request.Arguments.Should().ContainInConsecutiveOrder("--cwd", RowTree);
        disk.Request.Arguments.Should().NotContain("--session").And.NotContain(RootA).And.NotContain(RootB);
        disk.Request.InheritsEnvironment.Should().BeFalse();
        Runners.Kimi.KimiEnvironment.Refusal(disk.Request, KimiPlaces.ForShim(RowFolder, Path.Combine(RowFolder, "persons-bin"))).Should().BeEmpty();

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.Arguments.Should().ContainInConsecutiveOrder("--home", It.IsAny<string>())
                .Which.Should().StartWith(RowFolder + Path.DirectorySeparatorChar);
        }
```