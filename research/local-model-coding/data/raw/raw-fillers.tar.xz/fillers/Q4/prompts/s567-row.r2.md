You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s567-row — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Arrange: using var standIn = StandIn(); var before = _person.Hash(); GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
 using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
 var played = ending == "cancelled"
     ? new PlayedKimi(_launcher) { During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); } }
     : new PlayedKimi(_launcher) { Turn = (_, _) => PlayedKimi.Answered(PlayedKimi.Minted, 100, 10, Advice) };
 for "refused": before AskAsync delete the fake person's credentials folder (`Directory.Delete(_person.Credentials, true)`), so the launch control
 refuses before any launch ("has no credentials folder; run `kimi login`").
Act: var reply = await AskAsync(Service(played, Path.Combine(Repo, "src")), cts.Token).
Assert: reply.TryGetProperty("answers", out var answers) and the single row's "status" is RowOutcomes.Answered for "answered" (and not for the others);
 for "answered": played.Shims.Should().ContainSingle().Subject.Request: its stdin/prompt Contains the copy's path (a folder under the folder after "--cwd")
  and NotContain(Path.Combine(Repo, "src")); no "--session" argument;
 for every ending: Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder)) is empty (or the folder is absent);
  Directory.EnumerateDirectories(Path.GetTempPath(), "coai-question-*") has none made by this test (compare with a list taken before);
  _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
  _person.Hash().Should().Equal(before).
Before E5.3 g: "Expected Directory.Exists("…\coai-vh\<8>") to be False, but found True." / the recorder red.

## The exact existing types and members you may use (context pack)
# Region s567-row (test) — src_mcp/tests/AKimiQuestionRowTests.cs

Fields already in the class: `_launcher` (ProcessLauncher), `_person` (KimiFixture), `_dir` (TempDir), `_unlinkedByTheDeleter` (List<string>), `Repo` (=_dir.At("repo")), `Homes` (=_dir.At("homes")), const `Advice`; helpers `Service(PlayedKimi, params string[] roots)`, `StandIn()` (an IDisposable: the fake person, the measured host, the lock root — keep it alive for the whole test, `using var`), `AskAsync(PanelService, CancellationToken)`.

## Existing APIs (copied from the repository)

namespace CoaiMcp.Tests (src_mcp/tests/, all `internal` or `public` in the test assembly):

```csharp
// TempDir.cs
public sealed class TempDir : IDisposable {
    public string Path { get; }
    public static TempDir For(string prefix);                    // Directory.CreateTempSubdirectory(prefix)
    public static implicit operator string(TempDir directory);   // passes as a path
    public string At(params string[] parts);                     // Path.Combine(Path, parts)
    public void Dispose();
}
// KimiFixture.cs  (a fake person: a sign-in, a config; NEVER the developer's real ~/.kimi-code)
public sealed class KimiFixture : IDisposable {
    public KimiFixture(string? config = null);
    public string Folder { get; }  public string PersonsHome { get; }  public string Credentials { get; }  public string PersonsConfig { get; }
    public KimiPlaces PlacesAt(string ownedRoot);                // pass as the Kimi seam: _person.PlacesAt
    public IReadOnlyList<string> Hash();                         // every entry of the person's folder: path, attributes, SHA-256 — unchanged = whole
    public void Dispose();
}
// WindowsStandIn.cs
internal static class WindowsStandIn { public static IDisposable Begin(); }   // nothing on Windows; a symlink stand-in for a junction elsewhere
// PlayedKimi.cs  (the shim played in process; git etc. run for real through `inner`)
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher {
    public const string Shim = "played-coai-mcp";  public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                // every shim launch, in order
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }   // what the n-th shim launch prints; default = an answered turn
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }  // runs while a shim is "alive"
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Lost(string session);            // exit 70, end session_lost
}
```

namespace CoaiMcp.Runners.Processes (src_mcp/runners/Processes/ProcessLauncher.cs):

```csharp
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) {
    public IReadOnlyDictionary<string, string?> Environment { get; init; }
    public string StdIn { get; init; }   // the prompt rides here for some runtimes
    public bool InheritsEnvironment { get; init; }
}
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed class ProcessLauncher : IProcessLauncher { }       // the real one: `new ProcessLauncher()`
```

The Kimi shim's argv (KimiRuntime.Arguments) holds literal pairs: `"--cwd", <cwd>`, `"--home", <home>`, `"--model", <m>` and, only on a continued turn, `"--session", <id>`
(AcpWords.HomeFlag = "--home", AcpWords.SessionFlag = "--session", namespace CoaiMcp.Runners.Acp).

Seams for a Kimi adapter built BY NAME (as the check and the service build it), per async flow, set SYNCHRONOUSLY in the test (not inside an awaited helper that returns):

```csharp
// namespace CoaiMcp.Runners.Kimi
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
internal static IDisposable KimiSeams.Using(HostKind host, KimiSeams seams);          // HostKind is CoaiMcp.Runners.Platform.HostKind (use HostKind.Windows)
public static IDisposable KimiCredentialsLock.RootFor(string folder);                  // the lock root of this flow
```

Deleter recorders (static, so the test class carries [Collection("fakecli-env")] and clears them in Dispose):

```csharp
// namespace CoaiMcp.Runners.Files
internal static Action<string>? GitScratch.AfterUnlink { get; set; }     // invoked by the DELETER when it unlinks a link: junction-first disposal must never invoke it
// namespace CoaiMcp.Runners.Kimi
internal static Action<string>? KimiHome.AfterUnlink { get; set; }
// namespace CoaiMcp.Runners.Vibe
public const string VibeHomes.OneShotFolder = "coai-vh";               // <homesRoot>\coai-vh\<8 hex>\kh-<10 hex> is a one-shot Kimi home
```

Assertion style: FluentAssertions (`using FluentAssertions;`), `[Fact]` / `[Theory]` from xUnit v3 (`using Xunit;`), `TestContext.Current.CancellationToken`.


## The question row flow

```csharp
// namespace CoaiMcp.Server
public PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing);
public Task<string> PanelService.AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default);
// VaultKeys.None("no vault in tests"); Serilog.Core.Logger.None; Noticing.None.
// namespace CoaiMcp.Core.QuestionConsult
public sealed record QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "");
public sealed record QuestionConsultSettings { IReadOnlyList<QuestionRow> Rows; IReadOnlyList<string> Roots; TimeSpan RowBudget; ... }   // init-only
public static class RowOutcomes { public const string Answered = "answered"; ... }
// namespace CoaiMcp.Core.Rounds: PanelConfig.Uniform(3, 2, StagePolicy.Human)
```

The existing Vibe test builds its service (src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs) — copy its shape, with the Kimi row and homes root:

```csharp
private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot, Providers = [], Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"), ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots, RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"), default, vibe, Logger.None, Noticing.None);
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
    JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;
private static JsonElement TheRow(JsonElement reply)
{
    reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
    return answers.EnumerateArray().Should().ContainSingle().Subject;     // then .GetProperty("status").GetString()
}
// the repository (InitializeAsync):
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files) { var full = Path.Combine([at, .. path.Split('/')]); Directory.CreateDirectory(Path.GetDirectoryName(full)!); await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken); }
    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}
// a Vibe test's assertions: var turn = vibe.Turns.Should().ContainSingle().Subject;
//   turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy"); turn.Request.StdIn.Should().NotContain(granted);
//   Directory.Exists(RowFolderOf(turn.Request)).Should().BeFalse("the row's home and copy are gone once it answered");
```

For the Kimi row the shim request is `played.Shims.Single().Request`; its prompt: check BOTH `request.StdIn` and the arguments (the shim takes the prompt on stdin or in argv — assert on the one that is non-empty / search `string.Join("\n", request.Arguments) + request.StdIn`).
The row's scratch is a `coai-question-*` folder under the temp folder; its home is the folder after "--home" (`<homes>/coai-vh/<8>/kh-<10 hex>`).
The row's launch is refused BEFORE any launch when the fake person has no credentials folder (`Directory.Delete(_person.Credentials, true)`): KimiLaunch says "has no credentials folder; run `kimi login`" — the shim is never started (played.Shims is empty).


## A short similar existing test (src_mcp/tests/AOneShotKimiHomeIsDisposedJunctionFirstTests.cs)

```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) =>
    _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
private void TheDeleterNeverMetTheJunction() =>
    _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
[Fact]
public void AOneShotHome_IsDisposedJunctionFirst_UnderItsLock()
{
    using var standIn = WindowsStandIn.Begin();
    var home = Reserved();                       // a OneShotHome under <root>\coai-vh\<8>
    MadeHomeIn(home.Folder);
    var before = _person.Hash();
    RecordingTheDeleter();
    home.Dispose();
    Directory.Exists(home.Folder).Should().BeFalse("the owner takes its folder whole when it ends");
    TheDeleterNeverMetTheJunction();
    ThePersonsFolderIsWhole(before);
}
```



## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Core.Rounds;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Platform;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Runners.Vibe;
using CoaiMcp.Server;
using FluentAssertions;
using Serilog.Core;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// A Kimi question-consultant row (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.6.7): a <c>disk</c> row reads the COPIES of its operator's
/// granted roots and is told the copies' paths, never the originals; and the row's scratch and its one-shot home <c>coai-vh\&lt;8&gt;</c> are gone,
/// junction-first, once the row ends — on an answer, a refusal before the launch and a cancellation alike.
/// </summary>
/// <remarks>
/// The whole <c>ask_consultants</c> flow through the service, git for real, the shim played (<see cref="PlayedKimi"/>) over a fake person
/// (<see cref="KimiFixture"/>) — shaped like <c>AVibeQuestionRowReadsACopyOfItsRootsTests</c>. The real <c>kimi</c> is never started.
/// </remarks>
[Collection("fakecli-env")]
public sealed class AKimiQuestionRowTests : IAsyncLifetime
{
    private const string Advice = "Retry with a jittered backoff, three attempts.";

    private readonly ProcessLauncher _launcher = new();
    private readonly KimiFixture _person = new();
    private readonly TempDir _dir = TempDir.For("testsToDelete-kimi-qrow-");
    private readonly List<string> _unlinkedByTheDeleter = [];

    private string Repo => _dir.At("repo");

    private string Homes => _dir.At("homes");

    public async ValueTask InitializeAsync()
    {
        // QWEN-FILL-BEGIN s567-init test
        Directory.CreateDirectory(Homes);
        var files = new (string Path, string Text)[]
        {
            (@"src\Mailer.cs", "void Send() { }\n"),
            (@"docs\notes.md", ""),
        };
        foreach (var (path, text) in files)
        {
            var full = Path.Combine(Repo, path);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
        }
        var args = new string[][]
        {
            new[] { "init", "-b", "main" },
            new[] { "config", "user.email", "t@example.com" },
            new[] { "config", "user.name", "t" },
            new[] { "add", "." },
            new[] { "commit", "-m", "base" },
        };
        foreach (var a in args)
        {
            var result = await _launcher.RunAsync(new ProcessRequest("git", a, Repo), TestContext.Current.CancellationToken);
            result.ExitCode.Should().Be(0, string.Join(' ', a) + ": " + result.StdErr);
        }
        // QWEN-FILL-END s567-init
    }

    public ValueTask DisposeAsync()
    {
        GitScratch.AfterUnlink = null;
        KimiHome.AfterUnlink = null;
        _dir.Dispose();
        _person.Dispose();

        return ValueTask.CompletedTask;
    }

    /// <summary>The service with one enabled Kimi <c>disk</c> row, the homes root <see cref="Homes"/> and the granted <paramref name="roots"/>.</summary>
    private PanelService Service(PlayedKimi played, params string[] roots)
    {
        // QWEN-FILL-BEGIN s567-service test
        var settings = new PanelSettings
        {
            ConsultantHomesRoot = Homes,
            Providers = [],
            Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
            DataDir = _dir.At("data"),
            ReviewerTimeout = TimeSpan.FromSeconds(30),
            QuestionConsult = new QuestionConsultSettings
            {
                Rows = [new QuestionRow("kimi-disk", "kimi", "kimi", string.Empty, string.Empty, PlayedKimi.Shim, string.Empty, "question-disk", Enabled: true)],
                Roots = roots,
                RowBudget = TimeSpan.FromSeconds(30),
            },
        };
        return new PanelService(settings, VaultKeys.None("no vault in tests"), default, played, Logger.None, Noticing.None);
        // QWEN-FILL-END s567-service
    }

    /// <summary>The fake person, the measured host and a lock root, stood in for THIS async flow (set synchronously, so the service's calls see them).</summary>
    private IDisposable StandIn() => new Scopes(
        WindowsStandIn.Begin(),   <<< REGION s567-row STARTS AFTER THIS LINE
        KimiCredentialsLock.RootFor(Path.Combine(_person.Folder, "locks")),
        KimiSeams.Using(HostKind.Windows, new KimiSeams(_person.PlacesAt, () => (PlayedKimi.Shim, []))));

    private sealed class Scopes(params IDisposable[] scopes) : IDisposable
    {
        public void Dispose()
        {
            foreach (var scope in scopes.Reverse())
            {
                scope.Dispose();
            }
        }
    }

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken ct) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct)).RootElement;

    /// <summary>   <<< REGION s567-row ENDS BEFORE THIS LINE
    /// S5.6.7: a <c>disk</c> row on a git root reads its copy — the prompt names the copy's path and never the root — and after each ending the
    /// row's scratch and <c>coai-vh\&lt;8&gt;</c> are gone, the deleter's unlink recorder never invoked, the fake person's folder intact.
    /// </summary>
    [Theory]
    [InlineData("answered")]
    [InlineData("refused")]
    [InlineData("cancelled")]
    public async Task AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(string ending)
    {
        ending.Should().BeOneOf("answered", "refused", "cancelled");
        // QWEN-FILL-BEGIN s567-row test
        // Arrange: using var standIn = StandIn(); var before = _person.Hash(); GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
        //  using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        //  var played = ending == "cancelled"
        //      ? new PlayedKimi(_launcher) { During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); } }
        //      : new PlayedKimi(_launcher) { Turn = (_, _) => PlayedKimi.Answered(PlayedKimi.Minted, 100, 10, Advice) };
        //  for "refused": before AskAsync delete the fake person's credentials folder (`Directory.Delete(_person.Credentials, true)`), so the launch control
        //  refuses before any launch ("has no credentials folder; run `kimi login`").
        // Act: var reply = await AskAsync(Service(played, Path.Combine(Repo, "src")), cts.Token).
        // Assert: reply.TryGetProperty("answers", out var answers) and the single row's "status" is RowOutcomes.Answered for "answered" (and not for the others);
        //  for "answered": played.Shims.Should().ContainSingle().Subject.Request: its stdin/prompt Contains the copy's path (a folder under the folder after "--cwd")
        //   and NotContain(Path.Combine(Repo, "src")); no "--session" argument;
        //  for every ending: Directory.EnumerateFileSystemEntries(Path.Combine(Homes, VibeHomes.OneShotFolder)) is empty (or the folder is absent);
        //   Directory.EnumerateDirectories(Path.GetTempPath(), "coai-question-*") has none made by this test (compare with a list taken before);
        //   _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
        //   _person.Hash().Should().Equal(before).
        // Before E5.3 g: "Expected Directory.Exists("…\coai-vh\<8>") to be False, but found True." / the recorder red.
        throw new NotImplementedException("s567-row");
        // QWEN-FILL-END s567-row
    }
}

```


Your previous answer was rejected: unbalanced braces (-1). Return only the region's code.
