```csharp
        if (launch.Confinement is LaunchConfinement.Planned { Plan: var plan } && (plan.Flags.Count + plan.Leading.Count + plan.AddDirs.Count) > 0)
            throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch));
```