```csharp
        var plain = Planned("kimi", CapabilityGrant.None);
        var plan = ((LaunchConfinement.Planned)plain.Confinement!).Plan;
        var flagged = plain with { Confinement = new LaunchConfinement.Planned(plan with { Flags = ["--yolo"] }) };
        Action build = () => AKimiConsultant().Build(flagged);
        build.Should().Throw<ArgumentException>().WithMessage("*shim*");
```