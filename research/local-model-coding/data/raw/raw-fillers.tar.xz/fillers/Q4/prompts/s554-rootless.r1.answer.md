```csharp
        var played = PlayedThatReadsTheMarker();
        var settings = Settings(string.Empty);
        RecordingTheDeleter();

        var (code, said) = await CheckAsync(settings, played, TestContext.Current.CancellationToken);

        code.Should().Be(0);
        var home = After(played.Shims.Should().ContainSingle().Subject.Request, AcpWords.HomeFlag);
        home.Should().Contain(Path.Combine("own", "kh-"));
        Directory.EnumerateDirectories(_temp.Path, "coai-check-*").Should().BeEmpty("the scratch is gone");
        Directory.Exists(home).Should().BeFalse();
        TheDeleterNeverMetTheJunction();
```