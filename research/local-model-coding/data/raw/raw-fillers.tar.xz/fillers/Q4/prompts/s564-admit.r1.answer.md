```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>()
                .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}: Grep and Glob read the disk (M-K6) whatever the working folder");
        }
```