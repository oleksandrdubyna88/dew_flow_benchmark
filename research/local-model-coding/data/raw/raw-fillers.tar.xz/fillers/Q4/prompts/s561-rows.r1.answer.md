```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk, Capability.Web])
        {
            var row = RuntimeCapabilities.Builtin.Of("kimi", capability)!;
            row.MeasuredWith.Version.Should().Be("2.1.1");
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md");
        }

        var none = RuntimeCapabilities.Builtin.Of("kimi", Capability.None)!;
        none.Standing.Should().Be(CapabilityStanding.Unconfined);
        none.MeasuredWith.Cells.Should().Contain("M-K6");

        var disk = RuntimeCapabilities.Builtin.Of("kimi", Capability.Disk)!;
        disk.Standing.Should().Be(CapabilityStanding.Unconfined);
        disk.MeasuredWith.Cells.Should().Contain("M-K6").And.Contain("M-K9");

        var web = RuntimeCapabilities.Builtin.Of("kimi", Capability.Web)!;
        web.Standing.Should().Be(CapabilityStanding.Unmeasured);
```