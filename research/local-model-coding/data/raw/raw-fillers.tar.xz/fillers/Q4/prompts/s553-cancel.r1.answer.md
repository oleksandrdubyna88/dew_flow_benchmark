```csharp
        using var cts = new CancellationTokenSource();
        RecordingTheDeleter();
        var played = new PlayedKimi(new ProcessLauncher()) { During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); } };
        var (_, said) = await CheckAsync(Settings(_homes.Path), played, cts.Token);
        said.GetProperty("state").GetString().Should().Be(ConsultCheckStates.Unavailable);
        TheOneShotFolderIsGone();
        TheDeleterNeverMetTheJunction();
```