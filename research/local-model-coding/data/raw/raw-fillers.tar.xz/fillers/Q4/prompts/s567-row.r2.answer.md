```csharp
        using var standIn = StandIn();
        var before = _person.Hash();
        GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);

        var played = ending == "cancelled"
            ? new PlayedKimi(_launcher) { During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); } }
            : new PlayedKimi(_launcher) { Turn = (_, _) => PlayedKimi.Answered(PlayedKimi.Minted, 100, 10, Advice) };

        if (ending == "refused")
        {
            Directory.Delete(_person.Credentials, true);
        }

        var reply = await AskAsync(Service(played, Path.Combine(Repo, "src")), cts.Token);

        reply.TryGetProperty("answers", out var answers).Should().BeTrue();
        var row = answers.EnumerateArray().Should().ContainSingle().Subject;

        if (ending == "answered")
        {
            row.GetProperty("status").GetString().Should().Be(RowOutcomes.Answered);
            var shim = played.Shims.Should().ContainSingle().Subject;
            var request = shim.Request;
            var prompt = string.Join("\n", request.Arguments) + request.StdIn;
            var copyPath = Path.Combine(Repo, "src");
            prompt.Should().Contain(copyPath);
            prompt.Should().NotContain(Path.Combine(Repo, "src"));
            // Check no --session argument
            var hasSession = request.Arguments.Any(a => a == "--session");
            hasSession.Should().BeFalse();
        }
        else
        {
            row.GetProperty("status").GetString().Should().NotBe(RowOutcomes.Answered);
        }

        // Common assertions for every ending
        var oneShotFolder = Path.Combine(Homes, VibeHomes.OneShotFolder);
        Directory.Exists(oneShotFolder).Should().BeFalse();
        
        var tempPath = Path.GetTempPath();
        var beforeScratches = Directory.EnumerateDirectories(tempPath, "coai-question-*").ToList();
        
        _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
        _person.Hash().Should().Equal(before);
```