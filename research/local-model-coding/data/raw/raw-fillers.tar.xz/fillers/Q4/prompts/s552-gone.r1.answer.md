```csharp
        var before = _person.Hash();
        RecordingTheDeleter();

        foreach (var played in new[] { PlayedThatReadsTheMarker(), new PlayedKimi(new ProcessLauncher()) { Turn = (_, request) => PlayedKimi.Lost(PlayedKimi.Minted) } })
        {
            await CheckAsync(Settings(_homes.Path), played, TestContext.Current.CancellationToken);

            TheOneShotFolderIsGone();
            TheDeleterNeverMetTheJunction();
            _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
        }
```