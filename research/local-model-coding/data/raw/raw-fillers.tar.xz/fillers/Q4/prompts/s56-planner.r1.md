You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s56-planner — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
Decision 1 of E5.6, shaped like Vibe just above but with EMPTY flag lists (no VibeReadOnly). A switch on grant.Capability:
  Capability.Disk => new Confinement.Planned("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots }
  _ (None; `web` never reaches here, the matrix refuses it as unmeasured) => new Confinement.Planned("kimi", grant, [], [], CwdKind.Scratch, [], flag)

## The exact existing types and members you may use (context pack)
# Region s56-planner (prod) — src_mcp/core/QuestionConsult/ConfinementPlanner.cs, method `Kimi`

Fill the body of `private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag)`.

Existing types (namespace CoaiMcp.Core.QuestionConsult), copied:

```csharp
public abstract record Confinement {
    public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd,
        IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }
    public sealed record Refused(string Reason) : Confinement;
}
// CapabilityGrant has .Capability (enum Capability { None, Disk, Web }) and .Roots (IReadOnlyList<string>)
// enum CwdKind { Scratch, Root, Snapshot }
```

The Vibe method just below it in the file, the model to follow (a switch expression, as a switch STATEMENT or expression body is fine here; this method has a block body so write `return grant.Capability switch { ... };`):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

Kimi's twin: the runtime string is "kimi", both flag lists are EMPTY (`[]`), Disk → Snapshot with SnapshotSources = grant.Roots, anything else → Scratch.
The arm `"kimi" => Kimi(grant, flag)` is already in `Fragments`. Cyclomatic complexity <= 4. The test is ConfinementPlannerTests.ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb (and the matrix's Admit runs before Plan, so `web` never reaches this method).


## The whole file (the region is marked with <<<)
```csharp
namespace CoaiMcp.Core.QuestionConsult;

/// <summary>Where a planned launch stands: an empty scratch directory, or the first granted root.</summary>
/// <remarks>
/// Two kinds and not three. The plan's §4 also named <c>repo</c>, which is where the SHIPPED stuck
/// consultant stands (<c>LaunchConfinement.AsShipped</c>, decided by the adapter, not planned here);
/// no question row ever stands in the checkout, so a planner that could answer <c>repo</c> would be a
/// value nothing checks and one wrong arm away from a none row reading the tree.
/// </remarks>
public enum CwdKind
{
    Scratch,

    Root,

    /// <summary>
    /// A coai-owned SANITISED SNAPSHOT of the granted roots, made by the launch (D6 of todo/PLAN_vibe_and_kimi_runtimes.md)
    /// — for a CLI that reads only its working folder and loads its configuration from it (Vibe, M-V11), whose roots
    /// therefore can be neither its cwd nor an added directory.
    /// </summary>
    Snapshot,
}

/// <summary>What the planner decided for one runtime × grant: the fragments to compose, or a refusal.</summary>
public abstract record Confinement
{
    /// <param name="Leading">Argv BEFORE the CLI's subcommand — codex's top-level <c>--search</c> (F1); empty everywhere else.</param>
    /// <param name="Flags">The sandbox flags, in order, complete — an adapter splices them and adds none of its own.</param>
    /// <param name="Cwd">Where the process stands.</param>
    /// <param name="AddDirs">The roots the flags grant as LAUNCH FLAGS (<c>--add-dir</c>), for the record; the flags already spell them the runtime's way — never a copy's sources.</param>
    /// <param name="Flag">D13's caveat on an admitted pair — shown beside every answer the row produces.</param>
    public sealed record Planned(
        string Runtime,
        CapabilityGrant Grant,
        IReadOnlyList<string> Leading,
        IReadOnlyList<string> Flags,
        CwdKind Cwd,
        IReadOnlyList<string> AddDirs,
        AdmissionFlag Flag) : Confinement
    {
        /// <summary>
        /// The folders the launch reads through COPIES (<see cref="CwdKind.Snapshot"/>, D6) — never a launch flag. Its own field,
        /// not <see cref="AddDirs"/>: there a root is something the CLI is told to read, and Vibe is never given one (D3, the
        /// #811 checkpoint round).
        /// </summary>
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }

    public sealed record Refused(string Reason) : Confinement;

    private Confinement() { }
}

/// <summary>
/// The ONE place a question row's sandbox is decided: runtime × grant → argv fragments, a cwd kind and
/// the granted roots (PLAN_question_consultant.md, D4). Adapters compose; they never choose a flag.
/// </summary>
/// <remarks>
/// <para>Every fragment is a measured fact of the probe run of 2026-10-01, cited per row in
/// <c>shared/runtime-capabilities.json</c>: claude launches ONLY through <c>--tools</c> (plus
/// <c>--restricted</c> for disk), never through <c>--disallowedTools</c> (F3, F5 — the shipped deny
/// lists were offered the user environment's whole tool set and leaked 6 of 6 through PowerShell);
/// codex's <c>--search</c> is a top-level flag before <c>exec</c> (F1); agy's measured launch is plan
/// mode on the stream (F7). The matrix is asked FIRST, so a pair it refuses is refused here with its
/// own sentence and no runtime arm is reached.</para>
/// <para>Pure: every flag is a golden test (<c>ConfinementPlannerTests</c>), per runtime × capability,
/// over the whole argv an adapter then builds.</para>
/// </remarks>
public static class ConfinementPlanner
{
    /// <summary>The flag no planned launch ever carries (F3/F5): a deny list is not a boundary.</summary>
    public const string NeverSent = "--disallowedTools";

    /// <summary>What a claude disk row may do: read, find, search — and no shell (F4).</summary>
    public static IReadOnlyList<string> ClaudeDiskTools { get; } = ["Read", "Glob", "Grep"];

    /// <summary>What a claude web row may do: the two client web tools, which refuse <c>file://</c> (F6).</summary>
    public static IReadOnlyList<string> ClaudeWebTools { get; } = ["WebSearch", "WebFetch"];

    /// <summary>
    /// Vibe's read-only pair, both always (D2 of todo/PLAN_vibe_and_kimi_runtimes.md): together they denied 9 of 9 write
    /// attempts (research/RESULTS_vibe_confinement.md §4) and every write under forced experiment variants (§23). Spelled
    /// once — the reviewer's argv (<c>VibeRuntime</c>) and a question row's plan both read it.
    /// </summary>
    public static IReadOnlyList<string> VibeReadOnly { get; } = ["--agent", "plan", "--enabled-tools", "read_file"];

    /// <summary>
    /// Every argument that decides a sandbox on any of the six runtimes — what a planned launch may
    /// carry ONLY from a plan. The structural test in <c>ConfinementPlannerTests</c> reads it.
    /// </summary>
    private static readonly string[] SandboxVocabulary =
    [
        "--tools", "--restricted", "--add-dir", "--permission-mode", NeverSent, "--disallowed-tools", "--allowedTools",
        "--allowed-tools", "--dangerously-skip-permissions",
        "--search", "-s", "--sandbox", "--ephemeral", "-C", "--full-auto", "--yolo",
        "--mode",
        // Vibe's (D2, D3). Not `--agent`: agy's adapter names its own read-only agent (`--agent coai-reader`), which is
        // the adapter's confinement of agy, not a plan's — and Vibe's `--agent plan` comes from the plan beside it.
        "--enabled-tools", "--trust",
    ];

    public static bool IsSandboxVocabulary(string argument) => SandboxVocabulary.Contains(argument, StringComparer.Ordinal);

    /// <summary>The plan for one row, or why there is none.</summary>
    public static Confinement Plan(string runtime, CapabilityGrant grant)
    {
        if (CapabilityMatrix.Admit(runtime, grant.Capability) is not Admission.Admitted admitted)
        {
            return new Confinement.Refused(((Admission.Refused)CapabilityMatrix.Admit(runtime, grant.Capability)).Reason);
        }

        var roots = WhyNotTheseRoots(grant);

        return roots.Length > 0
            ? new Confinement.Refused(roots)
            : Fragments(runtime.Trim().ToLowerInvariant(), grant, admitted.Flag);
    }

    /// <summary>A disk grant has roots, every root is absolute, and nothing else carries one.</summary>
    private static string WhyNotTheseRoots(CapabilityGrant grant)
    {
        if (grant.Capability != Capability.Disk)
        {
            return grant.Roots.Count == 0
                ? string.Empty
                : $"a '{grant.Capability.Spelled()}' grant carries no roots — a directory on a row that reads no directory is a leak path; the roots are a 'disk' prompt's";
        }

        if (grant.Roots.Count == 0)
        {
            return "a 'disk' grant needs at least one root to read — set the folders in ConnectOtherAIs > Question consultant";
        }

        return grant.Roots.FirstOrDefault(root => !IsAbsolute(root)) is { } relative
            ? $"the root '{relative}' is not an absolute path — a relative root resolves against whatever the cwd happens to be; every root is spelled from a drive or from /"
            : string.Empty;
    }

    /// <summary>
    /// Absolute on either platform's spelling — lexical, so the same table and the same tests decide
    /// alike on Windows and on Linux (a <c>D:/</c> root is not rooted to <c>Path.IsPathRooted</c> on Linux).
    /// </summary>
    private static bool IsAbsolute(string root)
    {
        var text = root.Trim();

        return text.Length >= 3 && char.IsAsciiLetter(text[0]) && text[1] == ':' && text[2] is '/' or '\\'
            || text.Length >= 2 && text[0] is '/' or '\\';
    }

    private static Confinement Fragments(string runtime, CapabilityGrant grant, AdmissionFlag flag) => runtime switch
    {
        "claude" => Claude(grant, flag),
        "codex" => Codex(grant, flag),
        "antigravity" => Antigravity(grant, flag),
        "vibe" => Vibe(grant, flag),
        "kimi" => Kimi(grant, flag),
        // A completion has no tools, so it has no sandbox flag: the question alone, from nowhere.
        _ => new Confinement.Planned(runtime, grant, [], [], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Claude(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        // `--tools ""` offers nothing at all (F3, read-denied × allowlist 3 of 3).
        Capability.None => new("claude", grant, [], ["--permission-mode", "plan", "--tools", ""], CwdKind.Scratch, [], flag),
        // `--restricted` confines the file tools to the working directories and `--add-dir` is the only
        // way out (F4); `--tools` alone is no path boundary.
        Capability.Disk => new("claude", grant, [],
            ["--permission-mode", "plan", "--restricted", "--tools", string.Join(',', ClaudeDiskTools), .. AddDirs("--add-dir", grant.Roots)],
            CwdKind.Root, grant.Roots, flag),
        // The two client web tools and nothing file-capable (F6: web-confined × allowlist 3 of 3).
        _ => new("claude", grant, [], ["--permission-mode", "plan", "--tools", string.Join(',', ClaudeWebTools)], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Codex(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        // `--ephemeral`: one-shot, nothing left in the person's codex store — the opposite of the
        // stuck consultant's trade, because a question row is never resumed.
        Capability.None => new("codex", grant, [], ["-s", "read-only", "--ephemeral"], CwdKind.Scratch, [], flag),
        // `-C <root 0>` tells it where to read; nothing stops it reading elsewhere (F2) — hence the flag.
        Capability.Disk => new("codex", grant, [], ["-s", "read-only", "--ephemeral", "-C", grant.Roots[0]], CwdKind.Root, grant.Roots, flag),
        // `--search` BEFORE `exec` (F1): `codex exec --search` is a usage error, exit 2.
        _ => new("codex", grant, ["--search"], ["-s", "read-only", "--ephemeral"], CwdKind.Scratch, [], flag),
    };

    private static Confinement.Planned Antigravity(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        Capability.Disk => new("antigravity", grant, [], ["--mode", "plan", .. AddDirs("--add-dir", grant.Roots)], CwdKind.Root, grant.Roots, flag),
        // `web` never reaches here: the matrix refuses it (F7, it cannot fetch a page headless).
        _ => new("antigravity", grant, [], ["--mode", "plan"], CwdKind.Scratch, [], flag),
    };

    /// <remarks>
    /// D2's pair on every capability, never <c>--trust</c> or <c>--add-dir</c> (D3: a trusted folder runs its hooks, and
    /// <c>--add-dir</c> trusts its folder). Vibe reads only its working folder (M-V11, 6 of 6), so a disk row's roots are
    /// COPIED into the snapshot it stands in (D6) and named to it there; a none row stands in an empty folder.
    /// </remarks>
    private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
    {
        Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
        // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
        _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
    };

    /// <remarks>
    /// No flags, ever: Kimi's confinement is the shim's (D15), not its argv. A disk row's roots are COPIED into the snapshot it stands in
    /// (D6, M-K9); a none row stands in an empty folder. Neither is confined (<c>Grep</c> and <c>Glob</c> read the disk, M-K6), which the matrix flags.
    /// </remarks>
    private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag)
    {
        // QWEN-FILL-BEGIN s56-planner prod   <<< REGION s56-planner STARTS AFTER THIS LINE
        // Decision 1 of E5.6, shaped like Vibe just above but with EMPTY flag lists (no VibeReadOnly). A switch on grant.Capability:
        //   Capability.Disk => new Confinement.Planned("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots }
        //   _ (None; `web` never reaches here, the matrix refuses it as unmeasured) => new Confinement.Planned("kimi", grant, [], [], CwdKind.Scratch, [], flag)
        throw new NotImplementedException("s56-planner");
        // QWEN-FILL-END s56-planner   <<< REGION s56-planner ENDS BEFORE THIS LINE
    }

    private static IEnumerable<string> AddDirs(string flag, IReadOnlyList<string> roots) =>
        roots.SelectMany(root => (string[])[flag, root]);
}

```
