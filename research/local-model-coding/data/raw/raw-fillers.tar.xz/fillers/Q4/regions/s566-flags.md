# Region s566-flags (test) — src_mcp/tests/ConfinementPlannerTests.cs, `APlanWithFlags_IsRefusedForKimi`

```csharp
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "");   // helper of the class, see the s565-launch pack
private static Runners.Kimi.KimiConsultant AKimiConsultant();
// ConsultantLaunch is a record: `launch with { Confinement = ... }`; its Confinement is a LaunchConfinement:
public sealed record LaunchConfinement.Planned(Confinement.Planned Plan) : LaunchConfinement;
// Confinement.Planned is a record: `plan with { Flags = ["--yolo"] }` (Flags is IReadOnlyList<string>)
```

Steps: `var plain = Planned("kimi", CapabilityGrant.None);` `var plan = ((LaunchConfinement.Planned)plain.Confinement).Plan;`
`var flagged = plain with { Confinement = new LaunchConfinement.Planned(plan with { Flags = ["--yolo"] }) };`
`var build = () => AKimiConsultant().Build(flagged);` `build.Should().Throw<ArgumentException>().WithMessage("*shim*");`
(FluentAssertions: `using FluentAssertions;` is already in the file; the delegate type is `Action`.)
