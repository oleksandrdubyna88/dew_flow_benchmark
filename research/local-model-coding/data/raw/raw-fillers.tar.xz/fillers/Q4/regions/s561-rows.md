# Region s561-rows (test) — src_mcp/tests/CapabilityMatrixTests.cs, `KimiHasThreeRows_EachCitingItsCells`

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public enum Capability { None, Disk, Web }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
public sealed record RuntimeCapabilities { public static RuntimeCapabilities Builtin { get; } ; public RuntimeCapabilityRow? Of(string runtime, Capability capability); }
```

The data (shared/runtime-capabilities.json, already written): kimi × none = unconfined, cells [M-K6, M-K3, M-K4]; kimi × disk = unconfined, cells [M-K6, M-K3, M-K4, M-K9, "M-K9 (e)"];
kimi × web = unmeasured, cells []; all three cli "kimi", version "2.1.1", resultRef beginning "research/RESULTS_kimi_confinement.md".

The existing test next to it, the shape to follow:

```csharp
[Fact]
public void TheVibeRows_RestOnTheVibeProbe_AndItsWebIsUnmeasured_SoRefused()
{
    foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
    {
        var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
        row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
        row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
    }
    RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6", "...");
}
```
Use the `!` after `Of(...)` only after asserting `Should().NotBeNull()` so the red is the null message ("Expected RuntimeCapabilities.Builtin.Of("kimi", Capability.None) not to be <null>.").
