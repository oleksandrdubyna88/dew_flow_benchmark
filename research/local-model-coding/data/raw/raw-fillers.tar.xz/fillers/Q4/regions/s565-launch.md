# Region s565-launch (test) — src_mcp/tests/ConfinementPlannerTests.cs, `AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome`

Class fields/helpers already in the file (ConfinementPlannerTests):

```csharp
private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree = Path.Combine(RowFolder, "tree");
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{ Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)), ScratchDir = Scratch, Workdir = RowTree };
private static Runners.Kimi.KimiConsultant AKimiConsultant();   // added by the skeleton: a Kimi consultant over a fake person's places (Windows host kind)
```

`KimiConsultant.Build(ConsultantLaunch launch)` returns `ReviewerInvocation` with `.Request` (ProcessRequest: Executable, Arguments, WorkingDirectory, Environment, StdIn, InheritsEnvironment) and `.Role` (string).
`ConsultantRoles.Question` is the role of a planned launch (namespace CoaiMcp.Runners.Consultation). The shim's argv holds `"--cwd", <cwd>`, `"--home", <home>` (home = under `RowFolder` + separator), and
`"--session", <id>` only on a continued turn (AcpWords.SessionFlag, namespace CoaiMcp.Runners.Acp) — a question row has none.

```csharp
// namespace CoaiMcp.Runners.Kimi (src_mcp/runners/Kimi/KimiEnvironment.cs)
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places);   // empty when the built environment is admitted
// KimiPlaces: the record AKimiConsultant's seam makes with KimiPlaces.ForShim(root, personsBin). For the Refusal check, take places = KimiPlaces.ForShim(<the folder after --home's owner root>, ...)
// — if that is not straightforward, assert instead what the sentence of the old Vibe test asserts: request.InheritsEnvironment.Should().BeFalse() and
// request.Environment.Should().NotBeEmpty() (the minimal, explicit environment); say so in a comment. Do NOT invent members.
```

The Vibe twin to copy the shape from:

```csharp
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Request.Arguments.Should().ContainInConsecutiveOrder("--workdir", Scratch).And.NotContain("--trust").And.NotContain("--resume", "one shot");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named");
```
Note: the skeleton's KimiConsultant.Build already needs the s56-noflags region filled before a planned Kimi launch builds; the planner arm (s56-planner) must be filled for `Planned("kimi", ...)`.
