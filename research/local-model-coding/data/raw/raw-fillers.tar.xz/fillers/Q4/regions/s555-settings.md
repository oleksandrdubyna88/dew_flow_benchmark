# Region s555-settings (test helper) — AKimiConsultantCheckTests.Settings

## The check

```csharp
// namespace CoaiMcp.Server  (src_mcp/src/Server/Consultation/ConsultantCheckMode.cs) — internal, visible to the tests
internal static async Task<(int Code, string Out, string Err)> ConsultantCheckMode.AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
// args: ["--check-consultant", "--caller", "claude"]; Out is the JSON the check prints (empty when none); Noticing.None is the no-op notifier.
// ConsultantCheck.OwnName = "own": the check's scratch is <tempRoot>/coai-check-*/ with own/tree (the COPY of the scratch repository) and, rootless, own/kh-<10 hex> (the home).
// ConsultCheckStates (public static class, CoaiMcp.Server): Answered = "answered", Failed = "failed", Unavailable, ... NotAttempted = "not-attempted" (the canary property).

// namespace CoaiMcp.Server (src_mcp/src/Server/PanelSettings.cs) — init-only properties used by the existing check tests:
public sealed record PanelSettings { IReadOnlyList<...> Providers; string DataDir; TimeSpan ReviewerTimeout; bool ConsultEnabled; string ConsultantHomesRoot;
    IReadOnlyDictionary<string, ConsultantChoice> Consultants; ... }
public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "");
public readonly record struct CallerIdentity(...)  // CallerIdentity.Claude is the string "claude": the caller's key in Consultants
```

How the existing Vibe check test builds its settings and reads the reply (src_mcp/tests/ConsultantCheckTests.cs):

```csharp
private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
{
    Providers = [], DataDir = _data, ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60), ConsultEnabled = enabled,
    Consultants = new Dictionary<string, ConsultantChoice> { [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe) },
};
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);
    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
// the Vibe test: AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT";
//   code.Should().Be(0); said.GetProperty("state").GetString() == "answered"; said.GetProperty("markerRead").GetBoolean().Should().BeTrue();
//   Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
```

The answer the check wants (ConsultantCheck.cs:114-117): two lines, `marker: <the word from CHECK.md>` and `canary: <the word from the outside file, or CANNOT>`.
CHECK.md is at the root of the scratch repository; the played shim sees the COPY of it in the folder after `--cwd`.
The fixed-up usings in AKimiConsultantCheckTests.cs: System.Text.Json; CoaiMcp.Runners.Acp; .Files; .Kimi; .Platform; .Processes; .Vibe; CoaiMcp.Server; FluentAssertions; Xunit.
