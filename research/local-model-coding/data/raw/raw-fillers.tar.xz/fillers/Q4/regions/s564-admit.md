# Region s564-admit (test) — src_mcp/tests/CapabilityMatrixTests.cs, `AdmissionFlagsBothRows`

```csharp
// namespace CoaiMcp.Core.QuestionConsult
public static class CapabilityMatrix { public static Admission Admit(string runtime, Capability capability); }
public abstract record Admission {
    public sealed record Admitted(CapabilityStanding Standing, AdmissionFlag Flag) : Admission;   // members: .Standing, .Flag
    public sealed record Refused(string Reason) : Admission;
}
public enum AdmissionFlag { None, Unconfined, DefaultDeny }   // check the file CapabilityMatrix.cs if a member name differs
```

The Vibe test next to it uses exactly this chain, copy it:
`CapabilityMatrix.Admit("vibe", capability).Should().BeOfType<Admission.Admitted>().Which.Flag.Should().Be(AdmissionFlag.None, $"vibe × {capability}: ...");`
For kimi: `AdmissionFlag.Unconfined` for both Capability.None and Capability.Disk.
