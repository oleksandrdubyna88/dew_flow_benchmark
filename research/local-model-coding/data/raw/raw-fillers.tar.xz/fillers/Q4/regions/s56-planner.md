# Region s56-planner (prod) — src_mcp/core/QuestionConsult/ConfinementPlanner.cs, method `Kimi`

Fill the body of `private static Confinement.Planned Kimi(CapabilityGrant grant, AdmissionFlag flag)`.

Existing types (namespace CoaiMcp.Core.QuestionConsult), copied:

```csharp
public abstract record Confinement {
    public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd,
        IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement {
        public IReadOnlyList<string> SnapshotSources { get; init; } = [];
    }
    public sealed record Refused(string Reason) : Confinement;
}
// CapabilityGrant has .Capability (enum Capability { None, Disk, Web }) and .Roots (IReadOnlyList<string>)
// enum CwdKind { Scratch, Root, Snapshot }
```

The Vibe method just below it in the file, the model to follow (a switch expression, as a switch STATEMENT or expression body is fine here; this method has a block body so write `return grant.Capability switch { ... };`):

```csharp
private static Confinement.Planned Vibe(CapabilityGrant grant, AdmissionFlag flag) => grant.Capability switch
{
    Capability.Disk => new("vibe", grant, [], VibeReadOnly, CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots },
    // `web` never reaches here: the matrix refuses it (no Vibe cell exercises the web).
    _ => new("vibe", grant, [], VibeReadOnly, CwdKind.Scratch, [], flag),
};
```

Kimi's twin: the runtime string is "kimi", both flag lists are EMPTY (`[]`), Disk → Snapshot with SnapshotSources = grant.Roots, anything else → Scratch.
The arm `"kimi" => Kimi(grant, flag)` is already in `Fragments`. Cyclomatic complexity <= 4. The test is ConfinementPlannerTests.ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb (and the matrix's Admit runs before Plan, so `web` never reaches this method).
