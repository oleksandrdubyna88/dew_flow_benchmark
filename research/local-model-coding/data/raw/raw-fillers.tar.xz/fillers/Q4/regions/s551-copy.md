# Region s551-copy (test) — src_mcp/tests/AKimiConsultantCheckTests.cs

Helpers already in the class (the skeleton, filled by their own regions): `Settings(string homesRoot)`, `CheckAsync(PanelSettings, PlayedKimi, CancellationToken) => (int Code, JsonElement Said)`, `PlayedThatReadsTheMarker()`, `After(ProcessRequest, string flag)`, `RecordingTheDeleter()`, `TheDeleterNeverMetTheJunction()`, `TheOneShotFolderIsGone()`; fields `_person` (KimiFixture), `_homes`, `_data`, `_temp` (TempDir), `_warned`, `_unlinkedByTheDeleter`.

## Existing APIs (copied from the repository)

namespace CoaiMcp.Tests (src_mcp/tests/, all `internal` or `public` in the test assembly):

```csharp
// TempDir.cs
public sealed class TempDir : IDisposable {
    public string Path { get; }
    public static TempDir For(string prefix);                    // Directory.CreateTempSubdirectory(prefix)
    public static implicit operator string(TempDir directory);   // passes as a path
    public string At(params string[] parts);                     // Path.Combine(Path, parts)
    public void Dispose();
}
// KimiFixture.cs  (a fake person: a sign-in, a config; NEVER the developer's real ~/.kimi-code)
public sealed class KimiFixture : IDisposable {
    public KimiFixture(string? config = null);
    public string Folder { get; }  public string PersonsHome { get; }  public string Credentials { get; }  public string PersonsConfig { get; }
    public KimiPlaces PlacesAt(string ownedRoot);                // pass as the Kimi seam: _person.PlacesAt
    public IReadOnlyList<string> Hash();                         // every entry of the person's folder: path, attributes, SHA-256 — unchanged = whole
    public void Dispose();
}
// WindowsStandIn.cs
internal static class WindowsStandIn { public static IDisposable Begin(); }   // nothing on Windows; a symlink stand-in for a junction elsewhere
// PlayedKimi.cs  (the shim played in process; git etc. run for real through `inner`)
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher {
    public const string Shim = "played-coai-mcp";  public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                // every shim launch, in order
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }   // what the n-th shim launch prints; default = an answered turn
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }  // runs while a shim is "alive"
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Lost(string session);            // exit 70, end session_lost
}
```

namespace CoaiMcp.Runners.Processes (src_mcp/runners/Processes/ProcessLauncher.cs):

```csharp
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) {
    public IReadOnlyDictionary<string, string?> Environment { get; init; }
    public string StdIn { get; init; }   // the prompt rides here for some runtimes
    public bool InheritsEnvironment { get; init; }
}
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed class ProcessLauncher : IProcessLauncher { }       // the real one: `new ProcessLauncher()`
```

The Kimi shim's argv (KimiRuntime.Arguments) holds literal pairs: `"--cwd", <cwd>`, `"--home", <home>`, `"--model", <m>` and, only on a continued turn, `"--session", <id>`
(AcpWords.HomeFlag = "--home", AcpWords.SessionFlag = "--session", namespace CoaiMcp.Runners.Acp).

Seams for a Kimi adapter built BY NAME (as the check and the service build it), per async flow, set SYNCHRONOUSLY in the test (not inside an awaited helper that returns):

```csharp
// namespace CoaiMcp.Runners.Kimi
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
internal static IDisposable KimiSeams.Using(HostKind host, KimiSeams seams);          // HostKind is CoaiMcp.Runners.Platform.HostKind (use HostKind.Windows)
public static IDisposable KimiCredentialsLock.RootFor(string folder);                  // the lock root of this flow
```

Deleter recorders (static, so the test class carries [Collection("fakecli-env")] and clears them in Dispose):

```csharp
// namespace CoaiMcp.Runners.Files
internal static Action<string>? GitScratch.AfterUnlink { get; set; }     // invoked by the DELETER when it unlinks a link: junction-first disposal must never invoke it
// namespace CoaiMcp.Runners.Kimi
internal static Action<string>? KimiHome.AfterUnlink { get; set; }
// namespace CoaiMcp.Runners.Vibe
public const string VibeHomes.OneShotFolder = "coai-vh";               // <homesRoot>\coai-vh\<8 hex>\kh-<10 hex> is a one-shot Kimi home
```

Assertion style: FluentAssertions (`using FluentAssertions;`), `[Fact]` / `[Theory]` from xUnit v3 (`using Xunit;`), `TestContext.Current.CancellationToken`.


## The check

```csharp
// namespace CoaiMcp.Server  (src_mcp/src/Server/Consultation/ConsultantCheckMode.cs) — internal, visible to the tests
internal static async Task<(int Code, string Out, string Err)> ConsultantCheckMode.AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct);
// args: ["--check-consultant", "--caller", "claude"]; Out is the JSON the check prints (empty when none); Noticing.None is the no-op notifier.
// ConsultantCheck.OwnName = "own": the check's scratch is <tempRoot>/coai-check-*/ with own/tree (the COPY of the scratch repository) and, rootless, own/kh-<10 hex> (the home).
// ConsultCheckStates (public static class, CoaiMcp.Server): Answered = "answered", Failed = "failed", Unavailable, ... NotAttempted = "not-attempted" (the canary property).

// namespace CoaiMcp.Server (src_mcp/src/Server/PanelSettings.cs) — init-only properties used by the existing check tests:
public sealed record PanelSettings { IReadOnlyList<...> Providers; string DataDir; TimeSpan ReviewerTimeout; bool ConsultEnabled; string ConsultantHomesRoot;
    IReadOnlyDictionary<string, ConsultantChoice> Consultants; ... }
public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "");
public readonly record struct CallerIdentity(...)  // CallerIdentity.Claude is the string "claude": the caller's key in Consultants
```

How the existing Vibe check test builds its settings and reads the reply (src_mcp/tests/ConsultantCheckTests.cs):

```csharp
private PanelSettings Settings(string runtime = "codex", TimeSpan? timeout = null, bool enabled = true) => new()
{
    Providers = [], DataDir = _data, ReviewerTimeout = timeout ?? TimeSpan.FromSeconds(60), ConsultEnabled = enabled,
    Consultants = new Dictionary<string, ConsultantChoice> { [CallerIdentity.Claude] = new(runtime, Runtime: runtime, ExecutablePath: FakeCliExe) },
};
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);
    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
// the Vibe test: AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT";
//   code.Should().Be(0); said.GetProperty("state").GetString() == "answered"; said.GetProperty("markerRead").GetBoolean().Should().BeTrue();
//   Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
```

The answer the check wants (ConsultantCheck.cs:114-117): two lines, `marker: <the word from CHECK.md>` and `canary: <the word from the outside file, or CANNOT>`.
CHECK.md is at the root of the scratch repository; the played shim sees the COPY of it in the folder after `--cwd`.
The fixed-up usings in AKimiConsultantCheckTests.cs: System.Text.Json; CoaiMcp.Runners.Acp; .Files; .Kimi; .Platform; .Processes; .Vibe; CoaiMcp.Server; FluentAssertions; Xunit.


## A short similar existing test (src_mcp/tests/AOneShotKimiHomeIsDisposedJunctionFirstTests.cs)

```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) =>
    _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
private void TheDeleterNeverMetTheJunction() =>
    _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
[Fact]
public void AOneShotHome_IsDisposedJunctionFirst_UnderItsLock()
{
    using var standIn = WindowsStandIn.Begin();
    var home = Reserved();                       // a OneShotHome under <root>\coai-vh\<8>
    MadeHomeIn(home.Folder);
    var before = _person.Hash();
    RecordingTheDeleter();
    home.Dispose();
    Directory.Exists(home.Folder).Should().BeFalse("the owner takes its folder whole when it ends");
    TheDeleterNeverMetTheJunction();
    ThePersonsFolderIsWhole(before);
}
```

