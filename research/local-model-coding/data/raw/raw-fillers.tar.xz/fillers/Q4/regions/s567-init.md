# Region s567-init (test) — src_mcp/tests/AKimiQuestionRowTests.cs

Fields already in the class: `_launcher` (ProcessLauncher), `_person` (KimiFixture), `_dir` (TempDir), `_unlinkedByTheDeleter` (List<string>), `Repo` (=_dir.At("repo")), `Homes` (=_dir.At("homes")), const `Advice`; helpers `Service(PlayedKimi, params string[] roots)`, `StandIn()` (an IDisposable: the fake person, the measured host, the lock root — keep it alive for the whole test, `using var`), `AskAsync(PanelService, CancellationToken)`.

## Existing APIs (copied from the repository)

namespace CoaiMcp.Tests (src_mcp/tests/, all `internal` or `public` in the test assembly):

```csharp
// TempDir.cs
public sealed class TempDir : IDisposable {
    public string Path { get; }
    public static TempDir For(string prefix);                    // Directory.CreateTempSubdirectory(prefix)
    public static implicit operator string(TempDir directory);   // passes as a path
    public string At(params string[] parts);                     // Path.Combine(Path, parts)
    public void Dispose();
}
// KimiFixture.cs  (a fake person: a sign-in, a config; NEVER the developer's real ~/.kimi-code)
public sealed class KimiFixture : IDisposable {
    public KimiFixture(string? config = null);
    public string Folder { get; }  public string PersonsHome { get; }  public string Credentials { get; }  public string PersonsConfig { get; }
    public KimiPlaces PlacesAt(string ownedRoot);                // pass as the Kimi seam: _person.PlacesAt
    public IReadOnlyList<string> Hash();                         // every entry of the person's folder: path, attributes, SHA-256 — unchanged = whole
    public void Dispose();
}
// WindowsStandIn.cs
internal static class WindowsStandIn { public static IDisposable Begin(); }   // nothing on Windows; a symlink stand-in for a junction elsewhere
// PlayedKimi.cs  (the shim played in process; git etc. run for real through `inner`)
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher {
    public const string Shim = "played-coai-mcp";  public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                // every shim launch, in order
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }   // what the n-th shim launch prints; default = an answered turn
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }  // runs while a shim is "alive"
    public static string SessionOf(ProcessRequest request);
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
    public static ProcessResult Lost(string session);            // exit 70, end session_lost
}
```

namespace CoaiMcp.Runners.Processes (src_mcp/runners/Processes/ProcessLauncher.cs):

```csharp
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) {
    public IReadOnlyDictionary<string, string?> Environment { get; init; }
    public string StdIn { get; init; }   // the prompt rides here for some runtimes
    public bool InheritsEnvironment { get; init; }
}
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed class ProcessLauncher : IProcessLauncher { }       // the real one: `new ProcessLauncher()`
```

The Kimi shim's argv (KimiRuntime.Arguments) holds literal pairs: `"--cwd", <cwd>`, `"--home", <home>`, `"--model", <m>` and, only on a continued turn, `"--session", <id>`
(AcpWords.HomeFlag = "--home", AcpWords.SessionFlag = "--session", namespace CoaiMcp.Runners.Acp).

Seams for a Kimi adapter built BY NAME (as the check and the service build it), per async flow, set SYNCHRONOUSLY in the test (not inside an awaited helper that returns):

```csharp
// namespace CoaiMcp.Runners.Kimi
public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim);
internal static IDisposable KimiSeams.Using(HostKind host, KimiSeams seams);          // HostKind is CoaiMcp.Runners.Platform.HostKind (use HostKind.Windows)
public static IDisposable KimiCredentialsLock.RootFor(string folder);                  // the lock root of this flow
```

Deleter recorders (static, so the test class carries [Collection("fakecli-env")] and clears them in Dispose):

```csharp
// namespace CoaiMcp.Runners.Files
internal static Action<string>? GitScratch.AfterUnlink { get; set; }     // invoked by the DELETER when it unlinks a link: junction-first disposal must never invoke it
// namespace CoaiMcp.Runners.Kimi
internal static Action<string>? KimiHome.AfterUnlink { get; set; }
// namespace CoaiMcp.Runners.Vibe
public const string VibeHomes.OneShotFolder = "coai-vh";               // <homesRoot>\coai-vh\<8 hex>\kh-<10 hex> is a one-shot Kimi home
```

Assertion style: FluentAssertions (`using FluentAssertions;`), `[Fact]` / `[Theory]` from xUnit v3 (`using Xunit;`), `TestContext.Current.CancellationToken`.


## The question row flow

```csharp
// namespace CoaiMcp.Server
public PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing);
public Task<string> PanelService.AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default);
// VaultKeys.None("no vault in tests"); Serilog.Core.Logger.None; Noticing.None.
// namespace CoaiMcp.Core.QuestionConsult
public sealed record QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "");
public sealed record QuestionConsultSettings { IReadOnlyList<QuestionRow> Rows; IReadOnlyList<string> Roots; TimeSpan RowBudget; ... }   // init-only
public static class RowOutcomes { public const string Answered = "answered"; ... }
// namespace CoaiMcp.Core.Rounds: PanelConfig.Uniform(3, 2, StagePolicy.Human)
```

The existing Vibe test builds its service (src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs) — copy its shape, with the Kimi row and homes root:

```csharp
private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot, Providers = [], Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"), ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots, RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"), default, vibe, Logger.None, Noticing.None);
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
    JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;
private static JsonElement TheRow(JsonElement reply)
{
    reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
    return answers.EnumerateArray().Should().ContainSingle().Subject;     // then .GetProperty("status").GetString()
}
// the repository (InitializeAsync):
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files) { var full = Path.Combine([at, .. path.Split('/')]); Directory.CreateDirectory(Path.GetDirectoryName(full)!); await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken); }
    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}
// a Vibe test's assertions: var turn = vibe.Turns.Should().ContainSingle().Subject;
//   turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy"); turn.Request.StdIn.Should().NotContain(granted);
//   Directory.Exists(RowFolderOf(turn.Request)).Should().BeFalse("the row's home and copy are gone once it answered");
```

For the Kimi row the shim request is `played.Shims.Single().Request`; its prompt: check BOTH `request.StdIn` and the arguments (the shim takes the prompt on stdin or in argv — assert on the one that is non-empty / search `string.Join("\n", request.Arguments) + request.StdIn`).
The row's scratch is a `coai-question-*` folder under the temp folder; its home is the folder after "--home" (`<homes>/coai-vh/<8>/kh-<10 hex>`).
The row's launch is refused BEFORE any launch when the fake person has no credentials folder (`Directory.Delete(_person.Credentials, true)`): KimiLaunch says "has no credentials folder; run `kimi login`" — the shim is never started (played.Shims is empty).


## A short similar existing test (src_mcp/tests/AOneShotKimiHomeIsDisposedJunctionFirstTests.cs)

```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
private void ThePersonsFolderIsWhole(IReadOnlyList<string> before) =>
    _person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
private void TheDeleterNeverMetTheJunction() =>
    _unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
[Fact]
public void AOneShotHome_IsDisposedJunctionFirst_UnderItsLock()
{
    using var standIn = WindowsStandIn.Begin();
    var home = Reserved();                       // a OneShotHome under <root>\coai-vh\<8>
    MadeHomeIn(home.Folder);
    var before = _person.Hash();
    RecordingTheDeleter();
    home.Dispose();
    Directory.Exists(home.Folder).Should().BeFalse("the owner takes its folder whole when it ends");
    TheDeleterNeverMetTheJunction();
    ThePersonsFolderIsWhole(before);
}
```

