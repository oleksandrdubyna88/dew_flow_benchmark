# Region s56-noflags (prod) — src_mcp/runners/Kimi/KimiConsultant.cs, method `MustCarryNoFlag`

Fill `private static void MustCarryNoFlag(ConsultantLaunch launch)`. It is called by `Build` only when `launch.Confinement is LaunchConfinement.Planned`.

```csharp
// namespace CoaiMcp.Runners.Consultation
public abstract record LaunchConfinement {
    public sealed record Shipped : LaunchConfinement;
    public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement;
}
public sealed record ConsultantLaunch(string RepoPath, string Prompt, string Handle, string OutputDir, ReviewerSettings Settings, string AnswerSchemaFile = "")
    { public LaunchConfinement Confinement { get; init; } ... }
// namespace CoaiMcp.Core.QuestionConsult
public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag)
```

Other guards in the same file are written like this (the sentence style to match):

```csharp
private static string OwnedFolder(ConsultantLaunch launch) =>
    launch.Settings.OwnedScratch.Length > 0
        ? launch.Settings.OwnedScratch
        : throw new ArgumentException("a Kimi consultant keeps its home in a coai-owned folder of the conversation or the row (OwnedScratch), and none was given — never TEMP or the answers folder (D19)", nameof(launch));
```

Body: if `launch.Confinement is LaunchConfinement.Planned { Plan: var plan }` and `plan.Flags.Count + plan.Leading.Count + plan.AddDirs.Count > 0`, throw
`new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch))`; else do nothing. The test is
ConfinementPlannerTests.APlanWithFlags_IsRefusedForKimi (E5.6 decision 3; message must contain "shim"). Cyclomatic complexity <= 4.
