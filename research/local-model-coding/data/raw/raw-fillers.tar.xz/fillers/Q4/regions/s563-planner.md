# Region s563-planner (test) — src_mcp/tests/ConfinementPlannerTests.cs, `ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb`

Fields/helpers of the class (already there):

```csharp
private const string RootA = "D:/projects/alpha";   // RootB likewise
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
// CapabilityGrant.None, CapabilityGrant.Web, CapabilityGrant.Disk(params string[] roots)
// Confinement.Planned: Leading, Flags, AddDirs (IReadOnlyList<string>), Cwd (CwdKind: Scratch, Root, Snapshot), SnapshotSources, Flag (AdmissionFlag)
// Confinement.Refused(string Reason)
```

The Vibe test just above it, the shape to follow:

```csharp
var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: ...");
disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given one (D3)");
disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
```
and the refusal check: `ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>().Which.Reason.Should().Contain("not been measured")`.
For kimi the `web` sentence must also contain `RESULTS_kimi_confinement.md` (the record CapabilityMatrix.RecordOf reads off the row's resultRef). The Admission flag on both planned rows is `AdmissionFlag.Unconfined` (assert `none.Flag`/`disk.Flag`).
