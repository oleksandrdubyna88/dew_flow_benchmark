You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s565-launch — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
See regions/s565-launch.md. Build the consultant with KimiConsultantOf() (the fake-person helper below), then Build(Planned("kimi", ...)).

## The exact existing types and members you may use (context pack)
# Context shared by every region (copied from the repository at commit e50f3023)

Language: C# 14 / .NET 10, xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`, `TestContext.Current.CancellationToken`), FluentAssertions
(`using FluentAssertions;`). Tests live in `namespace CoaiMcp.Tests;` (file-scoped). The test project can see `internal` members of the product.
Style: no comment noise; one `using` list; `.Should().Be(x, "why")` with a reason. A test never runs a real `kimi` and never makes a junction outside
its own `testsToDelete-` folder. Everything a test makes outside its process is under `TempDir.For("testsToDelete-<what>-")`.

## Test helpers that exist (namespace `CoaiMcp.Tests`)

```csharp
public sealed class TempDir : IDisposable
{
    public string Path { get; }
    public static TempDir For(string prefix);              // a fresh folder under TEMP
    public static implicit operator string(TempDir directory); // -> Path
    public string At(params string[] parts);               // Path.Combine(Path, parts)
    public void Dispose();
}

// A fake person's Kimi sign-in. Folder = a testsToDelete-kimi-* folder holding everything.
public sealed class KimiFixture : IDisposable
{
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";
    public string Folder { get; }            // the folder every part of the fixture lives in
    public string PersonsHome { get; }       // the fake person's ~/.kimi-code
    public string Credentials { get; }       // PersonsHome\credentials
    public KimiPlaces PlacesAt(string ownedRoot);          // places for an owned root ANYWHERE (what KimiSeams.PlacesFor takes)
    public IReadOnlyList<string> Hash();                   // names, bytes and read-only bits of the person's folder; compare before/after
    public void Dispose();
}

// Per-flow stand-ins for a scenario driving the REAL service/check over a Kimi row (new, in src_mcp/tests/KimiScenarioScopes.cs):
internal static class KimiScenarioScopes
{
    // The measured host (Windows) + fake person + lock root + the played shim's name. Call it SYNCHRONOUSLY and `using` it, so it reaches the test's flow.
    public static IDisposable StandIn(KimiFixture person);
}

// Kimi as a scenario plays it, in process (src_mcp/tests/PlayedKimi.cs). `kimi --version` answers "kimi 2.1.1"; every launch of the shim
// (Executable == PlayedKimi.Shim) is answered with a report; every other process (git) runs for real through `inner`.
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";   // the session id the played agent mints on a first turn
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                           // one per shim launch, enqueued when it ENDS
    public ConcurrentQueue<ProcessRequest> Versions { get; }                // the `--version` launches
    public int Peak { get; }
    // What the n-th shim launch (0-based) prints. Default: an answered turn (Answered(SessionOf(request), 19973, 31)).
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }
    // Runs while a shim is "alive", after its start is stamped; a test's seam to block or to cancel.
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }
    public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default);
    public static string SessionOf(ProcessRequest request);                 // the id after --session, else Minted
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice); // exit 0
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                       // end session_lost, exit 70
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
// Create it as `new PlayedKimi(new ProcessLauncher())` (ProcessLauncher is the real one, namespace CoaiMcp.Runners.Processes).
// A failing turn for S5.5.2's second arm: `Turn = (_, request) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.

// Shim reports the shim's own writer prints (src_mcp/tests/KimiShimScripts.cs):
internal static class KimiShimScripts
{
    public static string Report(AcpEnd end = AcpEnd.Answered, string answer = CleanReview, string reason = "", string failure = "", bool tokens = true,
        IReadOnlyList<AcpReadRecord>? reads = null, IReadOnlyList<AcpToolCall>? calls = null, string session = "session-1", long tokensIn = 19973, long tokensOut = 31);
}

// Product types the tests use (namespaces: CoaiMcp.Runners.Processes, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Files, CoaiMcp.Runners.Vibe, CoaiMcp.Server, CoaiMcp.Core.QuestionConsult):
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { /* + StdIn, Environment, InheritsEnvironment, Passthrough ... */ }
public static class GitScratch   { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after the GENERIC DELETER unlinks a link
public static class KimiHome     { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after KimiHome unlinks the junction (it does, by design)
public static class VibeHomes    { public const string OneShotFolder = "coai-vh"; /* one-shot homes live at <root>\coai-vh\<8 hex>\ */ }
```

The shim's argv (built by `KimiRuntime.Build`) holds, in order: `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <home> ...`; read a value with
`request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1]` or assert `Arguments.Should().ContainInConsecutiveOrder("--home", home)`.
A Kimi one-shot or conversation home is `<owned folder>\kh-<10 hex>` (a folder named `kh-` + 10 lower-case hex digits) — never the owned folder itself.

The recorder pattern for "disposed junction-first" (from `AOneShotKimiHomeIsDisposedJunctionFirstTests`): the test class keeps
`private readonly List<string> _unlinkedByTheDeleter = [];`, arms `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` before the act, resets
`GitScratch.AfterUnlink = null;` in `Dispose()`, and asserts
`_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");`
and the fake person's folder whole: `var before = person.Hash(); ... person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");`
# Region s565-launch (test) — `ConfinementPlannerTests.AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome` (S5.6.5), file `src_mcp/tests/ConfinementPlannerTests.cs`

Usings in the file: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit`. Other types are spelled with the `Runners.` prefix (the file's namespace is `CoaiMcp.Tests`), e.g. `Runners.Kimi.KimiEnvironment`.

Helpers already in the class (static fields are unique per run):

```csharp
private static readonly string Scratch   = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree   = Path.Combine(RowFolder, "tree");
private const string RootA = "D:/projects/alpha";  private const string RootB = "D:/projects/beta";
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
    Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
{ Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)), ScratchDir = Scratch, Workdir = RowTree };
// and the new helper right above this region's test:
private static Runners.Kimi.KimiConsultant KimiConsultantOf();   // a Kimi consultant over a fake person's paths (reads nothing of this machine)
```

Existing signatures:

```csharp
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime { public ReviewerInvocation Build(ConsultantLaunch launch); }  // CoaiMcp.Runners.Kimi
public sealed record ReviewerInvocation { public ProcessRequest Request { get; init; } public string Role { get; init; } /* ... */ }              // Build(...).Request, .Role
public static class KimiEnvironment { public static string Refusal(ProcessRequest request, KimiPlaces places); }                                  // empty when the environment is admitted
public sealed record KimiPlaces { /* from KimiPlaces.ForShim(ownedRoot, personsBin) */ }
public static class ConsultantRoles { public const string Consult = "consult"; public const string Question = "question"; }                       // CoaiMcp.Runners.Consultation
```

With `Build(Planned("kimi", grant))` the argv is: `--ask-acp --profile kimi --model <default model> --cwd <cwd> --home <home> ...`; `<home>` = `<RowFolder>\kh-<10 hex>`; no `--session` on a planned (one-shot) launch.
`request.InheritsEnvironment` is false. `built.Role` is `ConsultantRoles.Question`.
`KimiEnvironment.Refusal(request, places)` needs the `KimiPlaces` the consultant was built over: build the same places in the test with
`Runners.Kimi.KimiPlaces.ForShim(RowFolder + <home folder name>?)` — NOTE: `Refusal` is only meaningful with the real places of the launch; if it is awkward to get them here, assert the other points
and leave a one-line comment that the environment check is S5.4.2's. Do not invent a `KimiPlaces` constructor.

Similar existing test (Vibe, same file) — copy its shape:

```csharp
var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
none.Role.Should().Be(ConsultantRoles.Question);
var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
disk.Request.WorkingDirectory.Should().Be(RowTree, "...");
disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "...");
foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
{
    request.InheritsEnvironment.Should().BeFalse();
    request.Environment[...HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "the row's home lives in the row's own folder, gone with it");
}
```

Body to write (Kimi): `var consultant = KimiConsultantOf();` build `none` and `disk`. none: `WorkingDirectory == Scratch`; disk: `WorkingDirectory == RowTree`. For both: `--home` value (the argument after `"--home"`) starts with
`RowFolder + Path.DirectorySeparatorChar` and its file name starts with `"kh-"`; `Arguments` do not contain `"--session"`, `RootA`, `RootB`; `InheritsEnvironment` false; `Role` is `ConsultantRoles.Question`.
Red against a stub that ignores the plan: *Expected Request.WorkingDirectory to be "<Scratch>", but found ...*.


## The whole file (the region is marked with <<<)
```csharp
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Runners.Consultation;
using CoaiMcp.Runners.Reviewers;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// The confinement planner is the ONE place a question row's sandbox flags are decided, and every
/// adapter composes them rather than choosing its own (PLAN_question_consultant.md, D4; S1 acceptance 2).
/// </summary>
/// <remarks>
/// <para>Every fragment below is a fact from the probe run of 2026-10-01 (F1–F7 of the plan, cited by
/// row in <c>shared/runtime-capabilities.json</c>): claude's <c>--tools</c> allow-list and
/// <c>--restricted</c>, codex's top-level <c>--search</c>, agy's <c>--mode plan</c>. The goldens are
/// asserted as WHOLE argv lists, so an adapter that adds a sandbox flag of its own — or drops one the
/// planner gave it — fails here rather than reading past its roots with nothing in the output to say so.</para>
/// <para><c>--disallowedTools</c> appears in no plan and no planned launch: the shipped deny lists are
/// offered the user environment's whole tool set and leaked the canary 6 of 6 (F5).</para>
/// </remarks>
public sealed class ConfinementPlannerTests
{
    private const string RootA = "D:/projects/alpha";
    private const string RootB = "D:/projects/beta";

    private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;

    // ---------- the planner's fragments, per runtime × capability ----------

    [Fact]
    public void Claude_None_OffersNoToolAtAll_InAScratchCwd()
    {
        var plan = Plan("claude", CapabilityGrant.None);

        plan.Leading.Should().BeEmpty();
        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "");
        plan.Cwd.Should().Be(CwdKind.Scratch);
        plan.AddDirs.Should().BeEmpty();
        plan.Flag.Should().Be(AdmissionFlag.None);
    }

    [Fact]
    public void Claude_Disk_IsRestricted_WithTheThreeReadTools_AndEveryRootAdded()
    {
        var plan = Plan("claude", CapabilityGrant.Disk(RootA, RootB));

        plan.Flags.Should().Equal(
            "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB);
        plan.Cwd.Should().Be(CwdKind.Root, "the first root is the working directory (F4: --restricted confines to the working directories)");
        plan.AddDirs.Should().Equal(RootA, RootB);
        plan.Flags.Should().NotContain("Bash").And.NotContain("PowerShell", "no shell tool is offered to a disk row");
    }

    [Fact]
    public void Claude_Web_OffersTheTwoWebTools_AndNoDirectory()
    {
        var plan = Plan("claude", CapabilityGrant.Web);

        plan.Flags.Should().Equal("--permission-mode", "plan", "--tools", "WebSearch,WebFetch");
        plan.Flags.Should().NotContain("--add-dir", "a web row has no directory to read (A2)");
        plan.Flags.Should().NotContain("--restricted", "nothing file-capable is offered, so there is nothing to restrict");
        plan.Cwd.Should().Be(CwdKind.Scratch);
    }

    [Fact]
    public void Codex_EveryCapability_IsReadOnlyEphemeral_AndFlaggedUnconfined()
    {
        var none = Plan("codex", CapabilityGrant.None);
        none.Leading.Should().BeEmpty();
        none.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        none.Cwd.Should().Be(CwdKind.Scratch);

        var disk = Plan("codex", CapabilityGrant.Disk(RootA));
        disk.Flags.Should().Equal("-s", "read-only", "--ephemeral", "-C", RootA);
        disk.Cwd.Should().Be(CwdKind.Root);

        var web = Plan("codex", CapabilityGrant.Web);
        // The expectation is an ARRAY: `Equal("--search", "because…")` would assert the reason as a
        // second expected item — the trap ConsultantArgvTests already names.
        web.Leading.Should().Equal(["--search"], "F1: `--search` is a TOP-LEVEL flag; `codex exec --search` is a usage error (exit 2)");
        web.Flags.Should().Equal("-s", "read-only", "--ephemeral");
        web.Cwd.Should().Be(CwdKind.Scratch);

        foreach (var plan in (Confinement.Planned[])[none, disk, web])
        {
            plan.Flag.Should().Be(AdmissionFlag.Unconfined, "F2: codex reads anywhere and no flag removes the shell (D13)");
        }
    }

    [Fact]
    public void Antigravity_None_IsPlanMode_AndDisk_AddsTheRoots_BothFlaggedDefaultDeny()
    {
        var none = Plan("antigravity", CapabilityGrant.None);
        none.Flags.Should().Equal("--mode", "plan");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.Flag.Should().Be(AdmissionFlag.DefaultDeny);

        var disk = Plan("antigravity", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--mode", "plan", "--add-dir", RootA, "--add-dir", RootB);
        disk.Cwd.Should().Be(CwdKind.Root);
        disk.Flag.Should().Be(AdmissionFlag.DefaultDeny, "F7: held by the headless default alone");
    }

    [Fact]
    public void LocalAndApi_None_HaveNoFlagToSend_AndAScratchCwd()
    {
        foreach (var runtime in (string[])["local", "api"])
        {
            var plan = Plan(runtime, CapabilityGrant.None);

            plan.Leading.Should().BeEmpty(runtime);
            plan.Flags.Should().BeEmpty($"{runtime}: a completion has no sandbox flag — it has no tools");
            plan.Cwd.Should().Be(CwdKind.Scratch, runtime);
            plan.Flag.Should().Be(AdmissionFlag.None, runtime);
        }
    }

    /// <summary>
    /// Vibe (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): D2's two flags, both, on every capability — and no
    /// <c>--trust</c> or <c>--add-dir</c> ever (D3). A none row stands in an EMPTY scratch folder; a disk row stands in a
    /// SNAPSHOT of its roots (D6), because Vibe reads only its working folder (M-V11) — so its roots are never its cwd.
    /// </summary>
    [Fact]
    public void Vibe_None_StandsInAnEmptyScratch_AndDisk_InTheSnapshotOfItsRoots_ReadOnlyBothTimes()
    {
        var none = Plan("vibe", CapabilityGrant.None);
        none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        none.Cwd.Should().Be(CwdKind.Scratch);
        none.AddDirs.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.None);

        var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
        disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
        disk.Cwd.Should().Be(CwdKind.Snapshot, "M-V11: Vibe cannot read outside its cwd, and its cwd is never the checkout (D6)");
        disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        none.SnapshotSources.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.None);
        disk.Flags.Concat(disk.Leading).Should().NotContain(["--trust", "--add-dir"], "D3: a trusted folder runs its hooks");
        ConfinementPlanner.VibeReadOnly.Should().Equal(disk.Flags, "the reviewer and the planner spell D2 once");
    }

    /// <summary>
    /// Kimi (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>): NO flags, ever — its confinement is the shim's (D15), not its argv. A none row
    /// stands in an EMPTY scratch folder; a disk row stands in a SNAPSHOT of its roots (D6); a web row is refused (no cell measured it).
    /// </summary>
    [Fact]
    public void ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb()
    {
        // QWEN-FILL-BEGIN s563-plan test
        // See regions/s563-plan.md. Use the helper Plan("kimi", grant) for CapabilityGrant.None and CapabilityGrant.Disk(RootA, RootB);
        // assert Cwd (Scratch / Snapshot), Leading, Flags and AddDirs empty, SnapshotSources (empty / [RootA, RootB]).
        // For CapabilityGrant.Web: ConfinementPlanner.Plan("kimi", CapabilityGrant.Web) is a Confinement.Refused whose Reason contains
        // "not been measured" and "RESULTS_kimi_confinement.md". Fails before the change: the default arm gives Scratch for disk.
        throw new NotImplementedException("s563-plan");
        // QWEN-FILL-END s563-plan
    }

    // ---------- refusals ----------

    [Theory]
    [InlineData("antigravity", Capability.Web, "cannot fetch a page headless")]
    [InlineData("api", Capability.Disk, "cannot do 'disk'")]
    [InlineData("api", Capability.Web, "not been measured")]
    [InlineData("local", Capability.Disk, "cannot do 'disk'")]
    [InlineData("local", Capability.Web, "cannot do 'web'")]
    [InlineData("vibe", Capability.Web, "not been measured")]
    public void APairTheMatrixRefuses_IsRefusedByThePlannerToo_WithTheMatrixsOwnSentence(string runtime, Capability capability, string says)
    {
        var grant = capability == Capability.Disk ? CapabilityGrant.Disk(RootA) : new CapabilityGrant(capability, []);

        ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain(says, "the planner asks the matrix first and never re-decides it");
    }

    [Fact]
    public void AnUnknownRuntime_IsRefused_NamingTheOnesItKnows()
    {
        ConfinementPlanner.Plan("gemini", CapabilityGrant.None).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("gemini").And.Contain("claude, codex, antigravity, local, api, vibe");
    }

    [Fact]
    public void ADiskGrantWithNoRoot_IsRefused_AndARootOnANoneOrWebGrant_IsRefused()
    {
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Disk, [])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("at least one root", "a disk row with nowhere to read would read its cwd — which is nowhere");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.None, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a root on a none row is a leak path");
        ConfinementPlanner.Plan("claude", new CapabilityGrant(Capability.Web, [RootA])).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("carries no roots", "a web row is given the question and nothing of this machine (A2)");
    }

    [Theory]
    [InlineData("projects/alpha")]
    [InlineData("./alpha")]
    [InlineData("")]
    [InlineData("  ")]
    public void ARootThatIsNotAnAbsolutePath_IsRefused(string root)
    {
        ConfinementPlanner.Plan("claude", CapabilityGrant.Disk(root)).Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("absolute", "a relative root resolves against whatever the cwd happens to be");
    }

    [Fact]
    public void DisallowedTools_AppearsInNoPlan()
    {
        // F3/F5: the shipped deny lists leaked the canary 6 of 6 through PowerShell, which no deny
        // list names. A question row is confined by an ALLOW list or by `--restricted`, never by naming
        // what it may not do.
        foreach (var runtime in RuntimeCapabilities.Runtimes)
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is Confinement.Planned plan)
                {
                    plan.Flags.Concat(plan.Leading).Should().NotContain(ConfinementPlanner.NeverSent, $"{runtime} × {grant.Capability}");
                }
            }
        }
    }

    // ---------- the adapters compose the plan and nothing of their own ----------

    private static readonly string Scratch = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));

    private static readonly string Answers = Path.Combine(Path.GetTempPath(), "coai-answers-" + Guid.NewGuid().ToString("N"));

    private const string Repo = "D:/rsd/some-checkout";

    /// <summary>The row's own folder and its copy of the roots — what the row launch makes for a runtime that asks (S3); ignored by the rest.</summary>
    private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));

    private static readonly string RowTree = Path.Combine(RowFolder, "tree");

    private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(
        Repo, "the question", string.Empty, Answers, new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    {
        Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)),
        ScratchDir = Scratch,
        Workdir = RowTree,
    };

    [Fact]
    public void AClaudeQuestionLaunch_IsTheBaseAndThePlan_AndNothingElse()
    {
        var none = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.None, "sonnet"));
        none.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "", NoMcpServers.ClaudeFlag, "--model", "sonnet");
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty directory, never the checkout");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--restricted", "--tools", "Read,Glob,Grep",
            "--add-dir", RootA, "--add-dir", RootB, NoMcpServers.ClaudeFlag);
        disk.Request.WorkingDirectory.Should().Be(RootA);

        var web = new ClaudeConsultant(new ClaudeRuntime()).Build(Planned("claude", CapabilityGrant.Web));
        web.Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan", "--tools", "WebSearch,WebFetch", NoMcpServers.ClaudeFlag);
        web.Request.Arguments.Should().NotContain("--add-dir").And.NotContain(Repo, "a web row sees nothing of the checkout");
        web.Request.WorkingDirectory.Should().Be(Scratch);
    }

    [Fact]
    public void ACodexQuestionLaunch_PutsSearchBeforeExec_AndStaysEphemeral()
    {
        var web = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Web, "gpt-6-astra"));
        var args = web.Request.Arguments.ToList();
        var output = args[args.IndexOf("-o") + 1];

        args.Should().Equal(
            "--search", "exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check", "--color", "never",
            // The row's fast mode, Off by default (research/PLAN_fast_mode.md), before the instructions on stdin.
            "--json", "-o", output, "-m", "gpt-6-astra", "-c", "service_tier=default", "-");
        Path.GetDirectoryName(Path.GetFullPath(output)).Should().Be(Path.GetFullPath(Answers));
        web.Request.WorkingDirectory.Should().Be(Scratch);

        var none = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.None));
        none.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "--skip-git-repo-check"])
            .And.NotContain("--search").And.NotContain("-C");

        var disk = new CodexConsultant(new CodexRuntime()).Build(Planned("codex", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().StartWith(["exec", "-s", "read-only", "--ephemeral", "-C", RootA]);
        disk.Request.WorkingDirectory.Should().Be(RootA);
    }

    [Fact]
    public void AnAgyQuestionLaunch_IsTheMeasuredStreamLaunch_WithThePlansFlags()
    {
        var none = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.None, "gemini-3.1-pro-high"));
        // Both run as the reader agent from the read-only folder, never from the root or the scratch directory
        // (research/PLAN_agy_cannot_write_its_roots.md); a disk row still reaches its root through the plan's --add-dir.
        none.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "gemini-3.1-pro-high");
        none.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
        none.Request.StdIn.Should().Contain("the question").And.StartWith("{", "the prompt rides the stream, serialised");

        var disk = new AntigravityConsultant(new AntigravityRuntime()).Build(Planned("antigravity", CapabilityGrant.Disk(RootA)));
        disk.Request.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--add-dir", RootA,
            "--agent", "coai-reader");
        disk.Request.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());
    }

    [Fact]
    public void ALocalQuestionLaunch_RunsTheShimInTheScratchDirectory()
    {
        Directory.CreateDirectory(Answers);
        var schema = Path.Combine(Answers, "schema.json");
        File.WriteAllText(schema, "{}");
        var launch = Planned("local", CapabilityGrant.None) with { AnswerSchemaFile = schema };

        var built = new LocalConsultant(new LocalRuntime("local", "http://127.0.0.1:11434/v1"), "local").Build(launch);

        built.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands nowhere near the checkout");
        built.Request.Arguments.Should().Contain("--ask-local");
        built.Role.Should().Be(ConsultantRoles.Question);
    }

    /// <summary>
    /// A Vibe question row (S3 of todo/PLAN_vibe_and_kimi_runtimes.md): the plan's read-only pair, a none row in its EMPTY
    /// scratch and a disk row in the copy of its roots — never a root, never the checkout — on the row's own home in the
    /// built environment: <c>VIBE_CLI=python</c> and the model in the EXPLICIT environment, which is all a question row's
    /// minimal child gets (M-V12, 3 of 3).
    /// </summary>
    [Fact]
    public void AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));

        var none = consultant.Build(Planned("vibe", CapabilityGrant.None, "glm-5-3"));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Request.Arguments.Should().ContainInConsecutiveOrder("--agent", "plan", "--enabled-tools", "read_file")
            .And.ContainInConsecutiveOrder("--workdir", Scratch)
            .And.NotContain("--trust").And.NotContain("--add-dir").And.NotContain("--resume", "one shot");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("vibe", CapabilityGrant.Disk(RootA, RootB), "glm-5-3"));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "M-V11: Vibe reads its cwd only — the copy of the roots (D6)");
        disk.Request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Vibe");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            request.InheritsEnvironment.Should().BeFalse();
            request.Passthrough.Should().BeEquivalentTo(Runners.Processes.ProcessEnvironment.Minimal, "the question row's road (ForQuestion)");
            request.Environment.Should().Contain(Runners.Vibe.VibeLaunch.CliVariable, "python").And.Contain(Runners.Vibe.VibeLaunch.ModelVariable, "glm-5-3");
            request.Environment[Runners.Vibe.VibeLaunch.HomeVariable].Should().StartWith(RowFolder + Path.DirectorySeparatorChar,
                "the row's home lives in the row's own folder, gone with it");
            Runners.Vibe.VibeLaunch.EnvironmentRefusal(request).Should().BeEmpty("the one launch control admits it (D17)");
        }
    }

    /// <summary>
    /// A Kimi question row (E5.6): the shim request, in the row's EMPTY folder (none) or in the copy of its roots (disk), on a home under the
    /// row's own folder, one shot (no <c>--session</c>), the roots never named, the built environment, no flag of the plan's.
    /// </summary>
    [Fact]
    public void AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome()
    {
        // QWEN-FILL-BEGIN s565-launch test   <<< REGION s565-launch STARTS AFTER THIS LINE
        // See regions/s565-launch.md. Build the consultant with KimiConsultantOf() (the fake-person helper below), then Build(Planned("kimi", ...)).
        throw new NotImplementedException("s565-launch");
        // QWEN-FILL-END s565-launch   <<< REGION s565-launch ENDS BEFORE THIS LINE
    }

    /// <summary>E5.6 decision 3: a plan that carries any flag is not one coai made for kimi — refused, naming the shim.</summary>
    [Fact]
    public void APlanWithFlags_IsRefusedForKimi()
    {
        // QWEN-FILL-BEGIN s566-flags test
        // See regions/s566-flags.md. Hand-made plan with a flag, Build must throw ArgumentException naming the shim.
        throw new NotImplementedException("s566-flags");
        // QWEN-FILL-END s566-flags
    }

    /// <summary>A Kimi consultant over a fake person's paths, so building reads nothing of this machine (the same one <c>Adapters()</c> holds).</summary>
    private static Runners.Kimi.KimiConsultant KimiConsultantOf() => new(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
        new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))));

    /// <summary>No Vibe launch carries <c>--add-dir</c>, whatever the grant (D3: <c>--add-dir</c> trusts its folder).</summary>
    [Fact]
    public void NoVibeLaunch_CarriesAddDir_WhateverTheGrant()
    {
        var consultant = new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows));
        foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Disk(RootA, RootB), CapabilityGrant.Web])
        {
            if (ConfinementPlanner.Plan("vibe", grant) is not Confinement.Planned plan)
            {
                continue;
            }

            plan.AddDirs.Should().BeEmpty($"vibe × {grant.Capability}");
            consultant.Build(Planned("vibe", grant)).Request.Arguments.Should().NotContain("--add-dir", $"vibe × {grant.Capability}")
                .And.NotContain(RootA).And.NotContain(RootB);
        }
    }

    [Fact]
    public void ASnapshotCwd_NeedsAWorkdir_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("vibe", CapabilityGrant.Disk(RootA)) with { Workdir = string.Empty };

        var build = () => new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*Workdir*",
            "falling back to a root would hand Vibe the branch's own .vibe/ and AGENTS.md (D6)");
    }

    /// <summary>The structural half of acceptance 2: whatever a planned launch sends of the sandbox vocabulary, the plan gave it.</summary>
    [Fact]
    public void NoAdapter_SendsASandboxFlag_ThePlanDidNotGiveIt()
    {
        foreach (var (runtime, consultant) in Adapters())
        {
            foreach (var grant in (CapabilityGrant[])[CapabilityGrant.None, CapabilityGrant.Disk(RootA), CapabilityGrant.Web])
            {
                if (ConfinementPlanner.Plan(runtime, grant) is not Confinement.Planned plan)
                {
                    continue;
                }

                var argv = consultant.Build(Planned(runtime, grant)).Request.Arguments.ToList();
                var ownFlags = argv.Except(plan.Flags.Concat(plan.Leading)).Where(ConfinementPlanner.IsSandboxVocabulary);

                ownFlags.Should().BeEmpty($"{runtime} × {grant.Capability}: the planner is the one place");
            }
        }
    }

    [Fact]
    public void APlannedLaunch_IsOneShot_SoAHandleIsAContractViolation()
    {
        var resumed = Planned("claude", CapabilityGrant.None) with { Handle = "67289235-65f7-40b5-9532-e63515d90f30" };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(resumed);

        build.Should().Throw<ArgumentException>().WithMessage("*one-shot*");
    }

    [Fact]
    public void AScratchCwd_NeedsAScratchDirectory_OrTheLaunchIsRefused()
    {
        var nowhere = Planned("claude", CapabilityGrant.None) with { ScratchDir = string.Empty };

        var build = () => new ClaudeConsultant(new ClaudeRuntime()).Build(nowhere);

        build.Should().Throw<ArgumentException>().WithMessage("*ScratchDir*",
            "falling back to the checkout would hand a none row the very directory it must not see");
    }

    /// <summary>The regression guard (acceptance 5): today's argv, byte for byte, with the defaulted confinement.</summary>
    /// <remarks>
    /// The claude row moved when PLAN_the_consultant_works_on_every_vendor.md merged second, as that plan's §7 said it
    /// must: the stuck consultant is confined by the planner's own disk allowlist (<see cref="ConfinementPlanner.ClaudeDiskTools"/>)
    /// plus <c>--restricted</c> where the installed CLI declares it — never the deny list. Its launch is PREPARED first
    /// (<c>IConsultantRuntime.PrepareAsync</c> reads the CLI's help), which is what <c>ClaudeCli</c> stands for here;
    /// the CLI without the flag is <c>ClaudeConsultantArgvTests</c>' business.
    /// </remarks>
    [Fact]
    public void TheShippedConsultants_StillBuildTodaysArgv_ByteForByte()
    {
        var launch = new ConsultantLaunch(Repo, "help me", string.Empty, Answers, new ReviewerSettings("v") { Model = "m", ClaudeCli = ClaudeCapability.WithRestricted });
        launch.Confinement.Should().Be(LaunchConfinement.AsShipped, "the default is the stuck consultant as it ships");

        new ClaudeConsultant(new ClaudeRuntime()).Build(launch).Request.Arguments.Should().Equal(
            "-p", "--output-format", "json", "--permission-mode", "plan",
            "--restricted", "--tools", string.Join(',', ConfinementPlanner.ClaudeDiskTools),
            NoMcpServers.ClaudeFlag, "--add-dir", Repo, "--model", "m");

        var codex = new CodexConsultant(new CodexRuntime()).Build(launch).Request.Arguments.ToList();
        codex.Should().Equal(
            "exec", "-s", "read-only", "--skip-git-repo-check", "--color", "never", "-C", Repo, "--json", "-o", codex[codex.IndexOf("-o") + 1], "-m", "m",
            "-c", "service_tier=default", "-");

        // agy's argv CHANGED on purpose (research/PLAN_agy_cannot_write_its_roots.md): it runs as the reader agent, from the
        // read-only folder, and reaches the checkout through --add-dir — plan mode alone let it write there.
        var agy = new AntigravityConsultant(new AntigravityRuntime()).Build(launch).Request;
        agy.Arguments.Should().Equal(
            "--print=", "--input-format", "stream-json", "--output-format", "stream-json", "--mode", "plan", "--agent", "coai-reader",
            "--model", "m", "--add-dir", Repo);
        agy.WorkingDirectory.Should().Be(AntigravityReadOnly.Home());

        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is not "local" and not "antigravity" and not "vibe" and not "kimi"))
        {
            consultant.Build(launch).Request.WorkingDirectory.Should().Be(Repo, consultant.Vendor);
            consultant.Build(launch).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }

        // Vibe and Kimi never stand in the checkout (D6): the conversation's snapshot, which the service makes (S5.4.13 for Kimi).
        var inTheSnapshot = launch with { Workdir = RowTree, Settings = launch.Settings with { OwnedScratch = RowFolder } };
        foreach (var (_, consultant) in Adapters().Where(a => a.Runtime is "vibe" or "kimi"))
        {
            consultant.Build(inTheSnapshot).Request.WorkingDirectory.Should().Be(RowTree, consultant.Vendor);
            consultant.Build(inTheSnapshot).Role.Should().Be(ConsultantRoles.Consult, consultant.Vendor);
        }
    }

    private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters() =>
    [
        ("claude", new ClaudeConsultant(new ClaudeRuntime())),
        ("codex", new CodexConsultant(new CodexRuntime())),
        ("antigravity", new AntigravityConsultant(new AntigravityRuntime())),
        ("vibe", new Runners.Vibe.VibeConsultant(new Runners.Vibe.VibeRuntime("vibe", Runners.Platform.HostKind.Windows))),
        // A fake person's paths, so building reads nothing of this machine: the request names the places, it does not open them.
        ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows,
            new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", []))))),
    ];
}

```
