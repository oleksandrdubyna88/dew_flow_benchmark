```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var admitted = CapabilityMatrix.Admit("kimi", capability).Should().BeOfType<Admission.Admitted>(
                "Grep and Glob read the disk on their own — the row can read this machine (M-K6)").Which;
            admitted.Flag.Should().Be(AdmissionFlag.Unconfined, $"kimi × {capability}: Grep and Glob read the disk on their own (M-K6)");
            admitted.Standing.Should().Be(CapabilityStanding.Unconfined, $"kimi × {capability}: the row can read this machine (M-K6)");
        }
```