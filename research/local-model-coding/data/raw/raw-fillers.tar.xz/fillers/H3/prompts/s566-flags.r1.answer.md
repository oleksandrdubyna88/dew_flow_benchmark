```csharp
var launch = Planned("kimi", CapabilityGrant.None);
var withFlags = ((LaunchConfinement.Planned)launch.Confinement).Plan with { Flags = ["--yolo"] };
var withDirs = ((LaunchConfinement.Planned)launch.Confinement).Plan with { AddDirs = [RootA] };

var flagged = () => KimiConsultantOf().Build(launch with { Confinement = new LaunchConfinement.Planned(withFlags) });
var dirs = () => KimiConsultantOf().Build(launch with { Confinement = new LaunchConfinement.Planned(withDirs) });

flagged.Should().Throw<ArgumentException>().WithMessage("*shim*",
    "E5.6 decision 3: a plan with a flag is not one coai made for kimi, so it is refused, naming the shim");
dirs.Should().Throw<ArgumentException>().WithMessage("*shim*",
    "E5.6 decision 3: a plan with an add-dir is not one coai made for kimi, so it is refused, naming the shim");
```