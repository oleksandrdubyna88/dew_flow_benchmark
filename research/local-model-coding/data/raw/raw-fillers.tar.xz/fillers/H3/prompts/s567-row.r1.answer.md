```csharp
        using var person = new KimiFixture();
        using var stood = KimiScenarioScopes.StandIn(person);
        var personBefore = person.Hash();
        var unlinked = new List<string>();
        var granted = Path.Combine(Repo, "src");
        ProcessRequest? shimRequest = null;

        try
        {
            GitScratch.AfterUnlink = unlinked.Add;

            if (ending == "answered")
            {
                var seen = new List<string>();
                var kimi = new PlayedKimi(_launcher)
                {
                    Turn = (_, request) =>
                    {
                        seen.AddRange(Directory.EnumerateFiles(request.WorkingDirectory, "*", SearchOption.AllDirectories));

                        return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, Advice);
                    },
                };

                var reply = await AskAsync(ServiceOn(kimi, Homes, granted));
                TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());

                shimRequest = kimi.Shims.Should().ContainSingle().Subject.Request;
                var cwd = shimRequest.Arguments[shimRequest.Arguments.ToList().IndexOf("--cwd") + 1];
                shimRequest.StdIn.Should().Contain(cwd, "the prompt names the copy the shim reads");
                shimRequest.StdIn.Should().NotContain(granted, "never the original");
                cwd.Should().NotBe(granted, "the shim reads a copy, not the granted root");
                Path.GetFullPath(cwd).StartsWith(Path.GetFullPath(Repo) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                    .Should().BeFalse("the copy is not under the repository");
                seen.Should().Contain(p => Path.GetFileName(p) == "Mailer.cs", "the copy holds the granted tree");
                seen.Should().NotContain(p => Path.GetFileName(p) == "AGENTS.md", "the copy holds no AGENTS.md");
                seen.Should().NotContain(p => Path.GetFileName(p) == "config.toml", "the copy holds no .kimi-code config");
            }
            else if (ending == "refused-before-the-launch")
            {
                var plain = Directory.CreateDirectory(_dir.At("plain")).FullName;
                await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);

                var kimi = new PlayedKimi(_launcher);
                var reply = await AskAsync(ServiceOn(kimi, Homes, plain));
                var row = TheRow(reply);
                row.GetProperty("status").GetString().Should().Be(RowOutcomes.Refused, reply.ToString());
                row.GetProperty("reason").GetString().Should().Contain("not inside a Git work tree");
                kimi.Shims.Should().BeEmpty("the refusal comes before any launch");
            }
            else
            {
                using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
                var kimi = new PlayedKimi(_launcher)
                {
                    During = async (_, ct) =>
                    {
                        await caller.CancelAsync();
                        ct.ThrowIfCancellationRequested();
                    },
                };

                var asking = async () => await AskAsync(ServiceOn(kimi, Homes, granted), caller.Token);
                await asking.Should().ThrowAsync<OperationCanceledException>();

                shimRequest = kimi.Shims.Should().ContainSingle().Subject.Request;
            }
        }
        finally
        {
            GitScratch.AfterUnlink = null;
        }

        NothingIsLeftBehind(person, personBefore, unlinked, shimRequest);
```