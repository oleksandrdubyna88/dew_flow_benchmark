```csharp
using var person = new KimiFixture();
using var stood = KimiScenarioScopes.StandIn(person);
var played = new PlayedKimi(new ProcessLauncher())
{
    Turn = (_, request) =>
    {
        var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];
        var marker = File.ReadAllText(Path.Combine(cwd, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
        return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
    },
};
var before = person.Hash();
var settings = KimiSettings(_homes.Path);

var (code, said) = await CheckAsync(settings, played);

code.Should().Be(0, "the check of my-kimi must pass on a Kimi row that runs in a copy");
said.GetProperty("state").GetString().Should().Be("answered", said.ToString());
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");

var shim = played.Shims.Should().ContainSingle().Subject.Request;

var cwdValue = shim.Arguments[shim.Arguments.ToList().IndexOf("--cwd") + 1];
cwdValue.Should().Contain(Path.Combine("own", "tree"), "the consultant stands in a copy in the check's own scratch, never the repository");
shim.WorkingDirectory.Should().Be(cwdValue, "the shim's working directory is the same copy folder");

var home = shim.Arguments[shim.Arguments.ToList().IndexOf("--home") + 1];
var oneShotRoot = Path.Combine(_homes.Path, CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar;
home.Should().StartWith(oneShotRoot, "the one-shot home lives under the short homes root");
Path.GetFileName(Path.GetDirectoryName(home)!).Should().HaveLength(8, "the one-shot folder is named with 8 hex digits");
Path.GetFileName(home).Should().StartWith("kh-", "the home is a Kimi home folder");
Path.GetFileName(home).Should().HaveLength(3 + 10, "the Kimi home is kh- plus 10 hex digits");
home.Should().NotStartWith(_temp.Path, "the home is never under TEMP, which is where the scratch lives");

Directory.EnumerateDirectories(_temp.Path, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
```