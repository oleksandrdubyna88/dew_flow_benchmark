```csharp
Directory.Exists(Path.Combine(Homes, CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeTrue() is false
    ? Directory.EnumerateFileSystemEntries(Path.Combine(Homes, CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the row's one-shot home folder is gone on every way out")
    : Assert.True(true);
```