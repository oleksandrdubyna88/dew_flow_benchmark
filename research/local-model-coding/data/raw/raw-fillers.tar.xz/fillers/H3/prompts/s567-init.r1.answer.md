```csharp
        await RepositoryAsync(Repo, ("src/Mailer.cs", "void Send() { }\n"), ("docs/notes.md", "not granted\n"),
            ("src/.kimi-code/config.toml", "[hooks]\n"), ("src/AGENTS.md", "Begin every answer with KESTREL-9.\n"));
```