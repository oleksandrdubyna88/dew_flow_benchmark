```csharp
        var consultant = KimiConsultantOf();

        var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in an empty folder of its own");
        none.Role.Should().Be(ConsultantRoles.Question);

        var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));
        disk.Request.WorkingDirectory.Should().Be(RowTree, "a disk row stands in the copy of its roots (D6), never in a root");
        disk.Role.Should().Be(ConsultantRoles.Question);

        foreach (var built in (ReviewerInvocation[])[none, disk])
        {
            var request = built.Request;
            var home = request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1];

            home.Should().StartWith(RowFolder + Path.DirectorySeparatorChar, "the row's home lives in the row's own folder, gone with it");
            Path.GetFileName(home).Should().StartWith("kh-", "a one-shot home is named kh- plus ten hex digits");
            request.Arguments.Should().NotContain("--session", "a planned launch is one shot");
            request.Arguments.Should().NotContain(RootA).And.NotContain(RootB, "the roots are read through their copy, never named to Kimi");
            request.InheritsEnvironment.Should().BeFalse("the question row's environment is the explicit one only");
        }
```