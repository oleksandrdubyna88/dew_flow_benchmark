```csharp
        var none = RuntimeCapabilities.Builtin.Of("kimi", Capability.None);
        var disk = RuntimeCapabilities.Builtin.Of("kimi", Capability.Disk);
        var web = RuntimeCapabilities.Builtin.Of("kimi", Capability.Web);

        none.Should().NotBeNull("Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.None) not to be null.");
        disk.Should().NotBeNull("Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.Disk) not to be null.");
        web.Should().NotBeNull("Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.Web) not to be null.");

        none!.Standing.Should().Be(CapabilityStanding.Unconfined, "kimi × none is measured as unconfined");
        none.MeasuredWith.Cells.Should().Contain("M-K6", "kimi × none rests on the Grep and Glob cell M-K6");

        disk!.Standing.Should().Be(CapabilityStanding.Unconfined, "kimi × disk is measured as unconfined");
        disk.MeasuredWith.Cells.Should().Contain("M-K6", "kimi × disk rests on the read cell M-K6");
        disk.MeasuredWith.Cells.Should().Contain("M-K9", "kimi × disk rests on the write cell M-K9");

        web!.Standing.Should().Be(CapabilityStanding.Unmeasured, "kimi × web has not been measured");

        foreach (var row in new[] { none, disk, web })
        {
            row!.MeasuredWith.Version.Should().Be("2.1.1", "the Kimi rows were measured with kimi 2.1.1");
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md", "every Kimi row cites the Kimi probe record");
        }
```