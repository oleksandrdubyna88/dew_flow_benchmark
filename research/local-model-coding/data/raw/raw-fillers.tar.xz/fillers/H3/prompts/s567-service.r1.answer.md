```csharp
return new PanelService(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, string.Empty, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    kimi,
    Logger.None,
    Noticing.None);
```