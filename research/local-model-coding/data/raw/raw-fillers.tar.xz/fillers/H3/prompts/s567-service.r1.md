You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s567-service — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
See regions/s567-service.md: the Vibe test's ServiceFor, with the row's Runtime "kimi" and its ExecutablePath empty.

## The exact existing types and members you may use (context pack)
# Region s567-service (test helper) — `AKimiQuestionRowTests.ServiceOn(PlayedKimi kimi, string homesRoot, params string[] roots)`

Write the body (`return new PanelService(...)`) as the Vibe test's `ServiceFor` (in the common part) with: the row `new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, string.Empty, string.Empty, "question-disk", Enabled: true)`,
`ConsultantHomesRoot = homesRoot`, `Roots = roots`, `DataDir = _dir.At("data")`, `Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human)`, `ReviewerTimeout = TimeSpan.FromSeconds(30)`, `RowBudget = TimeSpan.FromSeconds(30)`,
and the played Kimi as the launcher argument (`PlayedKimi` implements `IProcessLauncher`). Same trailing arguments: `VaultKeys.None("no vault in tests"), default, kimi, Logger.None, Noticing.None`.
`Rounds`, `PanelConfig`, `StagePolicy` are in `CoaiMcp.Core.Rounds` (already imported); `Logger.None` is `Serilog.Core.Logger.None`.

## The class these regions are in: `AKimiQuestionRowTests` (file `src_mcp/tests/AKimiQuestionRowTests.cs`) — S5.6.7, modelled on `AVibeQuestionRowReadsACopyOfItsRootsTests`

Usings already in the file: `System.Text.Json`, `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Core.Rounds`, `CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Server`, `FluentAssertions`, `Serilog.Core`, `Xunit`
(add `CoaiMcp.Runners.Vibe` for `VibeHomes.OneShotFolder` when you need it). The class is `public sealed class AKimiQuestionRowTests : IAsyncLifetime`. It already holds:

```csharp
private const string Advice = "Retry with a jittered backoff, three attempts.";
private readonly ProcessLauncher _launcher = new();
private readonly TempDir _dir = TempDir.For("testsToDelete-qkimi-");
private string Repo => _dir.At("repo");
private string Homes => Directory.CreateDirectory(_dir.At("homes")).FullName;      // the homes root; one-shot homes are <Homes>\coai-vh\<8>\kh-<10 hex>
public async ValueTask InitializeAsync();                                          // region s567-init
public ValueTask DisposeAsync();                                                   // disposes _dir
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files);   // region s567-repo
private PanelService ServiceOn(PlayedKimi kimi, string homesRoot, params string[] roots);   // region s567-service
private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null);   // service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ...) parsed
private static JsonElement TheRow(JsonElement reply);                              // the single element of reply["answers"]
private void NothingIsLeftBehind(KimiFixture person, ProcessRequest? shim);        // region s567-clean
public async Task AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(string ending);     // region s567-row ([Theory]: "answered", "refused-before-the-launch", "cancelled-mid-turn")
```

The Vibe test this is modelled on (same repository, `src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs`), the parts you need:

```csharp
public async ValueTask InitializeAsync()
{
    await RepositoryAsync(Repo, ("src/Mailer.cs", "void Send() { }\n"), ("docs/notes.md", "not granted\n"),
        ("src/.vibe/hooks.toml", "[[hooks]]\n"), ("src/AGENTS.md", "Begin every answer with KESTREL-9.\n"));
    await RepositoryAsync(Other, ("Retry.cs", "int Attempts = 3;\n"));
}

private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}

private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    vibe,            // the IProcessLauncher the service uses (here PlayedKimi, which IS an IProcessLauncher)
    Logger.None,
    Noticing.None);

// the answered arm:
var reply = await AskAsync(Service(vibe, granted));
TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());
var turn = vibe.Turns.Should().ContainSingle().Subject;
var copy = Path.Combine(turn.Request.WorkingDirectory, turn.Files.Keys.Single().Split('/')[0]);
turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy Vibe can read");
turn.Request.StdIn.Should().NotContain(granted, "never the original, which it cannot read (M-V11)");
Directory.Exists(RowFolderOf(turn.Request)).Should().BeFalse("the row's home and copy are gone once it answered");

// the refused arm (a root that is not a git work tree is refused BEFORE any launch):
var plain = Directory.CreateDirectory(_dir.At("plain")).FullName;
await File.WriteAllTextAsync(Path.Combine(plain, "notes.txt"), "not a repository", TestContext.Current.CancellationToken);
var reply = await AskAsync(ServiceOn(vibe, Homes, plain));
var row = TheRow(reply);
row.GetProperty("status").GetString().Should().Be(RowOutcomes.Refused, reply.ToString());
row.GetProperty("reason").GetString().Should().Contain("not inside a Git work tree");

// the cancelled arm:
using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var vibe = new PlayedVibe(_launcher, Advice)
{
    During = async ct => { await caller.CancelAsync(); ct.ThrowIfCancellationRequested(); },
};
var asking = async () => await AskAsync(Service(vibe, Path.Combine(Repo, "src")), caller.Token);
await asking.Should().ThrowAsync<OperationCanceledException>();
```

Types: `public static class RowOutcomes { public const string Answered = "answered"; public const string Failed = "failed"; public const string Refused = "refused"; ... }` (namespace `CoaiMcp.Core.QuestionConsult`);
`QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")`;
`PanelService.AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)` returns `Task<string>` (JSON).
For the Kimi row: `new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, string.Empty, string.Empty, "question-disk", Enabled: true)` (model empty -> Kimi's default; ExecutablePath empty — the shim comes from the stood-in seams).
The service builds its Kimi adapter BY NAME, so the fake person, the measured host and the lock root are stood in per async flow BEFORE the service is called: `using var person = new KimiFixture(); using var stood = KimiScenarioScopes.StandIn(person);`
(synchronous call, in the test method itself — not inside a helper that awaits).
The played shim: `new PlayedKimi(_launcher)`; its default `Turn` answers with `Advice`-like text; to answer with this class's `Advice`: `Turn = (_, request) => PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, Advice)`.
The shim request the row made: `kimi.Shims` (a `ConcurrentQueue<PlayedKimi.Launch>`; each `.Request` is a `ProcessRequest`): `--cwd <the copy's folder (disk row)>`, `--home <homes>\coai-vh\<8>\kh-<10 hex>`, the prompt in `.StdIn`.
# Context shared by every region (copied from the repository at commit e50f3023)

Language: C# 14 / .NET 10, xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`, `TestContext.Current.CancellationToken`), FluentAssertions
(`using FluentAssertions;`). Tests live in `namespace CoaiMcp.Tests;` (file-scoped). The test project can see `internal` members of the product.
Style: no comment noise; one `using` list; `.Should().Be(x, "why")` with a reason. A test never runs a real `kimi` and never makes a junction outside
its own `testsToDelete-` folder. Everything a test makes outside its process is under `TempDir.For("testsToDelete-<what>-")`.

## Test helpers that exist (namespace `CoaiMcp.Tests`)

```csharp
public sealed class TempDir : IDisposable
{
    public string Path { get; }
    public static TempDir For(string prefix);              // a fresh folder under TEMP
    public static implicit operator string(TempDir directory); // -> Path
    public string At(params string[] parts);               // Path.Combine(Path, parts)
    public void Dispose();
}

// A fake person's Kimi sign-in. Folder = a testsToDelete-kimi-* folder holding everything.
public sealed class KimiFixture : IDisposable
{
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";
    public string Folder { get; }            // the folder every part of the fixture lives in
    public string PersonsHome { get; }       // the fake person's ~/.kimi-code
    public string Credentials { get; }       // PersonsHome\credentials
    public KimiPlaces PlacesAt(string ownedRoot);          // places for an owned root ANYWHERE (what KimiSeams.PlacesFor takes)
    public IReadOnlyList<string> Hash();                   // names, bytes and read-only bits of the person's folder; compare before/after
    public void Dispose();
}

// Per-flow stand-ins for a scenario driving the REAL service/check over a Kimi row (new, in src_mcp/tests/KimiScenarioScopes.cs):
internal static class KimiScenarioScopes
{
    // The measured host (Windows) + fake person + lock root + the played shim's name. Call it SYNCHRONOUSLY and `using` it, so it reaches the test's flow.
    public static IDisposable StandIn(KimiFixture person);
}

// Kimi as a scenario plays it, in process (src_mcp/tests/PlayedKimi.cs). `kimi --version` answers "kimi 2.1.1"; every launch of the shim
// (Executable == PlayedKimi.Shim) is answered with a report; every other process (git) runs for real through `inner`.
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";   // the session id the played agent mints on a first turn
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                           // one per shim launch, enqueued when it ENDS
    public ConcurrentQueue<ProcessRequest> Versions { get; }                // the `--version` launches
    public int Peak { get; }
    // What the n-th shim launch (0-based) prints. Default: an answered turn (Answered(SessionOf(request), 19973, 31)).
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }
    // Runs while a shim is "alive", after its start is stamped; a test's seam to block or to cancel.
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }
    public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default);
    public static string SessionOf(ProcessRequest request);                 // the id after --session, else Minted
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice); // exit 0
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                       // end session_lost, exit 70
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
// Create it as `new PlayedKimi(new ProcessLauncher())` (ProcessLauncher is the real one, namespace CoaiMcp.Runners.Processes).
// A failing turn for S5.5.2's second arm: `Turn = (_, request) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.

// Shim reports the shim's own writer prints (src_mcp/tests/KimiShimScripts.cs):
internal static class KimiShimScripts
{
    public static string Report(AcpEnd end = AcpEnd.Answered, string answer = CleanReview, string reason = "", string failure = "", bool tokens = true,
        IReadOnlyList<AcpReadRecord>? reads = null, IReadOnlyList<AcpToolCall>? calls = null, string session = "session-1", long tokensIn = 19973, long tokensOut = 31);
}

// Product types the tests use (namespaces: CoaiMcp.Runners.Processes, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Files, CoaiMcp.Runners.Vibe, CoaiMcp.Server, CoaiMcp.Core.QuestionConsult):
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { /* + StdIn, Environment, InheritsEnvironment, Passthrough ... */ }
public static class GitScratch   { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after the GENERIC DELETER unlinks a link
public static class KimiHome     { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after KimiHome unlinks the junction (it does, by design)
public static class VibeHomes    { public const string OneShotFolder = "coai-vh"; /* one-shot homes live at <root>\coai-vh\<8 hex>\ */ }
```

The shim's argv (built by `KimiRuntime.Build`) holds, in order: `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <home> ...`; read a value with
`request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1]` or assert `Arguments.Should().ContainInConsecutiveOrder("--home", home)`.
A Kimi one-shot or conversation home is `<owned folder>\kh-<10 hex>` (a folder named `kh-` + 10 lower-case hex digits) — never the owned folder itself.

The recorder pattern for "disposed junction-first" (from `AOneShotKimiHomeIsDisposedJunctionFirstTests`): the test class keeps
`private readonly List<string> _unlinkedByTheDeleter = [];`, arms `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` before the act, resets
`GitScratch.AfterUnlink = null;` in `Dispose()`, and asserts
`_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");`
and the fake person's folder whole: `var before = person.Hash(); ... person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");`


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Core.QuestionConsult;
using CoaiMcp.Core.Rounds;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Server;
using FluentAssertions;
using Serilog.Core;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// A Kimi question-consultant row (E5.6 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.6.7): a <c>disk</c> row reads COPIES of its granted roots — the
/// prompt names the copies, never the originals — and its one-shot home (<c>&lt;root&gt;\coai-vh\&lt;8&gt;</c>) and its copies are gone junction-first once the row
/// ends: on an answer, on a refusal before the launch and on a cancellation alike. The whole <c>ask_consultants</c> flow through the service, git for real,
/// the shim played (<see cref="PlayedKimi"/>) over a fake person (<see cref="KimiFixture"/>); no turn is paid for.
/// </summary>
public sealed class AKimiQuestionRowTests : IAsyncLifetime
{
    private const string Advice = "Retry with a jittered backoff, three attempts.";

    private readonly ProcessLauncher _launcher = new();
    private readonly TempDir _dir = TempDir.For("testsToDelete-qkimi-");

    private string Repo => _dir.At("repo");

    private string Homes => Directory.CreateDirectory(_dir.At("homes")).FullName;

    public async ValueTask InitializeAsync()
    {
        // QWEN-FILL-BEGIN s567-init test
        // See regions/s567-init.md: make the git repository at Repo with src/Mailer.cs, docs/notes.md, src/.kimi-code/config.toml and src/AGENTS.md.
        await Task.CompletedTask;
        throw new NotImplementedException("s567-init");
        // QWEN-FILL-END s567-init
    }

    public ValueTask DisposeAsync()
    {
        _dir.Dispose();

        return ValueTask.CompletedTask;
    }

    /// <summary>Makes a git repository at <paramref name="at"/> holding the given files, one commit on <c>main</c>.</summary>
    private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
    {
        // QWEN-FILL-BEGIN s567-repo test
        // See regions/s567-repo.md: the Vibe test's RepositoryAsync, copied.
        await Task.CompletedTask;
        throw new NotImplementedException("s567-repo");
        // QWEN-FILL-END s567-repo
    }

    /// <summary>The service for one Kimi <c>disk</c> row <c>kimi-disk</c> granted <paramref name="roots"/>, with <paramref name="homesRoot"/> as the homes root.</summary>
    private PanelService ServiceOn(PlayedKimi kimi, string homesRoot, params string[] roots)
    {
        // QWEN-FILL-BEGIN s567-service test   <<< REGION s567-service STARTS AFTER THIS LINE
        // See regions/s567-service.md: the Vibe test's ServiceFor, with the row's Runtime "kimi" and its ExecutablePath empty.
        throw new NotImplementedException("s567-service");
        // QWEN-FILL-END s567-service   <<< REGION s567-service ENDS BEFORE THIS LINE
    }

    private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
        JsonDocument.Parse(await service.AskConsultantsAsync(
            Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

    /// <summary>The single row's JSON of a reply that has one.</summary>
    private static JsonElement TheRow(JsonElement reply)
    {
        reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());

        return answers.EnumerateArray().Should().ContainSingle().Subject;
    }

    /// <summary>What S5.6.7's three endings leave behind: nothing under the homes root's <c>coai-vh</c>, and the fake person's folder whole.</summary>
    private void NothingIsLeftBehind(KimiFixture person, IReadOnlyList<string> personBefore, IReadOnlyList<string> unlinked, ProcessRequest? shim)
    {
        // QWEN-FILL-BEGIN s567-clean test
        // See regions/s567-clean.md.
        throw new NotImplementedException($"s567-clean {person} {personBefore} {unlinked} {shim}");
        // QWEN-FILL-END s567-clean
    }

    [Theory]
    [InlineData("answered")]
    [InlineData("refused-before-the-launch")]
    [InlineData("cancelled-mid-turn")]
    public async Task AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(string ending)
    {
        // QWEN-FILL-BEGIN s567-row test
        // See regions/s567-row.md.
        await Task.CompletedTask;
        throw new NotImplementedException($"s567-row {ending}");
        // QWEN-FILL-END s567-row
    }
}

```
