You write the body of ONE region in an existing C# file. The surrounding code, the
signatures and the types are fixed and correct: do not change them.

Return ONLY the code that goes between the two marker lines of region s552-gone — no marker lines, no method signature, no
explanation — as one ```csharp code block. Use only names that appear in the file or in the context below; do not invent
APIs, properties or overloads. Keep the file's code style and indentation.

## What the region must do (the author's instructions)
See regions/s552-gone.md.

## The exact existing types and members you may use (context pack)
# Region s552-gone (test) — `AKimiConsultantCheckTests.AfterTheCheck_TheHomeIsGone_JunctionFirst(bool theTurnFails)` (S5.5.2), `[Theory]` with `[InlineData(false)]` and `[InlineData(true)]`

Scenario: S5.5.1's check with `GitScratch.AfterUnlink` armed as a recorder; the check ends — arm 1 passed, arm 2 the played turn fails (exit 70). Then: `<_homes>\coai-vh\<8>` gone; the recorder never invoked;
the fake person's folder intact (bytes and read-only bits: `person.Hash()` equal to the hash before).
Red before E5.3 g (generic deleter meets the junction): *Expected the deleter's unlink recorder not to be invoked ...* — after it, green.

Arrange: `using var person = new KimiFixture(); using var stood = KimiScenarioScopes.StandIn(person);` `var before = person.Hash();`
`var unlinked = new List<string>(); GitScratch.AfterUnlink = unlinked.Add;` and reset `GitScratch.AfterUnlink = null;` in a `try/finally` (it is per async flow, but still reset it).
The played shim: when `theTurnFails` is false, the marker-reading answer (snippet in the common part); when true: `Turn = (_, _) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.
Act: `var (code, said) = await CheckAsync(KimiSettings(_homes), played);`
Assert:
- the turn fails -> `said.GetProperty("state").GetString().Should().NotBe("answered", said.ToString())`; the turn passes -> `"answered"`.
- `Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends, whatever ended it")` — `using CoaiMcp.Runners.Vibe;`; the `coai-vh` folder itself may remain, its `<8>` child must not (if `coai-vh` does not exist, the assertion on a missing folder must not throw: guard with `Directory.Exists`).
- `unlinked.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first")`.
- `person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before")`.
- the shim was launched once (`played.Shims.Should().ContainSingle()`) in both arms, so the home was made and then removed (a home that was never made proves nothing).

## The class these regions are in: `AKimiConsultantCheckTests` (file `src_mcp/tests/AKimiConsultantCheckTests.cs`)

Usings already in the file: `System.Text.Json`, `CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Server`, `FluentAssertions`, `Xunit`. Add others only if the body needs them.
The class is `[Collection("fakecli-env")] public sealed class AKimiConsultantCheckTests : IDisposable`. It already holds:

```csharp
private readonly TempDir _data = TempDir.For("testsToDelete-kcheck-data-");    // the check's DataDir
private readonly TempDir _temp = TempDir.For("testsToDelete-kcheck-temp-");    // the check's scratch parent: the check makes <_temp>\coai-check-*\ (see below)
private readonly TempDir _homes = TempDir.For("testsToDelete-kcheck-homes-");  // the homes root for the rooted tests
private readonly List<string> _warned = [];
public void Dispose();                                                          // disposes the three TempDirs (add resets of GitScratch.AfterUnlink / KimiHome.AfterUnlink here if your test arms them: they are per async flow, still reset them)

private PanelSettings KimiSettings(string homesRoot);                           // region s55-settings (a helper YOU may call from every test)
private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played)   // runs `--check-consultant --caller claude` in process; Said = the JSON the mode printed
{
    var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", "--caller", "claude"], played, _temp, _warned.Add, Noticing.None, TestContext.Current.CancellationToken);
    return (code, JsonDocument.Parse(stdout).RootElement.Clone());
}
```

How a check works (src/Server/Consultation/ConsultantCheck.cs, E4.2 + E5.5 decision 1: no new branch): the check makes a scratch repository `<_temp>\coai-check-<...>\` holding a committed `CHECK.md`
whose text is `The check word is <marker>.` and a canary file outside the repository. For a runtime that asks (`NeedsASanitisedSnapshot`, true for `KimiConsultant`) it makes a COPY at
`<scratch root>\own\tree` (`ConsultantCheck.OwnName == "own"`) and the consultant stands in it; for a runtime that declares a `HomesFolder` (Kimi: `coai-kimi`) it reserves a ONE-SHOT home with
`VibeHomes.ReserveOneShot(settings.ConsultantHomesRoot, warn)` — `<homesRoot>\coai-vh\<8 hex>\` — and passes that folder as the launch's `OwnedScratch`; the shim's `--home` is then `<that folder>\kh-<10 hex>`.
With an EMPTY `ConsultantHomesRoot` (settings built by hand) `ReserveOneShot` answers `OneShotReservation.None` and the home folder is the place's own folder `<scratch>\own` (so `--home` is `<scratch>\own\kh-<10 hex>`).
The one-shot home is disposed in `finally` (`OneShotHome.Dispose`, junction-first through `KimiHome.DisposeAllUnder`); the scratch (with `own\`) is disposed by `ConsultCheckScratch.Delete`, also junction-first for a Kimi home.

The answer the check judges: the consultant's advice text must contain a line `marker: <the marker>` and `canary: CANNOT`. The marker is the last word of the committed `CHECK.md` without the final dot, so the played shim
reads it from its own cwd (the COPY): 

```csharp
Turn = (_, request) =>
{
    var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];                 // the copy: <scratch>\own\tree
    var marker = File.ReadAllText(Path.Combine(cwd, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
    return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
},
```

The JSON the mode prints (`Said`): `state` ("answered" | "failed" | ...; constants in `ConsultCheckStates`), `markerRead` (bool), `failureKind` / `failureWhat` / `failureCure` for a failure. A cancelled turn is a `failed` record whose
`failureKind` is `ConsultFailureKinds.Cancelled` (`"cancelled"`) when the caller's token ends the turn — if the mode instead throws `OperationCanceledException` for an already-cancelled token, cancel the token DURING the shim instead (below) and assert whichever the mode gives, naming it in the assertion message.

Existing similar test (Vibe; same shape, other adapter) from `ConsultantCheckTests`:

```csharp
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());                    // Text(e, n) = e.GetProperty(n).GetString() ?? ""
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
home.Should().StartWith(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar, "D1: under the short homes root, never under TEMP");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
```

The fake person and the flow's stand-ins (EVERY test in this class does this first, synchronously, before the first await):

```csharp
using var person = new KimiFixture();
using var stood = KimiScenarioScopes.StandIn(person);
var played = new PlayedKimi(new ProcessLauncher()) { Turn = ... };       // see above
var before = person.Hash();                                                // the fake person's folder, before
```
# Context shared by every region (copied from the repository at commit e50f3023)

Language: C# 14 / .NET 10, xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`, `TestContext.Current.CancellationToken`), FluentAssertions
(`using FluentAssertions;`). Tests live in `namespace CoaiMcp.Tests;` (file-scoped). The test project can see `internal` members of the product.
Style: no comment noise; one `using` list; `.Should().Be(x, "why")` with a reason. A test never runs a real `kimi` and never makes a junction outside
its own `testsToDelete-` folder. Everything a test makes outside its process is under `TempDir.For("testsToDelete-<what>-")`.

## Test helpers that exist (namespace `CoaiMcp.Tests`)

```csharp
public sealed class TempDir : IDisposable
{
    public string Path { get; }
    public static TempDir For(string prefix);              // a fresh folder under TEMP
    public static implicit operator string(TempDir directory); // -> Path
    public string At(params string[] parts);               // Path.Combine(Path, parts)
    public void Dispose();
}

// A fake person's Kimi sign-in. Folder = a testsToDelete-kimi-* folder holding everything.
public sealed class KimiFixture : IDisposable
{
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";
    public string Folder { get; }            // the folder every part of the fixture lives in
    public string PersonsHome { get; }       // the fake person's ~/.kimi-code
    public string Credentials { get; }       // PersonsHome\credentials
    public KimiPlaces PlacesAt(string ownedRoot);          // places for an owned root ANYWHERE (what KimiSeams.PlacesFor takes)
    public IReadOnlyList<string> Hash();                   // names, bytes and read-only bits of the person's folder; compare before/after
    public void Dispose();
}

// Per-flow stand-ins for a scenario driving the REAL service/check over a Kimi row (new, in src_mcp/tests/KimiScenarioScopes.cs):
internal static class KimiScenarioScopes
{
    // The measured host (Windows) + fake person + lock root + the played shim's name. Call it SYNCHRONOUSLY and `using` it, so it reaches the test's flow.
    public static IDisposable StandIn(KimiFixture person);
}

// Kimi as a scenario plays it, in process (src_mcp/tests/PlayedKimi.cs). `kimi --version` answers "kimi 2.1.1"; every launch of the shim
// (Executable == PlayedKimi.Shim) is answered with a report; every other process (git) runs for real through `inner`.
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";   // the session id the played agent mints on a first turn
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                           // one per shim launch, enqueued when it ENDS
    public ConcurrentQueue<ProcessRequest> Versions { get; }                // the `--version` launches
    public int Peak { get; }
    // What the n-th shim launch (0-based) prints. Default: an answered turn (Answered(SessionOf(request), 19973, 31)).
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }
    // Runs while a shim is "alive", after its start is stamped; a test's seam to block or to cancel.
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }
    public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default);
    public static string SessionOf(ProcessRequest request);                 // the id after --session, else Minted
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice); // exit 0
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                       // end session_lost, exit 70
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
// Create it as `new PlayedKimi(new ProcessLauncher())` (ProcessLauncher is the real one, namespace CoaiMcp.Runners.Processes).
// A failing turn for S5.5.2's second arm: `Turn = (_, request) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.

// Shim reports the shim's own writer prints (src_mcp/tests/KimiShimScripts.cs):
internal static class KimiShimScripts
{
    public static string Report(AcpEnd end = AcpEnd.Answered, string answer = CleanReview, string reason = "", string failure = "", bool tokens = true,
        IReadOnlyList<AcpReadRecord>? reads = null, IReadOnlyList<AcpToolCall>? calls = null, string session = "session-1", long tokensIn = 19973, long tokensOut = 31);
}

// Product types the tests use (namespaces: CoaiMcp.Runners.Processes, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Files, CoaiMcp.Runners.Vibe, CoaiMcp.Server, CoaiMcp.Core.QuestionConsult):
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { /* + StdIn, Environment, InheritsEnvironment, Passthrough ... */ }
public static class GitScratch   { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after the GENERIC DELETER unlinks a link
public static class KimiHome     { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after KimiHome unlinks the junction (it does, by design)
public static class VibeHomes    { public const string OneShotFolder = "coai-vh"; /* one-shot homes live at <root>\coai-vh\<8 hex>\ */ }
```

The shim's argv (built by `KimiRuntime.Build`) holds, in order: `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <home> ...`; read a value with
`request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1]` or assert `Arguments.Should().ContainInConsecutiveOrder("--home", home)`.
A Kimi one-shot or conversation home is `<owned folder>\kh-<10 hex>` (a folder named `kh-` + 10 lower-case hex digits) — never the owned folder itself.

The recorder pattern for "disposed junction-first" (from `AOneShotKimiHomeIsDisposedJunctionFirstTests`): the test class keeps
`private readonly List<string> _unlinkedByTheDeleter = [];`, arms `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` before the act, resets
`GitScratch.AfterUnlink = null;` in `Dispose()`, and asserts
`_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");`
and the fake person's folder whole: `var before = person.Hash(); ... person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");`


## The whole file (the region is marked with <<<)
```csharp
using System.Text.Json;
using CoaiMcp.Runners.Files;
using CoaiMcp.Runners.Kimi;
using CoaiMcp.Runners.Processes;
using CoaiMcp.Server;
using FluentAssertions;
using Xunit;

namespace CoaiMcp.Tests;

/// <summary>
/// <c>--check-consultant</c> for a Kimi row (E5.5 of <c>todo/PLAN_vibe_and_kimi_runtimes_E5.md</c>, S5.5.1–S5.5.4): one turn as a consultation makes it — in a
/// COPY of the check's scratch repository, on a ONE-SHOT owned home (<c>&lt;root&gt;\coai-vh\&lt;8&gt;\kh-&lt;10 hex&gt;</c>), disposed junction-first whatever ended
/// the check. The whole mode in process (<see cref="ConsultantCheckMode.AnswerAsync"/>), git for real, the shim played (<see cref="PlayedKimi"/>), the
/// person a fake one (<see cref="KimiFixture"/>) — no turn is paid for and the real <c>kimi</c> is never started.
/// </summary>
[Collection("fakecli-env")]
public sealed class AKimiConsultantCheckTests : IDisposable
{
    private readonly TempDir _data = TempDir.For("testsToDelete-kcheck-data-");
    private readonly TempDir _temp = TempDir.For("testsToDelete-kcheck-temp-");
    private readonly TempDir _homes = TempDir.For("testsToDelete-kcheck-homes-");
    private readonly List<string> _warned = [];

    public void Dispose()
    {
        _data.Dispose();
        _temp.Dispose();
        _homes.Dispose();
    }

    /// <summary>The settings of a check of a Kimi consultant row <c>my-kimi</c> for the caller <c>claude</c>, with <paramref name="homesRoot"/> as the homes root (empty: a hand-built one).</summary>
    private PanelSettings KimiSettings(string homesRoot)
    {
        // QWEN-FILL-BEGIN s55-settings test
        // See regions/s55-settings.md: a PanelSettings with Providers = [], DataDir = _data, ReviewerTimeout 60 s, ConsultEnabled = true,
        // ConsultantHomesRoot = homesRoot and Consultants = { [CallerIdentity.Claude] = new ConsultantChoice("my-kimi", Runtime: "kimi") }.
        throw new NotImplementedException("s55-settings");
        // QWEN-FILL-END s55-settings
    }

    /// <summary>One <c>--check-consultant --caller claude</c> in process: the exit code and the JSON it said.</summary>
    private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played)
    {
        var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(
            settings, ["--check-consultant", "--caller", "claude"], played, _temp, _warned.Add, Noticing.None, TestContext.Current.CancellationToken);

        return (code, JsonDocument.Parse(stdout).RootElement.Clone());
    }

    [Fact]
    public async Task AKimiCheck_RunsInACopy_OnAOneShotHome()
    {
        // QWEN-FILL-BEGIN s551-copy test
        // See regions/s551-copy.md.
        throw new NotImplementedException("s551-copy");
        // QWEN-FILL-END s551-copy
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task AfterTheCheck_TheHomeIsGone_JunctionFirst(bool theTurnFails)
    {
        // QWEN-FILL-BEGIN s552-gone test   <<< REGION s552-gone STARTS AFTER THIS LINE
        // See regions/s552-gone.md.
        throw new NotImplementedException($"s552-gone {theTurnFails}");
        // QWEN-FILL-END s552-gone   <<< REGION s552-gone ENDS BEFORE THIS LINE
    }

    [Fact]
    public async Task ACheckCancelledMidTurn_StillDisposesItsHome()
    {
        // QWEN-FILL-BEGIN s553-cancel test
        // See regions/s553-cancel.md.
        throw new NotImplementedException("s553-cancel");
        // QWEN-FILL-END s553-cancel
    }

    [Fact]
    public async Task ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst()
    {
        // QWEN-FILL-BEGIN s554-rootless test
        // See regions/s554-rootless.md.
        throw new NotImplementedException("s554-rootless");
        // QWEN-FILL-END s554-rootless
    }
}

```
