```csharp
        using var person = new KimiFixture();
        using var stood = KimiScenarioScopes.StandIn(person);
        var before = person.Hash();
        var unlinked = new List<string>();
        GitScratch.AfterUnlink = unlinked.Add;
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        var played = new PlayedKimi(new ProcessLauncher())
        {
            During = async (_, ct) =>
            {
                await caller.CancelAsync();
                ct.ThrowIfCancellationRequested();
            },
        };

        try
        {
            var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(
                KimiSettings(_homes), ["--check-consultant", "--caller", "claude"], played, _temp, _warned.Add, Noticing.None, caller.Token);
            var said = JsonDocument.Parse(stdout).RootElement.Clone();

            said.GetProperty("state").GetString().Should().Be("failed", said.ToString());
            said.GetProperty("failureKind").GetString().Should().Be(ConsultFailureKinds.Cancelled, said.ToString());
            played.Shims.Should().ContainSingle("the played shim must have started before the token was cancelled");
            Directory.EnumerateFileSystemEntries(Path.Combine(_homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the one-shot home goes junction-first even when the check is cancelled");
            unlinked.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
            person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
            Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the check's scratch goes even when the check is cancelled");
        }
        finally
        {
            GitScratch.AfterUnlink = null;
        }
```