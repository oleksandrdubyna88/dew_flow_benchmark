```csharp
using var person = new KimiFixture();
using var stood = KimiScenarioScopes.StandIn(person);
var before = person.Hash();

Func<int, ProcessRequest, ProcessResult> turn = theTurnFails
    ? (_, _) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)
    : (_, request) =>
    {
        var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];
        var marker = File.ReadAllText(Path.Combine(cwd, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
        return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
    };

var played = new PlayedKimi(new ProcessLauncher()) { Turn = turn };
var unlinked = new List<string>();
GitScratch.AfterUnlink = unlinked.Add;

try
{
    var (code, said) = await CheckAsync(KimiSettings(_homes), played);

    var state = said.GetProperty("state").GetString();
    if (theTurnFails)
        state.Should().NotBe("answered", said.ToString());
    else
        state.Should().Be("answered", said.ToString());

    played.Shims.Should().ContainSingle("the shim was launched once, so the home was made");

    var oneShot = Path.Combine(_homes, CoaiMcp.Runners.Vibe.VibeHomes.OneShotFolder);
    if (Directory.Exists(oneShot))
        Directory.EnumerateFileSystemEntries(oneShot).Should().BeEmpty("the home's folder goes when the check ends, whatever ended it");

    unlinked.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
    person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
}
finally
{
    GitScratch.AfterUnlink = null;
}
```