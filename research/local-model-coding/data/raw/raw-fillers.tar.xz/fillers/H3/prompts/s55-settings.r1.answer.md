```csharp
        return new PanelSettings
        {
            Providers = [],
            DataDir = _data,
            ReviewerTimeout = TimeSpan.FromSeconds(60),
            ConsultEnabled = true,
            ConsultantHomesRoot = homesRoot,
            Consultants = new Dictionary<string, ConsultantChoice>
            {
                [CallerIdentity.Claude] = new("my-kimi", Runtime: "kimi"),
            },
        };
```