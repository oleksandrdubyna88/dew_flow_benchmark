```csharp
var none = Plan("kimi", CapabilityGrant.None);
none.Leading.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
none.Flags.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
none.AddDirs.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
none.Cwd.Should().Be(CwdKind.Scratch, "a none row stands in an empty scratch folder");
none.SnapshotSources.Should().BeEmpty("a none row reads no root");
none.Flag.Should().Be(AdmissionFlag.Unconfined, "F2-style: Kimi's confinement is the shim's (D15)");

var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));
disk.Leading.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
disk.Flags.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
disk.AddDirs.Should().BeEmpty("Kimi's confinement is the shim's (D15), not its argv");
disk.Cwd.Should().Be(CwdKind.Snapshot, "D6: Kimi never stands in the checkout, it stands in a snapshot of its roots");
disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
disk.Flag.Should().Be(AdmissionFlag.Unconfined, "F2-style: Kimi's confinement is the shim's (D15)");

ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>()
    .Which.Reason.Should().Contain("not been measured").And.Contain("RESULTS_kimi_confinement.md");
```