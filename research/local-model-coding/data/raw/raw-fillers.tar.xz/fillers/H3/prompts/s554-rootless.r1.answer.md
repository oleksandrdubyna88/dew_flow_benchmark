```csharp
        using var person = new KimiFixture();
        using var stood = KimiScenarioScopes.StandIn(person);
        var before = person.Hash();
        var unlinked = new List<string>();
        var home = string.Empty;
        var played = new PlayedKimi(new ProcessLauncher())
        {
            Turn = (_, request) =>
            {
                home = request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1];
                var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];
                var marker = File.ReadAllText(Path.Combine(cwd, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
                return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
            },
        };

        GitScratch.AfterUnlink = unlinked.Add;
        try
        {
            var (_, said) = await CheckAsync(KimiSettings(string.Empty), played);

            said.GetProperty("state").GetString().Should().Be("answered", said.ToString());

            var own = Path.GetDirectoryName(home);
            var scratch = Path.GetDirectoryName(own);
            Path.GetFileName(own).Should().Be("own", "the home sits in the check's own folder");
            Path.GetFileName(home).Should().StartWith("kh-", "the one-shot home is named kh-<10 hex>");
            Path.GetFileName(scratch).Should().StartWith("coai-check-", "the home is inside the check's scratch");
            Path.GetDirectoryName(scratch).Should().Be(_temp.Path, "the scratch is a direct child of the check's temp root");

            Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the scratch, and the home inside it, are gone");
            Directory.Exists(home).Should().BeFalse("the home is gone after the check");
            unlinked.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");
            person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");
        }
        finally
        {
            GitScratch.AfterUnlink = null;
        }
```