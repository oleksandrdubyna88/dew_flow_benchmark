# Region s551-copy (test) — `AKimiConsultantCheckTests.AKimiCheck_RunsInACopy_OnAOneShotHome` (S5.5.1)

Scenario: a Kimi row, the homes root a test folder; `ConsultantCheck.RunAsync` (through `CheckAsync`) -> passed; the shim request's `--cwd` is under `<scratch>\own\tree`; `--home` is
`<root>\coai-vh\<8>\kh-<10 hex>`; the scratch repository and its canary unchanged (the check's own invariant: `markerRead` true, and the state is `answered`, not `failed` for a broken invariant).
Red before E5.4 (the class did not exist): *Expected the check of my-kimi to pass, but it failed: the vendor 'my-kimi' runs on 'kimi', which cannot hold a consultation in this build ...* — after E5.4 this test is green once filled; keep it as the pin.

Arrange: `using var person = new KimiFixture(); using var stood = KimiScenarioScopes.StandIn(person);` a `PlayedKimi` whose `Turn` reads the marker from its cwd (snippet above), `var settings = KimiSettings(_homes);`.
Act: `var (code, said) = await CheckAsync(settings, played);`
Assert:
- `code` is 0; `said.GetProperty("state").GetString()` is `"answered"` (put `said.ToString()` in the message); `markerRead` is true.
- `var shim = played.Shims.Should().ContainSingle().Subject.Request;`
- `--cwd` value (`shim.Arguments[shim.Arguments.ToList().IndexOf("--cwd") + 1]`) contains `Path.Combine("own", "tree")`; `shim.WorkingDirectory` is the same folder.
- `--home` value starts with `Path.Combine(_homes, VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar` (`using CoaiMcp.Runners.Vibe;` for `VibeHomes`), its parent folder's name is 8 characters, its file name starts with `"kh-"` and is 3 + 10 characters long.
- The `--home` is never the scratch's own folder and never under `_temp`: `home.Should().NotStartWith(_temp.Path)`.
- `Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch")`.
- The person's folder whole: `person.Hash().Should().Equal(before)`.

## The class these regions are in: `AKimiConsultantCheckTests` (file `src_mcp/tests/AKimiConsultantCheckTests.cs`)

Usings already in the file: `System.Text.Json`, `CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Server`, `FluentAssertions`, `Xunit`. Add others only if the body needs them.
The class is `[Collection("fakecli-env")] public sealed class AKimiConsultantCheckTests : IDisposable`. It already holds:

```csharp
private readonly TempDir _data = TempDir.For("testsToDelete-kcheck-data-");    // the check's DataDir
private readonly TempDir _temp = TempDir.For("testsToDelete-kcheck-temp-");    // the check's scratch parent: the check makes <_temp>\coai-check-*\ (see below)
private readonly TempDir _homes = TempDir.For("testsToDelete-kcheck-homes-");  // the homes root for the rooted tests
private readonly List<string> _warned = [];
public void Dispose();                                                          // disposes the three TempDirs (add resets of GitScratch.AfterUnlink / KimiHome.AfterUnlink here if your test arms them: they are per async flow, still reset them)

private PanelSettings KimiSettings(string homesRoot);                           // region s55-settings (a helper YOU may call from every test)
private async Task<(int Code, JsonElement Said)> CheckAsync(PanelSettings settings, PlayedKimi played)   // runs `--check-consultant --caller claude` in process; Said = the JSON the mode printed
{
    var (code, stdout, _) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", "--caller", "claude"], played, _temp, _warned.Add, Noticing.None, TestContext.Current.CancellationToken);
    return (code, JsonDocument.Parse(stdout).RootElement.Clone());
}
```

How a check works (src/Server/Consultation/ConsultantCheck.cs, E4.2 + E5.5 decision 1: no new branch): the check makes a scratch repository `<_temp>\coai-check-<...>\` holding a committed `CHECK.md`
whose text is `The check word is <marker>.` and a canary file outside the repository. For a runtime that asks (`NeedsASanitisedSnapshot`, true for `KimiConsultant`) it makes a COPY at
`<scratch root>\own\tree` (`ConsultantCheck.OwnName == "own"`) and the consultant stands in it; for a runtime that declares a `HomesFolder` (Kimi: `coai-kimi`) it reserves a ONE-SHOT home with
`VibeHomes.ReserveOneShot(settings.ConsultantHomesRoot, warn)` — `<homesRoot>\coai-vh\<8 hex>\` — and passes that folder as the launch's `OwnedScratch`; the shim's `--home` is then `<that folder>\kh-<10 hex>`.
With an EMPTY `ConsultantHomesRoot` (settings built by hand) `ReserveOneShot` answers `OneShotReservation.None` and the home folder is the place's own folder `<scratch>\own` (so `--home` is `<scratch>\own\kh-<10 hex>`).
The one-shot home is disposed in `finally` (`OneShotHome.Dispose`, junction-first through `KimiHome.DisposeAllUnder`); the scratch (with `own\`) is disposed by `ConsultCheckScratch.Delete`, also junction-first for a Kimi home.

The answer the check judges: the consultant's advice text must contain a line `marker: <the marker>` and `canary: CANNOT`. The marker is the last word of the committed `CHECK.md` without the final dot, so the played shim
reads it from its own cwd (the COPY): 

```csharp
Turn = (_, request) =>
{
    var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];                 // the copy: <scratch>\own\tree
    var marker = File.ReadAllText(Path.Combine(cwd, "CHECK.md")).Trim().Split(' ')[^1].TrimEnd('.');
    return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 19973, 31, $"marker: {marker}{Environment.NewLine}canary: CANNOT");
},
```

The JSON the mode prints (`Said`): `state` ("answered" | "failed" | ...; constants in `ConsultCheckStates`), `markerRead` (bool), `failureKind` / `failureWhat` / `failureCure` for a failure. A cancelled turn is a `failed` record whose
`failureKind` is `ConsultFailureKinds.Cancelled` (`"cancelled"`) when the caller's token ends the turn — if the mode instead throws `OperationCanceledException` for an already-cancelled token, cancel the token DURING the shim instead (below) and assert whichever the mode gives, naming it in the assertion message.

Existing similar test (Vibe; same shape, other adapter) from `ConsultantCheckTests`:

```csharp
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());                    // Text(e, n) = e.GetProperty(n).GetString() ?? ""
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
home.Should().StartWith(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder) + Path.DirectorySeparatorChar, "D1: under the short homes root, never under TEMP");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
Directory.EnumerateFileSystemEntries(Path.Combine(homes, Runners.Vibe.VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
```

The fake person and the flow's stand-ins (EVERY test in this class does this first, synchronously, before the first await):

```csharp
using var person = new KimiFixture();
using var stood = KimiScenarioScopes.StandIn(person);
var played = new PlayedKimi(new ProcessLauncher()) { Turn = ... };       // see above
var before = person.Hash();                                                // the fake person's folder, before
```
# Context shared by every region (copied from the repository at commit e50f3023)

Language: C# 14 / .NET 10, xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`, `TestContext.Current.CancellationToken`), FluentAssertions
(`using FluentAssertions;`). Tests live in `namespace CoaiMcp.Tests;` (file-scoped). The test project can see `internal` members of the product.
Style: no comment noise; one `using` list; `.Should().Be(x, "why")` with a reason. A test never runs a real `kimi` and never makes a junction outside
its own `testsToDelete-` folder. Everything a test makes outside its process is under `TempDir.For("testsToDelete-<what>-")`.

## Test helpers that exist (namespace `CoaiMcp.Tests`)

```csharp
public sealed class TempDir : IDisposable
{
    public string Path { get; }
    public static TempDir For(string prefix);              // a fresh folder under TEMP
    public static implicit operator string(TempDir directory); // -> Path
    public string At(params string[] parts);               // Path.Combine(Path, parts)
    public void Dispose();
}

// A fake person's Kimi sign-in. Folder = a testsToDelete-kimi-* folder holding everything.
public sealed class KimiFixture : IDisposable
{
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";
    public string Folder { get; }            // the folder every part of the fixture lives in
    public string PersonsHome { get; }       // the fake person's ~/.kimi-code
    public string Credentials { get; }       // PersonsHome\credentials
    public KimiPlaces PlacesAt(string ownedRoot);          // places for an owned root ANYWHERE (what KimiSeams.PlacesFor takes)
    public IReadOnlyList<string> Hash();                   // names, bytes and read-only bits of the person's folder; compare before/after
    public void Dispose();
}

// Per-flow stand-ins for a scenario driving the REAL service/check over a Kimi row (new, in src_mcp/tests/KimiScenarioScopes.cs):
internal static class KimiScenarioScopes
{
    // The measured host (Windows) + fake person + lock root + the played shim's name. Call it SYNCHRONOUSLY and `using` it, so it reaches the test's flow.
    public static IDisposable StandIn(KimiFixture person);
}

// Kimi as a scenario plays it, in process (src_mcp/tests/PlayedKimi.cs). `kimi --version` answers "kimi 2.1.1"; every launch of the shim
// (Executable == PlayedKimi.Shim) is answered with a report; every other process (git) runs for real through `inner`.
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";   // the session id the played agent mints on a first turn
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                           // one per shim launch, enqueued when it ENDS
    public ConcurrentQueue<ProcessRequest> Versions { get; }                // the `--version` launches
    public int Peak { get; }
    // What the n-th shim launch (0-based) prints. Default: an answered turn (Answered(SessionOf(request), 19973, 31)).
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }
    // Runs while a shim is "alive", after its start is stamped; a test's seam to block or to cancel.
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }
    public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default);
    public static string SessionOf(ProcessRequest request);                 // the id after --session, else Minted
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice); // exit 0
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                       // end session_lost, exit 70
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
// Create it as `new PlayedKimi(new ProcessLauncher())` (ProcessLauncher is the real one, namespace CoaiMcp.Runners.Processes).
// A failing turn for S5.5.2's second arm: `Turn = (_, request) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.

// Shim reports the shim's own writer prints (src_mcp/tests/KimiShimScripts.cs):
internal static class KimiShimScripts
{
    public static string Report(AcpEnd end = AcpEnd.Answered, string answer = CleanReview, string reason = "", string failure = "", bool tokens = true,
        IReadOnlyList<AcpReadRecord>? reads = null, IReadOnlyList<AcpToolCall>? calls = null, string session = "session-1", long tokensIn = 19973, long tokensOut = 31);
}

// Product types the tests use (namespaces: CoaiMcp.Runners.Processes, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Files, CoaiMcp.Runners.Vibe, CoaiMcp.Server, CoaiMcp.Core.QuestionConsult):
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { /* + StdIn, Environment, InheritsEnvironment, Passthrough ... */ }
public static class GitScratch   { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after the GENERIC DELETER unlinks a link
public static class KimiHome     { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after KimiHome unlinks the junction (it does, by design)
public static class VibeHomes    { public const string OneShotFolder = "coai-vh"; /* one-shot homes live at <root>\coai-vh\<8 hex>\ */ }
```

The shim's argv (built by `KimiRuntime.Build`) holds, in order: `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <home> ...`; read a value with
`request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1]` or assert `Arguments.Should().ContainInConsecutiveOrder("--home", home)`.
A Kimi one-shot or conversation home is `<owned folder>\kh-<10 hex>` (a folder named `kh-` + 10 lower-case hex digits) — never the owned folder itself.

The recorder pattern for "disposed junction-first" (from `AOneShotKimiHomeIsDisposedJunctionFirstTests`): the test class keeps
`private readonly List<string> _unlinkedByTheDeleter = [];`, arms `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` before the act, resets
`GitScratch.AfterUnlink = null;` in `Dispose()`, and asserts
`_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");`
and the fake person's folder whole: `var before = person.Hash(); ... person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");`
