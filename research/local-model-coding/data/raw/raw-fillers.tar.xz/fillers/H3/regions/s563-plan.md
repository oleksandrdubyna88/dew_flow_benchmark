# Context shared by every region (copied from the repository at commit e50f3023)

Language: C# 14 / .NET 10, xUnit v3 (`[Fact]`, `[Theory]`, `Assert.SkipUnless`, `TestContext.Current.CancellationToken`), FluentAssertions
(`using FluentAssertions;`). Tests live in `namespace CoaiMcp.Tests;` (file-scoped). The test project can see `internal` members of the product.
Style: no comment noise; one `using` list; `.Should().Be(x, "why")` with a reason. A test never runs a real `kimi` and never makes a junction outside
its own `testsToDelete-` folder. Everything a test makes outside its process is under `TempDir.For("testsToDelete-<what>-")`.

## Test helpers that exist (namespace `CoaiMcp.Tests`)

```csharp
public sealed class TempDir : IDisposable
{
    public string Path { get; }
    public static TempDir For(string prefix);              // a fresh folder under TEMP
    public static implicit operator string(TempDir directory); // -> Path
    public string At(params string[] parts);               // Path.Combine(Path, parts)
    public void Dispose();
}

// A fake person's Kimi sign-in. Folder = a testsToDelete-kimi-* folder holding everything.
public sealed class KimiFixture : IDisposable
{
    public const string RefreshCanary = "CANARY-REFRESH-7f3a0c keep my sign-in private";
    public string Folder { get; }            // the folder every part of the fixture lives in
    public string PersonsHome { get; }       // the fake person's ~/.kimi-code
    public string Credentials { get; }       // PersonsHome\credentials
    public KimiPlaces PlacesAt(string ownedRoot);          // places for an owned root ANYWHERE (what KimiSeams.PlacesFor takes)
    public IReadOnlyList<string> Hash();                   // names, bytes and read-only bits of the person's folder; compare before/after
    public void Dispose();
}

// Per-flow stand-ins for a scenario driving the REAL service/check over a Kimi row (new, in src_mcp/tests/KimiScenarioScopes.cs):
internal static class KimiScenarioScopes
{
    // The measured host (Windows) + fake person + lock root + the played shim's name. Call it SYNCHRONOUSLY and `using` it, so it reaches the test's flow.
    public static IDisposable StandIn(KimiFixture person);
}

// Kimi as a scenario plays it, in process (src_mcp/tests/PlayedKimi.cs). `kimi --version` answers "kimi 2.1.1"; every launch of the shim
// (Executable == PlayedKimi.Shim) is answered with a report; every other process (git) runs for real through `inner`.
internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher
{
    public const string Shim = "played-coai-mcp";
    public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";   // the session id the played agent mints on a first turn
    public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
    public ConcurrentQueue<Launch> Shims { get; }                           // one per shim launch, enqueued when it ENDS
    public ConcurrentQueue<ProcessRequest> Versions { get; }                // the `--version` launches
    public int Peak { get; }
    // What the n-th shim launch (0-based) prints. Default: an answered turn (Answered(SessionOf(request), 19973, 31)).
    public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }
    // Runs while a shim is "alive", after its start is stamped; a test's seam to block or to cancel.
    public Func<ProcessRequest, CancellationToken, Task> During { get; init; }
    public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default);
    public static string SessionOf(ProcessRequest request);                 // the id after --session, else Minted
    public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice); // exit 0
    public static ProcessResult Uncaptured(string session, string answer = Advice);
    public static ProcessResult Lost(string session);                       // end session_lost, exit 70
    public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
}
// Create it as `new PlayedKimi(new ProcessLauncher())` (ProcessLauncher is the real one, namespace CoaiMcp.Runners.Processes).
// A failing turn for S5.5.2's second arm: `Turn = (_, request) => new ProcessResult(70, string.Empty, "the played agent failed", TimedOut: false)`.

// Shim reports the shim's own writer prints (src_mcp/tests/KimiShimScripts.cs):
internal static class KimiShimScripts
{
    public static string Report(AcpEnd end = AcpEnd.Answered, string answer = CleanReview, string reason = "", string failure = "", bool tokens = true,
        IReadOnlyList<AcpReadRecord>? reads = null, IReadOnlyList<AcpToolCall>? calls = null, string session = "session-1", long tokensIn = 19973, long tokensOut = 31);
}

// Product types the tests use (namespaces: CoaiMcp.Runners.Processes, CoaiMcp.Runners.Kimi, CoaiMcp.Runners.Files, CoaiMcp.Runners.Vibe, CoaiMcp.Server, CoaiMcp.Core.QuestionConsult):
public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);
public sealed record ProcessRequest(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory) { /* + StdIn, Environment, InheritsEnvironment, Passthrough ... */ }
public static class GitScratch   { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after the GENERIC DELETER unlinks a link
public static class KimiHome     { internal static Action<string>? AfterUnlink { get; set; } }   // TEST ONLY, per async flow: runs after KimiHome unlinks the junction (it does, by design)
public static class VibeHomes    { public const string OneShotFolder = "coai-vh"; /* one-shot homes live at <root>\coai-vh\<8 hex>\ */ }
```

The shim's argv (built by `KimiRuntime.Build`) holds, in order: `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <home> ...`; read a value with
`request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1]` or assert `Arguments.Should().ContainInConsecutiveOrder("--home", home)`.
A Kimi one-shot or conversation home is `<owned folder>\kh-<10 hex>` (a folder named `kh-` + 10 lower-case hex digits) — never the owned folder itself.

The recorder pattern for "disposed junction-first" (from `AOneShotKimiHomeIsDisposedJunctionFirstTests`): the test class keeps
`private readonly List<string> _unlinkedByTheDeleter = [];`, arms `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` before the act, resets
`GitScratch.AfterUnlink = null;` in `Dispose()`, and asserts
`_unlinkedByTheDeleter.Should().BeEmpty("the deleter's unlink recorder must not be invoked, because KimiHome unlinks the junction first");`
and the fake person's folder whole: `var before = person.Hash(); ... person.Hash().Should().Equal(before, "the person's folder: the same names, bytes and read-only bits as before");`
# Region s563-plan (test) — `ConfinementPlannerTests.ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb` (S5.6.3), file `src_mcp/tests/ConfinementPlannerTests.cs`

Usings in the file: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit`.
Constants and helper already in the class:

```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;   // fails if the planner refuses
```

Existing types (namespace `CoaiMcp.Core.QuestionConsult`):

```csharp
public enum CwdKind { Scratch, Root, Snapshot }
public abstract record Confinement
{
    public sealed record Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags,
        CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement
    { public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
    public sealed record Refused(string Reason) : Confinement;
}
public static class ConfinementPlanner { public static Confinement Plan(string runtime, CapabilityGrant grant); }
public sealed record CapabilityGrant(Capability Capability, IReadOnlyList<string> Roots)
{ public static CapabilityGrant None { get; } public static CapabilityGrant Web { get; } public static CapabilityGrant Disk(params string[] roots); }
```

What the planner gives for kimi now (already written, `ConfinementPlanner.Kimi`): `none` -> `Planned("kimi", grant, [], [], CwdKind.Scratch, [], flag)`;
`disk` -> `Planned("kimi", grant, [], [], CwdKind.Snapshot, [], flag) { SnapshotSources = grant.Roots }`, `flag` = `AdmissionFlag.Unconfined` for both;
`web` -> `Confinement.Refused` from the matrix, whose reason contains "not been measured" and the record named by the row's resultRef: "research/RESULTS_kimi_confinement.md".

Similar existing test (Vibe, same file):

```csharp
var none = Plan("vibe", CapabilityGrant.None);
none.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
none.Cwd.Should().Be(CwdKind.Scratch);
none.AddDirs.Should().BeEmpty();
var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
disk.Cwd.Should().Be(CwdKind.Snapshot, "...");
disk.AddDirs.Should().BeEmpty("AddDirs are launch flags, and Vibe is never given --add-dir (D3)");
disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
none.SnapshotSources.Should().BeEmpty();
```

Body to write: the same for kimi — `Leading`, `Flags`, `AddDirs` all `BeEmpty` on both (reason: Kimi's confinement is the shim's, D15, not its argv), `Flag` is `AdmissionFlag.Unconfined`;
none: `Cwd` `CwdKind.Scratch`, `SnapshotSources` empty; disk: `Cwd` `CwdKind.Snapshot`, `SnapshotSources` equal `[RootA, RootB]`. Then
`ConfinementPlanner.Plan("kimi", CapabilityGrant.Web).Should().BeOfType<Confinement.Refused>().Which.Reason.Should().Contain("not been measured").And.Contain("RESULTS_kimi_confinement.md");`.
Red before the change: *Expected plan.Cwd to be CwdKind.Snapshot, but found CwdKind.Scratch.* (the default arm).
