# Context pack — region `s55-settings` (test helper) — src_mcp/tests/AKimiConsultantCheckTests.cs, `private PanelSettings Settings(string homesRoot)`

You can NOT read the repository. Everything you need is in this file. Repository root: `/home/jinx/git/coai-exp/arm-Q2` (you only write the body between the QWEN-FILL markers).
Rules that hold for every body: C# 14 / .NET 10, `TreatWarningsAsErrors`; cyclomatic complexity <= 4 per method (extract helpers into the same class, each as a small private method if needed);
FluentAssertions `.Should()` with a reason string; xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`); never `dotnet test`; anything a test makes outside its process is named `testsToDelete-<what>-`
(use `TempDir.For("testsToDelete-…")`); no test makes a junction outside its own testsToDelete- folder; no path, name or token of a real machine. Remove the FILL markers and the placeholder `throw` when you fill; keep the method's signature.

Class fields available: `_data` (TempDir), `_homes` (TempDir), `_temp` (TempDir). Use `_data.Path` for DataDir.

### The check, in process (src_mcp/src/Server/Consultation/ConsultantCheckMode.cs, namespace CoaiMcp.Server)
```csharp
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct)
```
`Noticing.None` (CoaiMcp.Server) is the no-op notice. `tempRoot` is the folder the check makes its scratch (`coai-check-*`) in.
The stdout JSON has `state` (CoaiMcp.Server.ConsultCheckStates: Checking "checking", Answered "answered", Failed "failed", Unavailable "unavailable", AlreadyChecking, Abandoned, Unreadable),
`markerRead` (bool), and on a failed check `failureKind`, `failureWhat`, `failureCure`. `ConsultFailureKinds.Cancelled == "cancelled"` (namespace CoaiMcp.Runners.Consultation).

### PanelSettings / ConsultantChoice (namespace CoaiMcp.Server)
```csharp
public sealed record PanelSettings   // object initialiser; properties used here:
  IReadOnlyList<...> Providers;  string DataDir;  TimeSpan ReviewerTimeout;  bool ConsultEnabled = true;
  string ConsultantHomesRoot = string.Empty;   // the homes root: a one-shot Kimi home goes under <root>\coai-vh\<8 hex>; EMPTY = root-less (the home is under <scratch>\own)
  IReadOnlyDictionary<string, ConsultantChoice> Consultants;
public sealed record ConsultantChoice(string Vendor, string Model = "", string Runtime = "", string BaseUrl = "", string ExecutablePath = "", string Row = "")
```
`CallerIdentity.Claude` is the dictionary key the check reads for `--caller claude`. `VibeHomes.OneShotFolder == "coai-vh"` (namespace CoaiMcp.Runners.Vibe).

### The model test (src_mcp/tests/ConsultantCheckTests.cs — a Vibe check, the shape to follow)
```csharp
var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
{
    AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
};
using var homes = TempDir.For("testsToDelete-vh-check-");
var settings = Settings() with
{
    ConsultantHomesRoot = homes,
    Consultants = new Dictionary<string, ConsultantChoice>
    {
        [CallerIdentity.Claude] = new("mistral", Model: "glm-5-3", Runtime: "vibe", ExecutablePath: PlayedVibe.Exe),
    },
};
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty("the copy goes with the check's scratch");
Directory.EnumerateFileSystemEntries(Path.Combine(homes, VibeHomes.OneShotFolder)).Should().BeEmpty("the home's folder goes when the check ends");
```
Here the played launcher does NOT see the marker through a `Files` map: the played Kimi shim's request carries `--cwd <the copy>` and `WorkingDirectory` = the copy, so the Kimi `Turn`
reads `File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md"))` while the check is running (the copy exists until the check ends). The marker is the last word of CHECK.md's first line, minus a trailing full stop,
as in the Vibe test above. The shim's argv (built by KimiRuntime.Build): `--ask-acp --profile kimi --model <model> --cwd <cwd> --home <ownedRoot>\kh-<10 hex>` (the check's home flag value is the owned root `kh-<10 hex>` folder).
