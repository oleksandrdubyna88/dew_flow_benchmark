# Context pack — region `s55-standin` (test helper) — src_mcp/tests/AKimiConsultantCheckTests.cs, `private static IDisposable StandIn(KimiFixture person)`

You can NOT read the repository. Everything you need is in this file. Repository root: `/home/jinx/git/coai-exp/arm-Q2` (you only write the body between the QWEN-FILL markers).
Rules that hold for every body: C# 14 / .NET 10, `TreatWarningsAsErrors`; cyclomatic complexity <= 4 per method (extract helpers into the same class, each as a small private method if needed);
FluentAssertions `.Should()` with a reason string; xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`); never `dotnet test`; anything a test makes outside its process is named `testsToDelete-<what>-`
(use `TempDir.For("testsToDelete-…")`); no test makes a junction outside its own testsToDelete- folder; no path, name or token of a real machine. Remove the FILL markers and the placeholder `throw` when you fill; keep the method's signature.

Return the stand-in scope described below. The method is static and takes the fake person. Do NOT include a `CallingAs` member.

### The stand-in to copy (from src_mcp/tests/AKimiConsultationScenarioTests.cs)
```csharp
/// <summary>Several scopes, given back in reverse.</summary>
private sealed class Scopes(params IDisposable[] scopes) : IDisposable
{
    public void Dispose()
    {
        foreach (var scope in scopes.Reverse())
        {
            scope.Dispose();
        }
    }
}

private static Scopes StandIn(KimiFixture person) => new(
    WindowsStandIn.Begin(),
    KimiCredentialsLock.RootFor(Path.Combine(person.Folder, "locks")),
    KimiSeams.Using(HostKind.Windows, new KimiSeams(person.PlacesAt, () => (PlayedKimi.Shim, []))),
    CallingAs("CLAUDE_CODE_SESSION_ID"));   // <- OMIT this line: the check/row tests here do not use CallingAs
```
Signatures: `KimiCredentialsLock.RootFor(string folder)` returns IDisposable (namespace CoaiMcp.Runners.Kimi); `KimiSeams.Using(HostKind host, KimiSeams seams)` returns IDisposable;
`public sealed record KimiSeams(Func<string, KimiPlaces> PlacesFor, Func<(string Executable, IReadOnlyList<string> Prefix)> Shim)`; `HostKind` is in CoaiMcp.Runners.Platform.
The nested `Scopes` class goes INSIDE the test class; the file's usings already name every namespace used here.

### KimiFixture (src_mcp/tests/KimiFixture.cs, internal sealed class, IDisposable, namespace CoaiMcp.Tests) — a fake person's Kimi sign-in in its own testsToDelete-kimi- folder
```csharp
public KimiFixture(string? config = null)
public string Folder { get; }            // the fixture's root folder
public string PersonsHome { get; }       // <Folder>/persons/.kimi-code
public string Credentials { get; }       // <PersonsHome>/credentials
public KimiPlaces PlacesAt(string ownedRoot)   // the places for an owned root ANYWHERE
public IReadOnlyList<string> Hash()      // every entry of the person's folder: path, attributes, SHA-256 of bytes — "whole" means unchanged
public void Dispose()
```
`TempDir` (src_mcp/tests/TempDir.cs, public sealed class, IDisposable): `static TempDir For(string prefix)`, `string Path`, `string At(params string[] parts)`, implicit conversion to string, `Dispose()`.
`WindowsStandIn.Begin()` (internal static, namespace CoaiMcp.Tests) returns an IDisposable (nothing on Windows; a stand-in for the Windows host elsewhere).
`GitScratch.AfterUnlink` (namespace CoaiMcp.Runners.Files, `internal static Action<string>? AfterUnlink { get; set; }`, per async flow): invoked each time the DELETER unlinks a link. A Kimi home disposed junction-first never lets the deleter meet its junction, so a recorder assigned here (`GitScratch.AfterUnlink = list.Add`) must stay empty. Reset it to null in Dispose.
