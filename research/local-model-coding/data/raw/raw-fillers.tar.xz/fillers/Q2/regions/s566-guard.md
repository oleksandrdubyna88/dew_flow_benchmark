# Context pack — region `s566-guard` (prod) — src_mcp/runners/Kimi/KimiConsultant.cs, `internal static void MustCarryNoFlags(ConsultantLaunch launch)`

You can NOT read the repository. Everything you need is in this file. Repository root: `/home/jinx/git/coai-exp/arm-Q2` (you only write the body between the QWEN-FILL markers).
Rules that hold for every body: C# 14 / .NET 10, `TreatWarningsAsErrors`; cyclomatic complexity <= 4 per method (extract helpers into the same class, each as a small private method if needed);
FluentAssertions `.Should()` with a reason string; xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`); never `dotnet test`; anything a test makes outside its process is named `testsToDelete-<what>-`
(use `TempDir.For("testsToDelete-…")`); no test makes a junction outside its own testsToDelete- folder; no path, name or token of a real machine. Remove the FILL markers and the placeholder `throw` when you fill; keep the method's signature.

```csharp
namespace CoaiMcp.Runners.Kimi;
public sealed class KimiConsultant(KimiRuntime inner, string vendor = "kimi") : IConsultantRuntime
{
    public ReviewerInvocation Build(ConsultantLaunch launch)
    {
        ConsultantLaunches.MustBeLaunchable(launch);       // <- add `MustCarryNoFlags(launch);` right after this line
        var settings = launch.Settings with { OwnedScratch = OwnedFolder(launch), Model = ModelOf(launch.Settings) };
        ...
    }
    private static string OwnedFolder(ConsultantLaunch launch) => launch.Settings.OwnedScratch.Length > 0 ? launch.Settings.OwnedScratch : throw new ArgumentException("a Kimi consultant keeps its home in …", nameof(launch));
}
// CoaiMcp.Runners.Consultation:
public abstract record LaunchConfinement { public sealed record Planned(Confinement.Planned Plan) : LaunchConfinement; /* ... */ }
// CoaiMcp.Core.QuestionConsult:
public sealed record Confinement.Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags, CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag)
```
Body: `if (launch.Confinement is LaunchConfinement.Planned { Plan: var plan } && (plan.Leading.Count > 0 || plan.Flags.Count > 0)) { throw new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(launch)); }`
Complexity <= 4: it has one `if` with an `&&` and an `||` — if your tool counts that as 4, fine; otherwise extract `HasFlags(Confinement.Planned plan) => plan.Leading.Count + plan.Flags.Count > 0`.
The usings of the file already include CoaiMcp.Core.QuestionConsult and CoaiMcp.Runners.Consultation. Remove the FILL markers and the throw; then add the call in `Build` as stated (the call is part of this region's job).
Every planned launch the planner makes for kimi has Leading and Flags empty (ConfinementPlanner.Kimi), so the existing question-row paths keep working.
