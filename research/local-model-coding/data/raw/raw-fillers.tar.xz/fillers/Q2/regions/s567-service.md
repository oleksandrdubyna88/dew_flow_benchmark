# Context pack — region `s567-service` (test helper) — src_mcp/tests/AKimiQuestionRowTests.cs, `Service(PlayedKimi played, string homesRoot, params string[] roots)`

You can NOT read the repository. Everything you need is in this file. Repository root: `/home/jinx/git/coai-exp/arm-Q2` (you only write the body between the QWEN-FILL markers).
Rules that hold for every body: C# 14 / .NET 10, `TreatWarningsAsErrors`; cyclomatic complexity <= 4 per method (extract helpers into the same class, each as a small private method if needed);
FluentAssertions `.Should()` with a reason string; xUnit v3 (`Assert.SkipUnless`, `TestContext.Current.CancellationToken`); never `dotnet test`; anything a test makes outside its process is named `testsToDelete-<what>-`
(use `TempDir.For("testsToDelete-…")`); no test makes a junction outside its own testsToDelete- folder; no path, name or token of a real machine. Remove the FILL markers and the placeholder `throw` when you fill; keep the method's signature.

Class fields: `_dir` (TempDir), `_launcher`. Return the PanelService (the model's `ServiceFor`, with the Kimi row below).

### The model: src_mcp/tests/AVibeQuestionRowReadsACopyOfItsRootsTests.cs (same harness for Vibe)
```csharp
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}

private PanelService ServiceFor(PlayedVibe vibe, string homesRoot, string model, params string[] roots) => new(
    new PanelSettings
    {
        ConsultantHomesRoot = homesRoot,
        Providers = [],
        Rounds = PanelConfig.Uniform(3, 2, StagePolicy.Human),
        DataDir = _dir.At("data"),
        ReviewerTimeout = TimeSpan.FromSeconds(30),
        QuestionConsult = new QuestionConsultSettings
        {
            Rows = [new QuestionRow("vibe-disk", "mistral", "vibe", model, string.Empty, PlayedVibe.Exe, string.Empty, "question-disk", Enabled: true)],
            Roots = roots,
            RowBudget = TimeSpan.FromSeconds(30),
        },
    },
    VaultKeys.None("no vault in tests"),
    default,
    vibe,
    Logger.None,
    Noticing.None);

private async Task<JsonElement> AskAsync(PanelService service, CancellationToken? ct = null) =>
    JsonDocument.Parse(await service.AskConsultantsAsync(
        Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: ct ?? TestContext.Current.CancellationToken)).RootElement;

private static JsonElement TheRow(JsonElement reply)
{
    reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());
    return answers.EnumerateArray().Should().ContainSingle().Subject;
}

// a test of that class:
var vibe = new PlayedVibe(_launcher, Advice);
var granted = Path.Combine(Repo, "src");
var reply = await AskAsync(Service(vibe, granted));
TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());
var turn = vibe.Turns.Should().ContainSingle().Subject;
var copy = Path.Combine(turn.Request.WorkingDirectory, turn.Files.Keys.Single().Split('/')[0]);
turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy Vibe can read");
turn.Request.StdIn.Should().NotContain(granted, "never the original, which it cannot read (M-V11)");
Directory.Exists(RowFolderOf(turn.Request)).Should().BeFalse("the row's home and copy are gone once it answered");
```
Types: `QuestionRow(string Id, string Vendor, string Runtime, string Model, string BaseUrl, string ExecutablePath, string Key, string Prompt, bool Enabled, string Row = "")` and
`QuestionConsultSettings { Rows, Roots, RowBudget }` (namespace CoaiMcp.Core.QuestionConsult); `PanelConfig.Uniform(3, 2, StagePolicy.Human)` (CoaiMcp.Core.Rounds);
`new PanelService(PanelSettings settings, VaultKeys keys, DateTime vaultReadUtc, IProcessLauncher launcher, Serilog.ILogger log, Noticing noticing)` (CoaiMcp.Server); `Logger.None` is Serilog.Core.Logger;
`Task<string> PanelService.AskConsultantsAsync(string repoPath, string question, string context, string document = "", string feature = "", CancellationToken ct = default)`;
`RowOutcomes` (CoaiMcp.Core.QuestionConsult) constants: Answered "answered", TimedOut "timed_out", Failed "failed", Refused "refused", Blocked "blocked", Disabled "disabled".
The Kimi Vibe-difference: the row is `new QuestionRow("kimi-disk", "my-kimi", "kimi", string.Empty, string.Empty, string.Empty, string.Empty, "question-disk", Enabled: true)` (no executable path — the seams' shim runs), the launcher is a `PlayedKimi`, and the flow stands in with `StandIn(_person)`.
Where the Vibe class reads the home from the request's environment, the Kimi row's home is the shim argv's `--home` (under the row's one-shot folder `<Homes>\coai-vh\<8>\kh-<10 hex>`) and the row folder is the parent of the `--cwd`/WorkingDirectory tree (the row's scratch).

### PlayedKimi (src_mcp/tests/PlayedKimi.cs, namespace CoaiMcp.Tests, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`)
```csharp
public const string Shim = "played-coai-mcp";            // the shim's executable as the seams name it
public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666"; // the session id a first turn gets
public const string Advice = "Your parser counts the separator as a field. Check it with a two-field input.";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }              // every shim launch, enqueued when it ENDS
public ConcurrentQueue<ProcessRequest> Versions { get; }   // every "kimi --version"
public int Peak { get; }
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; } // n-th shim launch (0-based) -> what it prints; default: Answered(SessionOf(request), 19973, 31)
public Func<ProcessRequest, CancellationToken, Task> During { get; init; } // runs while the shim is "alive", before Turn
public static string SessionOf(ProcessRequest request)     // the --session value, else Minted
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice)
public static ProcessResult Uncaptured(string session, string answer = Advice)
public static ProcessResult Lost(string session)           // end session_lost, exit 70
public Task<ProcessResult> RunAsync(ProcessRequest request, CancellationToken ct = default) // "--version" -> kimi 2.1.1; Shim -> played; anything else -> inner (git runs for real)
```
Construct it as `new PlayedKimi(new ProcessLauncher())` (CoaiMcp.Runners.Processes.ProcessLauncher; it is also an IProcessLauncher).
