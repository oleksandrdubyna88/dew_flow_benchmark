# s568-kimi-admit (test, TypeScript) — src_vs_code/src/test/capabilityAdmission.test.ts, last test

Imports already at the top of the file:
```ts
import assert from 'node:assert/strict';
import { admit, CAPABILITIES, isCapability, STANDINGS } from '../capabilityAdmission';
import { RUNTIME_CAPABILITIES, RUNTIMES } from '../runtimeCapabilities.generated';
```
`admit` (src_vs_code/src/capabilityAdmission.ts):
```ts
export type AdmissionFlag = '' | 'unconfined' | 'default-deny';
export interface Admission {
  readonly admitted: boolean;
  readonly standing: CapabilityStanding | '';   // the row's standing; '' when no row
  readonly flag: AdmissionFlag;
  readonly reason: string;                      // '' when admitted
  readonly caveat: string;
}
export function admit(runtime: string, capability: string): Admission
```
Caveats: `unconfined` → `'unconfined: can read this machine — a shell is always there, and no flag removes it'`; confined → `''`.
An unmeasured pair's reason (from the table, already generated): `'kimi' has not been measured for 'web' (not measured: …) — a measured cell in research/RESULTS_kimi_confinement.md is what admits it; until then give this row a prompt of another capability`.

Similar existing test in the same file:
```ts
test('a flagged admission carries the caveat a person must acknowledge (D13)', () => {
  assert.match(admit('codex', 'web').caveat, /can read this machine/u);
  assert.equal(admit('claude', 'web').caveat, '', 'a confined pair has nothing to acknowledge');
});
```
Body: loop over `['none','disk']`: admitted true (message `x.reason`), standing `'unconfined'`, flag `'unconfined'`, caveat matches `/can read this machine/u`.
For `web`: admitted false, standing `'unmeasured'`, reason matches `/not been measured/u` and `/RESULTS_kimi_confinement\.md/u`, and does NOT include `RESULTS_question_consultant_capabilities.md`.
Red before the table had kimi: `'kimi' is not a runtime the question consultant can launch`. Run: `cd src_vs_code && node ../.agents/conventions/tools/low-priority.mjs npm test`.
