# s564-admit (test) — src_mcp/tests/CapabilityMatrixTests.cs, `AdmissionFlagsBothRows`

Namespace `CoaiMcp.Tests`; usings: `System.Text.Json`, `CoaiMcp.Core.QuestionConsult`, `FluentAssertions`, `Xunit`.
```csharp
// CoaiMcp.Core.QuestionConsult
public static Admission CapabilityMatrix.Admit(string runtime, Capability capability)
public abstract record Admission { Admitted(CapabilityStanding Standing, AdmissionFlag Flag) ; Refused(string Reason) }   // as used below
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
```
Similar existing test in the same class:
```csharp
foreach (var capability in Enum.GetValues<Capability>())
{
    CapabilityMatrix.Admit("codex", capability).Should().BeOfType<Admission.Admitted>()
        .Which.Flag.Should().Be(AdmissionFlag.Unconfined, $"codex × {capability}: F2");
}
```
Body: for `[Capability.None, Capability.Disk]` assert `CapabilityMatrix.Admit("kimi", capability)` is `Admission.Admitted` whose `.Flag` is `AdmissionFlag.Unconfined` (message `$"kimi × {capability}: Grep and Glob read the disk (M-K6)"`).
Red before the rows existed: `Refused "'kimi' is not a runtime the question consultant can launch …"`.
