# s554-rootless (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `ARootlessCheck_KeepsTheHomeInItsScratch_AndDisposesItJunctionFirst`

Read `s551-copy.md` first (class, helpers, `PlayedKimi`, `Check`, `StandIn`).
"Settings built by hand" = `Settings(string.Empty)`: `ConsultantHomesRoot` empty, so `VibeHomes.ReserveOneShot(settings.ConsultantHomesRoot, warn)` is not reached for a
reservation (check `ConsultantCheck.TurnAsync`: with an empty root it returns a non-`Reserved` reservation and the home is `place.Folder` = `<scratch>\own`), and the home is
`<scratch>\own\kh-<10 hex>`; `ConsultCheckScratch.Delete` disposes `<root>\own` junction-first (E5.3 g, `ConsultantCheck.OwnName == "own"`).
`ConsultantCheckMode.MissingRoot` (private) refuses a NON-EMPTY root that does not exist with exit 74; an empty root is not refused, as far as `PanelSettings.NamedRootRefusal` goes —
if the first run answers 74, note it in the notes file and use a homes root that is empty-by-name another way; do not weaken the assertion.
Body: `using var stood = StandIn(); RecordingTheDeleter(); var before = _person.Hash();` the played shim answers as in s551 (needs the marker);
`await Check(Settings(string.Empty), played, TestContext.Current.CancellationToken)`.
Assert: `home` = the argument after `"--home"` of the one shim request: `Path.GetFileName(Path.GetDirectoryName(home))` Be `"own"`, `Path.GetFileName(home)` MatchRegex `^kh-[0-9a-f]{10}$`;
`Directory.EnumerateDirectories(_temp, "coai-check-*")` BeEmpty (the scratch is gone); `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)`.
Red before E5.3 g: *Expected the deleter's unlink recorder not to be invoked …*.
