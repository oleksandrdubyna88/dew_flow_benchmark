# s563-planner (test) — src_mcp/tests/ConfinementPlannerTests.cs, `ThePlannerArm_IsACopyForDisk_AnEmptyFolderForNone_AndRefusesWeb`

Namespace `CoaiMcp.Tests`; usings: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit`.
Constants and helper in the class:
```csharp
private const string RootA = "D:/projects/alpha";
private const string RootB = "D:/projects/beta";
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant) =>
    ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Planned>().Which;
```
Existing types (`CoaiMcp.Core.QuestionConsult`):
```csharp
public static Confinement ConfinementPlanner.Plan(string runtime, CapabilityGrant grant)
public sealed record Confinement.Planned(string Runtime, CapabilityGrant Grant, IReadOnlyList<string> Leading, IReadOnlyList<string> Flags,
    CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag) { public IReadOnlyList<string> SnapshotSources { get; init; } }
public sealed record Confinement.Refused(string Reason)
public enum CwdKind { Scratch, Root, Snapshot }
public enum AdmissionFlag { None, Unconfined, DefaultDeny }
CapabilityGrant.None   CapabilityGrant.Web   CapabilityGrant.Disk(params string[] roots)
```
Similar existing test (Vibe):
```csharp
var disk = Plan("vibe", CapabilityGrant.Disk(RootA, RootB));
disk.Flags.Should().Equal("--agent", "plan", "--enabled-tools", "read_file");
disk.Cwd.Should().Be(CwdKind.Snapshot, "…");
disk.AddDirs.Should().BeEmpty("…");
disk.SnapshotSources.Should().Equal([RootA, RootB], "…");
```
Refusal shape, from the theory in the same file: `ConfinementPlanner.Plan(runtime, grant).Should().BeOfType<Confinement.Refused>().Which.Reason.Should().Contain(says, "…")`.
Already written in production: arm `"kimi" => Kimi(grant, flag)`; disk → Snapshot with `SnapshotSources = grant.Roots`, none → Scratch, no flags, flag `Unconfined` (from the matrix row). Web → `Refused` by the matrix, naming "not been measured" and `research/RESULTS_kimi_confinement.md`.
