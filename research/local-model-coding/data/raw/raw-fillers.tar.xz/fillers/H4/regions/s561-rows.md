# s561-rows (test) — src_mcp/tests/CapabilityMatrixTests.cs, `KimiHasThreeRows_EachCitingItsCells`

Namespace `CoaiMcp.Tests`; usings: `System.Text.Json`, `CoaiMcp.Core.QuestionConsult`, `FluentAssertions`, `Xunit`.
Existing types (`CoaiMcp.Core.QuestionConsult`):
```csharp
public enum Capability { None, Disk, Web }
public enum CapabilityStanding { Confined, Unconfined, DefaultDeny, Unsupported, Unmeasured }
public sealed record MeasuredWith(string Cli, string Version, string Date, string ResultRef, IReadOnlyList<string> Cells, string Note);
public sealed record RuntimeCapabilityRow(string Runtime, Capability Capability, CapabilityStanding Standing, MeasuredWith MeasuredWith);
public static RuntimeCapabilities RuntimeCapabilities.Builtin { get; }
public RuntimeCapabilityRow? RuntimeCapabilities.Of(string runtime, Capability capability)
```
Similar existing test in the same class (Vibe rows):
```csharp
foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
{
    var row = RuntimeCapabilities.Builtin.Of("vibe", capability)!;
    row.MeasuredWith.ResultRef.Should().Contain("RESULTS_vibe_confinement.md");
    row.MeasuredWith.Cells.Should().NotBeEmpty($"vibe × {capability} stands on measured cells");
}
RuntimeCapabilities.Builtin.Of("vibe", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-V6", "…");
```
The data (written): kimi none → unconfined, cells `M-K6, M-K3, M-K4`; disk → unconfined, cells `M-K6, M-K3, M-K4, M-K9, M-K9e`; web → unmeasured, cells `[]`; version "2.1.1", cli "kimi", date "2026-10-13", resultRef cites `research/RESULTS_kimi_confinement.md`.
Assert also `row.MeasuredWith.ResultRef` Contain "RESULTS_kimi_confinement.md" for all three.
