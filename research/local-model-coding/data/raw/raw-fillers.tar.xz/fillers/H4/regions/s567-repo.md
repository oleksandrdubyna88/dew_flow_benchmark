# s567-repo (test helper) — src_mcp/tests/AKimiQuestionRowTests.cs, `RepositoryAsync`

Class `AKimiQuestionRowTests : IAsyncLifetime` (namespace `CoaiMcp.Tests`; usings include `CoaiMcp.Runners.Processes`, `FluentAssertions`, `Xunit`). Field: `private readonly ProcessLauncher _launcher = new();`.
Signature (already in the file): `private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)`.
Copy of the existing helper in `AVibeQuestionRowReadsACopyOfItsRootsTests.cs`:
```csharp
private async Task RepositoryAsync(string at, params (string Path, string Text)[] files)
{
    Directory.CreateDirectory(at);
    foreach (var (path, text) in files)
    {
        var full = Path.Combine([at, .. path.Split('/')]);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, text, TestContext.Current.CancellationToken);
    }

    foreach (var args in (string[][])[["init", "-b", "main"], ["config", "user.email", "t@example.com"], ["config", "user.name", "t"], ["add", "."], ["commit", "-m", "base"]])
    {
        var result = await _launcher.RunAsync(new ProcessRequest("git", args, at), TestContext.Current.CancellationToken);
        result.ExitCode.Should().Be(0, string.Join(' ', args) + ": " + result.StdErr);
    }
}
```
`ProcessRequest("git", args, at)` = `(string Executable, IReadOnlyList<string> Arguments, string WorkingDirectory)`; `ProcessLauncher.RunAsync(ProcessRequest, CancellationToken)` returns `ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`.
Write it exactly like this (the one thing to check: the parameter named `Path` of the tuple shadows `System.IO.Path` only in the tuple element name — `Path.Combine` inside the body is the class).
