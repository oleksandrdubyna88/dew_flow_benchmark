# s566-flags (test) — src_mcp/tests/ConfinementPlannerTests.cs, `APlanWithFlags_IsRefusedForKimi`

Same fixtures as the pack `s565-launch.md` (helpers `Plan`, `Planned`, `Adapters()`, `RowFolder`, `RowTree`, `Scratch`).
Needed beyond them:
```csharp
// CoaiMcp.Core.QuestionConsult — sealed records, so `with` works
Confinement.Planned plan = Plan("kimi", CapabilityGrant.None) with { Flags = ["--yolo"] };
// CoaiMcp.Runners.Consultation
public sealed record LaunchConfinement.Planned(Confinement.Planned Plan) : LaunchConfinement;
ConsultantLaunch is a positional record with init members (`with { Confinement = … }` works — the file already does `launch with { Workdir = RowTree, Settings = … }`).
```
Production (already in the skeleton): `KimiConsultant.Build` calls `MustCarryNoFlags(planned.Plan)` first, which throws `ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", …)` once its fill is in.
Test: `var consultant = Adapters().Single(a => a.Runtime == "kimi").Consultant; var build = () => consultant.Build(launch); build.Should().Throw<ArgumentException>().WithMessage("*shim*");`
Today's red (skeleton, before the prod fill): `NotImplementedException` ("s566-noflags"); the plan's red for no check: *Expected a <System.ArgumentException> to be thrown, but no exception was thrown.*
