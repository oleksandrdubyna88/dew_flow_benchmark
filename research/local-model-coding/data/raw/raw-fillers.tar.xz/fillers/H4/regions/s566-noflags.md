# s566-noflags (prod) — src_mcp/runners/Kimi/KimiConsultant.cs, method `MustCarryNoFlags`

File: `src_mcp/runners/Kimi/KimiConsultant.cs`, namespace `CoaiMcp.Runners.Kimi`. Usings already there: `CoaiMcp.Core.Consultation`,
`CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Acp`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Reviewers`.

The caller (already written, in `Build`):
```csharp
if (launch.Confinement is LaunchConfinement.Planned planned)
{
    MustCarryNoFlags(planned.Plan);
}
```
The method to fill:
```csharp
private static void MustCarryNoFlags(Confinement.Planned plan)
```
Existing type (namespace `CoaiMcp.Core.QuestionConsult`, `src_mcp/core/QuestionConsult/ConfinementPlanner.cs`):
```csharp
public sealed record Planned(
    string Runtime, CapabilityGrant Grant,
    IReadOnlyList<string> Leading, IReadOnlyList<string> Flags,
    CwdKind Cwd, IReadOnlyList<string> AddDirs, AdmissionFlag Flag) : Confinement
{ public IReadOnlyList<string> SnapshotSources { get; init; } = []; }
```
Body: if `plan.Leading.Count > 0 || plan.Flags.Count > 0 || plan.AddDirs.Count > 0` throw
`new ArgumentException("a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(plan))`; else return.
`SnapshotSources` is NOT a flag (a disk plan has it). Complexity ≤ 4.
Test that pins it: `ConfinementPlannerTests.APlanWithFlags_IsRefusedForKimi` (`.Should().Throw<ArgumentException>().WithMessage("*shim*")`).
Do not change anything else in the file.
