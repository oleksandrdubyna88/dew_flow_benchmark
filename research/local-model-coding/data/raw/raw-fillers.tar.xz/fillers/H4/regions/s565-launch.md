# s565-launch (test) — src_mcp/tests/ConfinementPlannerTests.cs, `AKimiQuestionLaunch_IsTheShimRequest_InItsFolderOrItsCopy_OnTheRowsHome`

Namespace `CoaiMcp.Tests`. Usings of the file: `CoaiMcp.Core.QuestionConsult`, `CoaiMcp.Runners.Consultation`, `CoaiMcp.Runners.Reviewers`, `FluentAssertions`, `Xunit`
(other namespaces are spelled in full in this file, e.g. `Runners.Kimi.KimiEnvironment`, `Runners.Processes.ProcessRequest`).
Fields/helpers already in the class:
```csharp
private const string RootA = "D:/projects/alpha";  private const string RootB = "D:/projects/beta";
private static readonly string Scratch   = Path.Combine(Path.GetTempPath(), "coai-scratch-" + Guid.NewGuid().ToString("N"));
private static readonly string RowFolder = Path.Combine(Path.GetTempPath(), "coai-question-" + Guid.NewGuid().ToString("N"));
private static readonly string RowTree   = Path.Combine(RowFolder, "tree");
private static Confinement.Planned Plan(string runtime, CapabilityGrant grant);
private static ConsultantLaunch Planned(string runtime, CapabilityGrant grant, string model = "") => new(Repo, "the question", string.Empty, Answers,
    new ReviewerSettings(runtime) { Model = model, OwnedScratch = RowFolder })
    { Confinement = new LaunchConfinement.Planned(Plan(runtime, grant)), ScratchDir = Scratch, Workdir = RowTree };
private static IEnumerable<(string Runtime, IConsultantRuntime Consultant)> Adapters();   // has ("kimi", new Runners.Kimi.KimiConsultant(new Runners.Kimi.KimiRuntime("kimi", Runners.Platform.HostKind.Windows, new Runners.Kimi.KimiSeams(root => Runners.Kimi.KimiPlaces.ForShim(root, Path.Combine(RowFolder, "persons-bin")), () => ("coai-mcp", [])))))
```
Existing signatures:
```csharp
// CoaiMcp.Runners.Consultation
public interface IConsultantRuntime { ReviewerInvocation Build(ConsultantLaunch launch); … }
public sealed record ReviewerInvocation(string Provider, string Role, ProcessRequest Request, string OutputFile = "", IReviewerRuntime? Adapter = null, …, string Model = "", …)
public static class ConsultantRoles { public const string Consult = "consult"; public const string Question = "question"; }
// CoaiMcp.Runners.Processes: ProcessRequest has .Executable, .Arguments (IReadOnlyList<string>), .WorkingDirectory, .StdIn, .InheritsEnvironment (bool), .Environment, .Passthrough
// CoaiMcp.Runners.Kimi
public static string KimiEnvironment.Refusal(ProcessRequest request, KimiPlaces places)       // empty = admitted
public static KimiPlaces KimiPlaces.ForShim(string ownedRoot, string personsBin)
```
`KimiConsultant.Build` (E5.4): argv `--ask-acp --profile kimi --model … --cwd <cwd> --home <ownedScratch>\kh-<10 hex>`; a planned launch's cwd is `ConsultantLaunches.Cwd(launch, plan)`: Scratch → `launch.ScratchDir`, Snapshot → `launch.Workdir`. Home flag: `CoaiMcp.Runners.Acp.AcpWords.HomeFlag` ("--home"); session flag `AcpWords.SessionFlag` ("--session").
Similar existing test (Vibe): `AVibeQuestionLaunch_IsThePlansPair_InItsScratchOrItsSnapshot_OnTheRowsOwnHome` a few lines above in the same file — `none.Request.WorkingDirectory.Should().Be(Scratch, …)`, `disk.Request.WorkingDirectory.Should().Be(RowTree, …)`, `foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request]) { request.InheritsEnvironment.Should().BeFalse(); … }`.
Note `KimiPlaces.ForShim(home, …)` takes the OWNED ROOT = the `--home` value itself (the kh-… folder).
