# s55-check (test helper) — src_mcp/tests/AKimiConsultantCheckTests.cs, `Check`

The class (already in the file): `public sealed class AKimiConsultantCheckTests : IDisposable` in namespace `CoaiMcp.Tests`; usings: `System.Text.Json`,
`CoaiMcp.Runners.Files`, `CoaiMcp.Runners.Kimi`, `CoaiMcp.Runners.Platform`, `CoaiMcp.Runners.Processes`, `CoaiMcp.Runners.Vibe`, `CoaiMcp.Server`, `FluentAssertions`, `Xunit`.
Fields: `_person` (KimiFixture), `_data`, `_temp`, `_homes` (TempDir), `_warned` (List<string>), `_unlinkedByTheDeleter` (List<string>).
Signature to fill (add `async` to it):
```csharp
private Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, PlayedKimi played, CancellationToken ct)
```
Existing API (`CoaiMcp.Server.ConsultantCheckMode`, internal static, visible to the tests):
```csharp
internal static async Task<(int Code, string Out, string Err)> AnswerAsync(
    PanelSettings settings, string[] args, IProcessLauncher launcher, string tempRoot, Action<string> warn, Noticing noticing, CancellationToken ct)
```
`PlayedKimi : IProcessLauncher` (`CoaiMcp.Tests`), `Noticing.None` (`CoaiMcp.Server`).
The same helper in `ConsultantCheckTests.cs` (copy its shape):
```csharp
private async Task<(int Code, JsonElement Said, string Err)> Check(PanelSettings settings, IProcessLauncher launcher, CancellationToken ct, params string[] args)
{
    var (code, stdout, stderr) = await ConsultantCheckMode.AnswerAsync(
        settings, ["--check-consultant", .. args], launcher, _temp, _warned.Add, Noticing.None, ct);

    return (code, stdout.Length > 0 ? JsonDocument.Parse(stdout).RootElement.Clone() : default, stderr);
}
```
Here the args are fixed: `["--check-consultant", "--caller", "claude"]`. `_temp` is a `TempDir` (implicit `string`). ≤ 8 lines.
