# s552-gone (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `AfterTheCheck_TheHomeIsGone_JunctionFirst(bool theTurnFails)`

Read `s551-copy.md` first: same class, helpers, `PlayedKimi`, `Check`, `StandIn`. The theory's two arms: `false` = the turn answers (as in s551); `true` = the turn fails.
The skeleton line `_ = theTurnFails;` before the region may be removed once the body reads the parameter.
Failing arm: `Turn = (_, request) => PlayedKimi.Lost(PlayedKimi.SessionOf(request))` — a played shim that ends `session_lost`, exit 70 (a first turn has no `--session`; the check classifies the
exit as a failure — any nonzero-exit result is fine: or `new ProcessResult(70, "", "boom", TimedOut: false)` — `CoaiMcp.Runners.Processes.ProcessResult(int ExitCode, string StdOut, string StdErr, bool TimedOut)`).
Assert in both arms, after `await Check(Settings(_homes), played, TestContext.Current.CancellationToken)`:
- `OneShotRoot` holds nothing: `(!Directory.Exists(OneShotRoot) || !Directory.EnumerateFileSystemEntries(OneShotRoot).Any()).Should().BeTrue("coai-vh\\<8> is gone")`;
- `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)` (`_person.Hash()` taken before; it carries bytes and `ReadOnly` bits);
- failing arm: `said.GetProperty("state").GetString()` is not `"answered"` (message `said.ToString()`).
`StandIn()` first and synchronously (`using var stood = StandIn();`), then `RecordingTheDeleter()`.
The red before E5.3 g (already merged in this branch, so the test is green when filled): *Expected the deleter's unlink recorder not to be invoked …*.
Windows-only? No — `WindowsStandIn.Begin()` makes it run on Linux with symbolic links.
