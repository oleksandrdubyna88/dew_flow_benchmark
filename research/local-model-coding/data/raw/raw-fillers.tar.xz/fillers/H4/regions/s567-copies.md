# s567-copies (test) — src_mcp/tests/AKimiQuestionRowTests.cs, `AKimiDiskRow_ReadsItsCopies_AndLeavesNothingBehind(Ending ending)`

Class fields/helpers already in the file (complete): `_launcher` (ProcessLauncher), `_person` (KimiFixture), `_dir`, `_homes` (TempDir), `_unlinkedByTheDeleter` (List<string>),
`Repo` (`_dir.At("repo")`, a git repo with `src/Mailer.cs`, `docs/notes.md`, `src/AGENTS.md`), `OneShotRoot` (`<_homes>\coai-vh`), `Advice`, `StandIn()` (call first, synchronously: `using var stood = StandIn();`),
`Service(PlayedKimi played, params string[] roots)` (a `PanelService` with ONE `kimi-disk` row, `ConsultantHomesRoot = _homes`, `RowBudget` 30 s),
`AskAsync(PanelService service, CancellationToken? ct = null)` → `JsonElement` root of `ask_consultants`' reply (`JsonDocument.Parse(await service.AskConsultantsAsync(Repo, "Which helper retries an outbound send?", "I tried a fixed wait.", ct: …))`),
enum `Ending { Answered, RefusedBeforeTheLaunch, CancelledMidTurn }`. The skeleton line `_ = ending;` may go once the body reads it.
`GitScratch.AfterUnlink` (`CoaiMcp.Runners.Files`, `internal static Action<string>?`): set `GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;` (the class's `DisposeAsync` clears it).
`PlayedKimi` — see `s551-copy.md` (`Shims`, `Turn`, `During`, `SessionOf`, `Answered(session, in, out, answer)`); `new PlayedKimi(_launcher)`.
Reply handling copied from the Vibe twin (`AVibeQuestionRowReadsACopyOfItsRootsTests`):
```csharp
private static JsonElement TheRow(JsonElement reply)
{
    reply.TryGetProperty("answers", out var answers).Should().BeTrue(reply.ToString());

    return answers.EnumerateArray().Should().ContainSingle().Subject;
}
TheRow(reply).GetProperty("status").GetString().Should().Be(RowOutcomes.Answered, reply.ToString());   // RowOutcomes.Answered == "answered"; CoaiMcp.Core.QuestionConsult
var turn = vibe.Turns.Should().ContainSingle().Subject;
turn.Request.StdIn.Should().Contain(copy, "the prompt names the copy Vibe can read");
turn.Request.StdIn.Should().NotContain(granted, "never the original, which it cannot read (M-V11)");
Directory.Exists(RowFolderOf(turn.Request)).Should().BeFalse("the row's home and copy are gone once it answered");
```
For Kimi: the one shim request is `played.Shims.Should().ContainSingle().Subject.Request`; its `WorkingDirectory` is the row's copy folder (`<row folder>\tree`, a disk row) and the prompt (`StdIn`) names the copies' paths
(inside that tree), never `Path.Combine(Repo, "src")`. The row's folder is `Path.GetDirectoryName(WorkingDirectory)`; the `--home` argument (`"--home"`, the next argument) is `<row folder or coai-vh\<8>>\kh-<10 hex>` — after every ending
`Directory.Exists(Path.GetDirectoryName(home))` is false and `OneShotRoot` is absent or empty (`!Directory.Exists(OneShotRoot) || !Directory.EnumerateFileSystemEntries(OneShotRoot).Any()`),
`_unlinkedByTheDeleter` is empty and `_person.Hash()` equals the hash taken before.
Arms: Answered — root `Path.Combine(Repo, "src")`, status `answered`. RefusedBeforeTheLaunch — a plain folder `_dir.At("plain")` (create it; no `.git`): the row is refused before any launch
(status is not `answered`; `played.Shims` empty). CancelledMidTurn — `During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); }` with a linked `cts`, ask with `cts.Token`;
the reply is a row status (not `answered`) or an `OperationCanceledException` — handle both. The red before E5.3 g: *Expected Directory.Exists("…\coai-vh\<8>") to be False, but found True.* — in this branch E5.3 is merged, so it is green once filled.
