# s551-copy (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `AKimiCheck_RunsInACopy_OnAOneShotHome`

See `s55-check.md` for the class, its fields and `Check`. Helpers already in the class (complete):
```csharp
private void RecordingTheDeleter() => GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;   // GitScratch: CoaiMcp.Runners.Files, internal static Action<string>? AfterUnlink
private void TheDeleterNeverMetTheJunction();   private void ThePersonsFolderIsWhole(IReadOnlyList<string> before);
private string OneShotRoot => Path.Combine(_homes, VibeHomes.OneShotFolder);     // <homes>\coai-vh   (VibeHomes: CoaiMcp.Runners.Vibe)
private PanelSettings Settings(string homesRoot);   // caller "claude" → ConsultantChoice("my-kimi", Runtime: "kimi"); ConsultantHomesRoot = homesRoot
private IDisposable StandIn();                      // WindowsStandIn + lock root + KimiSeams.Using(...) for this flow — `using var stood = StandIn();` FIRST, synchronously
```
`PlayedKimi` (`src_mcp/tests/PlayedKimi.cs`, `internal sealed class PlayedKimi(IProcessLauncher inner) : IProcessLauncher`):
```csharp
public const string Shim = "played-coai-mcp";   public const string Minted = "0d6a5f2e-1111-2222-3333-444455556666";
public sealed record Launch(ProcessRequest Request, DateTime StartUtc, DateTime EndUtc);
public ConcurrentQueue<Launch> Shims { get; }          // one per shim launch
public Func<int, ProcessRequest, ProcessResult> Turn { get; init; }                         // (n-th launch, request) → what the shim prints
public Func<ProcessRequest, CancellationToken, Task> During { get; init; }                  // runs while the shim is "alive"
public static string SessionOf(ProcessRequest request);
public static ProcessResult Answered(string session, long tokensIn, long tokensOut, string answer = Advice);
public static ProcessResult Uncaptured(string session, string answer = Advice);
public static ProcessResult Lost(string session);        // exit 70, end session_lost
```
Construct with `new PlayedKimi(new ProcessLauncher())` (`CoaiMcp.Runners.Processes.ProcessLauncher` runs git for real).
`KimiFixture` (`src_mcp/tests/KimiFixture.cs`): `new KimiFixture()`, `.Folder`, `.PersonsHome`, `.PlacesAt(string ownedRoot)`, `IReadOnlyList<string> Hash()`.
Reply shape (check record JSON, from `ConsultantCheckTests`): `said.GetProperty("state").GetString()` is `"answered"` (`ConsultCheckStates.Answered`), `"failed"`, `"unavailable"`;
`said.GetProperty("markerRead").GetBoolean()`. The check's scratch repo has `CHECK.md` whose last word (trailing '.' trimmed) is the marker; the consultant must answer
`marker: <word>` + `canary: CANNOT`. The Vibe twin of this test (`ConsultantCheckTests.AVibeCheck_ReadsTheMarkerInACopyOfTheScratch_NeverTheScratchItself`):
```csharp
var vibe = new PlayedVibe(new ProcessLauncher(), string.Empty)
{
    AnswerFor = seen => $"marker: {seen.Files["CHECK.md"].Trim().Split(' ')[^1].TrimEnd('.')}{Environment.NewLine}canary: CANNOT",
};
…
var (code, said, _) = await Check(settings, vibe, TestContext.Current.CancellationToken, "--caller", "claude");
code.Should().Be(0);
Text(said, "state").Should().Be("answered", said.ToString());
said.GetProperty("markerRead").GetBoolean().Should().BeTrue("the copy holds the scratch's CHECK.md");
turn.Request.WorkingDirectory.Should().Contain(Path.Combine("own", "tree"), "a copy in the check's own scratch, never the repository");
```
For Kimi the played agent reads the file from disk: in `Turn`, `File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md"))` (the shim's cwd IS the copy).
The `--cwd` and `--home` values: `request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1]`, likewise `"--home"` (`CoaiMcp.Runners.Acp.AcpWords.HomeFlag`).
The one-shot home is `<_homes>\coai-vh\<8 chars>\kh-<10 hex>`; so `Path.GetDirectoryName(Path.GetDirectoryName(home))` is `OneShotRoot`.
