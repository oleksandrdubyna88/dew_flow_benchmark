# s553-cancel (test) — src_mcp/tests/AKimiConsultantCheckTests.cs, `ACheckCancelledMidTurn_StillDisposesItsHome`

Read `s551-copy.md` first (class, helpers, `PlayedKimi`, `Check`, `StandIn`).
Facts about cancellation in the check (`src_mcp/src/Server/Consultation/ConsultantCheck.cs`): `RunAsync` catches `OperationCanceledException` when the CALLER's token is
cancelled and returns a failed record with `new ConsultFailure.Cancelled()`; `TurnAsync`'s `finally` disposes the one-shot home (`held.Home.Dispose()`), which is
junction-first (E5.3 g). `ConsultantCheckMode.AnswerAsync` may instead let the cancellation out as `OperationCanceledException` — observe it, and handle both ways
(`try { … } catch (OperationCanceledException) { }`).
The blocking shim: `new PlayedKimi(new ProcessLauncher()) { During = async (_, ct) => { cts.Cancel(); await Task.Delay(Timeout.Infinite, ct); } }` with
`using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);` and `Check(Settings(_homes), played, cts.Token)`.
(`During` runs after the shim's start is stamped; the `ct` it is given is the executor's token, linked to the caller's — so `cts.Cancel()` ends the wait.)
Assert: the record (if one came back) says the check did not answer: `said.GetProperty("state").GetString()` is `"failed"`, and `said.ToString()` mentions cancel (lower-case contains
"cancel"; print `said.ToString()` in the message — the exact `failureKind` word is the one `ConsultFailure.Cancelled` has; read it from the first run's output and write it down);
`OneShotRoot` empty or absent; `TheDeleterNeverMetTheJunction()`; `ThePersonsFolderIsWhole(before)`. Green once filled (pins the `finally`).
