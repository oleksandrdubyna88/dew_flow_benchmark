```typescript
  const none = admit('kimi', 'none');
  const disk = admit('kimi', 'disk');
  const web = admit('kimi', 'web');

  for (const x of [none, disk]) {
    assert.equal(x.admitted, true, x.reason);
    assert.equal(x.standing, 'unconfined');
    assert.equal(x.flag, 'unconfined');
    assert.match(x.caveat, /can read this machine/u);
  }

  assert.equal(web.admitted, false);
  assert.equal(web.standing, 'unmeasured');
  assert.match(web.reason, /not been measured/u);
  assert.match(web.reason, /RESULTS_kimi_confinement\.md/u);
  assert.ok(!web.reason.includes('RESULTS_question_consultant_capabilities.md'));
```