```csharp
        var consultant = Adapters().Single(a => a.Runtime == "kimi").Consultant;

        var none = consultant.Build(Planned("kimi", CapabilityGrant.None));
        var disk = consultant.Build(Planned("kimi", CapabilityGrant.Disk(RootA, RootB)));

        none.Request.WorkingDirectory.Should().Be(Scratch, "a none row stands in its empty folder");
        disk.Request.WorkingDirectory.Should().Be(RowTree, "a disk row stands in the copy of its roots (D6)");

        foreach (var request in (Runners.Processes.ProcessRequest[])[none.Request, disk.Request])
        {
            var args = request.Arguments.ToList();
            var home = args[args.IndexOf("--home") + 1];

            Path.GetDirectoryName(home).Should().Be(RowFolder);
            Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
            request.Arguments.Should().NotContain("--session");
            request.Arguments.Should().NotContain(RootA).And.NotContain(RootB);
            request.InheritsEnvironment.Should().BeFalse();
            Runners.Kimi.KimiEnvironment.Refusal(request, Runners.Kimi.KimiPlaces.ForShim(home, Path.Combine(RowFolder, "persons-bin")))
                .Should().BeEmpty();
        }

        none.Role.Should().Be(ConsultantRoles.Question);
        disk.Role.Should().Be(ConsultantRoles.Question);
```