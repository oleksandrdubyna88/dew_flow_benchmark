```csharp
        var plan = Plan("kimi", CapabilityGrant.None) with { Flags = ["--yolo"] };
        var launch = Planned("kimi", CapabilityGrant.None) with { Confinement = new LaunchConfinement.Planned(plan) };
        var consultant = Adapters().Single(a => a.Runtime == "kimi").Consultant;

        var build = () => consultant.Build(launch);

        build.Should().Throw<ArgumentException>().WithMessage("*shim*");
```