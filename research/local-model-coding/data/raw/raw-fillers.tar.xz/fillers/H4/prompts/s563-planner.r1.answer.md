```csharp
        var none = Plan("kimi", CapabilityGrant.None);
        var disk = Plan("kimi", CapabilityGrant.Disk(RootA, RootB));
        var web = ConfinementPlanner.Plan("kimi", CapabilityGrant.Web);

        // No row gets a sandbox flag. The shim confines it, not the argv.
        none.Cwd.Should().Be(CwdKind.Scratch, "a none row stands in an empty folder");
        none.Leading.Should().BeEmpty();
        none.Flags.Should().BeEmpty();
        none.AddDirs.Should().BeEmpty();
        none.SnapshotSources.Should().BeEmpty();
        none.Flag.Should().Be(AdmissionFlag.Unconfined);

        disk.Cwd.Should().Be(CwdKind.Snapshot, "D6: a disk row stands in a copy of its roots, never the checkout");
        disk.SnapshotSources.Should().Equal([RootA, RootB], "the roots it reads through their copies");
        disk.Leading.Should().BeEmpty();
        disk.Flags.Should().BeEmpty();
        disk.AddDirs.Should().BeEmpty();
        disk.Flag.Should().Be(AdmissionFlag.Unconfined);

        // A web row is refused by the matrix before the planner's arm runs.
        web.Should().BeOfType<Confinement.Refused>()
            .Which.Reason.Should().Contain("not been measured").And.Contain("RESULTS_kimi_confinement.md");
```