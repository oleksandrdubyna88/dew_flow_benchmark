```csharp
        using var stood = StandIn();
        RecordingTheDeleter();
        var before = _person.Hash();
        var played = new PlayedKimi(new ProcessLauncher())
        {
            Turn = theTurnFails
                ? (_, request) => PlayedKimi.Lost(PlayedKimi.SessionOf(request))
                : (_, request) =>
                {
                    var text = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md")).Trim();
                    var marker = text.Split([' ', '\r', '\n', '\t'], StringSplitOptions.RemoveEmptyEntries).Last().TrimEnd('.');
                    var answer = $"marker: {marker}{Environment.NewLine}canary: CANNOT";
                    return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 20000, 30, answer);
                },
        };

        var (_, said, _) = await Check(Settings(_homes), played, TestContext.Current.CancellationToken);

        (!Directory.Exists(OneShotRoot) || !Directory.EnumerateFileSystemEntries(OneShotRoot).Any()).Should().BeTrue("coai-vh\\<8> is gone");
        TheDeleterNeverMetTheJunction();
        ThePersonsFolderIsWhole(before);
        if (theTurnFails)
        {
            said.GetProperty("state").GetString().Should().NotBe("answered", said.ToString());
        }
```