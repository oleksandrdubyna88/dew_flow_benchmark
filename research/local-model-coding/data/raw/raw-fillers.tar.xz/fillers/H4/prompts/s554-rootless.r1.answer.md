```csharp
        using var stood = StandIn();
        RecordingTheDeleter();
        var before = _person.Hash();

        var played = new PlayedKimi(new ProcessLauncher())
        {
            Turn = (_, request) =>
            {
                var checkText = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md"));
                var marker = checkText
                    .Split(new[] { ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                    .Last()
                    .TrimEnd('.');
                var answer = $"marker: {marker}{Environment.NewLine}canary: CANNOT";
                return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 20000, 30, answer);
            },
        };

        await Check(Settings(string.Empty), played, TestContext.Current.CancellationToken);

        var request = played.Shims.Should().ContainSingle().Subject.Request;
        var argv = request.Arguments.ToList(); // argument list of the shim request (name as used in s551-copy)
        var home = argv[argv.IndexOf("--home") + 1];

        Path.GetFileName(Path.GetDirectoryName(home)).Should().Be("own");
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");
        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty();
        TheDeleterNeverMetTheJunction();
        ThePersonsFolderIsWhole(before);
```