```csharp
        using var stood = StandIn();
        var played = new PlayedKimi(new ProcessLauncher())
        {
            Turn = (_, request) =>
            {
                var seen = File.ReadAllText(Path.Combine(request.WorkingDirectory, "CHECK.md"));
                var marker = seen.Trim().Split(' ')[^1].TrimEnd('.');
                var answer = $"marker: {marker}{Environment.NewLine}canary: CANNOT";
                return PlayedKimi.Answered(PlayedKimi.SessionOf(request), 20000, 30, answer);
            },
        };
        var before = _person.Hash();

        var (code, said, _) = await Check(Settings(_homes), played, TestContext.Current.CancellationToken);

        code.Should().Be(0);
        said.GetProperty("state").GetString().Should().Be("answered", said.ToString());
        said.GetProperty("markerRead").GetBoolean().Should().BeTrue();

        var request = played.Shims.Should().ContainSingle().Subject.Request;
        var cwd = request.Arguments[request.Arguments.ToList().IndexOf("--cwd") + 1];
        cwd.Should().Contain(Path.Combine("own", "tree"));
        request.WorkingDirectory.Should().Be(cwd);

        var home = request.Arguments[request.Arguments.ToList().IndexOf("--home") + 1];
        Path.GetDirectoryName(Path.GetDirectoryName(home)).Should().Be(OneShotRoot);
        Path.GetFileName(home).Should().MatchRegex("^kh-[0-9a-f]{10}$");

        Directory.EnumerateDirectories(_temp, "coai-check-*").Should().BeEmpty();
        ThePersonsFolderIsWhole(before);
```