```csharp
        foreach (var capability in (Capability[])[Capability.None, Capability.Disk])
        {
            var row = RuntimeCapabilities.Builtin.Of("kimi", capability);
            row.Should().NotBeNull($"Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.{capability}) not to be <null>.");
            row!.Standing.Should().Be(CapabilityStanding.Unconfined, $"kimi × {capability}");
            row.MeasuredWith.Version.Should().Be("2.1.1", $"kimi × {capability}");
            row.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md", $"kimi × {capability}");
            row.MeasuredWith.Cells.Should().Contain("M-K6", $"kimi × {capability}: Grep and Glob read the disk");
        }

        RuntimeCapabilities.Builtin.Of("kimi", Capability.Disk)!.MeasuredWith.Cells.Should().Contain("M-K9",
            "kimi × disk also stands on the disk cell M-K9");

        var web = RuntimeCapabilities.Builtin.Of("kimi", Capability.Web);
        web.Should().NotBeNull("Expected RuntimeCapabilities.Builtin.Of(\"kimi\", Capability.Web) not to be <null>.");
        web!.Standing.Should().Be(CapabilityStanding.Unmeasured, "kimi × web has no measured cell");
        web.MeasuredWith.Cells.Should().BeEmpty("kimi × web has no measured cell");
        web.MeasuredWith.ResultRef.Should().Contain("RESULTS_kimi_confinement.md", "kimi × web");
```