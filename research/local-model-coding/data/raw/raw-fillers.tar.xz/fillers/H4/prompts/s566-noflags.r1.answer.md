```csharp
        if (plan.Leading.Count > 0 || plan.Flags.Count > 0 || plan.AddDirs.Count > 0)
        {
            throw new ArgumentException(
                "a Kimi row's confinement is the shim's; a plan with flags is not one coai made for kimi", nameof(plan));
        }
```