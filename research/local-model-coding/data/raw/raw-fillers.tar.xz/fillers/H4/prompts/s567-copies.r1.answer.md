```csharp
using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
using var stood = StandIn();
GitScratch.AfterUnlink = _unlinkedByTheDeleter.Add;
var before = _person.Hash();

var root = Path.Combine(Repo, "src");
if (ending == Ending.RefusedBeforeTheLaunch)
{
    root = _dir.At("plain");
    Directory.CreateDirectory(root);
}

var played = new PlayedKimi(_launcher)
{
    Turn = (_, request) => PlayedKimi.Answered(PlayedKimi.SessionOf(request), 20000, 30, Advice),
};
if (ending == Ending.CancelledMidTurn)
{
    played.During = async (_, ct) =>
    {
        cts.Cancel();
        await Task.Delay(Timeout.Infinite, ct);
    };
}

// A cancelled row may come back as a row status or as OperationCanceledException.
JsonElement? reply = null;
try
{
    reply = await AskAsync(Service(played, root), cts.Token);
}
catch (OperationCanceledException) when (ending == Ending.CancelledMidTurn)
{
    // accepted: the cancelled row ended by exception
}

if (reply is { } answered)
{
    answered.TryGetProperty("answers", out var answers).Should().BeTrue(answered.ToString());
    var row = answers.EnumerateArray().Should().ContainSingle().Subject;
    var status = row.GetProperty("status").GetString();
    if (ending == Ending.Answered)
    {
        status.Should().Be(RowOutcomes.Answered, answered.ToString());
    }
    else
    {
        status.Should().NotBe(RowOutcomes.Answered, answered.ToString());
    }
}

string? rowFolder = null;
if (ending == Ending.RefusedBeforeTheLaunch)
{
    played.Shims.Should().BeEmpty();
}
else
{
    var request = played.Shims.Should().ContainSingle().Subject.Request;
    rowFolder = Path.GetDirectoryName(request.WorkingDirectory);
    request.StdIn.Should().Contain(Path.Combine(request.WorkingDirectory, "src"), "the prompt names the copy, never the root");
    request.StdIn.Should().NotContain(Path.Combine(Repo, "src"), "the prompt never names the granted root");
}

if (rowFolder is not null)
{
    Directory.Exists(rowFolder).Should().BeFalse("the row's folder is gone once the row ends");
}

(!Directory.Exists(OneShotRoot) || !Directory.EnumerateFileSystemEntries(OneShotRoot).Any()).Should().BeTrue("the one-shot home is gone");
_unlinkedByTheDeleter.Should().BeEmpty();
_person.Hash().Should().Be(before);
```