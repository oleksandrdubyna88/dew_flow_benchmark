```csharp
using var stood = StandIn();
RecordingTheDeleter();
var before = _person.Hash();
using var cts = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
var played = new PlayedKimi(new ProcessLauncher())
{
    During = async (_, ct) =>
    {
        cts.Cancel();
        await Task.Delay(Timeout.Infinite, ct);
    },
};

var said = default(JsonElement);
try
{
    (_, said, _) = await Check(Settings(_homes), played, cts.Token);
}
catch (OperationCanceledException)
{
    // AnswerAsync let the cancellation out: there is no record to read.
}

if (said.ValueKind != JsonValueKind.Undefined)
{
    said.GetProperty("state").GetString().Should().Be("failed", said.ToString());
    said.ToString().ToLowerInvariant().Should().Contain("cancel", said.ToString());
}

if (Directory.Exists(OneShotRoot))
{
    Directory.EnumerateFileSystemEntries(OneShotRoot).Should().BeEmpty("the one-shot home must be disposed when the check is cancelled");
}

TheDeleterNeverMetTheJunction();
ThePersonsFolderIsWhole(before);
```