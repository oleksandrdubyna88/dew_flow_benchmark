You are the CODER (Sonnet) who applies the review of the implementation of `todo/PLAN_a_spent_quota_cools_the_model_down.md` in this repository, on branch
`feat/quota-cooldown`. The work so far is every commit after `6786582e30d3e771549d05ed719478396f8099cd`. You work alone and nobody answers questions.

## Read first

1. The project instructions: `AGENTS.md` → `.agents/conventions/ENTRY.md` and `.agents/PROJECT.md`. Run the resolver with
   `--task implement --task test` and the changed files, and read the rules it selects.
2. The review: `/home/jinx/git/coai-exp2/r/de34a907e017/notes/review.json` (JSON; each finding has a severity, a file, a line and a fix).
3. The coder's notes: `/home/jinx/git/coai-exp2/r/de34a907e017/notes/code.md`. The plan `todo/PLAN_a_spent_quota_cools_the_model_down.md` for the decisions a finding refers to.

## The task

- Fix every **blocking** and **major** finding. Fix a **minor** one when it is cheap. A finding you think is wrong: open the
  code, and if it is wrong, say why in the notes and leave it.
- A fix of a defect starts with a test that fails for the right reason, as the rules ask.
- Then: the build, the changed test classes, the whole MCP suite once, the format check, and the extension's tests if
  `src_vs_code` changed (commands in `.agents/PROJECT.md` and the plan; always through
  `.agents/conventions/tools/low-priority.mjs`).
- Known at the start, not yours: Nothing is known to fail: at the base commit the whole MCP suite (13,807 tests) and the extension tests pass on this host (Linux, WSL2; tests marked Windows-only skip). A failure you see is yours or a flaky test: re-run that one test alone before you decide.
- Out of scope: what the plan names as out of scope; any push, pull request, release. Never run `agy`, `kimi`, `vibe`,
  `codex` or `claude`.

## Commits, notes, deadline

- Commit as you go (conventional messages, files by name, never `git add -A`, never push).
- Notes go to `/home/jinx/git/coai-exp2/r/de34a907e017/notes/fix.md`: per finding — fixed, not fixed (why), or wrong (why).
- **Deadline: 22:47 UTC (23:47 CET).** At the deadline, stop, commit what you have, and write what remains in the notes.

Your final answer: a short report — per finding what you did, and the final results of the build, the suite, format and the
extension's tests.
