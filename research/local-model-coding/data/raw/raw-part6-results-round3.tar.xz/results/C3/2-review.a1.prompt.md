You are the JUDGE (Opus) who reviews the implementation of `todo/PLAN_a_spent_quota_cools_the_model_down.md` in this repository. The work is every commit after
`6786582e30d3e771549d05ed719478396f8099cd` on the current branch (`git log 6786582e30d3e771549d05ed719478396f8099cd..HEAD`, `git diff 6786582e30d3e771549d05ed719478396f8099cd..HEAD`). You are READ-ONLY: never edit, create
or delete a file in the repository, and never commit.

## Read first

1. The project instructions: `AGENTS.md` → `.agents/conventions/ENTRY.md` and `.agents/PROJECT.md`. Run the resolver with
   `--task audit` and the changed files, and read the rules it selects.
2. The plan `todo/PLAN_a_spent_quota_cools_the_model_down.md` completely.

## What to check

- Each of the plan's 43 scenarios: a test with its exact name exists, asserts what the scenario's *Then* says, and
  would fail without the change for the plan's reason. A test that can never fail is a defect.
- The plan's decisions, one by one, and its Definition of Done.
- Correctness, concurrency and durability where the plan writes state, security, the project's rules and conventions,
  simplicity, and scope (nothing outside the plan).
- You may build and run tests (commands in `.agents/PROJECT.md` and the plan; always through
  `.agents/conventions/tools/low-priority.mjs`). Known at the start, not the coder's: Nothing is known to fail: at the base commit the whole MCP suite (13,807 tests) and the extension tests pass on this host (Linux, WSL2; tests marked Windows-only skip). A failure you see is yours or a flaky test: re-run that one test alone before you decide.

Settle every claim about code by opening the file. Report only findings you checked.

## Your answer

Your final message is ONLY this JSON, nothing before or after it:

```json
{"verdict": "ready | fix-then-ready | not-ready",
 "findings": [{"id": "R1", "severity": "blocking | major | minor", "file": "path", "line": 1,
               "summary": "one sentence", "fix": "what to change"}]}
```
