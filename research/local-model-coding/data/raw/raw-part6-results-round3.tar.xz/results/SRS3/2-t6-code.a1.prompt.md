You are the CODER for ONE task, **t6**, of `todo/PLAN_a_spent_quota_cools_the_model_down.md` in this repository (branch `feat/quota-cooldown`). You work alone and
nobody answers questions.

## Your task

Read your task document first: `/home/jinx/git/coai-exp2/r/68b68cbc1f57/work/t6.md`. It is complete: the contracts (every signature, type, field and test name),
the existing code to use, the steps, the commands and when you are done. **Implement exactly those contracts** — do not
rename, add parameters, change types or move code. Read only the files the document names, and the project instructions
(`AGENTS.md` → `.agents/conventions/ENTRY.md` and `.agents/PROJECT.md`) for how to work here.

## Rules

- Change ONLY these files: `src_mcp/src/Server/PanelService.cs`, `src_mcp/src/Server/ServerJsonContext.cs`, `src_mcp/src/Server/Rounds/RoundEngine.cs`, `src_mcp/tests/ACoolingRowStaysOutOfTheRoundTests.cs`, `research/module_server.md`. Other tasks work on other files at the same time.
- Red first: run each new test against the code before the change and check it fails for the reason the document gives;
  then write the production code; then green.
- Build, and run the test classes the document names (always through `.agents/conventions/tools/low-priority.mjs`; build
  with `-m:4 --disable-build-servers`). Do not run the whole suite.
- Known at the start, not yours: Nothing is known to fail: at the base commit the whole MCP suite (13,807 tests) and the extension tests pass on this host (Linux, WSL2; tests marked Windows-only skip). A failure you see is yours or a flaky test: re-run that one test alone before you decide.
- Commit with a conventional message, adding your files by name (never `git add -A`); never push. Never run `agy`, `kimi`,
  `vibe`, `codex` or `claude`.
- Notes to `/home/jinx/git/coai-exp2/r/68b68cbc1f57/notes/t6-code.md`: what you did, any red message that differed from the document, anything left.
- **Deadline: 16:20 UTC (17:20 CET).** At the deadline, commit what you have and write what remains in the notes.

Your final answer: what you implemented, the test results, and anything you could not do.
