# Fix notes — review of PLAN_a_spent_quota_cools_the_model_down (branch feat/quota-cooldown)

The review has 3 findings, all minor (R1, R2, R3). No blocking, no major. All three are fixed.

## R1 — a null entry in the file throws out of `Read()` — FIXED
- Red first: `ASpentQuotaIsRememberedUntilItsResetTests.ANullEntryInTheFile_IsSkipped_AndTheEntriesAroundItStand` parks Gemini, then puts a `null` before the real entry in the file.
  It failed with `System.NullReferenceException at QuotaCooldowns.Read() QuotaCooldowns.cs:232` (the real symptom).
- Fix: `Read()` now skips null elements (`entry is not null && …`). Green after.
- Deviation from the review's suggestion: I did NOT add the file shape as a second case of `ATornFile_ParksNobody_AndSaysSoOnce`.
  A null element is dropped like an entry with an empty key (silently, the valid entries stay). A torn file parks nobody and warns once.
  So the null case has its own test, which also checks that the valid entry still stands and a later `Park` keeps it.

## R2 — one cancelled probe loses the other keys' changes — FIXED
- Red first: `TheRoundParksAndLiftsTheQuotaTests.ACancelledProbeOfOneKey_DoesNotTakeTheOtherKeysDecidedParkWithIt`
  (a Claude spent result and an agy spent result whose probe is cancelled). It failed on `store.Standing("claude", Now).Should().NotBeNull()` — the Claude park was lost.
- Fix: new `DecidedUnlessCancelled` catches `OperationCanceledException` for one key, logs it ("cancelled", the key) and gives no change for that key.
  `AfterRoundAsync` then still makes its one locked write for the other keys. The old outer `catch (OperationCanceledException)` is removed (nothing else there can throw it).
  S42 (`ACancelledProbe_ParksNothing…`) is unchanged and still green: its log line still contains "cancelled".

## R3 — `research/module_tests.md` contradicts itself — FIXED
- The "NOT covered" paragraph no longer says the `RoundEngine` call site is covered only by the build.
  It now names `ARoundThatEndsOnASpentQuotaParksItTests` as the test that covers it.
- The two catalogue rows for the changed classes now name the new cases.

## Results
See the bottom of this file.

## Results (commit 2315160c, nothing pushed)
- Build: `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4` — 0 warnings, 0 errors. (One first attempt died with an `Internal CLR error 0x80131506` before compiling; the same command passed on the retry.)
- Changed classes: `ASpentQuotaIsRememberedUntilItsResetTests` + `TheRoundParksAndLiftsTheQuotaTests` — 24 passed, 0 failed.
- Whole MCP suite (once, after the fix): 13,888 total, 13,770 passed, 117 skipped (Windows-only), 1 failed.
  - The 1 failure: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — `ArgumentOutOfRangeException`, the unix-socket path
    `…/tmp/testsToDelete-coai-run-…/testsToDelete-regular-files-…/shown.sock` is longer than 108 characters. It fails the same way when run alone.
    It is the session's long temp root (same as in `code.md`), not my change: no file near it changed. I could not try a short TMPDIR: creating a folder outside the working directories needs approval and I did not ask. Not dismissed as flaky; it needs a shorter temp root.
- Format: `dotnet format whitespace` and `dotnet format style --verify-no-changes` on the 3 changed .cs files — clean. (With `--severity info` one hint, IDE0042 at `QuotaCooldowns.cs:192`, shows in the earlier `Decided` code; not mine, below the project's severity, left.)
- Extension tests: not run — `src_vs_code` did not change.
- Not done: nothing from the review remains.
