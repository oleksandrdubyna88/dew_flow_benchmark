# Coder notes — PLAN_a_spent_quota_cools_the_model_down (Sonnet, branch feat/quota-cooldown)

## Commits (all on feat/quota-cooldown, nothing pushed)
- 3d39271c story 1 (S1–S8) · eff12ff8 story 2 (S9–S25, S34–S37, S39–S43) · 77e62852 story 3 (S26–S29, S38)
- 45ac1700 story 4 (S30–S33, extension) · 212dea8b docs + plan status/§12 + guard lists

## Per-scenario state
Every scenario was written first against a stub/unchanged code and seen RED on an assertion (stub states listed below), then GREEN.
- S1 red `launcher.Launched … 4 … found 1`-style as the plan (found 4 vs 1) ✓ · S2 red found 1 vs 4 ✓ · S3 passes against the pre-change code (it only goes red for the tempting `Spent == true` shape; with the plan's AGY_1_3_3 reason that shape stays green because `ResetOutlasts` ends the ladder anyway — I added a 3rd case with the reset cut; break-it red seen: `Expected spentWordsOnly.Launched to be 1 … found 4`).
- S4, S5 red `Expected True, but found <null>`; S6 red `Expected transient.Limited to be True, but found False` (the plain text scan does not call "Too many requests" a limit at all); S6 break-it (`Spent` always true) red seen.
- S7 red `Expected type to be …RateLimited, but found …NonZeroExit` ✓ (plan's); S8 break-it (no 429/phrase check) red seen: `Expected type to be …NonZeroExit … found …RateLimited`.
- S9–S15, S34 (gauge half), S40, S43: red against a stub (`Available` for all / empty report / a prefix `KeyOf`): `Expected Gauge(...) to be …Spent…, but found Available`, `Expected report.Buckets… found empty collection`, `Expected type to be …CannotCheck, but found …Report`, S14: key differs at `gemini-4-argon-high` (prefix rule gave `antigravity/gemini`).
- S16–S21, S35–S37, S39: red against a stub store (`Standing` null, `Park` Written): `Expected standing not to be <null>`, `Expected type to be …Refused, but found …Written`, S19 red: no warning in the log. S18/S20 against the stub failed with FileNotFound (the stub never wrote); S35/S36 timed out on the in-lock hook (the stub never called it).
- S22–S25, S34 (round half), S41, S42: red against the stub: `Expected launcher.Launched to be 1 … found 0`, `Expected standing not to be <null>`, S24 `Expected logA.Lines … to have an item matching "transient"`, S42 a 10 s timeout waiting for the probe to start.
- S26, S27, S29 red against unchanged server (`Expected excluded to contain a single item, but the collection is empty`; S29 `Expected … cooling row carries its cooldown`); S28 and S38 pass against the stub (S28 can only be red against a store that writes on read; S38 only if the context lacked the member — the member was added first so the type compiled). S27's plan red is a break-it (key `antigravity` alone) — NOT run (see "What remains").
- S30 red `undefined !== {…}`; S31/S32 red `'' !== '…'` (against the empty stub, not the quota wording); S33 red `actual 0, expected 1` on the `cooldown-line` count (teeth: the same fixture draws a `reset-line` without the cooldown, asserted first).

## Whole suites
- Extension: `npm --prefix src_vs_code test` → exit 0 (6,662 tests across the node runs, 0 failed); typecheck and lint clean.
- MCP suite: see the final report / bottom of this file.

## Decisions / deviations (also in plan §12)
1. `ReadResetAsync` gained `bool? spent` (after `reason`); result is `QuotaReset.Back | StaysOpen`.
2. `AfterRoundAsync(results, launcher, ct)` — launcher as a parameter, returns the same list. `RoundEngine` got `cooldowns` + `launcher` as two trailing ctor parameters.
3. Refusal notice via constructor callback; new notice code `quota-cooldown-not-written` + producer `QuotaCooldownNotices` (added to the notice-producer census list in `TheRefusalsAreWrittenDownTests`).
4. `DeepseekRuntime`, `CustomCodexRuntime` derive from `CodexRuntime`: `QuotaKeyOf` virtual there, overridden to empty. agy empty model → `DefaultModel`. Unknown agy group → no probe launched.
5. Claude spend verdict carries `ReadUsage`.
6. S3 extra case; S25 clock 2026-07-10 (the plan's NOW is after July 15, 2026); S34 rows are undecided (`Spent = null`) because with `Spent = true` D5/S41 would park Gemini too; S36 is a Theory (two rows).
7. Guards moved with the code: clock guard (`QuotaCooldowns.cs` in the scanned set as the plan said; `PanelService.cs` named "not scanned, with a reason"), notice-producer census, and `teamServerTab.test.ts`'s CATALOG_CSS pin (re-pinned for `.cooldown-line` + `.badge.verdict.cooling` in `catalogCss.ts`; not added to the shared `catalogSheet.ts` piece).
8. The server sentence's time left: `N h` from one hour, `N min` below (D9 only shows `N h`).
9. Plan status line reworded to avoid `plan-lifecycle`'s "reads as promoted" check (the plan stays in todo/; promotion is after the code gate, out of scope).
10. Docs appended as new sections at the END of module_runners/server/extension/tests (+ a pointer line under the 2026-10-11 agy section in module_runners; RESULTS_vendor_quota_gauges.md §3.4 added with the hand capture as its first row).

## Environment notes
- `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` fails HERE with `ArgumentOutOfRangeException: path … invalid length for domain sockets (108)`: this session's TMPDIR is a long path; unrelated to the change. (Passes with a short temp root.)
- This host's shell tool refuses long heredocs and compound commands; the docs were appended from files.

## What remains
- The code gate over the branch (out of scope for the coder), the live `/quota` row for RESULTS §3.4 (owed to whoever sees the first real probe answer), promotion of the plan after the gate.
- S27's break-it, `dotnet format --verify-no-changes` and the final whole-suite re-run: see the bottom of this file for whether they ran.

## Final state (at the end of the session)
- MCP suite on the committed tree: 13,876 total, 13,758 passed, 117 skipped, 1 failed — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException`, the unix-socket path under this session's long temp root is past 108 characters. Not caused by this work (no file of mine is near it); it needs a shorter TMPDIR. (The first full run showed 3 failures: this one plus the two guard lists, fixed in 212dea8b.)
- Extension: `npm --prefix src_vs_code test` exit 0 (6,662 tests, 0 failed); typecheck and lint clean.
- `dotnet format whitespace` and `dotnet format style --verify-no-changes` on the files I changed: clean. The plan's whole-solution `dotnet format … --verify-no-changes` cannot run here: it stops on IL2026/IL3050 AOT analyzer errors in `src_server` (files I did not touch).
- `plan-lifecycle`: clean.
- S27 break-it RUN (QuotaKeyOf = "antigravity" for every agy model): S26, S27 and S29 go red (`Expected excluded to contain a single item, but the collection is empty`, not the plan's "found 2": the parked file names `antigravity/gemini`, so a coarser key matches nothing). Restored.
- Not done: the code gate, the live `/quota` row, promotion of the plan (all out of scope).
