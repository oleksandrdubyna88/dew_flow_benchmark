# Gate notes — feat/quota-cooldown (coai session 05e138f9, caller claude-sonnet-5-5)

Commands carried by the plan reply (operator switches): split into epics, Fable split, work autonomously,
ask consultants first, consult on a cadence. Applied: none of the epic/model-split commands. This change is
already built and committed, and its plan is frozen by the task order and by plan §11/§12 (one file, no epics,
by the owner's decision). The red-green fix rule (a failing test first, docs with the change) I apply
to every accepted finding. No question was asked, so the consultant order did not come up.

## Plan round 1 — verdict proceed, gating 4 of threshold 6, reviewers asked 2, answered 2 (codex, antigravity)
All five rejected with the frozen-plan reason (no finding showed a defect in the code that I could see now).
1. Major (plan) codex: a recovered account stays parked, no lift without a launch — reject: manual lift is out of scope by D12.
2. Major (plan) codex: the 16 KiB ceiling is not bounded for changing unknown model keys — reject: entries expire by reset, each write drops expired ones. To check in the code round.
3. Major (plan) antigravity: a standing cooldown makes the Lift unreachable after a re-login — reject: "try now" deferred by D12.
4. Major (plan) antigravity: the guess doubling is dead since expiry resets the counter — reject: decided in D5/S39; the code matches the plan (`QuotaCooldowns.ConsecutiveOf`).
5. Minor (plan) antigravity: S9 keys have no `antigravity/` prefix — reject: scenario wording only.

## Code round 1 — verdict proceed (gating 9 of threshold 5, the server still said proceed), reviewers asked 8, answered 8 (codex, antigravity; 4 roles each)
No `commands` beyond "work autonomously" and "ask the consultants first". Applied: red-green-red for every accepted fix (none were accepted), docs with changes (none changed), re-read the code before each decision. No question was asked.
I opened the code for every finding (QuotaCooldowns.cs, AntigravityRuntime.cs, AgyQuotaReport.cs, HeldFile.cs, VendorReason.cs, CooldownSentences.cs, ProcessLauncher.cs). All 13 were rejected in round 1, none accepted, so nothing was fixed and no second code round was run (the verdict was proceed).
1. Major Conventions ReviewerRuntime.cs:461 — quota key is an untyped string — reject: D3 fixes `string QuotaKeyOf`; a key type is a redesign, out of scope.
2. Major Architecture QuotaCooldowns.cs:184 — store decides vendor refusal semantics — reject: the plan's D5 design; the structured verdict is not bypassed (Rank 0 for Spent==true; Spent passed to ReadResetAsync).
3. Major Reliability QuotaCooldowns.cs:198 — a slow probe's park overwrites a newer Ok's lift — reject: no launch time on outcomes, so order across rounds is unknowable; D5's rule is spent-wins; bounded by reset; new feature.
4. Major UX QuotaCooldowns.cs:147 — sequential probes up to 90 s — reject: D5 one call per key, each bounded at 30 s; parallel probes would share one read-only agy home; needs all three agy quotas spent at once.
5. Major Architecture AgyQuotaReport.cs:133 — Parse hides JSON errors — reject: D6/S15 pin `no report in the answer`.
6. Minor Architecture QuotaCooldowns.cs:140 — depends on IProcessLauncher — reject: D5's signature, deviation 2.
7. Minor Consistency AgyQuotaReport.cs:40 — hardcoded model table — reject: D3 decided it; S14.
8. Major Reliability AgyQuotaReport.cs:49 — unknown/namespaced key gives GroupMissing — reject: that is D3/D5/S14 as planned; both key shapes resolve the same ids.
9. Major Reliability QuotaCooldowns.cs:269 — I/O exceptions can escape the lock path — reject: already covered by FolderRefusal, Hold.Unusable/Busy -> Refused (S37), and the catch in AfterRoundAsync.
10. Minor Security QuotaCooldowns.cs:235 — vendor text not truncated first — reject: wrong, VendorReason.Written caps it and the launcher bounds the output.
11. Major Performance PanelService.cs:421 — file read on every CanRun/probe — reject: D4 decided, no cache.
12. Major UX AgyQuotaReport.cs:204 — stale relative duration in the note — reject: wrong, the note holds absolute ISO instants; "in N h" is computed at render time.
13. Minor Performance AgyError.cs:42 — allocations in Parse — reject: bounded stderr, only on non-zero exit.

Observation for the owner, not a finding I accepted: finding 3 (cross-round ordering) and the plan-round findings 1/3 (no way to lift a parked row after a re-login without waiting for the reset) are real limits of the frozen plan; D12 defers a "try now" lift to a later plan.

## Final checks (no code was changed by this gate run; HEAD is still 2315160c)
- Build `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4`: 0 warnings, 0 errors.
- Whole MCP suite (once, `low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests`; on Linux the file has no `.exe`): total 13,888, passed 13,770, skipped 117 (Windows-only), failed 1 — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException`, the unix-socket path under this session's long temp root is longer than 108 characters. Run alone it fails the same way. Same failure as in notes/fix.md; not caused by the branch; needs a shorter TMPDIR. A first suite attempt was killed by the 10-minute background limit and a second one with a wrong file name (`.exe`) did not start; the third ran to the end (12 min).
- Format: `dotnet format whitespace` and `dotnet format style --verify-no-changes` on the changed product and test files: clean.
- Extension tests: not run in this session; `src_vs_code` was not changed here (the branch's own run is in notes/code.md: exit 0, 6,662 tests, 0 failed).
- Nothing pushed. No commit was made in this gate run (nothing was accepted).
