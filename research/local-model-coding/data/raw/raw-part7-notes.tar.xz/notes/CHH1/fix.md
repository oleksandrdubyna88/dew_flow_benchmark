# Fix notes — review of PLAN_a_spent_quota_cools_the_model_down (branch feat/quota-cooldown)

All six findings are fixed. No finding was wrong. Commits (after the review), oldest first:
`ce3402b1` R6, `3891335d` R1+R2, `7feac756` R5 (S24), `adab004b` R4, `035004ef` R3 (+R5 S33 note).

## R1 (major) — AfterRoundAsync had no test through a round: FIXED
- New class `src_mcp/tests/ASpentQuotaIsParkedByARealRoundTests.cs`. It runs a real plan round through `PanelService` and the engine.
  A Claude row runs on FakeCli, which answers the monthly spend-limit envelope with exit 1.
- It asserts: before the round nothing is excluded; after the round `quota-cooldowns.json` exists and holds `claude`;
  `ExcludedFrom(Stage.PlanReview)` names the row with this side's sentence (`claude: … spent …`) and not the vendor's words.
- Break-it done: the line `results = await _cooldowns.AfterRoundAsync(…)` in `RoundEngine.cs` commented out → RED:
  `Expected File.Exists(FilePath) to be True because the round parked the spent quota; … but found False.` Line restored → green.
- `research/module_tests.md`: a new `covered` row; the "not covered" sentence about the `AfterRoundAsync` call is removed.
  Plan §12 item 13 says the gap is closed.

## R2 (minor) — the notice for a refused write had no test: FIXED
- Second test in the same class: `ARefusedParkIsOneNoticeToThePerson_NotOnlyALogLine`. `PanelService` gets a recording `Noticing`;
  the cooldown file's path is made a directory, so the park is refused. It asserts exactly one notice with code `storage-note`,
  class `stand-down` and a title with `could not be remembered`; and that nothing is excluded after (the row is launched again —
  the reason the person must be told).
- Break-it done: the body of `OfferCooldownRefusal` replaced by a no-op → RED:
  `Expected var notice = offered to contain a single item matching (n.Code == "storage-note") … but no such item was found.` Restored → green.

## R3 (minor) — §12 left out changes outside the scope list: FIXED
- New §12 item 14 in the plan, one bullet per change with its reason: the Rounds-log row (`roundsBlock.ts`, `panelProvider.ts`),
  `ConsultFailures.Classify` reading `Spent`, the security lane's cooldown sentence (`coolingReasonOf` in `SecurityRoster`/`RosterBuilder`),
  the empty quota keys of `DeepseekRuntime` and `CustomCodexRuntime`, and the new files `CooldownNotices.cs`, `CooldownSentence.cs`, `QuotaCooldownTypes.cs`.
  I checked each statement against the diff before writing it.

## R4 (minor) — new tests read the page's HTML string: FIXED
- `aCoolingRowSaysWhenItIsBack.test.ts`, `TheModelsCard_AfterTheReset_IsTheCardItWas`: now reads the card through `pageTree` —
  no `.cooldown-line` node, and the verdict badge text is `coai-mcp will run it`.
- `statedReset.test.ts`, the new rounds-block test: the `rowOf` regex helper is replaced by `resetsOf` (`pageTree`; the texts of
  `span.warn.reset` in the row of the provider). It asserts exactly one reset line beside a cooling row, its text, the ledger's line once the cooldown has passed, and no `quota spent` on another row.
- The extension's old tests of the same file (not from this branch) still match on strings; not touched.
- Break-it for these two: NOT run (no time before the deadline for a second mutation cycle of the TS side). They read the same data
  as before, and the typecheck, lint and tests pass. This is a gap, said here on purpose.

## R5 (minor) — two tests did not match the plan: FIXED
- S24: case (c) (a probe that exits 1) is back in `AnUndecidedExhaustion_IsParkedOnlyWhenTheGaugeSaysSpent`; the separate test is deleted.
  While merging, (c) failed once — it shared the data directory with (b), which had parked the key. A fault of my merge, not of the product.
  (c) now runs before (b). The test passes.
- S33: NOT renamed to the plan's text. The plan's words "read off the RUNNING page;" would claim a run of the page's script, which the test does not do (the card is drawn by
  `modelsTabHtml`; deviation 10 already says so). The reason is now written in §12 item 10, as the finding allowed.

## R6 (minor) — wrong path in a doc comment: FIXED
- `ReviewerExecutor.cs` line 280 now says `todo/PLAN_a_spent_quota_cools_the_model_down.md`. No other `research/PLAN_a_spent…` reference exists (grep).

## Results (HEAD `035004ef`, Linux/WSL2)
- **Build** (`dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4`): 0 warnings, 0 errors.
- **Changed test classes**: `TheRoundParksAndLiftsTheQuotaTests` 11/11 and `ASpentQuotaIsParkedByARealRoundTests` 2/2 pass.
- **Whole MCP suite**, run twice (full output of the second run: `notes/suite-run2.txt`): 13,887 tests, 13,769 passed, 117 skipped
  (Windows-only), **1 failed** both times: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`.
  It is the same environmental failure the coder noted. It also fails alone, with
  `ArgumentOutOfRangeException … path '…/tmp/testsToDelete-coai-run-…/testsToDelete-regular-files-…/shown.sock' is of an invalid length for use with domain sockets (1–108)`:
  this session's temp directory makes the socket path 111 characters. The test touches no code of this branch. I could not
  shorten TMPDIR inside the allowed directories, so I did not get it green here. Not a product defect, and not "flaky": the cause is the path length.
- **Format**: `dotnet format whitespace … --verify-no-changes` clean; `dotnet format style … --verify-no-changes --severity warn` clean (no line outside the known IL2026/IL3050 ones).
- **Extension** (`src_vs_code`): `npm run typecheck` and `npm run lint` clean; `npm test`: every test group reports `fail 0`.
- `plan-lifecycle.mjs`: clean.
- Not done: break-its for the two rewritten TS tests (R4) — see R4 above.
