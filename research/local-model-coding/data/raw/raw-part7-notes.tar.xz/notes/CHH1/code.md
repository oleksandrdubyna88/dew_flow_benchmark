# Coder notes — PLAN_a_spent_quota_cools_the_model_down (branch feat/quota-cooldown)

All four stories are built and committed on `feat/quota-cooldown` (no push). The plan's own record of deviations is §12 of the plan (same list, shorter).

## Commits (oldest first)
1. `737d09e2` Story 1 — S1–S8 (verdict `Spent`, `AgyError`, agy and Claude `RateLimited`)
2. (next) `test(reviewers): S3 sees the tempting Spent==true wiring`
3. `d0a7ee67` Story 2 — S9–S25, S34–S37, S39–S43 (`AgyQuotaReport`, `AgyQuotaProbe`, `QuotaCooldowns`, `QuotaKeyOf`, `ReadResetAsync`)
4. `c206cb93` Story 3 — S26–S29, S38 (`CanRun`, `ReasonFor`, `ProviderStatus.Cooldown`, `RoundEngine` call)
5. `7a2775eb` Story 4 — S30–S33 (`cooldownWords.ts`, `providers.ts`, card line + badge, CSS + re-pinned hash)
6. `9a946a90` docs (module_runners/server/extension/tests, RESULTS §3.4, plan status + §12)
7. `7da7552e` fixes found by the whole suite and lint (notice census file, clock census, `verdictBadge` complexity)

## Per scenario: red seen? green?
Method: the new member/type shapes were stubbed first (a default value), the tests run RED, then the real code. "Red" below is what I actually saw.

| S | red | note |
|---|---|---|
| S1 | yes `Expected launched to be 1 … but found 4` | |
| S2 | yes `Expected launched to be 4 … but found 1` | |
| S3 | NOT red on the plan's shape (see D1 below) | green at first run; break-it with the tempting `Spent == true` wiring: red `Expected spentWordsOnly to be 1 … but found 4` after adding a reset-less case |
| S4, S5 | yes `Expected verdict.Spent to be True, but found <null>` | |
| S6 | yes, different: `Expected transient.Limited to be True, but found False` | break-it of "keyed on RESOURCE_EXHAUSTED alone" run too: red |
| S7 | yes `Expected type to be …RateLimited, but found …NonZeroExit` | pin in `AClaudeReasonInItsEnvelopeTests` reversed |
| S8 | green at first run (as the plan: a break-it); break-it keyed on a non-empty sentence: red `Expected type to be …NonZeroExit … but found …RateLimited` | |
| S9–S13, S34 (report half), S40 | yes, all red against the stub (`Available`) | |
| S14 | key half NOT seen red (table written real; a prefix rule was not tried); `GroupMissing` half red | |
| S15 | yes `Expected type to be CannotCheck, but found Answered` | |
| S43 | yes (stub gave no groups) | |
| S16, S17, S22, S23, S25, S41 | yes `Expected standing not to be <null>` | |
| S18 | yes (stub `Lift` wrote nothing; `KeysInFile` threw / standing) | |
| S19 | yes, different: `Expected log.Warnings to contain a single item, but the collection is empty` | no JsonException — the stub did not read |
| S20, S21, S39 | red against the stub | |
| S24 | yes `Expected logA.Information … transient` / standing | |
| S34 (round half) | red against the stub | |
| S35, S36 | red as a timeout: `Expected inside.Wait(…) to be True` (the stub never entered the lock) | |
| S37 | yes `Expected type to be Refused, but found Written` | |
| S42 | red as a timeout (stub never launched) | |
| S26, S27 | yes `Expected excluded to contain a single item, but the collection is empty` | S27's break-it ("key of `antigravity` alone") NOT run |
| S28 | green at first run (nothing was excluded yet) | |
| S29 | yes (no `cooldown` member) | |
| S38 | green at first run — I added the `Cooldown` record member before the first run | |
| S30 | yes `actual: undefined, expected: { untilUtc … }` (by mutating the product code) | |
| S31 | yes `actual: '' expected: 'quota spent — back 14.10.2026 09:19 (in 63 h)'` | |
| S32 | red under the same mutation (`''`), not the plan's "quota wording" | |
| S33 | red (`actual: [] expected: [ '' ]`) | |

Everything green at the end (see the suite numbers below).

## Deviations (also in the plan §12)
1. `RateLimitVerdict.Because(…, spent: …)` — lower-case parameter.
2. S3: reset-less case added (the AGY_1_3_3 reason's `Resets in 88h49m9s` ends the ladder through `ResetOutlasts` regardless of how `Hopeless` is wired).
3. S6(a) red differs (see table).
4. `ResetFor` takes the full key (`antigravity/gemini`).
5. S25 uses October 15, 2026 (the plan's July 15 is before the plan's NOW; a park on the past is no park → `QuotaReset.FromText` takes a stated instant only if it is ahead).
6. S34 round half: the Gemini row's refusal is the undecided one (otherwise S41's rule parks it).
7. Refused-write notice: `Action<string> refused` callback into `QuotaCooldowns`, `PanelService` offers it as `CooldownNotices.Refused` (code `storage-note`, class `stand-down`). A new file because the notice-census test (`TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper`) pins which files build notices; I added `CooldownNotices.cs` to its list.
8. `QuotaCooldowns` owns the `IProcessLauncher` (constructor), seams `QuotaCooldownSeams`.
9. agy `ReadResetAsync` recovers "explicit vs undecided" from the reason; no probe for an unknown agy family; undecided + spent bucket without a reset → parked on text/guess.
10. S33 reads the card from the HTML tree (`pageTree`), as `cardGauge.test.ts` does; the page script plays no part in drawing a card.
11. CSS: `.cooldown-line` shares `.reset-line`'s rule, new `.badge.verdict.cool`; `teamServerTab.test.ts` hash re-pinned (af6ca175…ef99). `verdictBadge(id, context, nowMs)`.
12. `EveryBudgetInAClockedClassReadsItsClockTests`: `QuotaCooldowns.cs` joins `Clocked`; `PanelService.cs` joins `Unscanned` (it now has a `TimeProvider` constructor parameter).
13. `RetryLadder.cs` note and `statedReset.ts` header rewritten as the DoD asks; RESULTS §3.4 written (first row = the hand capture; the row for coai's own probe is owed).
14. Plan status line: "coded … waiting for the code gate" (the words "implemented/shipped" trip `plan-lifecycle` as "promoted"); the plan stays in `todo/`.

## Decisions not in the plan
- `QuotaReset` is a union (`At`/`NotParked`) because the undecided agy case must be able to say "do not park".
- `AfterRoundAsync` abandons ALL of the round's writes (lifts too) when a probe is cancelled; it catches any other exception and logs a warning, returns `results` unchanged.
- Notes in the file: this side's sentence, then ". The vendor said: <redacted vendor reason>", capped at 400.
- The wire's `untilUtc` is `yyyy-MM-ddTHH:mm:ssZ` (second precision).

## Late additions (after the first whole-suite run)
- `c6723737`: a probe that THROWS (other than cancellation) costs its own key only (`ResetOfAsync`: explicit refusal → parked on text/guess with the failure named; undecided → not parked). Extra test `AProbeThatThrows_CostsItsOwnKeyOnly_TheOtherKeysAreStillSettled` (not in the plan; written after the code, not seen red — before this the generic catch in `AfterRoundAsync` would have dropped the whole round's parks). `QuotaCooldowns.cs` was 405 lines, so its types moved to `QuotaCooldownTypes.cs` (320 + 87).
- Break-it run afterwards: S14 with a `gemini-` prefix rule → red `Expected AgyQuotaGroups.KeyOf(model) to be the same string … gemini-4-argon-medium … differ at index 12`. S27 with the agy key `antigravity` alone → red, but as `Expected excluded to contain a single item, but the collection is empty` (the parked key `antigravity/gemini` no longer matches), not the plan's `found 2`.

## Results
- **Final whole MCP suite (HEAD c6723737): 13,879 tests, 13,761 passed, 117 skipped (Windows-only), 1 failed — `RegularFilesTests…socket` (environmental, below).**
- Whole MCP suite, first run (after story 3): 13,874 tests, 3 failed (two mine, fixed in `7da7552e`; one environmental, below). Second run: see "Final".
- `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` fails on this host in my session: `ArgumentOutOfRangeException … is of an invalid length for use with domain sockets` — the session's TMPDIR (`/home/jinx/git/coai-exp2/r/4650daee202d/tmp/…`) makes the socket path > 108 characters. Not mine; re-run alone: fails the same way; could not override TMPDIR here (the harness refused an env prefix).
- Extension: `npm run typecheck`, `npm run lint` clean; `npm test` exit 0 (all test files pass).
- Format: `dotnet format whitespace` and `dotnet format style --severity warn` verify clean. The full `dotnet format … --verify-no-changes` prints only IL2026/IL3050 errors from `src_server`/`src_bugs` (zero lines from `src_mcp`; not touched by me).
- `plan-lifecycle.mjs`: clean.

## What remains
- The code gate over the branch (the plan's DoD asks for it; not run — no reviewers here).
- RESULTS §3.4 second row: the first `/quota` answer coai's own probe reads in a real round (needs a real agy; forbidden here).
- Not exercised by any scenario: `RoundEngine`'s `AfterRoundAsync` call (wired in `RoundEngine.cs`), the notice for a refused write end to end (the callback is S37; `CooldownNotices` is a plain builder).
- Not run: the break-its for S35 (unlocked write) and S41 (last-writer).
- Help page sentence, "try now" button, automatic model switching: out of scope per D12.
