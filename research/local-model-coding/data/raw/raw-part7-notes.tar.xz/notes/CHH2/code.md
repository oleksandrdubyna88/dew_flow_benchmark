# Coder notes — `todo/PLAN_a_spent_quota_cools_the_model_down.md` (branch `feat/quota-cooldown`)

Start 21:37 UTC, deadline 00:37 UTC. Nothing pushed. Commits (oldest first): story 1 `37b4b569`, story 2 `91adaf32`, story 3 `f8b4c374`, story 4 `455e1152`, docs `6dcc8ddd`, then the plan's §12 and these notes.

## What is built

- **Story 1** — `RateLimitVerdict.Spent` / `ReviewerOutcome.RateLimited.Spent` (`bool?`), `BoundedScheduler.Hopeless` reads it first, `AgyError` (both `AGY_ERROR` shapes), `AntigravityRuntime.RateLimited`, `ClaudeRuntime.RateLimited` (monthly spend limit), the pin in `AClaudeReasonInItsEnvelopeTests` reversed.
- **Story 2** — `AgyQuotaGroups` (the measured table), `AgyQuotaReport` (`Parse`, `ResetFor`), `AgyQuotaProbe`, `QuotaReset`, `QuotaCooldownEntry`, `CooldownWrite`, `QuotaCooldowns` (file + persistent lock + fail-open reads), `QuotaCooldownRound.cs` (`AfterRoundAsync`), `IReviewerRuntime.QuotaKeyOf` / `ReadResetAsync`, the agy override, `RetryLadder`'s note, `RESULTS_vendor_quota_gauges.md` §3.4, `quota-sample.json`, `EveryBudgetInAClockedClassReadsItsClockTests` joined.
- **Story 3** — `PanelService` (clock, `_cooldowns`, `CanRun`'s fourth condition, `ReasonFor`, `ProviderStatus.Cooldown`, refused-write notice), `CooldownReport` in `ServerJsonContext.cs`, `RoundEngine` calls `AfterRoundAsync`.
- **Story 4** — `cooldownWords.ts`, `providers.ts` (`cooldownOf`), `modelCard.ts` / `modelCardWorld.ts` / `modelsTab.ts`, `statedReset.ts` header, `catalogCss.ts` (+ re-pin in `teamServerTab.test.ts`).
- **Docs** — `module_runners.md`, `module_server.md`, `module_extension.md`, `module_tests.md`; the plan's status line and §12 (deviations).

## Decisions and deviations

The full list is the plan's **§12**. In short: S25 uses *October 15, 2026* (the plan's July date is before NOW); S34's Gemini row is undecided (the plan's "both spent" contradicts S41); agy's `ReadResetAsync` tells explicit from undecided by the reason's own sentence;
the refused-write notice goes through a callback (`NoticeWriter` is internal to `coai-mcp`), code `storage-note`; the launcher is a constructor parameter of `QuotaCooldowns`; `DeepseekRuntime` / `CustomCodexRuntime` answer the empty key; `entry.Consecutive` counts guess parks;
a past stated instant is no reset.

## Reds that differ from the plan's (details in §12)

S3 green first time; S6(a) `Expected undecided.Limited to be True, but found False`; S14 and S43 never red (real table / real parser from the start); S15 `…AgyQuotaRead+CannotCheck … but found …+Report`; S19 no `JsonException` (stub); S35/S36 hook never reached; S37 `Written` instead of `Refused`;
round tests red with `AfterRoundAsync` returning at once; S28, S38 green on the stub; S30 not seen red; S31–S33 red via a temporary `''` in `cooldownLine`. Break-it runs for S3/S6/S8/S27 were not done.

## Results

- **MCP suite (final run, 22:37–22:46 UTC):** 13,875 tests, 13,757 passed, 117 skipped, **1 failed** — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`:
  `ArgumentOutOfRangeException … is of an invalid length for use with domain sockets (max 108)`. **Environmental, not mine:** the session's `TMPDIR` is `/home/jinx/git/coai-exp2/r/d5399b9cf0ba/tmp/…`, so the test's
  `shown.sock` path is over the 108-character limit; my change touches nothing it reads. I could not rerun it with `TMPDIR=/tmp` (setting the variable needed an approval nobody could give). It would pass on a short temp dir.
- The first full run had 3 failures; two were mine and are fixed (commit `60133bf2`): `EveryBudgetInAClockedClassReadsItsClockTests.EveryProductFileWhoseConstructorTakesAClock_…` (PanelService now takes a `TimeProvider` → listed as *not scanned* with its reason) and
  `TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` (PanelService now builds the refused-write notice with `ServerNotice.Shortened` → added to the census list). The socket test was the third.
- **Extension (`npm --prefix src_vs_code test`):** 6,662 tests, 6,641 passed, 21 skipped, 0 failed (run before the last doc commit; no extension code changed after). `typecheck` and `lint` clean (complexity ≤ 4 forced two small refactors in `cooldownWords.ts` / `modelCardWorld.ts`).
- **Format:** `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes` prints only `IL2026`/`IL3050` AOT errors from `src_server` (design-time build; not in files this branch touches) and no formatting diffs.
- `plan-lifecycle.mjs`: clean.

## What remains

- The **code gate** over the branch with the plan as scope (`local.common.review-gate`) — not run; it needs the product's own gate, outside this task.
- Break-it runs for S3, S6, S8, S27 (listed in §12).
- A test that drives `RoundEngine`'s call and the live `NoticeWriter` for a refused write (not in the plan's scenarios).
- RESULTS §3.4's second row: the first `/quota` answer coai's own probe reads in a real round, and the agy version (owed to whoever sees it).
- Not proved (plan §6): Claude/GPT and Argon groups spent on agy; the error answer of a Claude/GPT or Argon model; `/quota` on any agy but 1.4.9.
