# Fix notes — review of `todo/PLAN_a_spent_quota_cools_the_model_down.md` (branch `feat/quota-cooldown`)

Commits (oldest first): `2e599826` R1, `b77bc375` R3, `8d4d5f98` R2, then the docs commit (R4–R6). Nothing pushed. No `src_vs_code` file changed.

## Per finding

- **R1 (major) — fixed.** S3's first case used the AGY_1_3_3 reason, whose *Resets in 88h49m9s* already stops the ladder through `RetryLadder.ResetOutlasts`. The reason is now the spent words with no reset
  (`SpentWordsAndNoReset`). Seen red: with `Hopeless` wired as `limited.Spent == true || ResetOutlasts(…)` S3 fails with `Expected spentWords.Launched to be 1 because nobody decided, no reset is stated, and the words say the
  allowance is spent, but found 4.` The code was restored (`git diff` of `BoundedScheduler.cs` is empty). The plan's §12 says so now.
- **R2 (minor) — fixed.** `AgyError`'s scanner is small methods (`LineEnd`, `BodyAfterMarker`, `SkipWhile`, `Balanced`, `DepthChange`, `PastString`, `ClosingQuote`). `AgyError.cs` is now in the `CA1502` sections of
  `.editorconfig`, so the build holds the bound (it builds clean). **A defect found on the way:** a blank line before an `AGY_ERROR` line ran the whitespace scan on into the marker's own line, so `Parse` returned the
  same object twice. Test first: `ABlankLineBeforeTheMarker_DoesNotReadTheErrorTwice`, red `Expected … to contain a single item`, green after. I added `ABraceOrAnEscapedQuoteInsideTheSentence_DoesNotEndTheObject`
  to guard the refactor (green before and after — it is a characterisation test, not a red-first one).
- **R3 (minor) — fixed.** `ACoolingRowStaysOutOfTheRoundTests` builds `PanelService` over a `ScriptedResults` launcher; S29 asserts `_launcher.Launched` is positive, so the fake, not the host's `agy`, answered.
- **R4 (minor) — fixed.** Plan §12 items 12 (API-key quota key) and 13 (`ConsultFailures` reads `Spent`); `research/module_server.md` names `QuotaKeyOf(model, apiKey)` and the `+key` suffix; `module_runners.md` says
  that `ConsultFailures` reads `Spent`.
- **R5 (minor) — fixed.** `research/module_tests.md`: `ARoundThatEndsOnASpentQuotaParksItTests` has a row; the added methods are listed; the false *no test runs a whole round* clause is replaced by *the lift is not driven
  through a real round*.
- **R6 (minor) — fixed in the docs, not in the card.** The finding is right (`CanRun` excludes every row of a parked key, so the lift only covers a round that was already running). Plan §12 item 14,
  `module_server.md` and `module_runners.md` say it and name the cure: wait for the reset, or delete the key's entry from `quota-cooldowns.json`. I did **not** add the cure to the cooling badge's title: the finding
  calls it optional, and it would change `src_vs_code` and its pinned tests.

## Not done

- Break-it runs for S6, S8 and S27 (the coder's list; the review did not ask for them).
- The cure in the card's title (R6, optional).

## Results

- **Build** (`dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4`): succeeded, 0 warnings, 0 errors (with `CA1502` on for `AgyError.cs`).
- **Changed test classes** (`AStructuredVerdictOutranksTheWordScanTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`, `ACoolingRowStaysOutOfTheRoundTests`, `TheAgyQuotaReportPicksTheResetTests`): 31 of 31 passed after the changes.
- **Whole MCP suite** (`CoaiMcp.Tests`, log `notes/fix-suite.log`, 23:56–00:08 UTC): 13,884 tests, 13,766 passed, 117 skipped, **1 failed** —
  `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException … is of an invalid length for use with domain sockets (108)`. I re-ran its class alone: the same
  failure. The cause is this session's temp directory (`…/r/d5399b9cf0ba/tmp/testsToDelete-coai-run-…/…/shown.sock` is over 108 characters), not the branch: no file the branch changes is read by that test. I tried to re-run it
  with a short `TMPDIR`; that command needs an approval and was not given, so I did not go around it. It is the same failure the coder's notes record. **Not proved green on this host.**
- **Format** (`dotnet format … --no-restore --verify-no-changes`): exit 2, with only `IL2026`/`IL3050` AOT errors, all in `src_server/src` and `src_bugs/src` (none in a file of this branch), and no formatting diff.
  Without `--no-restore` the tool died with *Restore operation failed* (no network here), so the run is `--no-restore`, after the build had restored.
- **Extension tests:** not run — no `src_vs_code` file changed in this round (the coder's last run: 6,662 tests, 0 failed).
- `plan-lifecycle.mjs`: clean.
