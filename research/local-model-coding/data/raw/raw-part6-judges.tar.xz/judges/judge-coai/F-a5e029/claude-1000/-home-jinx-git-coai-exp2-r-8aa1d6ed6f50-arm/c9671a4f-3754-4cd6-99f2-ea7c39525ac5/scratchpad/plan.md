# PLAN — a spent quota cools the model down

> Status: **plan only, nothing implemented yet, 2026-10-28 — revised the same day after the plan gate (coai session 95dd15f6,
> round 1, verdict proceed, gating 5 of threshold 6, 2 of 2 reviewers) and a consultation (codex-2 / gpt-6-astra); the review record
> is §11, and the two real agy captures of 2026-10-28 (agy 1.4.9) are committed with this revision as fixtures.** Scope: `src_mcp/runners/Reviewers/ReviewerExecutor.cs`
> (`RateLimitVerdict`, `ReviewerOutcome.RateLimited`), `src_mcp/runners/Reviewers/BoundedScheduler.cs` (`Hopeless`),
> `src_mcp/runners/Reviewers/ReviewerRuntime.cs` (two new default members), `src_mcp/runners/Reviewers/AntigravityRuntime.cs`,
> `src_mcp/runners/Reviewers/ClaudeRuntime.cs`, `src_mcp/runners/Reviewers/RetryLadder.cs` (one note), three new files under
> `src_mcp/runners/Reviewers/` (`AgyError.cs`, `AgyQuotaReport.cs`, `QuotaCooldowns.cs`), `src_mcp/src/Server/PanelService.cs`,
> `src_mcp/src/Server/ServerJsonContext.cs`, `src_mcp/src/Server/Rounds/RoundEngine.cs`, `src_vs_code/src/providers.ts`,
> `src_vs_code/src/modelCard.ts`, `src_vs_code/src/modelCardWorld.ts`, `src_vs_code/src/statedReset.ts` (one note), a new
> `src_vs_code/src/cooldownWords.ts`, their tests, the fixtures `src_mcp/tests/fixtures/antigravity/quota-2026-10-28.json` and
> `models-2026-10-28.txt` (committed with this revision), `research/module_runners.md`, `research/module_server.md`,
> `research/module_extension.md`, `research/module_tests.md`. Issues: #878 (whole) and the QUOTA part of #765 (§1.2).
>
> Related docs: [PLAN_a_spent_kimi_quota_is_not_a_lost_sign_in.md](PLAN_a_spent_kimi_quota_is_not_a_lost_sign_in.md) (its D2, D3
> and D5 are respected below, by number), [PLAN_a_stated_wait_is_read_rather_than_matched.md](PLAN_a_stated_wait_is_read_rather_than_matched.md)
> (BLOCKED; untouched), [PLAN_provider_liveness.md](PLAN_provider_liveness.md) (not built; its "a live answer overrules a closed
> door" finding is D4's lift rule), [RESULTS_vendor_quota_gauges.md](../research/RESULTS_vendor_quota_gauges.md) §3 (the measured
> agy refusal), [architecture.md](../research/architecture.md) § *A field added to the round list, and what "an older half" does with it*.

## 1. The symptom

**#878 (the owner, 2026-10):** when a model's limit is reached — the 5-hour one, the weekly one, the monthly one — the model is
still called on the next round, and the launch ends on its timeout. That can take up to 30 minutes, while the same model answers
in far less when it works. The ask: detect it, keep the model out while it cools down so it is not even launched, and let it back
by itself.

**#765, the quota part (the owner, 2026-10):** Antigravity (`agy`) keeps SEPARATE limits for its Gemini models and for its
"Claude and GPT" models. The ask: read a spent quota from agy's structured error, read WHEN it comes back from
`agy -p '/quota' --output-format json`, remember it, switch back automatically, and show on the row's card the date and time the
quota returns and how long is left. The issue brings two real samples from the owner's PC. Verbatim, because they are the
fixtures of this plan:

The `/quota` answer, "a real answer, shortened" (the owner's words; the command asked was `/quota`, the answer names `usage`):

```json
{
  "status": "SUCCESS",
  "command": {
    "name": "usage",
    "data": {
      "groups": [
        {
          "name": "Gemini Models",
          "buckets": [
            {
              "id": "gemini-weekly",
              "window": "weekly",
              "remaining_fraction": 0,
              "reset_time": "2026-10-14T07:19:16Z"
            },
            {
              "id": "gemini-5h",
              "window": "5h",
              "disabled": true,
              "remaining_fraction": 1
            }
          ]
        },
        {
          "name": "Claude and GPT models",
          "buckets": [
            {
              "id": "3p-weekly",
              "window": "weekly",
              "remaining_fraction": 1,
              "reset_time": "2026-10-18T16:30:21Z"
            },
            {
              "id": "3p-5h",
              "window": "5h",
              "remaining_fraction": 1,
              "reset_time": "2026-10-11T21:30:21Z"
            }
          ]
        }
      ]
    }
  }
}
```

The refusal of a plain Gemini request on a spent quota — exit code 3, this line on stderr, and a final JSON with `status=ERROR`:

```
AGY_ERROR: {
  "short_error": "RESOURCE_EXHAUSTED (code 429): Individual quota reached. Please upgrade your subscription to increase your limits. Resets in 62h46m48s.",
  "status": "RESOURCE_EXHAUSTED",
  "error_code": 429,
  "code_kind": "http",
  "retryable": true
}
```

```json
{
  "status": "ERROR",
  "response": "",
  "error": "Individual quota reached. Please upgrade your subscription to increase your limits. Resets in 62h46m48s."
}
```

**The real `/quota` answer, run by this plan's author on 2026-10-28 (agy 1.4.9, this machine, `agy -p '/quota' --output-format
json --print-timeout 20s`, exit 0, stderr empty)** is committed verbatim as `src_mcp/tests/fixtures/antigravity/quota-2026-10-28.json`
(it carries no personal data: percentages and reset instants). What it shows beyond the issue's sample — all of it read from the
file, by a script, not remembered:

| group `name` | bucket `id` | `window` | `remaining_fraction` | `reset_time` |
|---|---|---|---|---|
| Gemini Models (description: *Models within this group: Gemini Flash, Gemini Pro*) | `gemini-weekly` | weekly | 0.38499391078948975 | 2026-10-31T08:16:06Z |
| | `gemini-5h` | 5h | 0.8772271275520325 | 2026-10-28T23:43:10Z |
| Claude and GPT models (*Claude Opus, Claude Sonnet, GPT-OSS*) | `3p-weekly` | weekly | 1 | 2026-11-04T19:49:10Z |
| | `3p-5h` | 5h | 1 | 2026-10-29T00:49:10Z |
| Gemini 4 Argon (*For paid Pro plans, Argon quota is separate …*) | `gemini-argon-wtu-weekly` | weekly | 0.8337441086769104 | 2026-11-01T17:09:46Z |

So there are THREE groups, not two; a group can have ONE bucket (Argon, weekly only); a bucket carries `id` AND `name` (and
sometimes a `description`); `remaining_fraction` is fractional; the envelope is the stream's `result` shape (`status`, `response`
holding a tab-separated table, `usage`, then `command`). `agy models` the same day (committed as `models-2026-10-28.txt`) lists:
`gemini-4-argon-{low,medium,high}`, `gemini-3.8-flash-{low,medium,high}`, `claude-opus-5-5-{low,medium,high}`,
`claude-sonnet-5-5-{low,medium,high}`, `gpt-oss-120b-medium`. The 2026-10-10 list (`research/RESULTS_vendor_quota_gauges.md:213-216`)
also had `gemini-3.7-flash`, `gemini-3.6-flash` and `gemini-3.1-pro`.

The issue's own rules, kept as written: classify a spent quota ONLY from `status=RESOURCE_EXHAUSTED` together with the sentence
*Individual quota reached* — one exit 3, one HTTP 429 or one `status=ERROR` proves nothing; `retryable=true` is present even on a
weekly block and means nothing; `disabled=true` makes a bucket's `remaining_fraction` meaningless; a spent bucket without a
`reset_time` is an UNKNOWN reset, never an invented date; the error answer was observed on Gemini only, and nobody spends the
Claude/GPT quota to see theirs; an unknown model gets an unknown group, never Gemini by default; the Claude/GPT group coming back
does not bring Gemini back; and no model is switched automatically without a policy the project has.

## 2. Why (read from the code on `origin/main` e1ed0ed6, 2026-10-28 — every line below was opened, not remembered)

- **Nothing is remembered between rounds.** The only refusal record is the ledger line's `resetsUtc`
  (`src_mcp/runners/Reviewers/UsageLedger.cs:268`, written by `StatedResetOf` at `:438`, from the ambient clock at `:396`), and
  nothing on the server reads it back. `RetryLadder.ResetOutlasts` says so on purpose: *"Nothing is persisted across rounds: a
  local CLI's account can change under it (a re-login), and a parked row would then refuse a working account"*
  (`src_mcp/runners/Reviewers/RetryLadder.cs:87-88`); `src_vs_code/src/statedReset.ts` repeats it in its header. So the next round
  launches the spent row again — a fast refusal on agy, and on a CLI that hangs instead of refusing, the reviewer's whole timeout
  (`ReviewerSettings.Timeout`, 10 minutes by default, `src_mcp/runners/Reviewers/ReviewerRuntime.cs:101`; the ladder's steps on
  top, `BoundedScheduler.LadderAsync`, `src_mcp/runners/Reviewers/BoundedScheduler.cs:617`). That is #878's "up to 30 minutes".
- **The one "can this row run" predicate is the seam.** `PanelService.CanRun` (`src_mcp/src/Server/PanelService.cs:407-408`) is
  read from two directions: `RosterBuilder.BuildWork` deals work only to rows it accepts (`src_mcp/src/Server/Rounds/RosterBuilder.cs:220`;
  the security roster at `:95` uses the same `_canRun`), and `ExcludedFrom` (`PanelService.cs:460`) names, with `ReasonFor`
  (`:478`), every enabled row it refused — the round's sentence (`RoundEngine.cs:406-407`, `src_mcp/src/Server/Rounds/`), the
  "no ticked vendor can run" skip (`src_mcp/src/Server/Rounds/SkipReasons.cs:41`) and the card's badge all come from it. One
  condition added there reaches all of them. `ReasonFor` writes its words on THIS side and never quotes a vendor (its remark:
  the sentence travels into the calling AI's instruction stream); the plan keeps that.
- **agy's refusal is read by words, not by its fields.** `AntigravityRuntime` (`src_mcp/runners/Reviewers/AntigravityRuntime.cs:32`)
  overrides neither `RateLimited` nor `WhyItFailed`, so the executor's `Classified` (`src_mcp/runners/Reviewers/ReviewerExecutor.cs:1007`)
  falls back to `RateLimitVerdict.ByText` (`:275`): `RateLimit.Hit` (`:333`) needs a non-zero exit and one of `Phrases` (`:301`,
  *quota*, *usage limit*, …) or a status-code shape (`:325`); `RateLimit.Reason` (`:394`) picks the marked line; `Hopeless`
  (`:373`) is true when the line carries a `Spent` word (`:357`). The `AGY_ERROR` line carries *quota* AND the word *exhausted*
  inside `RESOURCE_EXHAUSTED`, so TODAY every `RESOURCE_EXHAUSTED` from agy reads as a spent allowance — the one with
  *Individual quota reached* and a transient one alike. The issue's five states cannot be told apart by that scan. Nothing reads
  `status`, `error_code`, `retryable`, `exit 3` or the stream's `status:"ERROR"` — and nothing should read the last three (§1).
- **The reset is already read, as text.** `CooldownParser.StatedReset` (`src_mcp/runners/Reviewers/CooldownParser.cs:83`) reads
  *Resets in 88h49m9s* (the duration regex at `:223`), a date and a clock time; `Until` (`:62`) is the Team server's reading with
  the 30-minute doubling guess (`Fallback`, `:87`; `Unparseable` `:26`, `MaxGuess` `:34`, `WeeklyWithoutDate` `:44`,
  `MaxStatedWait` `:52`). No reader of `/quota` exists: `agy --help` (1.3.3) listed no quota command on 2026-10-10
  (`research/RESULTS_vendor_quota_gauges.md:211-213`); the command exists on agy 1.4.9 and was run once on 2026-10-28 (§1, the
  committed fixture). **Nothing in coai's code has ever run it**: the reader and the probe are new work.
- **The Team server already does what the local side does not.** `AccountSlot` (`src_server/src/Slots/AccountSlot.cs:31`) carries
  `CooldownUntilUtc`, `IsReady` (`:45`) and `IsCoolingDown` (`:49`); `SlotRegistry.MarkCoolingDown` (`src_server/src/Slots/SlotRegistry.cs:343`)
  parks on `CooldownParser.Until` (`:348`), `MarkSucceeded` (`:374`) lifts, the state is `state.json` (`:399`). This plan brings the
  same three ideas — park on the stated reset, lift on success, a durable record — to the local side, keyed by quota rather than by
  account slot.
- **Claude's monthly spend limit ends as a plain exit.** `ClaudeRuntime.WhyItFailed` (`src_mcp/runners/Reviewers/ClaudeRuntime.cs:153`)
  reads the envelope's `is_error` and adds `(HTTP 429)`, but the runtime has no `RateLimited`, and the raw envelope carries none of
  `Phrases` and no status-code shape (`api_error_status":429` fails the `\bstatus\b\W{0,4}` regex) — so the measured envelope
  *"You've hit your monthly spend limit. Switch to another model to continue."* (`src_mcp/tests/AClaudeReasonInItsEnvelopeTests.cs:22-24`)
  is `NonZeroExit`, pinned at `:57-64`. A spent allowance that is not `RateLimited` is neither hopeless nor parkable.
- **Kimi is already classified from its structured report** (`KimiRuntime.RateLimited`, `src_mcp/runners/Kimi/KimiRuntime.cs:277`),
  hopeless by the vendor's own words; its reset clause is quoted and never parsed (the Kimi plan's D3). It needs no classifier here,
  only the parking rule.
- **The wire to the card is additive by convention.** `ProviderStatus` (`src_mcp/src/Server/ServerJsonContext.cs:7`) adds nullable
  members with `[JsonIgnore(WhenWritingNull)]` (`Warning` `:42`, `SurvivorMarker` `:50`), built in `PanelService.ProbeAsync`
  (`PanelService.cs:286`, the record at `:301-309`); the extension's `parseProviders` (`src_vs_code/src/providers.ts:240`, one row
  at `:262-277`) reads field by field and an older half ignores what it does not know (`research/architecture.md` § *A field added
  to the round list*). The card's foot already draws a `reset-line` from the ledger (`src_vs_code/src/modelCard.ts:273-279`,
  `statedReset.ts:33,44`; the words in `resetWords.ts:21,34`, `clockOf` in the viewer's zone through `Intl.DateTimeFormat`).
- **No zone conversion exists on the server**, and it cannot: the container is a chiselled image with no tz database, so
  `TimeZoneInfo.FindSystemTimeZoneById` throws there and works on a developer's box (`CooldownParser.cs:187-191`). The extension runs
  on Node, where `Intl` carries every zone.

## 3. Decisions

- **D1 — A structured verdict outranks the word scan (three values).** `RateLimitVerdict` (`ReviewerExecutor.cs:266`) gains
  `bool? Spent` (an init property, default `null`), and so does `ReviewerOutcome.RateLimited` (`:226`), carried from the verdict in
  `Classified` (`:1007`). `BoundedScheduler.Hopeless` (`BoundedScheduler.cs:680-682`) becomes `limited.Spent ?? RateLimit.Hopeless(limited.Reason)`,
  the `ResetOutlasts` half unchanged. `true`: the vendor's own field said the allowance is spent; `false`: it said transient;
  `null`: nobody said — the text is read exactly as today. Reason: the five states of §1 need the vendor's field to win over a word
  that happens to be inside a status name, and every text-only runtime keeps today's behaviour because `null` is the default.
- **D2 — agy is classified from the `AGY_ERROR` line and nothing else.** New `AgyError.Parse(stderr)` reads every line starting
  `AGY_ERROR` in BOTH observed shapes — `AGY_ERROR: {"short_error":…,"status":…,"error_code":…,"retryable":…}` (agy 1.3.3,
  `research/RESULTS_vendor_quota_gauges.md:197-198`; the test constant `src_mcp/tests/EveryPaidLaunchIsWrittenTests.cs:44-45`) and
  `AGY_ERROR {"code":…,"message":…}` (`src_mcp/tests/fixtures/antigravity/consult-quota.stderr.txt`, agy of 2026-10-02) — taking
  `status` or `code`, and `short_error` or `message`, by name; a line whose JSON does not parse is no error. `AntigravityRuntime`
  gains `RateLimited`: a non-zero exit with a parsed `RESOURCE_EXHAUSTED` whose message contains *Individual quota reached* →
  `Because(message, Spent: true)`; a `RESOURCE_EXHAUSTED` without that sentence → `Because(message, Spent: null)` (undecided: the
  ladder reads the words as today, and D5 asks the gauge before parking); anything else → `RateLimitVerdict.ByText(result)`,
  unchanged. Exit 3, HTTP 429, `retryable` and the stream's `status:"ERROR"` are not read (§1). The reason is the vendor's sentence;
  the executor has already redacted both streams before any adapter sees them (`StartAsync`, between `ReviewerExecutor.cs:932`
  and `:980`).
- **D3 — A cooldown is keyed by the QUOTA, never by the row id** (the Kimi plan's D5 constraint 1). `IReviewerRuntime`
  (`ReviewerRuntime.cs:324`) gains `string QuotaKeyOf(string model) => string.Empty` — empty means *this runtime has no quota coai
  parks*. Overrides: `CodexRuntime` → `codex`; `ClaudeRuntime` → `claude`; `KimiRuntime` → `kimi`; `AntigravityRuntime` → the key
  of the model's group by **one explicit, measured table** (`AgyQuotaGroups`, revised after the consultation — a prefix rule
  `gemini-` → Gemini would park every Gemini row when only Argon is spent, because Argon's ids start `gemini-` too):

  | model family (the id minus its trailing `-low` / `-medium` / `-high`) | group `name` (corroborates only) | bucket `id`s (what is matched) | key |
  |---|---|---|---|
  | `gemini-3.8-flash`, `gemini-3.7-flash`, `gemini-3.6-flash`, `gemini-3.1-pro` | Gemini Models | `gemini-weekly`, `gemini-5h` | `antigravity/gemini` |
  | `gemini-4-argon` | Gemini 4 Argon | `gemini-argon-wtu-weekly` | `antigravity/argon` |
  | `claude-opus-5-5`, `claude-sonnet-5-5`, `gpt-oss-120b` | Claude and GPT models | `3p-weekly`, `3p-5h` | `antigravity/3p` |
  | any other family | — | — | `antigravity/?<model>` (its own key; no inferred group; no gauge-based parking) |

  The families are the `agy models` lists of 2026-10-28 and 2026-10-10 (§1); the ids are the committed `/quota` fixture's; the
  group names and descriptions are never parsed at run time, a test only checks the table against the fixtures (S14, S43). A
  model the table does not know is the issue's unknown group — never Gemini by default; a positively classified spent refusal
  for it (D2, `Spent == true`) is still parked on the `stated`/`guess` fallback under its own key. Adding a family is one table
  row with the fixture that shows it. `LocalRuntime`, `ApiRuntime`, `RemoteRuntime`, `CustomCodexRuntime` and `VibeRuntime` keep
  the empty key — a local engine has no quota, a Team server parks its own slots, and the other three have no measured quota
  answer (§10). Two rows on one CLI sign-in share one key, as two Kimi rows share one lane (`BoundedScheduler.LaneOf`,
  `BoundedScheduler.cs:210`). (`local.common.vendor-routing` still forbids a Claude model on agy; the `3p` row is for GPT-OSS and
  for an agy row somebody configures against that rule, whose quota is still a fact.)
- **D4 — One small durable file, read on every decision, lifted by a success or by the clock.** New `QuotaCooldowns` over
  `<data dir>/quota-cooldowns.json` (the directory `PanelSettings.DataDir`, `src_mcp/src/Server/PanelSettings.cs:359`, so it
  partitions per side like everything else, `research/module_server.md:1928-1935`). One entry per key: `key`, `untilUtc` (ISO
  8601, UTC — `common.utc-timestamps`), `source` (`quota` | `stated` | `guess`), `model`, `note` (this side's sentence, then the
  vendor's redacted sentence through `VendorReason.Written`, at most 400 characters), `sinceUtc`, `consecutive`. Written with
  `AtomicFile.Write` (`src_mcp/runners/Files/AtomicFile.cs:46`, temp then move); a torn or unparseable file reads as *no cooldown*
  with ONE warning per process — a bad file must never park a working account (fail open); read on every `CanRun`, no cache (it
  is under 16 KiB for ever, §8); expired entries are dropped at the next write and ignored on read. `Standing(key, now)` answers the
  entry while `untilUtc > now` — at the instant itself the row is back, by itself, with no write. `Lift(key)` removes the entry when
  a launch of the same key ends `Ok` (a re-login, a plan bought: the liveness plan's "a live answer overrules a closed door"). The
  JSON is source-generated (Native AOT; the pattern of `runners/Kimi/KimiSurvivorMarker.cs`). **This reverses the "nothing is
  persisted across rounds" note** of `RetryLadder.cs:87-88` and `statedReset.ts`'s header, on purpose and for #878; the note's
  worry (a re-login under a parked row) is answered by the lift, the expiry and the card's sentence saying what is parked and why.
  - **The fail-open contract, stated whole (gate F1).** Every read — `Standing` from `CanRun`, from `ProbeAsync`, in the
    `--providers` one-shot mode (`src_mcp/src/Program.cs:386`) alike — catches `JsonException`, `IOException` and
    `UnauthorizedAccessException` and answers *no cooldown*, logging once per process. Every write — including creating the data
    directory when it is missing — catches `IOException` and `UnauthorizedAccessException` and answers an explicit
    `CooldownWrite.Refused(why)` that `AfterRoundAsync` logs as a warning AND writes as one server notice through the shared
    `NoticeWriter` (`src_mcp/src/Server/NoticeWriter.cs:33`, appending with `ServerNotices.Append`, `ServerNotices.cs:92`), so a
    lost park is visible to the person, not only in a log (plan gate round 2, F2); **a refused write never discards or delays the round's
    completed results**, which are already in hand (D5). No new `[JsonSerializable]` registration is needed for the wire:
    `ProvidersAnswer` is registered at `ServerJsonContext.cs:367` and its graph reaches `ProviderStatus.Cooldown`; S38 proves it
    by serialising one through the context.
  - **Two processes, one file (gate F3).** Several `coai-mcp` servers share one data directory, and a read-modify-write of the
    JSON can lose another process's park or lift. So every mutation runs under a **separate, persistent lock file**
    `<data dir>/quota-cooldowns.lock`, taken with the product's one cross-process primitive, `HeldFile.TakeWithin(path, wait)` with `wait` a parameter of `QuotaCooldowns`, default **30 s** (plan gate round 2, F5: a
    round takes minutes, so 30 s of contention costs nothing; tests pass a short wait)
    (`src_mcp/runners/Files/HeldFile.cs:36`; the pattern of `SessionStore.cs:469-470` and `ConsultCheckState.cs:430`): take the
    lock → re-read the JSON → apply the WHOLE aggregate of the round (D5) → `AtomicFile.Write` the JSON → release. The lock file is
    never deleted, never replaced and never the file being written (a held file cannot be the one `File.Move` replaces); the
    `/quota` probe runs OUTSIDE the lock, before it. `Hold.Busy` after the wait and `Hold.Unusable` both answer
    `CooldownWrite.Refused(why)` — **never an unlocked write**. Reads take no lock (`AtomicFile`'s move makes the JSON whole or
    previous). S35–S37 pin it.
- **D5 — Where and when a row is parked: after the round, from its outcomes, aggregated per key, one gauge call per key.**
  `RoundEngine` calls `await _cooldowns.AfterRoundAsync(results, ct)` between `RunAllAsync` (`RoundEngine.cs:416`) and the summary
  (`:443`), so the scheduler, the executor and the ladder are untouched. `results` is what `RunAllAsync` already returns — the
  list of `(ReviewerInvocation Invocation, ReviewerOutcome Outcome)` pairs (`BoundedScheduler.cs:224`, built at `:477`) — so the
  invocation of every outcome is in hand (gate F0): `result.Invocation` is the FIRST attempt's launch, and its `Request` is what D6
  clones (same executable, environment, home). **First aggregate, then mutate (gate F5):** the results are grouped by
  `Invocation.Adapter.QuotaKeyOf(Invocation.Model)` (empty keys dropped); per key, a qualifying spent outcome WINS over a sibling
  `Ok` in either order (a spent quota is the newer fact about the account; an answer that got through was the last of its window),
  one decision per key, then ONE locked write for the whole round (D4). A key qualifies for parking when any of its outcomes is
  `RateLimited` with `Spent == true`, or `RateLimited` with `Spent == null` and `RateLimit.Hopeless(reason)` — except for agy,
  where the gauge decides the undecided case (below); a key with an `Ok` and no qualifying refusal is lifted; everything else —
  a transient refusal, a `NonZeroExit` (an authentication error is one, with its `VendorDiagnosis` cure), a timeout — changes
  nothing. The reset comes from the new default member
  `Task<QuotaReset> ReadResetAsync(ReviewerInvocation, string reason, int consecutive, IProcessLauncher, DateTimeOffset nowUtc, CancellationToken)`
  on `IReviewerRuntime` — `consecutive` passed explicitly (the consultation; it is the standing entry's count, or 0 when none
  stands): the default answers `CooldownParser.StatedReset(reason, nowUtc)` as `stated` ("an estimate from the error text", the
  issue's words) or, when the text names no reset, `guess` = `nowUtc + CooldownParser.Fallback(reason, consecutive)` (the Team
  server's own 30-minute doubling to five hours — not a date anyone invented, a retry interval coai owns and says so).
  **Doubling restarts after expiry** (decided): an expired entry is deleted (D4), so a refusal after a gap starts at 30 minutes
  again — the vendor's window most likely reset in between, and a counter kept past its own expiry would park a working account
  longer each time (S39). **agy's override runs `/quota`** (D6) once per key per round, outside the lock: a reading of the row's
  group → `quota` with the bucket's `reset_time`; a group the gauge does not carry, a spent bucket without `reset_time`, or a call
  that fails → "cannot check", and the default's `stated`/`guess` road with the failure named in the note. For the UNDECIDED agy
  case (`Spent == null`): buckets all available → not parked, the note says *transient*; a bucket at 0 → parked `quota`; cannot
  check → not parked, the note says *could not check* — the issue's "undetermined" is never a parked row. **An explicitly spent
  refusal (`Spent == true`) whose gauge answers `Available`** is parked on `stated`/`guess` all the same (the refusal is the newer
  fact and the vendor's own field), and the note names the contradiction (S41). Kimi: `Spent` stays `null` and its reason is
  hopeless by the vendor's words (the Kimi plan's D2 stands); its clause is never parsed (D3 stands) → `guess`. Codex: hopeless by
  *hit your usage limit* → `stated` when its sentence names a date (`CooldownParser`'s *will refresh on July 15, 2026* form), else
  `guess`. **Cancellation:** the probe takes the round's token; a cancelled or stopped probe parks nothing, logs it, and the
  completed results still reach the summary — `AfterRoundAsync` never throws past the engine (S42). The clock is injected
  (`TimeProvider`, as `BoundedScheduler.cs:104-110`); the ledger's `StatedResetOf(outcome, DateTimeOffset.UtcNow)`
  (`UsageLedger.cs:396`) is not touched by this plan.
- **D6 — The `/quota` reader: the owner's command verbatim, parsed by name, the issue's selection rules.** `AgyQuotaProbe.ReadAsync`
  reuses the refused launch's own request (`invocation.Request with { Arguments = ["-p", "/quota", "--output-format", "json",
  "--print-timeout", "20s"], StdIn = "", Timeout = 30 s, TrackAs = "antigravity/quota" }`) — the same executable, the same
  environment (`ANTIGRAVITY_API_KEY` when set), the same working directory `AntigravityReadOnly.Home()` every reviewer launch runs in
  (`AntigravityRuntime.cs:39-63`, `AntigravityReadOnly.cs:56`) — through `IProcessLauncher` (exe + argv, a timeout that kills the
  tree). No `--disable-slash-commands` (the chat adapter passes it, `src_vs_code/src/agyAdapter.ts:21`; it would disable the very
  command). `/usage` is not called. `AgyQuotaReport.Parse(stdout)` reads `command.data.groups[].buckets[]` — `id`, `window`,
  `remaining_fraction`, `reset_time` (a `DateTimeOffset`, its offset kept, stored as UTC), `disabled` — by name; `name` and
  `description` are ignored; the group of a key is the buckets whose `id` is in D3's row for that key, EXACTLY (`gemini-weekly`,
  `gemini-5h` | `gemini-argon-wtu-weekly` | `3p-weekly`, `3p-5h`), wherever they sit. `ResetFor(key, nowUtc)` answers one of:
  `Available` (every active, readable bucket's `remaining_fraction > 0`); `Spent(untilUtc, which)` — the active weekly at 0 → its
  `reset_time`; else the active 5h at 0 → its `reset_time`; both active at 0 → the LATER instant, naming both; a group with ONE
  bucket (Argon) follows the same two rules with the one it has; `SpentWithoutReset` (a bucket at 0 with no `reset_time`, or one
  whose `reset_time` is not after `nowUtc` — a past instant is no reset, never a park on the past); `GroupMissing`. Edge cases,
  decided (the consultation): a `disabled: true` bucket is skipped for every rule; a bucket whose `remaining_fraction` is missing
  or not a number in `[0, 1]` is unreadable and skipped; a group that is absent, empty, all disabled or all unreadable is
  `GroupMissing` (cannot check); both active at 0 with one `reset_time` missing or past → `Spent` on the known one, the note naming
  the unknown. A probe that exits non-zero, times out or answers no parseable report is `CannotCheck(why)`. **Observed:** the
  committed 2026-10-28 answer (every group available, fractional fractions, three groups); the issue's sample (Gemini weekly at 0,
  5h disabled). **NOT observed anywhere:** the Claude/GPT (`3p`) group at 0, the Argon group at 0, and the error answer of a
  Claude/GPT or Argon model on a spent quota — every such fixture is constructed from a real one and marked so
  (`common.measurement` rule 3).
- **D7 — Claude's monthly spend limit is a spent rate limit.** `ClaudeRuntime` gains `RateLimited`: a non-zero exit whose
  envelope says `is_error: true` with `api_error_status: 429` and a `result` containing *hit your monthly spend limit* →
  `Because("<the sentence> (HTTP 429)", Spent: true)` (the sentence as `WhyItFailed` already builds it, `ClaudeRuntime.cs:153-184`);
  every other envelope → `ByText`. `RateLimit.Spent` is NOT given the phrase: the structured verdict carries the fact (D1), and the
  raw envelope is not `Marked`, so `GateReportingTests.EveryHopelessPhrase_HasAnObservedAnswerThatSurvivesTheLineFilter`
  (`src_mcp/tests/GateReportingTests.cs:206-209`) would refuse it rightly. The pin at `AClaudeReasonInItsEnvelopeTests.cs:57-64`
  (`NonZeroExit`) is reversed in the same commit: the outcome becomes `RateLimited`, one launch, hopeless. **The order in the
  executor is kept, and it is what makes this work (gate F2):** `Classified` asks the adapter's `RateLimited` FIRST
  (`ReviewerExecutor.cs:1010-1013`) and reaches `WhyItFailed` only for a launch that was not limited — so the spend envelope, which
  is both `is_error` and a 429, becomes `RateLimited` and never `NonZeroExit`; S7 pins that by being green only in that order.
  Claude names no reset in that sentence → parked `guess` (D5). The spend limit resets with the billing month, which the sentence
  does not say; the plan invents no day.
- **D8 — Time zone: UTC on the server, the viewer's zone on the card, `dd.MM.yyyy HH:mm`; Europe/Paris is a test, not a
  constant.** The issue asks for Paris with daylight saving. The server stores and says UTC ISO (it cannot convert — §2, last
  bullet — and its sentence reaches logs and the calling AI, which have no zone). The extension formats the instant with
  `Intl.DateTimeFormat('en-GB', { day, month, year, hour, minute, hourCycle: 'h23', timeZone? })` in the VIEWER's zone, as
  `clockOf` does today (`resetWords.ts:34`), and `timeZone` stays a test parameter: a viewer in Paris reads *14.10.2026 09:19*,
  a viewer in Kyiv *14.10.2026 10:19*, and the test pins `Europe/Paris` in summer AND winter so the DST half is proved. A
  hard-coded Paris would be wrong for every other viewer, and the owner's example is satisfied where the owner sits.
- **D9 — The wire and the card.** `ProviderStatus` gains `CooldownReport? Cooldown` (`UntilUtc`, `Source`, `Note`), nullable,
  `[JsonIgnore(WhenWritingNull)]`, built in `ProbeAsync` from `Standing(RuntimeFor(provider)?.QuotaKeyOf(provider.Model), now)`.
  `CanRun` gains `&& !IsCooling(provider)`; `ReasonFor` answers `its <quota name> is spent — back at <ISO UTC> (in N h)` /
  `… — back at about <ISO UTC> (estimated from the error text)` / `… — reset time unknown; next try at <ISO UTC> (coai's own
  wait)`, this side's words only; `<quota name>` is *Gemini quota on Antigravity*, *Claude-and-GPT quota on Antigravity*,
  *Gemini 4 Argon quota on Antigravity*, *quota for <model> on Antigravity (group unknown)*, *Claude plan allowance*, *Codex usage
  limit*, *Kimi plan quota*. The
  extension: `ProviderHealth.cooldown?` parsed like `warning`; a new leaf `cooldownWords.ts` — `cooldownLine(report, nowMs,
  timeZone?)` → `quota spent — back 14.10.2026 09:19 (in 63 h)` (hours and minutes rounded UP as `resetWords.ts:26` does, for
  the same reason), `quota spent — back about 14.10.2026 09:19 (in 63 h, estimated from the error text)`, `quota spent — reset
  time unknown; next try 11.10.2026 17:00 (in 30 min)`, and `''` once `untilUtc` has passed; the card's foot draws it as
  `cooldown-line` INSTEAD of the ledger's `reset-line` while a cooldown stands (two lines about one reset would disagree the day
  the gauge and the text differ), and `verdictBadge` (`src_vs_code/src/modelCardWorld.ts:134`) draws `cooling down` with the
  note as its title instead of *coai-mcp will run it*. An older extension ignores the member; an older server sends none and the
  card reads as today — the seam's own rule. No ticking: the panel re-renders on its 10 s probe refresh
  (`src_vs_code/src/panelProvider.ts:1070`) and the text is computed at render.
- **D10 — The five states, each with its road** (the issue §4; the scenarios in §4 prove each):

  | state | how coai knows | what happens |
  |---|---|---|
  | available | no refusal; `/quota` buckets `> 0` | nothing; an `Ok` lifts a standing cooldown (D4) |
  | spent | `Spent == true` (agy D2, Claude D7), or a hopeless reason (codex, Kimi) | one launch; parked until `quota` / `stated` / `guess` (D5) |
  | transient rate limit | `RateLimited` not hopeless; or agy undecided with `/quota` all available | the ladder as today; nothing parked |
  | authentication error | `NonZeroExit` with its `VendorDiagnosis` cure (`src_mcp/runners/Reviewers/VendorDiagnosis.cs:55`) | nothing parked; the cure as today |
  | cannot check | `/quota` failed, no group, no `reset_time` | nothing parked for an undecided refusal; `stated`/`guess` for a spent one, the failure named |

- **D11 — Nothing new is an outcome.** No `ReviewerOutcome` subtype is added: a cooling row is EXCLUDED from the roster (a roster
  fact, like a missing key), so `ReviewerNotices.ByType` (`src_mcp/src/Server/ReviewerNotices.cs:47`), the reflection guard
  (`src_mcp/tests/TheRefusalRoadsAreCountedTests.cs:206-207`), `Described` (`BoundedScheduler.cs:766`) and `FeatureSecondRound`
  are untouched (the Kimi plan's D5 constraint 3). The security roster shares `_canRun` (`RosterBuilder.cs:95`), so a cooling row
  is out of the security lane too — right for a spent quota, and named here rather than discovered.
- **D12 — Out of scope, with the reason** (a later plan, `PLAN_a_cooldown_reaches_every_road`, not written yet):
  - #765's **fallback model from another quota**, the **every-other-call mode** and **switching models automatically** — the
    issue itself says *do not switch the model automatically without a policy the project has*; a policy is a decision for the
    owner, and this plan ships the fact the policy would read (`Standing`).
  - The consultation, consultant-check and question-row roads (`ConsultantTurnBooks`, `ConsultationFailedTurns`, `ConsultantCheck`,
    `QuestionRowLaunch` — they write `resetsUtc` through `UsageLedger.StatedResetOf` and would need the same `AfterRoundAsync`
    and the same `CanRun` read); api rows (a key per endpoint and credential), custom codex, Vibe (no measured quota answer).
  - A *try now* button to lift a cooldown by hand; the help page sentence in five languages (`helpContent.ts:581` and its four
    translations); a ticking seconds countdown; the `/usage` alias; the Team server (it has its own slots).
  - Live `agy` calls in the build: no test runs the real CLI; the one real `/quota` run is the 2026-10-28 capture (§1), done by
    hand before the build. The first `/quota` answer coai's own probe reads in a real round is story 2's deviation record.
  - **Epics.** The gate's reply carried the operator's standing commands (split into 3–4 epics with per-epic gating, a Fable split,
    consultants, autonomous mode, cadence). This plan stays ONE file with four stories and no epics, by the owner's decision for
    this experiment: it is the frozen specification several coding pipelines implement whole, at ~1,100–1,500 changed lines —
    under one epic's size — and a split would give each pipeline a different document. Recorded in §11.

## 4. Scenarios (each red is an ASSERTION message, never a compile error — stub a missing class so it returns `null`/`Available`/empty first)

C# classes live in `src_mcp/tests/`; every `Given` fixture carries no real id, path or secret (public repository). `NOW` in the
C# tests is `new DateTimeOffset(2026, 10, 11, 16, 30, 0, TimeSpan.Zero)` through `FixedClock` (`src_mcp/tests/FixedClock.cs:12`) or
`ManualClock` (`src_mcp/tests/ManualClock.cs:18`); every temp folder is `TempDir.For("testsToDelete-quota-")`. Samples: **AGY_1_3_3**
= the two stderr lines of `research/RESULTS_vendor_quota_gauges.md:197-198` (`error_id` redacted, as `EveryPaidLaunchIsWrittenTests.cs:41-45`
carries them); **AGY_OLD** = `fixtures/antigravity/consult-quota.stderr.txt`; **QUOTA_SAMPLE** = the issue's JSON of §1, byte for
byte (story 2 commits it as `fixtures/antigravity/quota-sample.json`); **QUOTA_REAL** = `fixtures/antigravity/quota-2026-10-28.json`
(committed with this revision); **MODELS_REAL** = `fixtures/antigravity/models-2026-10-28.txt`; **CLAUDE_SPEND** =
`AClaudeReasonInItsEnvelopeTests.SpendLimit` (`:22-24`). Anything else is constructed and says so in a comment. `NOW` is before
every reset in QUOTA_REAL (its earliest is 2026-10-28T23:43:10Z).

### `AStructuredVerdictOutranksTheWordScanTests` (story 1)

- **S1** `ASpentVerdict_IsHopeless_WhateverTheWordsSay` — Given a fake `IReviewerRuntime` whose `RateLimited` answers
  `Because("try again later", usage, Spent: true)` and `ScriptedResults` (`src_mcp/tests/ScriptedResults.cs:15`) answering exit 1
  for ever, a `BoundedScheduler(retryLadder: three 1 ms steps)` as `AStatedResetIsNeverWaitedOutTests.cs:41-48` builds it; When the
  work runs; Then `Launched == 1`, the outcome is `RateLimited` with `Attempts == 1` and `Spent == true`. Red: `Expected
  launcher.Launched to be 1, but found 4`.
- **S2** `ATransientVerdict_ClimbsTheLadder_EvenWhenTheTextSaysExhausted` — Given `Because("RESOURCE_EXHAUSTED (code 429): too
  many requests", usage, Spent: false)` (constructed); Then `Launched == 4`. Red: `Expected launcher.Launched to be 4, but found 1`.
- **S3** `AnUndecidedVerdict_ReadsTheTextAsBefore` — Given `Spent: null` with the AGY_1_3_3 reason → 1 launch; with
  `"429 Too Many Requests"` → 4. Red (wire `Hopeless` as `limited.Spent == true` first, the tempting shape): `Expected
  launcher.Launched to be 1, but found 4` on the first case.

### `AnAgyQuotaIsReadFromItsStructuredErrorTests` (story 1)

- **S4** `TheIndividualQuotaLine_IsASpentVerdict` — Given `new ProcessResult(3, "", AGY_1_3_3, TimedOut: false)`; When
  `new AntigravityRuntime().RateLimited(invocation, result)`; Then `Limited`, `Spent == true`, `Reason` contains `Individual quota
  reached` and `Resets in 88h49m9s`, and `RateLimit.Hopeless(Reason)` is true. Red: `Expected verdict.Spent to be True, but found
  <null>`.
- **S5** `TheOlderErrorShape_IsReadToo` — Given exit 3 and AGY_OLD on stderr; Then `Spent == true`, `Reason` contains
  `Resets in 33m52s`. Red: the same message.
- **S6** `WithoutTheQuotaSentence_NothingIsSpent` — Given (a) exit 3, AGY_1_3_3 with the sentence replaced by `Too many requests`
  (constructed) → `Limited`, `Spent == null`; (b) exit 3, stderr `error: something else` and stdout
  `{"event":"result","result":{"status":"ERROR","response":"","error":"something else"}}` → `Limited == false`; (c) exit 3, stderr
  `429 Too Many Requests` → `Limited`, `Spent == null`. Red (break-it: an override keyed on `RESOURCE_EXHAUSTED` alone): `Expected
  verdict.Spent to be <null>, but found True` on (a).

### `AClaudeSpendLimitIsASpentQuotaTests` (story 1)

- **S7** `TheMonthlySpendLimitEnvelope_IsASpentRateLimit` — Given the real `ReviewerExecutor` over `Answers(Ran(CLAUDE_SPEND))`
  exactly as `AClaudeReasonInItsEnvelopeTests.cs:57-64` builds it; Then `launch.Terminal` is `RateLimited` with `Spent == true`,
  `Reason` contains `monthly spend limit` and `HTTP 429`, and `ReviewerSummaryFactory.Describe` starts `rate limited (after 1
  attempt)`. Red: `Expected type to be CoaiMcp.Runners.Reviewers.ReviewerOutcome+RateLimited, but found …+NonZeroExit`. The pin at
  `AClaudeReasonInItsEnvelopeTests.cs:63` is changed to `RateLimited` in the same commit. This test also pins the executor's order
  (D7): the envelope is `is_error` too, so a `Classified` that asked `WhyItFailed` first would answer `NonZeroExit` — the red above.
- **S8** `AnotherEnvelope_IsStillAnExit` — Given the HTTP 400 envelope (`OldCliNewModel`, `:26`) with exit 1 → `NonZeroExit`; a
  success envelope with exit 1 → not limited. Red (break-it: an override keyed on `is_error` alone): `Expected type to be
  …+NonZeroExit, but found …+RateLimited`.

### `TheAgyQuotaReportPicksTheResetTests` (story 2, pure over `AgyQuotaReport`)

- **S9** `GeminiWeeklySpent_FiveHourDisabled_BlocksUntilTheWeeklyReset_AndThe3pGroupIsAvailable` — Given QUOTA_SAMPLE; When
  `Parse` then `ResetFor("gemini", NOW)` and `ResetFor("3p", NOW)`; Then `Spent(2026-10-14T07:19:16Z, "weekly")` (the disabled 5h
  bucket ignored) and `Available`. Red: `Expected verdict to be Spent(2026-10-14T07:19:16+00:00, weekly), but found Available`.
- **S10** `ClaudeAndGptWeeklySpent_UsesThe3pWeeklyBucket` — Given QUOTA_SAMPLE with `3p-weekly`'s `remaining_fraction` set to `0`
  (constructed; the issue says this answer was never observed); Then `Spent(2026-10-18T16:30:21Z, "weekly")`. Red: `… but found
  Available`.
- **S11** `WeeklyAvailable_FiveHourSpent_UsesTheFiveHourReset` — Given `3p-5h` at `0`, `3p-weekly` at `1` (constructed); Then
  `Spent(2026-10-11T21:30:21Z, "5h")`. Red: `… but found Available`.
- **S12** `BothActiveBucketsSpent_TheLaterResetWins_AndBothAreNamed` — Given both 3p buckets at `0` (constructed); Then
  `Spent(2026-10-18T16:30:21Z, "weekly and 5h")`. Red: `Expected verdict.Which to be "weekly and 5h", but found "weekly"`.
- **S13** `ASpentBucketWithoutResetTime_IsUnknown_NeverADate` — Given `gemini-weekly` at `0` with no `reset_time` (constructed);
  Then `SpentWithoutReset`. Red: `Expected verdict to be SpentWithoutReset, but found Spent(0001-01-01T00:00:00+00:00, weekly)`.
- **S14** `AnUnknownModel_HasNoGroup` — `AgyQuotaGroups.KeyOf`: every model id of MODELS_REAL resolves to its D3 key
  (`gemini-4-argon-high` → `antigravity/argon`, `gemini-3.8-flash-high` → `antigravity/gemini`, `claude-sonnet-5-5-low` → `antigravity/3p`,
  `gpt-oss-120b-medium` → `antigravity/3p`); `gemini-3.1-pro-high` (the 2026-10-10 list) → `antigravity/gemini`; `llama-4-maverick`
  and `gemini-3.9-flash-high` (not in the table) → `antigravity/?<model>`; and `ResetFor("antigravity/?llama-4-maverick", NOW)`
  over QUOTA_REAL → `GroupMissing`. Red: `Expected key to be "antigravity/argon", but found "antigravity/gemini"` (a prefix rule).
- **S15** `AProbeThatFails_IsCannotCheck_AndTheCommandIsTheOwners` — Given a one-line `IProcessLauncher` fake that keeps the
  request and answers, in turn, exit 1 with stderr `unknown command /quota`; a `TimedOut: true` result; exit 0 with stdout `not
  json`; When `AgyQuotaProbe.ReadAsync(invocation, launcher, ct)`; Then each is `CannotCheck` naming `exit 1: unknown command
  /quota`, `timed out after 30 s`, `no report in the answer`; and the kept request has `Arguments == ["-p", "/quota",
  "--output-format", "json", "--print-timeout", "20s"]`, `StdIn == ""`, `Timeout == 30 s`, the invocation's executable, environment
  and working directory, and no `--disable-slash-commands`. Red: `Expected verdict to be CannotCheck, but found Available`.
- **S34** `ArgonSpent_WithOrdinaryGeminiAvailable_ParksOnlyArgon` — Given QUOTA_REAL with `gemini-argon-wtu-weekly`'s
  `remaining_fraction` set to `0` (constructed from the real capture; Argon at 0 is not observed); Then
  `ResetFor("antigravity/argon", NOW)` is `Spent(2026-11-01T17:09:46Z, "weekly")` and `ResetFor("antigravity/gemini", NOW)` is
  `Available`; and through `AfterRoundAsync` (two agy rows, `gemini-4-argon-high` and `gemini-3.8-flash-high`, both ended spent, one
  probe answering that JSON) only `antigravity/argon` stands. Red: `Expected standing("antigravity/gemini") to be <null>, but found …`.
- **S43** `TheRealAnswer_ReadsThreeGroups_AllAvailable` — Given QUOTA_REAL verbatim; Then `Parse` yields three groups with
  buckets `gemini-weekly`, `gemini-5h`, `3p-weekly`, `3p-5h`, `gemini-argon-wtu-weekly`, fractions `0.38499391078948975`,
  `0.8772271275520325`, `1`, `1`, `0.8337441086769104`; `ResetFor` is `Available` for all three D3 keys; and the group names and
  descriptions are not consulted (a copy with every `name`/`description` blanked gives the same verdicts). Red:
  `Expected buckets to contain 5 item(s), but found 4` (a two-group reader).
- **S40** `TheEdgeCases_AreDecidedAsWritten` (a `[Theory]`, one row per case, each constructed from QUOTA_REAL) — a group whose
  buckets are all `disabled: true` → `GroupMissing`; an empty `buckets` → `GroupMissing`; `remaining_fraction` missing, `"0"`,
  `-1` or `2` → that bucket skipped, the group `Available` when the other is readable and `> 0`; a weekly at 0 whose `reset_time`
  is `NOW - 1 h` → `SpentWithoutReset`; both at 0 with the 5h `reset_time` missing → `Spent(<weekly reset>, "weekly; 5h reset
  unknown")`. Red: `Expected verdict to be GroupMissing, but found Available` on the first row.

### `ASpentQuotaIsRememberedUntilItsResetTests` (story 2, the file)

- **S16** `AParkedKey_StandsUntilItsReset_ThenIsBackOnItsOwn` — Given `QuotaCooldowns(dir, FixedClock(NOW), log)`; When
  `Park("antigravity/gemini", NOW + 63 h, "quota", model, note)`; Then `Standing(key, NOW)` is the entry with that `UntilUtc` and
  `Source`, `Standing(key, NOW + 63 h)` is `null`, and `Standing("antigravity/3p", NOW)` is `null`. Red: `Expected standing not to
  be <null>`.
- **S17** `TheRecordSurvivesANewStore` — a second `QuotaCooldowns` over the same directory (a server restart) answers the same
  entry. Red: `Expected standing not to be <null>`.
- **S18** `AnAnsweredLaunch_LiftsTheCooldown` — `Lift(key)` → `Standing` is `null`, and the file no longer names the key. Red:
  `Expected standing to be <null>, but found QuotaCooldownEntry { … }`.
- **S19** `ATornFile_ParksNobody_AndSaysSoOnce` — Given `quota-cooldowns.json` holding `{"v":1,"entries":[{"key":`; Then
  `Standing` is `null` for every key, no exception, and the Serilog sink (as `TheReviewerFailuresAreWrittenDownTests` wires one)
  holds exactly one warning naming the file after three reads. Red: `System.Text.Json.JsonException: Expected depth to be zero at
  the end of the JSON payload …` escaping the test.
- **S20** `AnExpiredEntry_IsDroppedAtTheNextWrite_AndTheFileStaysSmall` — Given a `ManualClock`, three keys parked for 1 h, the
  clock advanced 2 h, a fourth key parked; Then the file holds one entry; and ten entries with 400-character notes keep the file
  under 16 KiB. Red: `Expected entries to contain 1 item(s), but found 4`.
- **S21** `TheGuess_DoublesPerConsecutivePark_AndStopsAtFiveHours` — `QuotaReset.Guess(reason, consecutive, NOW)` is
  `NOW + CooldownParser.Fallback(reason, consecutive)`: 30 min, 60 min, 120 min, 240 min, 5 h, 5 h; and `Park` of a key already
  standing with `guess` carries `consecutive + 1`. Red: `Expected until to be <2026-10-11 17:30:00 +00:00>, but found
  <2026-10-11 17:00:00 +00:00>`.
- **S35** `TwoWriters_InterleavedUnderTheLock_LoseNeitherKey` — Given two `QuotaCooldowns` over one directory and a seam that
  lets the test hold A after its locked re-read (an `Action` hook called inside the lock, as `HeldFile.TakeVerified`'s `afterOpen`
  hook does, `HeldFile.cs:92`); When A parks `codex` and pauses, B parks `claude` on another thread, A resumes; Then B waited (its
  write landed after A's), and the file holds BOTH keys. Red (an unlocked read-modify-write): `Expected entries to contain 2
  item(s), but found 1`.
- **S36** `AParkAndALift_InterleavedUnderTheLock_EndWhereTheLastWriteSays` — Run 1: A parks `codex` and pauses after its locked
  read; B's `Lift("codex")` waits on the lock; A writes and releases; B re-reads (sees `codex`), lifts, writes → `codex` absent.
  Run 2: A lifts (nothing stands) and pauses; B's park waits; A releases having written nothing; B parks → `codex` stands. Assert
  `Standing("codex")` after each run, and that the hook counted no write outside the lock. Red: run 1 ends with `codex` standing
  (B read before A wrote).
- **S37** `AWriteThatCannotHappen_IsRefusedOutLoud_AndParksNothingUnlocked` — (a) the lock held by another handle for longer than
  the wait (the test passes 200 ms) → `Park` answers `CooldownWrite.Refused` naming the lock, the file unchanged, and one notice
  naming it is handed to the notice writer; (b) a data directory that is a FILE → `Refused`
  naming the `IOException`; (c) `Standing` over the same broken directory → `null`, no throw. Red: `System.IO.IOException: … because
  it is being used by another process` escaping (a) — or on Linux the advisory-lock refusal.
- **S39** `AGapPastExpiry_RestartsTheGuessAtThirtyMinutes` — `ManualClock`: park `claude` with `guess` (30 min), advance 31 min
  (expired), park again → 30 min, not 60; without the gap → 60. Red: `Expected until to be <NOW+31min+30min>, but found <…+60min>`.

### `TheRoundParksAndLiftsTheQuotaTests` (story 2, `QuotaCooldowns.AfterRoundAsync` over constructed `(Invocation, Outcome)` pairs)

- **S22** `ASpentAgyRefusal_AsksQuotaOnce_AndParksTheGroupUntilTheReset` — Given two antigravity rows (models
  `gemini-3.8-flash-high`, `gemini-3.1-pro-high`) each ended `RateLimited(AGY_1_3_3 reason) { Spent = true }`, and a
  `ScriptedResults` answering exit 0 with QUOTA_SAMPLE; When `AfterRoundAsync`; Then `Launched == 1`, `Standing("antigravity/gemini")`
  has `UntilUtc == 2026-10-14T07:19:16Z`, `Source == "quota"`, and `Standing("antigravity/3p")` is `null`. Red: `Expected standing
  not to be <null>`.
- **S23** `WhenQuotaCannotBeRead_TheStatedResetIsAnEstimate` — Given the same refusal and a probe answering exit 1; Then
  `UntilUtc == NOW + 88h49m9s`, `Source == "stated"`, the note contains `exit 1`. Red: `Expected source to be "stated", but found
  "quota"`.
- **S24** `AnUndecidedExhaustion_IsParkedOnlyWhenTheGaugeSaysSpent` — Given `RateLimited(AGY_1_3_3 with the sentence replaced by
  "Too many requests") { Spent = null }` (constructed) and (a) a probe answering QUOTA_SAMPLE with `gemini-weekly` at `1` → not
  parked, the log says `transient`; (b) QUOTA_SAMPLE as is → parked `quota`; (c) a probe exiting 1 → not parked, the log says
  `could not check`. Red: `Expected standing to be <null>, but found QuotaCooldownEntry { … }` on (a).
- **S25** `ACodexSpentAllowance_IsParkedOnItsStatedDate_AndAnAnswerLiftsIt` — Given a codex row ended `RateLimited("You've hit
  your usage limit. Your limit will refresh on July 15, 2026.") { Spent = null }` (constructed from `CooldownParser`'s own date
  form) → `Standing("codex")` is `2026-07-16T00:00:00Z`, `stated`; then an `Ok` result for codex → `null`. And a Claude row ended
  `RateLimited("You've hit your monthly spend limit. … (HTTP 429)") { Spent = true }` → `Standing("claude")` is `NOW + 30 min`,
  `guess`; a `Kimi` row ended `RateLimited(KimiMonthlyQuotaTests.MonthlyLine)` → `Standing("kimi")`, `guess`. Red: `Expected standing
  not to be <null>`.
- **S41** `ASpentRefusalWinsOverASiblingAnswer_InEitherOrder_AndOverAnAvailableGauge` — Given two agy Gemini rows, one ended
  `RateLimited(AGY_1_3_3) { Spent = true }` and one `Ok`, in both list orders, with a probe answering QUOTA_REAL (every bucket
  available); Then `antigravity/gemini` stands in both orders, `Source == "stated"` (`NOW + 88h49m9s`), and the note says the
  gauge read `Available` while the refusal said spent; one probe launch. Red: `Expected standing not to be <null>` on the
  `[Ok, RateLimited]` order (a last-writer rule) and `Expected source to be "stated", but found "quota"`.
- **S42** `ACancelledProbe_ParksNothing_AndTheResultsAreStillTheRounds` — Given a launcher whose `/quota` launch waits for its
  token, and a token cancelled while it waits; When `AfterRoundAsync` with the spent Gemini results; Then it returns (no
  `OperationCanceledException` escapes), nothing stands, the log says the probe was cancelled, and the `results` list handed in is
  returned unchanged. Red: `System.Threading.Tasks.TaskCanceledException: A task was canceled` escaping.

### `ACoolingRowStaysOutOfTheRoundTests` (story 3, through `PanelService` as `RoundNamesTheExcludedTests.cs:66-76` builds it, plus `clock:`)

- **S26** `ACoolingAgyRow_IsExcluded_WithThisSidesSentence` — Given a data dir whose `quota-cooldowns.json` parks
  `antigravity/gemini` until `2026-10-14T07:19:16Z` (`quota`) with a note carrying the vendor's sentence, an enabled antigravity row
  on `gemini-3.8-flash-high`, `FixedClock(NOW)`; Then `ExcludedFrom(Stage.PlanReview)` is one line starting `antigravity: its
  Gemini quota on Antigravity is spent — back at 2026-10-14T07:19:16Z (in 63 h)` and NOT containing `Individual quota reached`.
  Red: `Expected excluded to contain a single item, but the collection is empty`.
- **S27** `AnotherGroupOnTheSameCli_StillRuns` — a second antigravity row on `gpt-oss-120b-medium` is not excluded. Red (break-it:
  a key of `antigravity` alone): `Expected excluded to contain 1 item(s), but found 2`.
- **S28** `WhenTheResetHasPassed_TheRowRunsAgain_WithoutAnyWrite` — `FixedClock(2026-10-14T07:19:16Z)` → excluded is empty, and the
  file's bytes are unchanged. Red: `Expected excluded to be empty, but found {"antigravity: …"}`.
- **S29** `TheProvidersAnswer_CarriesTheCooldown_AndNothingForARowThatIsNotCooling` — `await service.ProvidersAsync()`
  (`PanelService.cs:258`) parsed as JSON: the antigravity row has `cooldown.untilUtc == "2026-10-14T07:19:16Z"`, `cooldown.source ==
  "quota"`, a `cooldown.note`; the second row's object has NO `cooldown` property. Red: `Expected status.Cooldown not to be <null>`.
- **S38** `AProvidersAnswerWithACooldown_SerialisesThroughTheGeneratedContext` — Given a `ProvidersAnswer` holding one
  `ProviderStatus` with a populated `Cooldown` and one without; When serialised with `ServerJsonContext.Default.ProvidersAnswer`
  (`ServerJsonContext.cs:367`) and parsed back as a `JsonDocument`; Then the first row's `cooldown` has `untilUtc`, `source`, `note`
  as camel-case members and the second row has no `cooldown` member. Red: `Expected JSON to contain property "cooldown"` (a
  `JsonIgnore` on the wrong condition, or a member the context cannot reach — a `NotSupportedException` in AOT).

### `aCoolingRowSaysWhenItIsBack.test.ts` (story 4, `src_vs_code/src/test/`)

- **S30** `test('TheParser_ReadsTheCooldown — present when the server sends it, absent for an older server and for a half')` —
  `parseProviders` over a row with `cooldown: {untilUtc, source, note}` → `health.cooldown` equal; a row without it → no
  `cooldown` key; a row with `cooldown: {source: "quota"}` (no `untilUtc`) → no `cooldown` key. Red: `Expected values to be
  strictly deep-equal: undefined !== { untilUtc: …, source: 'quota', note: … }`.
- **S31** `test('AQuotaReset_IsSaidAsDateTimeAndTimeLeft — 2026-10-14T07:19:16Z is 14.10.2026 09:19 in Europe/Paris, 63 h left')`
  — `cooldownLine({untilUtc: '2026-10-14T07:19:16Z', source: 'quota', note}, Date.parse('2026-10-11T16:30:00Z'), 'Europe/Paris')`
  → `quota spent — back 14.10.2026 09:19 (in 63 h)`; the same instant in `Europe/Kyiv` → `… 10:19 …`; `2026-12-01T07:19:16Z` in
  `Europe/Paris` → `… 01.12.2026 08:19 …` (winter: the DST half); 34 minutes left → `(in 34 min)`; an `untilUtc` already passed
  → `''`. Red: `Expected values to be strictly equal: '' !== 'quota spent — back 14.10.2026 09:19 (in 63 h)'`.
- **S32** `test('AnEstimateAndAGuess_SayWhatTheyAre — about … from the error text; reset time unknown, next try')` —
  `stated` → `quota spent — back about 14.10.2026 09:19 (in 63 h, estimated from the error text)`; `guess` with 30 min left →
  `quota spent — reset time unknown; next try 11.10.2026 19:00 (in 30 min)` in Paris. Red: the `quota` wording for both.
- **S33** `test('TheModelsCard_CarriesTheCooldownLine_AndTheBadge — read off the RUNNING page; nothing for a row that is not cooling')`
  — `modelsTabHtml` over `panelState('reviewers', …)` (`src_vs_code/src/test/panelPageHarness.ts:293`) whose `reported` carries the
  cooldown for one of two rows, run through `runPageHtml` (`src_vs_code/src/test/pageScriptHarness.ts:204`); Then that card's
  `.cooldown-line` text is the S31 line, its verdict badge reads `cooling down` with the note as `title`, it has no `.reset-line`
  even with a `roundsSnapshot` that would draw one, and the other card has no `.cooldown-line` and the `coai-mcp will run it`
  badge. Red: `Expected values to be strictly equal: null !== 'quota spent — back …'`.

## 5. Build order

1. **Story 1** — D1, D2, D7 (S1–S8). Nothing persists yet; every round behaves as today except that agy's transient
   `RESOURCE_EXHAUSTED` climbs the ladder and Claude's spend limit is a one-launch `RateLimited`.
2. **Story 2 (cornerstone)** — D3, D4, D5, D6 (S9–S25, S34–S37, S39–S43). The record, the reader, the probe, the rule — all
   testable without `PanelService`.
3. **Story 3** — D9's server half, D10, D11 (S26–S29, S38): `CanRun`, `ReasonFor`, `ProviderStatus.Cooldown`, `RoundEngine`'s call.
4. **Story 4** — D8, D9's extension half (S30–S33). Can be written beside story 3 once `CooldownReport`'s three member names are
   fixed (they are, in D9); merged after it.

Docs travel with each story (§7). The code gate runs once over the whole branch, with this plan as the scope.

## 6. Test plan

- Unit and scenario tests in `src_mcp/tests/` (xUnit v3, run as the MTP executable through `low-priority.mjs`, never
  `dotnet test`): the seven classes of §4, each scenario seen RED first with the message named there, then green, then
  broken-and-restored where the scenario says *break-it*. The launcher is faked in process (`ScriptedResults`, or the one-line
  recording fake of S15); the clock is `FixedClock`/`ManualClock`; no test runs `agy`, `claude`, `codex` or `kimi`.
- `EveryBudgetInAClockedClassReadsItsClockTests` (`src_mcp/tests/`) judges classes that own a `TimeProvider`: `QuotaCooldowns` owns
  one and uses no `Stopwatch`, `CancelAfter`, `Task.Delay` or timer — the probe's bound is `ProcessRequest.Timeout`, the launcher's
  own. If the guard lists product files by name, `QuotaCooldowns.cs` joins its list in story 2.
- Extension node tests (`npm --prefix src_vs_code test`): the four tests of S30–S33, the card one RUNNING the page per
  `.agents/PROJECT.md`'s webview rule; the parser cases cover the old-server shape (no member) so the seam rule is pinned on this side.
- The existing suites that must stay green and are touched on purpose: `AClaudeReasonInItsEnvelopeTests` (S7's reversal),
  `AStatedResetIsNeverWaitedOutTests` (unchanged behaviour: agy's stated reset still ends the ladder), `CooldownParserTests`,
  `GateReportingTests`, `RoundNamesTheExcludedTests`, `TheReviewerFailuresAreWrittenDownTests`, `statedReset.test.ts`,
  `providersBadge.test.ts`.
- Cross-process (S35–S37): two `QuotaCooldowns` in ONE test process over one directory, interleaved through the in-lock hook —
  `HeldFile`'s exclusive open is per handle, so two handles in one process contend exactly as two processes do; no test spawns a
  second process for it, and no test holds an inheritable handle (`NoTestHoldsAnInheritableHandleTests`).
- Not proved here, and said so: the Claude/GPT and Argon groups spent on agy; the error answer of a Claude/GPT or Argon model on a
  spent quota; `/quota` on any agy but 1.4.9 (the issue's sample's version is not recorded); coai's own probe against a real agy.
  The first `/quota` answer the PROBE reads in a real round is written into `research/RESULTS_vendor_quota_gauges.md` as a new
  §3.4 by whoever sees it first; the hand capture of 2026-10-28 goes there as §3.4's first row with this plan's story 2.

## 7. Definition of Done

- [ ] S1–S43 green, each seen red first with the message named in §4; the suites of §6 green; `dotnet format` clean.
- [ ] Every write to `quota-cooldowns.json` runs under `quota-cooldowns.lock`; a write that cannot happen is an explicit refusal
      that never touches the round's results (S35–S37); a bad or unreadable file parks nobody (S19, S37).
- [ ] agy keys come from D3's table only — Argon spent parks Argon alone (S34); an unknown family gets its own key (S14).
- [ ] A row whose quota is spent is not launched by the next round: it is EXCLUDED with this side's sentence naming the return
      time in UTC, and the round's summary / skip sentence say so (S26, S28).
- [ ] agy's spent quota is classified from `AGY_ERROR`'s `status` + sentence, never from exit 3, 429 or `status=ERROR` alone
      (S4–S6); the reset is read from `/quota` by the issue's rules (S9–S14), with the stated text as a marked estimate and
      coai's own wait as a marked guess when it cannot (S23, S32).
- [ ] The five states each take their road (D10): a transient refusal is not parked, an authentication error is not parked, a
      failed check parks nothing it did not already know (S24).
- [ ] The cooldown survives a server restart and ends by itself at the stated instant, with no write (S17, S28); an answered
      launch lifts it (S18, S25).
- [ ] Claude's monthly spend limit is a spent rate limit with one launch (S7).
- [ ] The card shows the return date and time in the viewer's zone as `dd.MM.yyyy HH:mm` and the time left, rounded up, and says
      when it is an estimate or a guess (S31–S33); an older server or extension on the other side changes nothing (S30).
- [ ] `quota-cooldowns.json` has its budget (§8) and is under 16 KiB in S20.
- [ ] `RetryLadder.cs:87-88`'s note and `statedReset.ts`'s header say what is now persisted and by whom.
- [ ] Docs: `research/module_runners.md` (the agy classifier, `QuotaKeyOf`, `ReadResetAsync`, the parking rule; its agy quota
      paragraph at `:1231` and `:1261`), `research/module_server.md` (the file in the data directory, `CanRun`'s fourth
      condition, the wire member), `research/module_extension.md` (the card line and badge), `research/module_tests.md`
      (the seven classes and the node file, each flow `covered`; what is not proved).
- [ ] The plan gate ran over this document before story 1; the code gate over the branch with this plan as scope; every finding
      resolved with a reason; this plan promoted with its deviations when shipped (with the later-plan line of D12 kept).

## 8. Budget — the one thing that grows

`<data dir>/quota-cooldowns.json`:

- **Projected size:** at most one entry per key; the keys this plan can write are `codex`, `claude`, `kimi`, `antigravity/gemini`,
  `antigravity/argon`, `antigravity/3p` and one `antigravity/?<model>` per unknown agy model a person configures — under ten in
  any real settings file. Beside it, `quota-cooldowns.lock`: one empty file, created once, never grows, never deleted.
  An entry is six short fields and a note capped at 400 characters: ≤ 600 bytes. **Ten entries ≈ 6 KB; the 16 KiB bound of S20
  is the ceiling**, kept for ever by the next rule.
- **Who retires it:** every write drops every entry whose `untilUtc` is past (S20); every read ignores them. The file is never
  deleted and never rotated — it is a set, not a log. A key is also removed by `Lift` (S18).
- **When it is interrupted:** `AtomicFile.Write` publishes by move, so a kill mid-write leaves the previous file whole; a torn file
  (a NAS, a partial copy) reads as *no cooldown* with one warning (S19) and is overwritten whole by the next park. There is no
  in-flight state: a round's parks and lifts are ONE write under the lock, and nothing waits on it but the lock wait (30 s at most). Several
  `coai-mcp` processes on one data directory read the file on every decision, so a park by one is seen by the others on their
  next round; two rounds ending at once serialise on the lock and both aggregates land (S35). A holder that dies releases the
  lock with its handle (`HeldFile`'s own property); nothing stale is left to sweep.
- **The probe:** one `agy` child per spent key per round, bounded at 30 s by the launcher's own tree-killing timeout
  (`common.security`, external processes), tracked as `antigravity/quota` like every reviewer launch. No cache, no retry.

## 9. Stories

Four stories, no epics, one cornerstone — the shape of the Kimi quota plan. Model roles per `common.subagent-models`: **Fable**
specs the cornerstone (this document is that spec for story 2); **Opus** writes the other stories' briefs from this document and
reviews every story; **Sonnet** codes. Each story: red first, the red message in the summary, cyclomatic complexity ≤ 4 per
method, no real machine data in a test or fixture, `testsToDelete-` on every temp folder.

**Commands, for every story** (from the worktree root; `low-priority.mjs` on every run that is not a one-liner):

```bash
node .agents/conventions/tools/low-priority.mjs dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4
node .agents/conventions/tools/low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests.exe --filter-class "*<TheClass>"   # the story's classes first
node .agents/conventions/tools/low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests.exe                                 # then the whole suite
node .agents/conventions/tools/low-priority.mjs dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes
node .agents/conventions/tools/low-priority.mjs npm --prefix src_vs_code run typecheck && node .agents/conventions/tools/low-priority.mjs npm --prefix src_vs_code run lint
node .agents/conventions/tools/low-priority.mjs npm --prefix src_vs_code test                                                          # story 4
node .agents/conventions/tools/plan-lifecycle.mjs                                                                                      # every story that edits a doc
```

No generator check applies: no `shared/*.json` file changes (the wire member is a nullable record field on `ProviderStatus`, read
field by field on the other side).

### Story 1 — a verdict says whether the allowance is spent (D1, D2, D7)

- **Owns:** D1, D2, D7; S1–S8.
- **Files:** `src_mcp/runners/Reviewers/ReviewerExecutor.cs` (`RateLimitVerdict` `:266-277` gains `Spent`; `RateLimited` `:226`
  gains `Spent`; `Classified` `:1007` carries it), `src_mcp/runners/Reviewers/BoundedScheduler.cs` (`Hopeless` `:680-682`), new
  `src_mcp/runners/Reviewers/AgyError.cs` (the `AGY_ERROR` line parser, both shapes), `src_mcp/runners/Reviewers/AntigravityRuntime.cs`
  (`RateLimited` override), `src_mcp/runners/Reviewers/ClaudeRuntime.cs` (`RateLimited` override beside `WhyItFailed` `:153`);
  tests `AStructuredVerdictOutranksTheWordScanTests.cs`, `AnAgyQuotaIsReadFromItsStructuredErrorTests.cs`,
  `AClaudeSpendLimitIsASpentQuotaTests.cs`, and the one-line change at `AClaudeReasonInItsEnvelopeTests.cs:63`.
- **Red-first, expected reds:** S1 `Expected launcher.Launched to be 1, but found 4`; S2 `… to be 4, but found 1`; S3 (with
  `limited.Spent == true`) `… to be 1, but found 4`; S4, S5 `Expected verdict.Spent to be True, but found <null>`; S6 (break-it)
  `Expected verdict.Spent to be <null>, but found True`; S7 `Expected type to be …RateLimited, but found …NonZeroExit`; S8
  (break-it) the reverse.
- **Done when:** `Spent` is three-valued on the verdict and the outcome; the scheduler's `Hopeless` reads it first; agy's quota
  verdict comes from the structured line in both observed shapes and a transient `RESOURCE_EXHAUSTED` is undecided; Claude's
  spend limit is `RateLimited`, hopeless, one launch; `AStatedResetIsNeverWaitedOutTests` and `GateReportingTests` unchanged and
  green; `RateLimit.Spent` unchanged.

### Story 2 — CORNERSTONE: the quota is read, remembered and released (D3, D4, D5, D6)

- **Why the cornerstone:** this is the rule every other story renders. A wrong key parks a working row (two agy groups under one
  key, or one sign-in under two); a wrong lift keeps a cured account out; a gauge read wrongly parks a row on a disabled bucket or
  invents a date the vendor never gave. If this story is wrong, stories 3 and 4 faithfully show a wrong decision.
- **Owns:** D3, D4, D5, D6; S9–S25, S34–S37, S39–S43.
- **Files:** `src_mcp/runners/Reviewers/ReviewerRuntime.cs` (`IReviewerRuntime` `:324` gains the default members `QuotaKeyOf` and
  `ReadResetAsync`; `CodexRuntime` `:587` overrides `QuotaKeyOf`), `AntigravityRuntime.cs` (`QuotaKeyOf` through the table,
  `ReadResetAsync` through the probe), `ClaudeRuntime.cs` and `src_mcp/runners/Kimi/KimiRuntime.cs` (`QuotaKeyOf`, one line each),
  new `src_mcp/runners/Reviewers/AgyQuotaReport.cs` (`AgyQuotaGroups` — D3's table and `KeyOf`; `Parse`, `ResetFor`, the verdict
  record, its source-generated JSON context) and `AgyQuotaProbe` (in the same file or beside it, under 400 lines together), new
  `src_mcp/runners/Reviewers/QuotaCooldowns.cs` (`QuotaReset`, `QuotaCooldownEntry`, `CooldownWrite`, the file, the lock,
  `Standing`/`Park`/`Lift`, the per-key aggregation, `AfterRoundAsync`, its JSON context; split into two files if it passes
  400 lines), `src_mcp/runners/Reviewers/RetryLadder.cs:87-88` (the note rewritten: the ladder still persists nothing;
  `QuotaCooldowns` does, after the round); tests `TheAgyQuotaReportPicksTheResetTests.cs`,
  `ASpentQuotaIsRememberedUntilItsResetTests.cs`, `TheRoundParksAndLiftsTheQuotaTests.cs`; fixtures: `quota-2026-10-28.json` and
  `models-2026-10-28.txt` are already committed (this revision), story 2 adds `quota-sample.json` (QUOTA_SAMPLE verbatim) and the
  RESULTS §3.4 row for the hand capture.
- **Red-first, expected reds:** S9–S12 `… but found Available`; S13 `… but found Spent(0001-01-01…)`; S14 `Expected key to be
  "antigravity/argon", but found "antigravity/gemini"`; S15 `Expected verdict to be CannotCheck, but found Available`; S16, S17,
  S22, S25, S41 `Expected standing not to be <null>`; S18 `Expected standing to be <null>, but found …`; S19 a `JsonException`
  escaping; S20 `Expected entries to contain 1 item(s), but found 4`; S21, S39 the until-instant messages; S23 `Expected source to
  be "stated", but found "quota"`; S24, S34 `Expected standing to be <null>, but found …`; S35 `Expected entries to contain 2
  item(s), but found 1`; S36 `codex` standing after run 1; S37 an `IOException` escaping; S40 `Expected verdict to be
  GroupMissing, but found Available`; S42 a `TaskCanceledException` escaping; S43 `Expected buckets to contain 5 item(s), but found 4`.
- **Done when:** every key of D3 answers from the table; the file and the lock behave as D4 and §8 say, every write refused out
  loud when it cannot happen; `AfterRoundAsync` aggregates per key, parks and lifts as D5 says with one probe per key outside the
  lock, and never throws past the engine; the probe's argv is the owner's command and nothing more; every verdict of D6 is
  produced from QUOTA_REAL, QUOTA_SAMPLE or a marked construction; the note never carries an unredacted vendor line;
  `EveryBudgetInAClockedClassReadsItsClockTests` green.
- **Deviation record owed:** the first `/quota` answer coai's PROBE reads in a real round, and the agy version that gave it
  (§6, last bullet).

### Story 3 — the row stays out, and the server says why (D9 server half, D10, D11)

- **Owns:** S26–S29, S38; the `RoundEngine` wiring; `module_server.md`, `module_runners.md`.
- **Files:** `src_mcp/src/Server/PanelService.cs` (constructor `:57-65` gains `TimeProvider? clock = null`; `_cooldowns` built
  beside the ledger at `:103`; `CanRun` `:407-408`; `ReasonFor` `:478`; `ProbeAsync` `:301-309` sets `Cooldown`),
  `src_mcp/src/Server/ServerJsonContext.cs` (`ProviderStatus` `:7` gains `Cooldown`; `CooldownReport` beside
  `SurvivorMarkerReport`), `src_mcp/src/Server/Rounds/RoundEngine.cs` (a `QuotaCooldowns` constructor parameter at `:23-40`, the
  call between `:416` and `:443`, passed from `PanelService.cs:144-146`); tests `ACoolingRowStaysOutOfTheRoundTests.cs`.
- **Red-first, expected reds:** S26 `Expected excluded to contain a single item, but the collection is empty`; S27 (break-it)
  `… to contain 1 item(s), but found 2`; S28 `Expected excluded to be empty, but found {…}`; S29 `Expected status.Cooldown not to
  be <null>`; S38 `Expected JSON to contain property "cooldown"`.
- **Done when:** a cooling row is excluded from every stage's roster and the security roster, named with this side's sentence in
  UTC; a passed reset lets it back with no write; `--providers` carries `cooldown` only for a cooling row; the docs describe the
  fourth condition of `CanRun`, the file and the member.

### Story 4 — the card says when it is back (D8, D9 extension half)

- **Owns:** S30–S33; `module_extension.md`; the `statedReset.ts` header note.
- **Files:** `src_vs_code/src/providers.ts` (`ProviderHealth` `:21` gains `cooldown?`; `oneProvider` `:262-277` and a `cooldownOf`
  beside `warningOf` `:281`), new `src_vs_code/src/cooldownWords.ts` (a leaf like `resetWords.ts`; `cooldownLine`, the
  `dd.MM.yyyy HH:mm` formatter, the rounded-up span reused from `resetWords.ts:26` by export rather than copy),
  `src_vs_code/src/modelCard.ts` (`foot` `:273-279` draws `cooldown-line` instead of `reset-line` while one stands; `top` `:196`
  unchanged, the badge comes from `modelCardWorld.ts`), `src_vs_code/src/modelCardWorld.ts` (`verdictBadge` `:134-139`),
  `src_vs_code/src/statedReset.ts` (header: what is persisted now, and by whom); test `aCoolingRowSaysWhenItIsBack.test.ts`.
- **Red-first, expected reds:** S30 `Expected values to be strictly deep-equal: undefined !== {…}`; S31 `'' !== 'quota spent — back
  14.10.2026 09:19 (in 63 h)'`; S32 the `quota` wording where `stated`/`guess` wording is expected; S33 `null !== 'quota spent — …'`.
- **Done when:** the card line and badge render from `cooldown` alone, in the viewer's zone, with the three wordings of D9; an
  answer without the member draws today's card; `npm --prefix src_vs_code test`, `typecheck` and `lint` green.

## 10. What is observed and what is not (the measurement rule)

| fact | status |
|---|---|
| `AGY_ERROR: {…"status":"RESOURCE_EXHAUSTED"…}` on a spent Gemini quota, exit 3, with the stream's `status:"ERROR"` result | observed, agy 1.3.3, 2026-10-10 (`RESULTS_vendor_quota_gauges.md:187-192` the stream, `:197-198` stderr); again by the owner in #765 (`Resets in 62h46m48s`) |
| `AGY_ERROR {"code":…,"message":…}` | observed, 2026-10-02 (`fixtures/antigravity/consult-quota.stderr.txt`) |
| the `/quota` JSON of §1 (Gemini weekly at 0, 5h disabled, two groups) | observed by the owner on his PC (#765, "shortened"); the agy version is not recorded |
| the `/quota` JSON `quota-2026-10-28.json` (three groups, every bucket available, fractional fractions) and `models-2026-10-28.txt` | observed by this plan's author, agy 1.4.9, this machine, 2026-10-28, by hand — not by coai's code |
| the Claude/GPT (`3p`) group at 0 on agy; the Argon group at 0 | NOT observed — the issue says so for 3p; S10–S12, S34 are constructed from the real answers |
| Claude's monthly spend-limit envelope | observed (`AClaudeReasonInItsEnvelopeTests.cs:22-24`) |
| codex's dated reset sentence | constructed from `CooldownParser`'s own date form; codex's observed spent line (`GateReportingTests` `SpentAllowance`) names no date |
| Kimi's 5-hour and monthly sentences | observed in prompt mode (the Kimi plan); the ACP form still unmeasured there |
| `TimeZoneInfo` throwing in the chiselled image | recorded at `CooldownParser.cs:187-191`; not re-measured here |

## 11. Review record (2026-10-28)

### The plan gate — coai session 95dd15f6, round 1, verdict `proceed`, gating 5 of threshold 6, 2 of 2 reviewers (antigravity, codex)

| # | severity, reviewer | finding | decision | where it landed |
|---|---|---|---|---|
| F0 | blocking, antigravity | `ReadResetAsync` has no `ReviewerInvocation` after `RunAllAsync` | **rejected** — `RunAllAsync` returns `(Invocation, Outcome)` pairs (`BoundedScheduler.cs:224`, `:477`) and `RoundEngine` keeps them; made explicit anyway | D5: `AfterRoundAsync(results, ct)` over the pairs; `result.Invocation.Request` is what D6 clones |
| F1 | major, antigravity | the storage contract on an unreadable/unwritable file is unstated; a new `[JsonSerializable]` may be needed | **accepted** as a stated fail-open contract; no new registration (`ProvidersAnswer` at `ServerJsonContext.cs:367` reaches `Cooldown`) | D4 (fail-open bullet), S37, S38 |
| F2 | major, antigravity | the executor asks `RateLimited` before `WhyItFailed`; D7 must keep that order | **accepted** as a clarification | D7, S7 |
| F3 | major, codex | two processes share one data dir; a read-modify-write loses a park or a lift | **accepted** — a separate persistent `quota-cooldowns.lock` through `HeldFile`, held across re-read → aggregate → `AtomicFile.Write`; the probe outside; `Busy`/`Unusable` → an explicit refusal, never an unlocked write | D4 (two-processes bullet), §8, S35–S37 |
| F4 | major, codex | `/quota` never run against a real agy | **accepted**, and answered by a real capture the same day (agy 1.4.9), committed verbatim with this revision | §1, §2, §10, S43, QUOTA_REAL |
| F5 | minor, codex | aggregate per key before any mutation; a spent outcome wins over a sibling `Ok` | **accepted** | D5, S41 |

### The consultation (codex-2 / gpt-6-astra; each point verified against the code or the capture before it was taken) — all accepted

- The real `/quota` has THREE groups, one of them (Gemini 4 Argon) with ONE weekly bucket; buckets carry `id` and `name`; fractions are
  fractional; `agy models` lists `gemini-4-argon-*` beside `gemini-3.8-flash-*`. A prefix rule would park ordinary Gemini when only
  Argon is spent → D3's explicit measured table, a separate `antigravity/argon` key, buckets matched on `id`, descriptions never parsed,
  unknown families keep their own key with no gauge-based parking; S14 rewritten, S34 and S43 added.
- `consecutive` passed explicitly to `ReadResetAsync` → D5's signature.
- Whether doubling restarts after expiry → decided yes (D5), S39.
- The undefined cases — an empty or all-disabled group, a missing or invalid fraction, a past `reset_time`, mixed known/unknown
  resets, an explicit-spent refusal with an `Available` gauge → D6's edge-case sentence, S40, S41.
- Cancellation during the post-round probe → D5's last sentence, S42.

### The plan gate on this revision — coai session b227f8cf (branch `docs/plan-a-spent-quota-cools-the-model-down-r2`, the same commit a2b9609d), round 1, verdict `proceed`, gating 4 of threshold 6, 2 of 2 reviewers (antigravity, codex)

| # | Severity, reviewer | Finding | Decision |
|---|---|---|---|
| F0 | Major, codex | The 16 KiB budget is not enforced when unknown model keys accumulate | Rejected: a key exists only for a configured row's model that was refused, and only until its reset (`MaxStatedWait` 14 d, a guess ≤ 5 h); expired entries drop at the next write (S20). A cap with eviction could un-park a really spent row |
| F1 | Major, codex | Spent + Available gauge can recur every round | Rejected: the vendor's explicit refusal is authoritative for that launch; the relaunch after expiry is the bounded retry (an answer lifts it, S18; a refusal parks again) |
| F2 | Minor, codex | A refused aggregate write is silent | Accepted: the refusal is also one server notice through `NoticeWriter` (D4, S37) |
| F3 | Major, antigravity | The probe would run in a pruned review worktree | Rejected: the cloned request runs in `AntigravityReadOnly.Home()`, a stable per-user folder (`AntigravityReadOnly.cs:48,56`; `AntigravityRuntime.cs:64`), not the review worktree |
| F4 | Major, antigravity | Map families by prefix instead of the table | Rejected: the prefix is what the consultation removed (`gemini-` would catch Argon); the suffix is stripped only when present, so a bare family id matches |
| F5 | Minor, antigravity | The 5 s lock wait drops writes under contention | Accepted: the wait is a parameter, default 30 s (D4, §8) |

### The operator's gate commands — declined for this plan, with the reason

The reply carried the standing commands: split into 3–4 epics with per-epic gating, a Fable split, consultants, autonomous mode and
the consultation cadence. The owner's decision for this experiment: the plan stays ONE file with four stories and no epics. It is
the frozen specification that several coding pipelines implement whole, from the same commit, at ~1,100–1,500 changed lines — less
than one epic of this repository's other plans — and a split would hand each pipeline a different document and a different gate
history. The code gate still runs once over the whole branch with this plan as its scope (D12, §5).

### What this revision changed, in one list

D3 (the table, Argon), D4 (fail-open contract, the lock), D5 (pairs, aggregation, `consecutive`, doubling restart, contradiction,
cancellation), D6 (ids, edge cases, the real capture), D7 (the executor's order), D12 (the epics decision), §1 and §2 (the
capture), §4 (S14 rewritten; S34–S43 appended — numbered in the order they were decided, so S43 sits in the report class and S38
in the roster class; no existing name changed), §5, §6, §7, §8, the story cards, §10, this section. Estimated coder work is now
~2.5–3 h (≈1,300–1,500 lines with tests).
