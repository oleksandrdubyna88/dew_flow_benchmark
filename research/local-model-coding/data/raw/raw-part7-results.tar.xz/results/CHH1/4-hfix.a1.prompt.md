You are the FIXER (Sonnet). Two fresh reviewers read the implementation of `todo/PLAN_a_spent_quota_cools_the_model_down.md` in this repository, on branch
`feat/quota-cooldown` (every commit after `6786582e30d3e771549d05ed719478396f8099cd`). They changed nothing. You fix what they found. You work alone and nobody
answers questions. After you, a separate reviewer will check the whole work again.

## Read first

1. The project instructions: `AGENTS.md` → `.agents/conventions/ENTRY.md` and `.agents/PROJECT.md`. Run the resolver with
   `--task implement --task test` and the files you will change, and read the rules it selects.
2. The two reviews: `/home/jinx/git/coai-exp2/r/4650daee202d/notes/hA.json` (does each decision of the plan hold at every site) and `/home/jinx/git/coai-exp2/r/4650daee202d/notes/hB.json` (do the tests test
   what they claim, on every CI machine). The plan `todo/PLAN_a_spent_quota_cools_the_model_down.md` for the decisions a finding refers to. The coder's notes:
   `/home/jinx/git/coai-exp2/r/4650daee202d/notes/code.md`.

## What to do

- Settle each finding by opening the file first. A finding can be wrong: then do not change the code, and say why.
- Fix every **blocking** and **major** finding that is right. Fix a **minor** one when it is cheap.
- A fix of a defect starts with a test that fails for the right reason, as the rules ask.
- Then: the build, the changed test classes, the whole MCP suite once, the format check, and the extension's tests if
  `src_vs_code` changed (commands in `.agents/PROJECT.md` and the plan, always through
  `.agents/conventions/tools/low-priority.mjs`).
- Known at the start, not yours: Nothing is known to fail: at the base commit the whole MCP suite (13,807 tests) and the extension tests pass on this host (Linux, WSL2; tests marked Windows-only skip). A failure you see is yours or a flaky test: re-run that one test alone before you decide.
- Out of scope: what the plan names as out of scope; any push, pull request, release. Never run `agy`, `kimi`, `vibe`,
  `codex` or `claude`.

## Commits, notes, deadline

- Commit as you go (conventional messages, files by name, never `git add -A`, never push).
- In `/home/jinx/git/coai-exp2/r/4650daee202d/notes/hfix.md`: per finding id (A1…, B1…) — fixed (the commit), not fixed (why), or wrong (why).
- **Deadline: 23:56 UTC (00:56 CET).** At the deadline, stop, commit what you have, and write what remains in the notes.

Your final answer: a short report — per finding what you did, and the final results of the build, the suite, format and
the extension's tests.
