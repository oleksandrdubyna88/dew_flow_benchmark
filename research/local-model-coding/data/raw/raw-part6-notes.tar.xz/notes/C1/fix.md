# Fixes — review of `feat/quota-cooldown`

Commits (conventional, files by name, nothing pushed): 74f758c1 (R1) · e2b2bd41 (R3, R4) · e21e6082 (R5) · f8a595ab (R2, R6).
Each defect fix started with a test that was seen red for the right reason.

| id | severity | result |
|---|---|---|
| R1 | major | **fixed.** New `ASpentQuotaOfARoundCoolsTheRowForTheNextOneTests`: a real `review_plan` round through `PanelService` (real `git`, a scripted `agy` launcher in front of the real one: exit 3 + AGY_1_3_3 for the review, QUOTA_SAMPLE for `/quota`). Asserts `quota-cooldowns.json` holds `antigravity/gemini` until 2026-10-14T07:19:16 and that `ExcludedFrom(PlanReview)` then names the row. Seen red: with the `results = await _cooldowns.AfterRoundAsync(...)` line commented out the test fails with `Expected File.Exists(file) to be True`; the line was restored from git. This covers `PanelService` handing its launcher and `noticing.Offer` to the store only as far as the launcher is concerned (the park happens through it); the notice seam is covered by the existing store tests, not by a round-level one. |
| R2 | minor | **fixed.** Line break between the `.badge.verdict.ok` rule and the `.badge.health.ok::before` rule restored in `catalogSheet.ts`. Measured: with the break back, removing `, .catalog .cooldown-line` hashes to `862e9808…9d82e`, the previous pin, as the review said. `CATALOG_CSS` is re-pinned to `f2fb35ae…7204c` and the comment in `teamServerTab.test.ts` says why. |
| R3 | minor | **fixed.** `AfterRoundAsync` runs the locked write as `await Task.Run(() => Apply(changes), ct)`. `Park`/`Lift` stay synchronous public methods (their tests and callers unchanged). Test `AContendedLock_IsWaitedForOffTheCallingThread` holds the lock, and asserts the call returns its task in under 2 s while the wait is 5 s; seen red (the call blocked for 5 s), green after. |
| R4 | minor | **fixed.** A lift is queued only when `Standing(key, now)` finds an entry (`LiftOf`, extracted to stay under the complexity cap of 4). Test `AnAnsweredRow_WithNothingParked_TakesNoLock_WritesNothing_AndPostsNoNotice`: no file and no lock appear in the data directory, and with the lock held by someone else there is no notice and no warning. Seen red (the lock file was created). An expired entry is not lifted by the round, but the next write drops it, as before. |
| R5 | minor | **fixed.** `reset_time` is parsed with `DateTimeStyles.AssumeUniversal`; `AgyQuotaReport.Parse` disposes every `JsonDocument` after reading it. Test `AnAgyResetWithoutAnOffsetIsReadAsUtcTests` switches the process zone to `Etc/GMT-9` through `TZ` for one parse (it sits in the serial `fakecli-env` collection) — seen red with the old flag, green with the new. The disposal has no test of its own: a disposed-or-not `JsonDocument` is not observable from outside, and the report copies every string out before disposal (the existing report tests pass). |
| R6 | minor | **fixed in the plan.** §12 items 13 and 14 record S34's undecided Gemini row (D5/S41) and S14's test name; item 15 lists this review's fixes. The test names were left as they are. |

No finding was judged wrong.

## Results

- Build (`dotnet build dew_flow_connect_other_ais.slnx -c Debug`): succeeded, 0 warnings.
- Changed test classes: all green (`TheRoundParksAndLiftsTheQuotaTests`, `ASpentQuotaIsRememberedUntilItsResetTests`, `ASpentQuotaOfARoundCoolsTheRowForTheNextOneTests`, `ACoolingRowStaysOutOfTheRoundTests`, `AnAgyResetWithoutAnOffsetIsReadAsUtcTests`, `TheAgyQuotaReportPicksTheResetTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`).
- Whole MCP suite, once: 13,894 tests (+4 over the coder's run), 13,776 passed, 117 skipped, **1 failed**:
  `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — `ArgumentOutOfRangeException`, the Unix-socket path
  `…/tmp/testsToDelete-coai-run-…/testsToDelete-regular-files-…/shown.sock` is past 108 characters because of this session's `TMPDIR`. It touches nothing of this change. I could not re-run it with a short
  `TMPDIR` (the shell refuses an `env TMPDIR=…` prefix), so that is a reading of the message, not a measurement. Everything else is green.
- Format: `dotnet format whitespace` and `style` `--verify-no-changes` clean; `plan-lifecycle.mjs` clean.
- Extension (`npm --prefix src_vs_code test`): 6540 tests, 6520 pass, 0 fail, 20 skipped; `npm run lint` clean.
