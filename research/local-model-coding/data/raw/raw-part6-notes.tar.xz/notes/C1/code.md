# Coder notes — a spent quota cools the model down

Branch `feat/quota-cooldown`, base 6786582e. Commits (conventional, files added by name, nothing pushed):
d69221b5 story 1 · 3502941b report+probe · b61db5b1 store+round · 3d5710a1 server · 463b15e4 extension · aa74be74 lint/re-pin · 16a58ba2 docs · 16553eb8/0f08d166 plan.

## Result

- All 43 scenarios have a test with the plan's class and name (C#: seven classes in `src_mcp/tests`; node: `src_vs_code/src/test/aCoolingRowSaysWhenItIsBack.test.ts`).
- MCP whole suite: see the last section. Extension: `npm --prefix src_vs_code test` 6540 tests, 6520 pass, 0 fail (rest skipped); typecheck and lint clean.
- Format: `dotnet format whitespace` and `style` `--verify-no-changes` clean. The plain `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes` prints
  IL2026/IL3050 AOT analyzer errors in `src_server/**` only (files this change does not touch) — not mine.
- `plan-lifecycle.mjs`: clean.

## Decisions / deviations

The full list is in the plan, §12 (12 items). Short form:
1. `ReadResetAsync` takes an extra `bool? spent`; the default decides "transient → NotParked" so the engine has no vendor condition.
2. `ResetFor` takes the full key. 3. `JsonDocument` for the `/quota` report (no source-gen context for it). 4. Notice seam `Func<ServerNotice,bool>` + two internal in-lock hooks;
   notice code is `storage-note`. 5. Warn-once is per store. 6. S25's codex part runs on its own July clock (the plan's NOW would make *July 15, 2026* past).
7. `CustomCodexRuntime.QuotaKeyOf` empty. 8. The clocked-class guard lists `QuotaCooldowns.cs` (scanned) and `PanelService.cs` (not scanned, reason given).
9. Settings sheet hash re-pinned for `.cooldown-line`. 10. `ReasonFor` order. 11. reds. 12. environment.

## Reds that differ from the plan / not seen

- Production code for the report, the store, the server and the card was written before their tests; red was produced afterwards by temporarily breaking the
  code and restoring it from git (a mistake on the way: an uncommitted edit of `PanelService.cs`/`ServerJsonContext.cs` was lost by a `git checkout` and re-applied; from then on every
  mutation round started from a commit).
- Seen red with the plan's message: S1, S2, S4, S5, S7 (story 1); S9–S14, S34, S40 (report); S16, S17, S18, S19 (`JsonException` escaping), S20, S22, S25, S36 (codex standing after run 1), S37, S41, S42
  (`TaskCanceledException`), S26, S27, S29, S38, S30–S33.
- Red with a DIFFERENT message: S6(a) (`Expected undecided.Limited to be True, but found False`), S21 (`Consecutive` 1 vs 0 — the until-instant part is a pure function and was not broken),
  S23 (until-instant mismatch, not `quota` vs `stated`), S24 (a) as expected, S35 (B finished before A released — the lock removed), S31/S32 (`''` instead of the plan's text: the same thing).
- NOT seen red: S3 (green with the stub; its red is for the tempting `Spent == true` wiring), S6/S8 break-it variants, S15, S43, S27's `antigravity`-alone key,
  S28, S39 in isolation (only the `Consecutive` half of S21 was broken).

## What remains

- The code gate over the whole branch (needs the plan as scope) — not run (no model calls by the coder).
- The first real `/quota` answer read by coai's own probe → `research/RESULTS_vendor_quota_gauges.md` §3.4 (a placeholder row for the hand capture is there).
- The break-it variants listed above; promotion of the plan to `research/` when shipped.
- `RegularFilesTests.A_fifo_a_socket_…` fails in THIS session because `TMPDIR` is longer than the 108-character Unix-socket path limit — environmental, unrelated.

## Whole MCP suite (last run, after commit df9634e9)

13,888 tests (base 13,807, so +81): 13,770 passed, 117 skipped, 1 failed — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`,
which fails here only because this session's `TMPDIR` makes the Unix-socket path longer than 108 characters (`ArgumentOutOfRangeException … invalid length for use with domain sockets`).
It does not touch this change. I could not re-run it with a short `TMPDIR` (the shell refused the env prefix), so that is a reading of the message, not a measurement.
Two real failures found by earlier whole-suite runs were mine and are fixed (committed): `EveryBudgetInAClockedClassReadsItsClockTests` (new clocked classes must be listed) and
`TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` (the census of notice producers now lists `QuotaCooldowns.cs`).
