# t3 — code notes: `QuotaCooldowns`, the durable file and its lock

## What I did

- **New** `src_mcp/runners/Reviewers/QuotaCooldowns.cs` (229 lines): the records `QuotaCooldownEntry`, `CooldownWrite`
  (`Written`, `Unchanged`, `Refused`), the internal `QuotaCooldownFile`, the source-generated `QuotaCooldownJson` context, and the
  partial class `QuotaCooldowns` with every member named in the contract and the private fields `_dataDir`, `_clock`, `_log`, `_launcher`.
  - Read: `ReadEntries` fails open. Missing file is silent. A torn, unreadable or non-v1 document gives `[]` and ONE warning per instance (`Interlocked.Exchange` flag).
  - Write: `Change` creates the data directory, then `HeldFile.TakeWithin(LockPath, wait)`, re-reads, drops expired entries, calls `AfterLockedRead`,
    applies the change, and `AtomicFile.Write`s only when the result differs. Busy, unusable, `IOException` and `UnauthorizedAccessException` become `Refused`.
    Every refusal is logged as a warning and passed once to `onRefused` inside try/catch.
  - `Park` caps the note at `NoteCap` after `VendorReason.Written`. `Consecutive` is the standing guess's count + 1 only when both source and previous source are `guess`.
  - `Lift` goes through `Change` even for a key that does not stand, so the lock is taken and `AfterLockedRead` is reached; the no-op result is `Unchanged` with no write.
- **New** `src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs`: 12 tests (S16–S21, S35–S37, S39, plus `TenEntriesWithLongNotes_StayUnderSixteenKiB`,
  and `ANearbyGuess_StillDoubles` as the second body of S39).
- **Edited** `src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs`: added `QuotaCooldownsFile` constant and its entry in `Clocked`. No `Sanctioned` entry was needed.
- **Edited** `src_mcp/runners/Reviewers/RetryLadder.cs:87-88`: comment only. The sentence about nothing being persisted now says the ladder persists nothing and that `QuotaCooldowns` answers the re-login worry.

## Choices I made where the document left room

- `Lift` does not short-circuit on a key that does not stand. It goes through `Change` so the lock and `AfterLockedRead` run, as S36 run 2 requires. The no-op is detected by comparing the result with the live (expired-dropped) list, so an unchanged file is never rewritten.
- Refusal `Why` text: busy lock → names `LockPath` and the wait; unusable lock → names `LockPath` and the cause; exceptions → `"{ExceptionTypeName}: {message}"`. The `onRefused` sentence is the same text as `Why`.
- Test helpers: `Store(...)` uses the per-test `TempDir`; `StoreAt(dir, ...)` is used where a test needs another directory. Interleaving tests are `async Task` and use `FinishesWithin(task, within)` (a `Task.WhenAny` with a `Task.Delay`) because xUnit analyzer `xUnit1031` rejects blocking task waits in test methods. The `Task.Delay` is in the test only, not in `QuotaCooldowns.cs`.
- S37(b) asserts `Why` starts with `IOException`. On this host `Directory.CreateDirectory` on a file path throws `IOException`, so that is the one asserted.

## Red messages (stub that returns null / Unchanged, before the implementation)

Stub run: 11 of 12 failed, each with an assertion (no compile error, no escaping exception except where noted):

- `AParkedKey_StandsUntilItsReset_ThenIsBackOnItsOwn`: `Expected standing not to be <null>.`
- `TheRecordSurvivesANewStore`: `Expected standing not to be <null>.`
- `AnAnsweredLaunch_LiftsTheCooldown`: `Expected type to be ...CooldownWrite+Written, but found ...CooldownWrite+Unchanged.`
- `ATornFile_ParksNobody_AndSaysSoOnce`: `Expected warnings to contain a single item, but the collection is empty.`
- `AnExpiredEntry_IsDroppedAtTheNextWrite_AndTheFileStaysSmall`: `FileNotFoundException` on `quota-cooldowns.json` (the stub writes nothing). The document's `Expected entries to contain 1 item(s), but found 4` needs a file that exists; the stub has no file, so this is the stub's own red.
- `TenEntriesWithLongNotes_StayUnderSixteenKiB`: `FileNotFoundException` (same reason as above).
- `TheGuess_DoublesPerConsecutivePark_AndStopsAtFiveHours`: `Expected standing not to be <null>.` (after I added a `NotBeNull` check; the first version threw a NullReferenceException).
- `TwoWriters_InterleavedUnderTheLock_LoseNeitherKey`: `Expected paused.Wait(...) to be True` (the stub never calls the hook).
- `AParkAndALift_InterleavedUnderTheLock_EndWhereTheLastWriteSays`: `Expected paused.Wait(...) to be True`.
- `AWriteThatCannotHappen_IsRefusedOutLoud_AndParksNothingUnlocked`: `Expected type to be ...CooldownWrite+Refused, but found ...CooldownWrite+Unchanged.`
- `AGapPastExpiry_RestartsTheGuessAtThirtyMinutes`: passed on the stub by coincidence (stub returns 0 and the `QuotaReset` guess is real). Its red is not a stub red; it is covered by the next point.
- `ANearbyGuess_StillDoubles`: `Expected store.NextConsecutive("claude", now) to be 1, but found 0.`

Note: `AGapPastExpiry` passed on the stub. The document's red for S39 (`Expected until to be <NOW+31min+30min>, but found <…+60min>`) needs a real `NextConsecutive`, and this test does check that with the real code. It is green now. I did not see that message as a red; the coincidence is worth knowing.

## Break-it check (step 3)

- Lock removed (each take used a fresh lock file name): `TwoWriters_InterleavedUnderTheLock_LoseNeitherKey` went red on `Expected (FinishesWithin(second, …)) to be False because B waits on the lock while A holds it, but found True.` (the wait assertion fires before the entries count). `AParkAndALift_…` went red the same way on its run 1 wait check. Restored afterwards.
- Note: a first break that kept one shared `LockPath + ".broken"` file did NOT break exclusion (both writers still shared one lock). That was my mistake in the break, not a test gap; the second break is the honest one.

## Results

- Build (`dew_flow_connect_other_ais.slnx`, Debug, `-m:4 --disable-build-servers`): 0 errors, 0 warnings.
- `ASpentQuotaIsRememberedUntilItsResetTests`: 12 / 12 passed.
- `EveryBudgetInAClockedClassReadsItsClockTests`: 9 / 9 passed (includes the new `QuotaCooldownsFile` entry; no `Sanctioned` entry was needed).
- `NoTestHoldsAnInheritableHandleTests`: 2 / 2 passed.
- `TheLeakingTestSitesRemoveWhatTheyMadeTests`: 6 / 6 passed. It did not ask for a doc entry for the new class.
- Whole MCP suite (`CoaiMcp.Tests`, run once in the background): total 13834, failed 1, succeeded 13716.
  The one failure is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`:
  `ArgumentOutOfRangeException: The path '…/shown.sock' is of an invalid length for use with domain sockets`. The Unix socket path limit
  is 108 characters and this worktree's temp path is too long. Not my change. Re-run alone (`--filter-class RegularFilesTests`, 32 tests):
  the same test still fails with the same error (30 succeeded). It is environmental (the worktree path length), not a logic failure.
- `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes`: exits 2. Every line of its output is an AOT/trimming analyzer error
  (IL2026 / IL3050) in `src_server/src/*Endpoints.cs`, which this task does not touch. The format step cannot finish on the solution here.
  Scoped check on my four files instead: `dotnet format src_mcp/tests/CoaiMcp.Tests.csproj --verify-no-changes --include` (the two test files) and
  `dotnet format src_mcp/runners/CoaiMcp.Runners.csproj --verify-no-changes --include` (QuotaCooldowns.cs, RetryLadder.cs): both exit 0.

## Left / not done

- Nothing left in scope. `QuotaCooldowns.Round.cs` / `AfterRoundAsync` are t4's and are not written here.
- `_launcher` is stored and never read in this half (t4 reads it). The build shows no warning for it.
