# t7 — notes (docs, the plan's status and deviations)

## Done

- `research/module_runners.md`: a new section at the end, *A spent quota cools its row down* (the agy classifier, the three-valued `Spent`, `QuotaKeyOf` and the `AgyQuotaGroups` table, `ReadResetAsync`, `GaugeDecidesUndecided`, `QuotaReset`, `AgyQuotaReport` / `AgyQuotaProbe` and the `ResetFor` rules, `QuotaCooldowns` and `AfterRoundAsync`). The two agy quota sentences (the `RESOURCE_EXHAUSTED` paragraph near `:1408`) now say what is classified and that the gauge decides the undecided case.
- `research/module_server.md`: a new section at the end: the file and the lock in the data directory, `CanRun`'s fourth condition, `ReasonFor`'s cooling sentence, `ProviderStatus.Cooldown` / `CooldownReport`, `RoundEngine`'s call, the refused write as a `storage-note` / `failure` notice.
- `research/module_extension.md`: a new section at the end: `cooldownWords.ts`, `ProviderHealth.cooldown`, the card's `cooldown-line` in place of `reset-line`, the `cooling down` badge, the shared CSS rule and the re-pinned hash.
- `research/module_tests.md`: a new section at the end: the eight flows (seven C# classes and the node file) as `covered`, the touched fixture and pins, and the not-proved list (the plan's §6 list, in my words).
- `research/RESULTS_vendor_quota_gauges.md`: new `### 3.4` before `## 4` with the 2026-10-28 hand capture as its first row, marked observed by hand, and the line that the first real probe answer is still owed.
- `src_vs_code/src/statedReset.ts`: header comment only. The last clause now says what `coai-mcp` persists and where the card reads it. No code change.
- `todo/PLAN_a_spent_quota_cools_the_model_down.md`: the status block rewritten (code written, S1–S43 covered, record closed 2026-10-29; the plan stays in `todo/`); DoD boxes `Docs` and `RetryLadder.cs:87-88 / statedReset.ts` ticked; the others left `[ ]`; a new `## 12. Deviations` list of 11 items, each checked against the code (grep of the names). Item 10 is the not-proved probe read; item 11 keeps the D12 later-plan line.

## Checks run

- `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers` (through `low-priority.mjs`): exit 0.
- `CoaiMcp.Tests --filter-class CoaiMcp.Tests.ScenarioCoverageTests` (through `low-priority.mjs`): exit 0. On Linux the test binary is `src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests` (no `.exe`); the brief's `.exe` path does not exist here, so the first attempt failed with ENOENT (exit 127) and the second, with the extensionless path, passed.
- `plan-lifecycle.mjs` (run with the repo root as the argument): clean. The first run flagged the status line: its `status: **implemented` opening reads as promoted, so the status was reworded (the plan is still in `todo/`).
- `npm --prefix src_vs_code test` (through `low-priority.mjs`): 6539 tests, 6519 pass, 0 fail, 20 skipped.
- Commit `ecbcf25b` (seven files, by name; no push).

## Not done / left

- Red-first: no tests were written (docs only), so there was no red run for this task.
- `dotnet format` was not run (no production code changed by t7).
- The brief's suites that read the touched docs are the two above; the rest of the MCP suite and the extension suite were not re-run by t7.
- The DoD items about the scenarios (S1–S43 green, the `dotnet format`, the budget, the agy/lock/fail-open items) are left `[ ]`: t7 did not re-prove them, and the code gate and promotion are for a human.
- The first real `/quota` answer coai's own probe reads in a round is still owed (RESULTS §3.4; plan §12 item 10).
- Commit: the t7 document says "do not commit", but the coder brief says to commit with the files named. I followed the brief: one commit, the seven files named, no push.
