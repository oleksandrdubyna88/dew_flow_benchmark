# t4 — `AfterRoundAsync`: a round parks and lifts the quota (code notes)

## What I did

- `src_mcp/runners/Reviewers/QuotaCooldowns.Round.cs` (new): `AfterRoundAsync` per the contract. Aggregates per quota key (empty keys dropped), classifies each outcome, asks the runtime once per parking key outside the lock, then ONE `Change(...)` for the whole round. Helpers: `PlanAllAsync`, `ByKey`, `PlanAsync`, `Answers`, `Refusal`, `FirstWhere`, `Spent`, `WordsSpent`, `GaugeDecides`, `Answered`, `RefusalOf`, `ResetOfAsync`, `LogNotParked`, `Apply`, `EntryOf`, `NoteOf`. Every method is at cyclomatic complexity 4 or below.
- `src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs` (new): S22, S23, S24, S25, S34, S41, S42 as written in the brief, plus a private `KimiFake` (`IReviewerRuntime`), a private `WaitsForTheToken` launcher, and a `Sink` log capture.

## Deviations from the brief (recorded)

1. **S25 clock:** the codex part runs on its own `FixedClock(2026-07-14T12:00:00Z)`, as the brief allows. The Claude and Kimi parts run on the October `NOW`.
2. **S34** lives in this class (the brief's own note). The round half uses the `gemini-3.8-flash-high` row ended `Ok`, so only Argon is spent, as the brief's reading requires.
3. **Test exe path:** the brief says `CoaiMcp.Tests.exe`. On this Linux host the runner is `src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests` (no `.exe`). I ran that path.
4. **`Guess` replacement:** when `reset.UntilUtc <= now`, I replaced it with `QuotaReset.Guess(...)` exactly as written, which drops `Gauge`. A gauge-spent reset whose instant is in the past is therefore not parked, which matches "never park on the past".
5. **Refusal variable naming:** the brief's `Park…` helper names are not used; I named the helpers as above. No contract signature changed.
6. **`Cap` reuse:** `Cap` is `QuotaCooldowns.cs`'s private static (t3). I used it from the partial class and did not touch `Park`. `NoteOf` is `Cap(VendorReason.Written(...))`, the same sequence `Park` uses.

## Red messages (before the production code, against the stub)

The stub returned `results` unchanged. Seven assertion failures, all assertion messages (no compile errors):

- `Expected standing not to be <null>.` (S22, S23, S41-style, S34 standing checks)
- `Expected launcher.Launched to be 1 because one gauge read answers for the whole group, but found 0` (S22)
- `Expected said {empty} to have an item matching ... "transient" ...` (S24a)
- `Expected said {empty} to have an item matching ... "cancelled"` (S42)
- `Expected launcher.Launched to be 1, but found 0` (S41, S34)

The brief's red messages were different in detail for S23 (`Expected source to be "stated"`). On the stub the S23 failure came out as `standing not to be <null>`, which fires first. That is the stub's behaviour, not a different defect.

## Break-it check

Temporarily made the park a last-writer rule (an `Ok` as the last row lifts before any refusal is read). Build and run: `Test run summary: Failed!`, with `Expected launcher.Launched to be 1, but found 0` (S41) and the S42 `cancelled` message. Restored the line, rebuilt, re-ran the class: `Passed!`.

## Results

- Build: `Build succeeded`, 0 warnings, 0 errors (Debug, `-m:4 --disable-build-servers`).
- `TheRoundParksAndLiftsTheQuotaTests`: `Passed!` (after the change; the red run above was before it).
- Whole MCP suite (once, 12m 26s): total 13872, succeeded 13754, skipped 117, **failed 1**: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`. Cause: `UnixDomainSocketEndPoint` rejects the socket path as over 108 characters, because this checkout's temp directory is long. Re-run alone: the same failure (`total 1, failed 1`). It touches no quota code and is outside my two files. Not fixed here (not my file); it needs the suite run from a shorter path or the test to skip on long paths.
- The four related classes named in the brief (`ASpentQuotaIsRememberedUntilItsResetTests`, `TheAgyQuotaReportPicksTheResetTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`, `EveryBudgetInAClockedClassReadsItsClockTests`) were covered by the whole-suite run; each was not run on its own.
- `dotnet format --verify-no-changes` on the whole solution exits with IL2026/IL3050 analyzer errors in `src_server` (not my files; none of the output names `src_mcp/`). Format on the MCP test project alone, limited to my two files (`--include`): 0 error lines.
- Committed `4e527f88` (`feat(quota): a finished round parks …`), only my two files, with the `Co-Authored-By` trailer.

## Left

- Nothing in the brief is left undone. The one open item is the `RegularFilesTests` path-length failure above, which is outside t4.
