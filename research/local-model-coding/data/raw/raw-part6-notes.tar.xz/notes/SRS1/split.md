# Split of PLAN_a_spent_quota_cools_the_model_down.md into tasks

Judge: Sonnet. Base `6786582e` on `feat/quota-cooldown`. Nothing was committed. Task documents: `/home/jinx/git/coai-exp2/r/d1d1bda56b29/work/t1.md` … `t7.md`; list: `work/tasks.json`.
Checked by script: 7 tasks, no file in two tasks, S1–S43 all covered (S34 only in t4).

## Tasks and order

| id | title | scenarios | depends |
|---|---|---|---|
| t1 | three-valued `Spent`, the runtime quota seam, Claude's spend limit | S1 S2 S3 S7 S8 | — |
| t2 | agy: `AGY_ERROR` classifier, key table, `/quota` report + probe, runtime overrides | S4 S5 S6 S9–S15 S40 S43 | t1 |
| t3 | `QuotaCooldowns` store, lock file, fail-open read, refused write | S16–S21 S35 S36 S37 S39 | t1 |
| t4 | `AfterRoundAsync` (round parks and lifts, per key, one probe, one write) | S22 S23 S24 S25 S34 S41 S42 | t1 t2 t3 |
| t5 | server: `CanRun`, `ReasonFor`, `ProviderStatus.Cooldown`, `RoundEngine` call | S26–S29 S38 | t3 t4 |
| t6 | extension: `cooldownWords.ts`, parser, card line, badge | S30–S33 | — |
| t7 | docs, `statedReset.ts` header, RESULTS §3.4, plan status + deviations (LAST) | — | t1–t6 |

Parallel: t1 ∥ t6; then t2 ∥ t3; then t4; then t5; t7 last.

## Decisions a task document does not show in full

1. **Cornerstone split in two, by a `partial` class.** Story 2 is too big for one coder. `QuotaCooldowns` is `public sealed partial class` in `QuotaCooldowns.cs` (t3: store, lock, `Change`) and `QuotaCooldowns.Round.cs` (t4: `AfterRoundAsync`). The seam between them is named in t3 (`Change`, `NextConsecutive`, fields `_clock` `_log` `_launcher`, `NoteCap`, `Now`).
2. **Undecided agy needs a third interface member.** The plan names two default members; D5's "the gauge decides the undecided case" cannot be done with them. Added `IReviewerRuntime.GaugeDecidesUndecided` (agy true) and `QuotaReset.Gauge` (`spent`/`available`/`unknown`). `AfterRoundAsync` reads `Gauge` for an undecided refusal. `ReadResetAsync` stays as the plan's signature.
3. **`PanelService` takes `QuotaCooldowns? cooldowns`, not `TimeProvider? clock`.** `EveryBudgetInAClockedClassReadsItsClockTests` fails for any product file whose constructor takes a `TimeProvider` unless the file is in its lists; `PanelService.cs` would then need a second edit of a guard file that t3 owns. The store owns the clock; `Standing(key)` has an overload without `now`. `QuotaCooldowns.cs` is added to the guard's `Clocked` list by t3 (file is in t3's list).
4. **Refused write → server notice.** `QuotaCooldowns` is in the Runners project and cannot see `NoticeWriter`/`Noticing` (Server project). It takes `Action<string>? onRefused`; `PanelService` turns it into one notice with the existing code `storage-note`, class `failure` (no new `ServerNoticeCodes` entry, so no shared catalog change).
5. **S34 moved to t4's class** (`TheRoundParksAndLiftsTheQuotaTests`): its round half needs `AfterRoundAsync`, so it cannot be in t2's class. The plan's sentence "only `antigravity/argon` stands" contradicts S41's rule if the Gemini row ended spent; the task says: the Gemini row ends `Ok` in that test.
6. **S25 codex date.** The plan's example date (July 15, 2026) is before the shared `NOW` (Oct 11). The codex part runs on its own clock (2026-07-14); `AfterRoundAsync` also never parks on a past instant (falls back to the guess).
7. **Kimi's reset is always a guess** (Kimi plan D3): `KimiRuntime.ReadResetAsync` override in t1 (the default would run `CooldownParser.StatedReset` over a Kimi clause). `CustomCodexRuntime` (`CustomRuntime.cs`, added to t1) keeps the empty key.
8. **agy probe shape.** `AgyQuotaProbe.ReadAsync` returns `AgyQuotaRead(Report?, Why)`; its `ResetFor(key, now)` returns the verdict (or `CannotCheck(Why)`). Verdict type `AgyQuotaVerdict` with nested `Available`, `Spent(UntilUtc, Which)`, `SpentWithoutReset(Which)`, `GroupMissing`, `CannotCheck(Why)`. `ResetFor` algorithm is spelled out in six steps (t2). The real `/quota` answer is ONE json object (not NDJSON) — `Parse` reads it whole, falls back to lines and to a `result` wrapper.
9. **`AgyError.Parse` reads a pretty-printed `AGY_ERROR: {` object too** (the owner's issue pasted it multi-line; the plan only named two one-line shapes), with `Utf8JsonReader` + `JsonDocument.TryParseValue`.
10. **Guess counter.** `NextConsecutive(key, now)` = standing guess entry's count + 1, else 0 (so 30, 60, 120, 240 min, 5 h); the plan's "the standing entry's count" is read as "the count the next guess uses". Doubling restarts after expiry because expired entries are not standing.
11. **Card CSS pin.** A new `.cooldown-line` rule changes the sha256 pinned in `teamServerTab.test.ts`; t6 shares `.reset-line`'s rule through a second selector and re-pins (both files in t6's list). `modelsTab.ts` is NOT touched: the card reads `facts.context.reported[id].cooldown` with `facts.now` itself; `verdictBadge` gets an optional `now` parameter.
12. **Docs and the plan belong to t7 only** (the module docs, RESULTS §3.4, `statedReset.ts` header, plan status + `## 12. Deviations`). t1–t6 write no doc, so no two tasks share a file; if a doc-reading test (`ScenarioCoverageTests`, leaking-sites test) fails earlier because a doc is missing, the coder reports it and does not edit.
13. t4/t5 tests for `PanelService` and agy rows tell the coder to copy existing builders (`RoundNamesTheExcludedTests.cs:66-76`, `AntigravityOnLinuxTests.cs:63`) instead of inventing one; I did not open `ProviderSettings`/`AuthFor` fully, so t5 may need to give the agy row a vault key — stated in the brief as a thing to check.

## Not done / risk

- I did not run the resolver's `read` for every rule (the 289 KB rule set) — I read PROJECT.md, ENTRY.md, the plan and the code; the "rules for every task" block in each brief is a summary of the PROJECT.md and plan constraints (red first, MTP exe, low-priority.mjs, complexity ≤ 4, `testsToDelete-`, UTC).
- Task docs were not compiled against the repository; signatures were copied from the lines opened (cited in each brief). The places I told the coder to open first because I did not: `ReviewerOutcome.Ok/NonZeroExit` constructors, `ProviderSettings` properties, `ProvidersAnswer` members, `recordOf`/`textOf` in `providers.ts`, `modelsTab.test.ts:160-210` DOM helpers.
- t7's plan-lifecycle rules were not read; the brief tells the coder to run the tool and fix what it names.
