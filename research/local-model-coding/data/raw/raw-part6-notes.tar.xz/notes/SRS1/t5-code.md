# t5 — a cooling row stays out of the round, and the server says why (coder notes)

## What I did

- `src_mcp/src/Server/ServerJsonContext.cs`: `ProviderStatus.Cooldown` (`CooldownReport?`, `WhenWritingNull`, after `SurvivorMarker`); new `public sealed record CooldownReport(string UntilUtc, string Source, string Note)` beside `SurvivorMarkerReport`. No new `[JsonSerializable]`.
- `src_mcp/src/Server/PanelService.cs`:
  - constructor takes `QuotaCooldowns? cooldowns = null` as the last parameter; `_cooldowns = cooldowns ?? new QuotaCooldowns(settings.DataDir, TimeProvider.System, log, launcher, onRefused: RefusedWrite)`.
  - `RefusedWrite(string why)`: one `failure` / `storage-note` server notice through `_noticing.Offered`, subject `quota-cooldowns.json`.
  - `ProbeAsync`: `Cooldown = CooldownOf(provider)`.
  - `CoolingOf`, `IsCooling`, `CooldownOf`, `CoolingSentence` (internal static), `QuotaNameOf`, `BackOf`, `LeftOf`, `CoolingReasonOf`.
  - `CanRun` gains `&& !IsCooling(provider)`.
  - `ReasonFor`: the cooling sentence when the auth is not `unavailable`, else the existing `ExclusionReason`.
  - `RoundEngine` construction passes `_cooldowns` before `hostStopping`.
- `src_mcp/src/Server/Rounds/RoundEngine.cs`: parameter `QuotaCooldowns cooldowns` and field `_cooldowns`; `results = await _cooldowns.AfterRoundAsync(results, cancellation.Token);` between the `RunAllAsync` call and the summary.
- `src_mcp/tests/ACoolingRowStaysOutOfTheRoundTests.cs`: S26, S27, S28, S29, S38 (class `ACoolingRowStaysOutOfTheRoundTests`).

## Deviation (one, forced): the sentence's clock

The contract says `CoolingSentence(entry, provider, _cooldowns.Now)`. `QuotaCooldowns.Now` is `internal` in `CoaiMcp.Runners`, and that assembly does not grant `InternalsVisibleTo` to the server assembly (`CoaiMcp`). The fix belongs in `QuotaCooldowns.cs` (t3, out of bounds for me). So `CoolingReasonOf` uses `DateTimeOffset.UtcNow`. In production the store runs on `TimeProvider.System`, so this is the same instant. In the tests the store has a `FixedClock(NOW)`, so the "(in N h)" part is computed from the real clock. **Consequence: S26 is red** (see below).

The one-line fix for whoever owns `QuotaCooldowns.cs`: make `Now` public (or add `InternalsVisibleTo("CoaiMcp")` to `src_mcp/runners/CoaiMcp.Runners.csproj`), then in `PanelService.CoolingReasonOf` use `_cooldowns.Now` as the contract says.

## Red first

Stubs added first (the `cooldowns` parameter, the field, the engine parameter, `CoolingOf` → null, `CooldownOf` → null, `CoolingSentence` → empty, `RefusedWrite` empty). Build succeeded. Red messages from the stub run:

- S26 `ACoolingAgyRow_IsExcluded_WithThisSidesSentence`: `Expected excluded to contain a single item, but the collection is empty.` (the document's wording matches.)
- S27 `AnotherGroupOnTheSameCli_StillRuns`: `Expected excluded to contain a single item, but the collection is empty.` The document expected a different message only in the break-it variant (see below).
- S28 `WhenTheResetHasPassed_TheRowRunsAgain_WithoutAnyWrite`: **passed at the stub** (nothing is excluded, so the expectation holds trivially). Its real red is the break-it below.
- S29 `TheProvidersAnswer_CarriesTheCooldown_AndNothingForARowThatIsNotCooling`: `Expected gemini.TryGetProperty("cooldown", out var cooldown) to be True because the cooling row carries its cooldown, but found False.` (The document's `Expected status.Cooldown not to be <null>` belongs to a typed assertion; this test reads the JSON, so the wording differs.)
- S38 `AProvidersAnswerWithACooldown_SerialisesThroughTheGeneratedContext`: **passed at the stub**, because the wire member was already in place. Its real red is the break-it below.

## Break-it (each by hand, then restored)

- S27: `CoolingOf` reads `Standing("antigravity/gemini")` for every agy row → `Expected excluded to contain a single item, but found 2` (both rows named).
- S28: `CoolingOf` reads `Standing(key, DateTimeOffset.MinValue)` (ignores the reset) → `Expected excluded to be empty, but found at least one item {"antigravity: … (in -21709 min)"}`.
- S38: `[JsonIgnore]` unconditional on `Cooldown` → `Expected rows[0].TryGetProperty("cooldown", out var cooldown) to be True because Expected JSON to contain property "cooldown", but found False.`

All three restored; the file contents were checked afterwards and the build was rerun.

## Green / red after the change

`ACoolingRowStaysOutOfTheRoundTests` (run alone): 4 of 5 pass.
- **S26 fails** (the clock, above): `Expected excluded to start with "antigravity: its Gemini quota on Antigravity is spent — back at 2026-10-14T07:19:16Z (in 63 h)", but "… (in -21709 min)"`. The wording and the exclusion are right; only the "in N h" is off.
- S27, S28, S29, S38 pass.

Related classes (run alone, after the change): `RoundNamesTheExcludedTests` 11/11, `AntigravityOnLinuxTests` 11/11, `ASpentQuotaIsRememberedUntilItsResetTests` 12/12, `TheRoundParksAndLiftsTheQuotaTests` 7/7. `EveryBudgetInAClockedClassReadsItsClockTests`: see below (the run was not repeated in isolation after the last edit).

## Format

`dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes --include <the four files>`: no complaint (the only output is the existing IL2026/IL3050 analyzer noise in `src_server`, filtered out).

## Not done

- **ARefusedWrite** (the bonus notice test): not written. The service does not expose the store it builds, and a refused write can only be provoked through a round or `Park`. Skipped, as the brief allows.
- **S26** is red until the clock is fixed (above). I did not touch `QuotaCooldowns.cs`.
- The whole suite: see the result section below.

## Whole suite

Run once (9m 00s), log in the scratchpad `t5-suite.txt`: total 13878, succeeded 13758, skipped 117, **failed 3**:

1. `ACoolingRowStaysOutOfTheRoundTests.ACoolingAgyRow_IsExcluded_WithThisSidesSentence` — S26, the clock (see the deviation above). Mine.
2. `TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` — a census test, NOT in my file list. It keeps a hand-written list of the producers that call `ServerNotice.Shortened(`; `src_mcp/src/Server/PanelService.cs` is now a producer (my `RefusedWrite`) and is not on that list. Caused by my change. The fix belongs in that test (add PanelService.cs with its reason), or `RefusedWrite` must stop calling the helper. Not edited (out of bounds) — needs a decision.
3. `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — the Unix socket path is over 108 characters in this worktree's path. Not mine (t2 and t4 saw the same).

## Commit

`dc252630` on `feat/quota-cooldown`, the four task files added by name. Not pushed.

## Left

- S26: make `QuotaCooldowns.Now` reachable (public, or InternalsVisibleTo for the server assembly) and use `_cooldowns.Now` in `PanelService.CoolingReasonOf` instead of `DateTimeOffset.UtcNow`.
- Census test 2 above.
- ARefusedWrite (bonus) not written.
