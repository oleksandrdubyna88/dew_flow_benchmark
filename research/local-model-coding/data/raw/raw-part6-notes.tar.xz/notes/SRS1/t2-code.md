# t2 — coder notes (agy: AGY_ERROR classifier, /quota report, probe, runtime overrides)

Branch: feat/quota-cooldown (worktree wt/t2). Not committed yet at the time of writing; not pushed.

## What I did

Files changed (only the task's list):
- `src_mcp/runners/Reviewers/AgyError.cs` — new. `AgyError.Parse` reads every `AGY_ERROR` value: one-line and pretty-printed shapes, first JSON value after the marker, `status` (else string `code`), `short_error` (else `message`). A torn value and a value with both fields empty are no error.
- `src_mcp/runners/Reviewers/AgyQuotaReport.cs` — new. `AgyQuotaGroups` (the D3 table, `KeyOf` with one effort strip and exact family lookup, `BucketIdsOf`, `NameOf`), the bucket/group/verdict records, `AgyQuotaReport` (`Parse`, `ResetFor` following the six steps), `AgyQuotaRead`, `AgyQuotaProbe` (`RequestFor` = the owner's argv, `ReadAsync` with the four failure reasons).
- `src_mcp/runners/Reviewers/AntigravityRuntime.cs` — `RateLimited` (D2), `QuotaKeyOf`, `GaugeDecidesUndecided => true`, `ReadResetAsync` (answers by verdict through a switch expression). Added the two constants `ExhaustedStatus` and `IndividualQuota`.
- `src_mcp/tests/AnAgyQuotaIsReadFromItsStructuredErrorTests.cs` — new. S4, S5, S6, plus `AgyError_ParsesBothShapes_AndIgnoresABadLine`.
- `src_mcp/tests/TheAgyQuotaReportPicksTheResetTests.cs` — new. S9–S15, S40 (theory, cases by name), S43.
- `src_mcp/tests/fixtures/antigravity/quota-sample.json` — new, verbatim from the task document (checked: parses as JSON).

Nothing else was touched. The committed fixtures (`quota-2026-10-28.json`, `models-2026-10-28.txt`, `consult-quota.stderr.txt`) are read only.

## Red first

Stubs were written first (types with the final shapes, bodies returning wrong answers), so the tests compiled and failed on assertions.

Red messages seen (assertion failures, not compile errors):
- S4 `TheIndividualQuotaLine_IsASpentVerdict`: `Expected True, but found <null>.` The document says `Expected verdict.Spent to be True, but found <null>`. Same assertion; my test has no `because` text.
- S5 `TheOlderErrorShape_IsReadToo`: `Expected True, but found <null>.` (same wording difference as S4).
- S6 `WithoutTheQuotaSentence_NothingIsSpent`: `Expected generic.Limited to be True, but found False.` (stub returns the text verdict, so case (a) fails on Limited before reaching Spent.)
- AgyError parse fact: `Expected AgyError.Parse(Agy133) to contain a single item, but the collection is empty.`
- S9: `Expected report.ResetFor("antigravity/gemini", Now) to be ...Spent { UntilUtc = 2026-10-14 07:19:16, Which = "weekly" }, but found ...Available`. Document wording differs only in the variable name.
- S10 / S11 / S12: `... found Available`. The document's S12 red said `found "weekly"`; my stub returns Available, so the message differs. Assertion, same test.
- S13: `Expected type to be ...SpentWithoutReset, but found ...Available.`
- S14: `Expected AgyQuotaGroups.KeyOf(id) to be ... "antigravity/argon", but found "antigravity/gemini"` (the stub returns Gemini for everything). Matches the document's prefix-rule red in content.
- S15: `Expected exited.ResetFor(...) to be CannotCheck { Why = "exit 1: unknown command /quota" }, but found ...Available`. The document's wording matches apart from the variable name.
- S40 rows: `Expected ... to be GroupMissing, but found Available` on the first row (as the document says); the other rows fail the same way.
- S43: `Expected report.Groups to contain 3 item(s), but found 0`. The stub Parse returns an empty report, so this fails on the group count, not on the bucket count. The document's "found 4" message is the two-group reader case, which the stub does not produce.

Red count: 12 of 16 in the second class and 4 of 4 in the first class fail on the stubs; the passing ones are the rows whose expected answer the stub already gives (S40 `Available` rows, plus the "not spent" case of S6b). That is as expected for a stub.

## Break-it (step 4)

- S6(a): `bool? spent = true;` (every RESOURCE_EXHAUSTED spent). Result: `WithoutTheQuotaSentence_NothingIsSpent` fails with `Did not expect a value, but found True.` The document asked for `Expected verdict.Spent to be <null>, but found True`; the assertion is `Should().BeNull()`, so FluentAssertions words it differently.
- S14: prefix rule (`model.StartsWith("gemini-")` → Gemini). Result: `AnUnknownModel_HasNoGroup` fails with `Expected AgyQuotaGroups.KeyOf(id) to be ... because the id gemini-4-argon-medium ... "antigravity/argon"`.
- Both restored by hand; the file contents were checked to match the implementation above, then rebuilt.

## Green

- Build: `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers` → 0 errors, 0 warnings reported by the grep.
- `AnAgyQuotaIsReadFromItsStructuredErrorTests`: 4 / 4 passed.
- `TheAgyQuotaReportPicksTheResetTests`: 16 / 16 passed.
- Wider classes (after restore and rebuild):
  - AStatedResetIsNeverWaitedOutTests: 9 / 9
  - CooldownParserTests: 18 / 18
  - GateReportingTests: 12 / 12
  - EveryPaidLaunchIsWrittenTests: 41 / 41
  - ConsultFailureTests: 11 / 11
  - ConsultAntigravityDenialScenarioTests: 27 / 27
- Whole suite: see the final section below.

## Notes on the run

- The test executable is `src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests` (no `.exe` on this Linux host). The document's `CoaiMcp.Tests.exe` path does not exist here; I used the real binary.
- The shell check rejected some commands with `$` variables and loops, so the runs were done one class at a time.

## Whole suite (run once, as the document asks)

- Result: total 13845, succeeded 13727, skipped 117, failed 1.
- The one failure: `CoaiMcp.Tests.RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`. Error: a Unix domain socket path of about 130 characters is over the 108-character limit (`.../wt/t2/tmp/testsToDelete-coai-run-.../shown.sock`). It is a path-length problem from this worktree's location. Re-run alone: the class `RegularFilesTests` gives 30 passed, 1 failed (the same test), 1 skipped. This test does not use any file I changed. I did NOT verify it passes at base in a short path, so the claim "environment, not my change" is an inference from the error, not a measured result. Needs a check by someone with a shorter worktree path.
- The whole run took about 25 minutes because other test suites (other worktrees) ran on the same host.

## Format

- `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes`: no format complaint names any of my six files. The output has many analyzer errors (IL2026/IL3050) in `src_server/src/*Endpoints.cs`, which are outside this task's files and were not touched.

## Commit

- `8598637e` on `feat/quota-cooldown`, with the six task files added by name (`git add` of the six paths). Not pushed.

## Left / to check

- The `RegularFilesTests` socket-path failure above: confirm at base in a short worktree path.
- The census-style test over `src_mcp/runners` (Process/JsonSerializer/size) passed in the whole run; no new-file failure from it.
- `RateLimit.Hopeless` is asserted only on the spent path (S4), not on the undecided Spent == null path.
- The `Spent` in `RateLimitVerdict` (`Because(..., spent: null)`) for another RESOURCE_EXHAUSTED: `RateLimit.Hopeless` was not asserted on that path (not required by the document).
