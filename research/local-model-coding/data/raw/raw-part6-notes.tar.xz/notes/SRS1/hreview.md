# hreview — review of the spent-quota cooldown (plan `todo/PLAN_a_spent_quota_cools_the_model_down.md`, branch `feat/quota-cooldown`)

Reviewed commits: `6786582e..HEAD` (the plan commit to `ecbcf25b`). Written before any code change (step 1).

## Findings

**H1 — blocking — `src_mcp/runners/Reviewers/ReviewerRuntime.cs:819` (`DeepseekRuntime`).**
DeepSeek derives from `CodexRuntime`, which overrides `QuotaKeyOf` to `"codex"` (`ReviewerRuntime.cs:603`), so a DeepSeek row inherits the Codex quota: a refused DeepSeek row that is spent parks `codex` and excludes every Codex row, and the card and exclusion sentence say "Codex usage limit". D3 keeps every API-style and custom row on the empty key; DeepSeek is an API key row with no measured quota of its own.
Fix: override `QuotaKeyOf(string model)` → `string.Empty` in `DeepseekRuntime`, after a failing test that asserts `new DeepseekRuntime().QuotaKeyOf("deepseek-chat")` is empty (fails today: `"codex"`).

**H2 — major — `src_mcp/src/Server/PanelService.cs:453` (`CoolingReasonOf`).**
The exclusion sentence takes `DateTimeOffset.UtcNow`, but the store's clock is the injected `TimeProvider` (`QuotaCooldowns.Now`). With the test clock at 2026-10-11 the sentence says `(in -21728 min)`. Reproduced: `ACoolingRowStaysOutOfTheRoundTests.ACoolingAgyRow_IsExcluded_WithThisSidesSentence` (S26) is red at `ACoolingRowStaysOutOfTheRoundTests.cs:31`. The plan's D9 and S26 need the sentence to use the store's clock.
Fix: pass `_cooldowns.Now` (internal, same assembly) instead of `DateTimeOffset.UtcNow`. The S26 test is the red test already; no new test is needed.

**H3 — major — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:169-186` (`ReadEntries` inside `Rewrite`, `:156`).**
Under the lock, `Rewrite` re-reads through `ReadEntries`, which turns *any* `IOException`/`UnauthorizedAccessException` into "no entries" (D4 fail-open is meant for a torn file only). A transient read failure while another `coai-mcp` holds the file (a sharing violation, an antivirus scan) therefore reads as nobody parked, and the write that follows overwrites the file with this round's entries alone, losing the other process's park or lift. D4 and the fail-open contract say a refused write, not a silent overwrite, in this case.
Fix: inside `Rewrite`, read so that a torn/unparseable file still reads as `[]` but an I/O failure propagates to `Change`'s existing catch (→ `Refused`). Test first: hold the JSON file open with `FileShare.None` and assert `Park` answers `Refused` and the file's bytes are unchanged.

**H4 — minor — `src_mcp/tests/AStructuredVerdictOutranksTheWordScanTests.cs` and `AClaudeSpendLimitIsASpentQuotaTests.cs`.**
The plan names the scenarios S3 `AnUndecidedVerdict_ReadsTheTextAsBefore` and S8 `AnotherEnvelope_IsStillAnExit`; the tests are named `AnUndecidedVerdict_ReadsTheVendorsResetAsBefore_AgysDaysAway` / `…ClimbsWhenTheTextNamesNoReset` and `AnotherErrorEnvelope_IsStillAnExit`. The brief asks for the exact name.
Fix: rename the S8 method to the plan's name (cheap). S3 is two cases split into two facts; keep the split and name the first one as the plan does.

**H5 — minor — `src_mcp/runners/Reviewers/QuotaCooldowns.Round.cs:12-38` (`AfterRoundAsync`).**
A non-cancellation exception from any one key's probe (e.g. the launcher throwing) aborts the whole round's plans, including the lifts of keys that were fine. The outcome is safe (nothing wrong is parked; the results are returned) but a lift is lost.
Fix: none in this pass (a per-key catch is a design choice; recorded, not changed).

**H6 — minor — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:192`.**
`_unreadableSaid` is per instance, and D4 says one warning per process. The product builds one `QuotaCooldowns` per process (`PanelService`), so this is the same thing in practice. Not a defect on a second look.

**H7 — minor — `src_vs_code/src/modelCardWorld.ts:146` / `modelCard.ts`.**
Checked on a second look: the card's cooldown line uses the card's `now` and falls back to the ledger's reset line once the cooldown has passed (`cooldownLineOf` returns `''`, the ternary picks `reset-line`). No defect.

## Checked and found correct (no finding)
- Plan decisions D1, D2, D3 (apart from H1), D4 (apart from H3), D5 (aggregation, one probe per key, spent-wins, one locked write), D6 (`AgyQuotaReport` rules and the probe request), D7 (the executor order, `ClaudeRuntime.RateLimited`), D8 (time zone in the viewer's zone), D9 (`cooldown` on the wire, `CanRun`, the reason sentence), D10, D11 (`CanRun` covers the security roster).
- Lock discipline: every write runs under `quota-cooldowns.lock`; a refused write is a value and reaches the notice; reads take no lock.
- `AgyError.Parse` both shapes; `status`/`code` and `short_error`/`message`; a bad JSON line is no error.
- `cooldownWords.ts` matches S31/S32 wording; `providers.ts` parses only a whole `cooldown`.

## Test-name check (S1–S43)
All 43 scenario names exist in a test file except the two renamed in H4 (S3, S8). Behaviour checked by reading the bodies of the classes that matter (S1–S8, S9–S15, S16–S21, S22–S25, S26–S29, S30–S33, S34–S43); not every Then was re-derived by hand. The full suite run is the evidence for the rest (see the final report).

## Status (after step 2)

Red-first was observed for each defect fix (the test failed for the stated reason before the fix, then passed after it):
- H1: `ADeepseekRowParksNoCodexQuota_AndACodexRowStillParksIt` red with `Expected string to be empty … but found "codex"`.
- H2: `ACoolingAgyRow_IsExcluded_WithThisSidesSentence` (S26) red with `… (in -21728 min)`; the test was already there.
- H3: `AnUnreadableFile_IsARefusedWrite_NotAnOverwrite` red with `Expected … Refused … but found … Written`.

| id | severity | status |
|---|---|---|
| H1 | blocking | fixed: `DeepseekRuntime.QuotaKeyOf` → empty (`ReviewerRuntime.cs`); new test in `TheRoundParksAndLiftsTheQuotaTests.cs` |
| H2 | major | fixed: `PanelService.CoolingReasonOf` reads `_cooldowns.Now`; `QuotaCooldowns.Now` made public so the other assembly can read it |
| H3 | major | fixed: `QuotaCooldowns.Rewrite` uses `ReadStrict`, so an I/O failure under the lock refuses the write (`ASpentQuotaIsRememberedUntilItsResetTests.cs`) |
| H4 | minor | fixed: S8 renamed `AnotherEnvelope_IsStillAnExit`; S3's two facts renamed `AnUndecidedVerdict_ReadsTheTextAsBefore` and `…_AndClimbsOnA429` |
| H5 | minor | not fixed: a per-key catch changes the round's error contract; recorded for the owner |
| H6 | minor | wrong on a second look (one instance per process) |
| H7 | minor | wrong on a second look (fallback is correct) |

Found by the baseline suite, not in the list above:
- `TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` failed because `PanelService.RefusedWrite` built a `ServerNotice` with `ServerNotice.Shortened` directly (a seventh producer outside the guard's list). Fixed by making `StartupNotices.Note` internal and calling it from `RefusedWrite`; the guard's list is unchanged.
- `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` fails on this host: the socket path under the test's temp root is longer than the 108-character Unix limit. The test and its file are not in this branch's diff. Not fixed (environment: the checkout's path length).

Baseline (before the fixes): 13,878 total, 3 failed (S26, the guard, the socket test).

Final (commits 203cbdad, a9c6a30f, 411b7dc1; the tree is clean):
- Build: `dew_flow_connect_other_ais.slnx` Debug, 0 errors.
- Whole MCP suite (foreground, current code): 13,880 total, 13,761 passed, 2 failed, the rest skipped (Windows-only).
  - `RegularFilesTests.A_fifo_a_socket_…`: fails alone too; the socket path under the test temp root exceeds the 108-char Unix limit. Environment; this branch does not touch it. Left as is.
  - `AskHumanScenarioTests.RequireRefusesTheThirdBatch_…`: failed once under full-suite load, passes alone (1/1). Flaky timing; not touched by this branch.
- Format: `dotnet format --verify-no-changes` exit 0 on `src_mcp/src/CoaiMcp.csproj` and `src_mcp/tests/CoaiMcp.Tests.csproj`. The solution-wide run prints existing AOT analyzer messages from `src_server` and is not a format signal; not used.
- Extension (`src_vs_code`): not run in this pass; no file under `src_vs_code` changed here.
- Background runs were stopped by the background time limit (the run had no summary); only the foreground run is cited above.
