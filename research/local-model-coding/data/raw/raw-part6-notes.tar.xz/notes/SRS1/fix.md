# Fix notes — review of the quota-cooldown implementation

Commits: `db0cf93c` (R2, R4), `91ad4902` (R1), `a3282a0f` (R3, R5, R6, R7).

| id | severity | status |
|---|---|---|
| R1 | major | fixed |
| R2 | major | fixed |
| R3 | minor | fixed |
| R4 | minor | fixed |
| R5 | minor | fixed |
| R6 | minor | fixed |
| R7 | minor | fixed |

## R1 — no test pins `AfterRoundAsync` in the engine or the refused-write notice
Fixed. Two tests in `EndToEndTests` run a real round through `PanelService` on the fake CLI, with codex refusing "You've hit your usage limit":
- `ARoundThatCodexRefusesAsSpent_ParksCodex_AndTheNextRoundLeavesItOut`: `quota-cooldowns.json` holds `codex`, and the next `ExcludedFrom(PlanReview)` names the row.
- `AQuotaWriteTheStoreRefuses_ReachesTheNoticesAsAStorageNote`: a directory sits where the lock file belongs (refused at once, not after 30 s), and exactly one `StorageNote` `failure` notice reaches `Noticing`, with subject `quota-cooldowns.json`.

Teeth: with the `RoundEngine` line commented out, both fail ("collection is empty"). With `onRefused: RefusedWrite` replaced by `null` in `PanelService`, the second fails. Both lines restored.

## R2 — S25's Kimi half ran a hand-written fake
Fixed. `KimiFake` is deleted. S25 uses the real `KimiRuntime` (`KimiMonthlyQuotaTests.Kimi()`, made `internal` for it), so `KimiRuntime.QuotaKeyOf` and `ReadResetAsync` run. `ADeepseekRowParksNoCodexQuota_AndACodexRowStillParksIt` now also asserts `CustomCodexRuntime.QuotaKeyOf` is empty.
Not shown: that deleting a `KimiRuntime` override turns S25 red. The test keys on `"kimi"` and a `FromGuess` source, which the real overrides produce; I did not revert them to confirm.

## R3 — S3's first case could not go red for the plan's reason
Fixed. The case now uses "You've hit your usage limit." (hopeless by its words, no reset), so only the `?? RateLimit.Hopeless(reason)` half stops the ladder. The old agy sentence stays as its own fact (`…AndStopsOnAResetThatOutlastsTheBudget`). Teeth not demonstrated by reverting the scheduler.

## R4 — a cancelled probe threw away every plan of the round
Fixed, test first. `ACancelledAgyProbe_StillParksTheCodexQuotaTheSameRoundSpent` failed with "Expected store.Standing("codex") not to be <null>"; it passes after `TryPlanAsync` catches the cancellation per key (the key gets no plan, the log says so) and the other plans go into the one locked write. The outer `OperationCanceledException` catch could no longer be reached, so it is removed; the existing `ACancelledProbe_ParksNothing…` test still passes and still sees "cancelled" in the log.

## R5 — `StorageRefusal` sat inside `Of`'s doc block
Fixed. `StorageRefusal` is above the "notice a refusal makes" block, with its own summary.

## R6 — duplicated `<summary>` on `DeepseekRuntime.QuotaKeyOf`
Fixed.

## R7 — the S40 row "5h fraction is 2" could not fail
Fixed. The weekly bucket is disabled in that row, so the 5h bucket is the only candidate: unreadable gives `GroupMissing`, whereas a reader without the [0, 1] check would see a readable bucket at 2 and answer `Available`.
Not shown: I did not remove the range check to watch the row go red.

## Results
- Build: `dew_flow_connect_other_ais.slnx` Debug, 0 warnings, 0 errors.
- Changed classes (`EndToEndTests`, `TheRoundParksAndLiftsTheQuotaTests`, `AStructuredVerdictOutranksTheWordScanTests`, `TheAgyQuotaReportPicksTheResetTests`, `KimiMonthlyQuotaTests`): all passed.
- Whole MCP suite (one foreground run, HEAD `a3282a0f`): 13,884 total, 13,766 passed, 117 skipped (Windows-only etc.), 1 failed.
  - The failure is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException`, the socket path under the test temp root is over the 108-character Unix limit. It depends on the length of this checkout's temp path and does not touch this branch. I did not re-run it alone (the path is the same every time) and left it.
- Format: `dotnet format --verify-no-changes --no-restore` clean (exit 0, no output) on `CoaiMcp.csproj`, `CoaiMcp.Runners.csproj` and `CoaiMcp.Tests.csproj`.
- Extension: not run; I changed nothing under `src_vs_code` (earlier commits of the branch did).
