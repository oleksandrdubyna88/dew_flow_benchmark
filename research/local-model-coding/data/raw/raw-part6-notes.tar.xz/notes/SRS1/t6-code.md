# t6 — the card says when the model is back (extension half): coder notes

Commit: `63ab55ac` on `tmp/t6` (not pushed).

## What I did

- `src_vs_code/src/cooldownWords.ts` (new leaf, imports only `./resetWords`): `CooldownReport`, `cooldownClock`, `cooldownLine` with the three wordings (quota / stated / guess). Dates via `formatToParts`, parts joined as `dd.MM.yyyy HH:mm`.
- `src_vs_code/src/resetWords.ts`: `spanOf` exported, nothing else changed.
- `src_vs_code/src/providers.ts`: `ProviderHealth.cooldown?` with doc comment; `cooldownOf` beside `warningOf`; `oneProvider` spreads it.
- `src_vs_code/src/modelCardWorld.ts`: `verdictBadge(id, context, now = Date.now())` shows `cooling down` (title = note) while the cooldown is ahead; otherwise today's behaviour. No `warn` verdict class exists in `catalogSheet.ts`, so the badge is `badge verdict cooling` alone.
- `src_vs_code/src/modelCard.ts`: passes `facts.now` to `verdictBadge`; `foot` draws `cooldown-line` INSTEAD of `reset-line` while a cooldown stands; `cooldownLineOf` helper.
- `src_vs_code/src/catalogCss.ts`: `.catalog .reset-line, .catalog .cooldown-line` in one rule, comment extended.
- `src_vs_code/src/test/teamServerTab.test.ts`: hash re-pinned to `0b56eca39346f908bc26068497a41c59a522daff9dfded6a924d72f905126492`, one comment block added.
- `src_vs_code/src/test/aCoolingRowSaysWhenItIsBack.test.ts` (new): S30, S31, S32, S33.

## Red messages (seen before the production code)

- S30: `Expected values to be strictly deep-equal: undefined !== { untilUtc: '2026-10-14T07:19:16Z', source: 'quota', note: 'n' }` (as the document).
- S31: `Expected values to be strictly equal: '' !== 'quota spent — back 14.10.2026 09:19 (in 63 h)'` (as the document).
- S32: `'' !== 'quota spent — back about 14.10.2026 09:19 (in 63 h, estimated from the error text)'` (the stated case failed first; the document named the quota wording).
- S33: `null !== ''` on the cooldown-line text. The document's example said `null !== 'quota spent — back …'`; the stub returned `''`, so the expected value was `''`. Same assertion, different expected text.

Two deviations in how I got to red:
- `tsc` does not emit when there are type errors. The test read `cooldown` from `ProviderHealth`, which did not have it yet, so I added the type field (`providers.ts`, with its doc comment and the import) before the first red run. No runtime behaviour was added with it.
- The stubs take `_`-prefixed parameters so `noUnusedParameters` does not block the emit.

## Choices I made beyond the contracts

- `stillCooling(id, context, now)`: a private helper in `modelCardWorld.ts`. `verdictBadge` with the inline check scored complexity 6 under ESLint (limit 4). The helper keeps `verdictBadge` at 4. Behaviour is the contract's.
- S33 runs the full catalog page (`catalogHtml(state, 'test-nonce', 'models')`), not `modelsTabHtml`, because `runPageHtml` needs the page's own script. Card text is read with `pageTree` (it has `text()`; the harness `Node` does not).

## Checks

- Mutation: I drew both lines in `foot` (cooldown and reset). S33 failed on `1 !== 0` at the "no `.reset-line`" assertion. Restored, recompiled, green.
- CSS hash: with the second selector and comment reverted, the sheet hashed to `862e9808…9d82e` (the previous pin), so the comment's claim holds. Re-applied, new pin `0b56eca3…2492`.
- `teamServerTab.test.js` 19/19 green, but only when run with cwd `src_vs_code`. From the repo root, the LEAF test failed with ENOENT on `src/catalogSheet.ts`. That was my cwd, not the code.
- `aCoolingRowSaysWhenItIsBack.test.js` 4/4 green.
- `statedReset`, `providersBadge`, `modelsTab`, `importCycles.test.mjs`: 45/45 green.
- `npm --prefix src_vs_code run typecheck`: clean.
- `npm --prefix src_vs_code run lint`: clean (after the `stillCooling` split).
- `npm --prefix src_vs_code test` (second run, grep of batch totals): 513 compiled and 15 source files; every batch `fail 0`. One batch reported `tests 12 / pass 11 / fail 0`. The one difference is not a failure, and I did not check which test it was (most likely a skip). The first full run's output file was not readable from here, so I took totals from the second run.
- A temp-folder message ("held by a scanner") at the end of the run is environmental; the run's own tests are unaffected.

## Things to know

- The task document's header says "Do not commit", but the Rules section and the brief ask for a conventional commit with files added by name. I committed (`63ab55ac`). If the intent was no commit, reset that commit (`git reset --soft HEAD~1`) and nothing else changes.
- I created a temporary `.git-commit-msg-t6.txt` in the worktree to pass the message to `git commit -F`; it was removed before the commit and is not in it.

## Left

- Nothing in the task scope. Not pushed.
- Out of scope and untouched: `modelsTab.ts`, `statedReset.ts`, `helpContent.ts`, `src_mcp/`, `src_server/`, `shared/*.json`.
