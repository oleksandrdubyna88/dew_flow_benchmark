# t1 — coder notes

Branch worktree: `wt/t1`. Nothing committed yet at the time of writing (see the final message for the commit state).

## What was done

- `ReviewerExecutor.cs`
  - `RateLimitVerdict.Spent` (`bool?`, init, default null) and `Because(reason, usage, bool? spent = null)`.
  - `ReviewerOutcome.RateLimited.Spent` (`bool?`, init, default null), beside `Usage`; positional parameters unchanged.
  - `Classified` carries `Spent = verdict.Spent` on the limited branch. Order (adapter asked first) unchanged.
  - `RateLimit.Spent` and `RateLimit.Hopeless` unchanged.
- `BoundedScheduler.cs` — `Hopeless` is `(limited.Spent ?? RateLimit.Hopeless(limited.Reason)) || ResetOutlasts(...)`; `<remarks>` extended by one sentence.
- `QuotaReset.cs` (new) — the record, its three source constants, three gauge constants, `Gauge` init property, and `Guess`, `Stated`, `Quota`, `StatedOrGuess` exactly as the contract.
- `ReviewerRuntime.cs` — on `IReviewerRuntime`: default `QuotaKeyOf` (empty), default `ReadResetAsync` (`StatedOrGuess`), default `GaugeDecidesUndecided` (`false`). `CodexRuntime.QuotaKeyOf` is `public virtual` → `"codex"`.
- `CustomRuntime.cs` — `CustomCodexRuntime.QuotaKeyOf` override → empty.
- `ClaudeRuntime.cs` — `QuotaKeyOf` → `"claude"`; `RateLimited` override: exit ≠ 0 AND envelope is an error (`is_error` true) with `api_error_status` 429 AND `result` containing `hit your monthly spend limit` (ordinal, ignore case) → `Because(WhyItFailed(...), Usage.None, spent: true)`; otherwise `ByText`. Catches `JsonException or InvalidOperationException`. Helpers `SaysMonthlyLimit`, `HttpStatusOf`, `ReasonOf` keep each method small (complexity ≤ 4).
- `KimiRuntime.cs` — `QuotaKeyOf` → `"kimi"`; `ReadResetAsync` → `QuotaReset.Guess(..., "Kimi names its reset in a clause coai does not parse")`.
- Tests:
  - `AStructuredVerdictOutranksTheWordScanTests.cs` (new): S1, S2, S3 (two facts).
  - `AClaudeSpendLimitIsASpentQuotaTests.cs` (new): S7, S8 (two facts plus the success-envelope fact in S8).
  - `AClaudeReasonInItsEnvelopeTests.cs`: the one pin at `:63` changed from `NonZeroExit` to `RateLimited`.

Deviations from the document, all small:
- S7 counts launches with `ScriptedResults` (a `Launched` count) instead of the sibling's `Answers` helper; the envelope text is the same constant.
- S8 splits into two facts (`AnotherErrorEnvelope_IsStillAnExit`, `ASuccessfulEnvelopeThatExitsOne_IsNotALimit`); the 400 case also asserts `Limited == false` through `ClaudeRuntime.RateLimited`.
- The S1 red message carries the FluentAssertions `because` text, so it reads `Expected launcher.Launched to be 1 because …, but found 4.` The core text `Expected launcher.Launched to be 1 …, but found 4` is what the document names.
- Test helper `Verdicting` builds its invocation directly (not through `Build`), and `Run` takes the launcher so each test counts its own launches.

## Red messages seen (before production code)

- S1 `ASpentVerdict_IsHopeless_WhateverTheWordsSay`: `Expected launcher.Launched to be 1 because …, but found 4.` (as the document).
- S2 `ATransientVerdict_ClimbsTheLadder_EvenWhenTheTextSaysExhausted`: `Expected launcher.Launched to be 4 because …, but found 1.` (as the document).
- S3: both facts GREEN at red stage. Expected: S3 is a guard for the undecided path, which the current code already gives.
- S7 `TheMonthlySpendLimitEnvelope_IsASpentRateLimit`: `Expected type to be CoaiMcp.Runners.Reviewers.ReviewerOutcome+RateLimited, but found CoaiMcp.Runners.Reviewers.ReviewerOutcome+NonZeroExit.` (as the document).
- Pin test `AClaudeReasonInItsEnvelopeTests.TheExecutorAsksClaudeWhyItFailed_AndTheSentenceCarriesTheAnswer` (after the pin change): same message at red stage.
- S8 passes at red stage (correct: it guards the current behaviour, the 400 envelope already is an exit).

## Green

- Build: `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers` → Build succeeded, 0 warnings.
- `AStructuredVerdictOutranksTheWordScanTests`: 4/4.
- `AClaudeSpendLimitIsASpentQuotaTests`: 3/3.
- `AClaudeReasonInItsEnvelopeTests`: 19/19.
- `AStatedResetIsNeverWaitedOutTests` 9/9, `GateReportingTests` 27/27, `KimiIsClassifiedFromItsReportTests` 9/9, `ReviewerExecutorTests` 27/27, `ConsultFailureTests` 41/41 (run via the MTP exe with `--filter-class`).

## Break-it checks

- S8: `ClaudeRuntime.RateLimited` keyed on `is_error` alone → `AnotherErrorEnvelope_IsStillAnExit` red: `Expected type to be CoaiMcp.Runners.Reviewers.ReviewerOutcome+NonZeroExit, but found CoaiMcp.Runners.Reviewers.ReviewerOutcome+RateLimited.` (as the document). Restored, green.
- S3: `Hopeless` wired as `(limited.Spent ?? false) || ResetOutlasts(...)` → ALL FOUR facts stayed green. The document predicted `Launched 1, found 4` on the first S3 case; that does not happen, because `ResetOutlasts` still reads agy's `Resets in 88h49m9s` as outlasting the budget, so the first case stays at 1 either way. The second case (`429 Too Many Requests`) has no spent word, so it climbs under both wirings. **Gap:** nothing in S3 as written catches a regression where a `null` verdict stops reading the WORDS. A case such as `Because("RESOURCE_EXHAUSTED (code 429): too many requests", Usage.None, spent: null)` → `Launched == 1` would catch it (the word `exhausted` makes it hopeless today). Not added: the document fixes the test list. Reported to the owner for a decision.
- Restored both breaks; S1–S3, S7, S8 green again after the restore.

## Still to do

- Whole suite (13,807 tests) — see final message for the result.
- `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes`.
- Commit (own files only, conventional message; no push).

## Final results

- Whole MCP suite (MTP exe, no filter): total 13818, succeeded 13700, skipped 117, failed 1.
  - Failed: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`.
  - Cause: `ArgumentOutOfRangeException` — the test's socket path under this long worktree path is longer than the 108-character Unix socket limit. It fails deterministically when run alone too (30/32 in its class). Environmental; not in my files; not fixed here (not in my file list).
- `AFeatureIsReviewedEndToEndTests` failed once during the full run and passed 32/32 alone — treated as flaky.
- `dotnet format --verify-no-changes`: no lines reference my files. The solution-wide output lists existing analyzer errors in `src_server` (not mine).
- Commit: own files only, no push. See the final message for the hash.
