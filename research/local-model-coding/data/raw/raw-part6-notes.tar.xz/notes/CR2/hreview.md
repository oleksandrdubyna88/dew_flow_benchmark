# Review of the spent-quota cooldown (branch feat/quota-cooldown, plan todo/PLAN_a_spent_quota_cools_the_model_down.md)

Reviewer: H (Haiku). Written before any code change, per the brief.

## Scenarios

All 43 scenario names (S1–S43) exist as tests with the plan's names. I opened each class and read each *Then* against its assertions. Every scenario asserts its outcome and would fail without the change (the broken paths are explicitly excluded by the stubbed-red notes in code.md, but the assertions themselves are sound). The TS file has S30–S33 under the plan's names. No scenario-level defect found.

## Findings

H1 — major — `src_mcp/runners/Reviewers/ReviewerRuntime.cs:841` (`DeepseekRuntime : CodexRuntime("deepseek")`)
DeepseekRuntime inherits `CodexRuntime.QuotaKeyOf` = `"codex"`, so a DeepSeek row that is refused parks the Codex CLI's quota, and a DeepSeek answer lifts a parked Codex row. The plan (D3) gives the empty key to every runtime that is not the Codex CLI's own quota (CustomCodexRuntime is excluded for this reason); DeepSeek runs on its own API key, so its quota is not the Codex sign-in's.
Fix: override `QuotaKeyOf` to `string.Empty` in `DeepseekRuntime`, with a test that a DeepSeek runtime's key is empty and a Codex one's is `codex`.

H2 — major — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:154-157` (in `Locked`, through `ReadEntries` at `:212-232`)
Under the lock, a transient I/O failure while reading the file (on Windows, a sharing violation while another process is replacing it) is treated as "no entries" (`Unreadable` returns `[]`). The write then replaces the file with only this round's changes, silently dropping every other key's park. That is exactly the lost-park the lock exists to prevent (plan F3). A torn or unparseable file may be overwritten (plan §8); an I/O failure may not.
Fix: under the lock, read with a variant that lets an I/O failure propagate, so `Locked`'s existing catch refuses the write and nothing is replaced; keep "torn/absent → no entries". Test: hold the file with `FileShare.None`, park a second key, expect `Refused` and the first key still standing.

H3 — major — `src_mcp/runners/Reviewers/AntigravityRuntime.cs`, `Decided` (the `SpentWithoutReset` arm)
The plan (D6, undecided case) says a spent bucket without a reset time for an UNDECIDED refusal is "cannot check" → not parked. The code maps `SpentWithoutReset` to `QuotaReset.ByText(...)` regardless of `spent`, so an undecided exhaustion whose gauge shows a zero bucket with no reset is parked on coai's 30-minute-doubling guess for hours. The plan says "the issue's 'undetermined' is never a parked row".
Fix: the `SpentWithoutReset` arm parks only when `spent == true`; otherwise `NotSpent` with the cause named. Test: undecided refusal + a gauge with a zero bucket lacking `reset_time` → not parked.

H4 — minor — `src_mcp/runners/Kimi/KimiRuntime.cs` (around `:274-283`)
The new `QuotaKeyOf` and `ReadResetAsync` members were inserted between `RateLimited`'s XML doc comment and its method, so `RateLimited` is left without its doc and `QuotaKeyOf` carries the wrong one.
Fix: move the two members above the doc comment of `RateLimited`.

H5 — minor — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:292` (`DecidedAsync`)
Every key with an `Ok` result is lifted, so on every healthy round `Apply` takes the lock file and may write a refusal notice ("A spent quota could not be remembered") even though nothing was spent. A lift with nothing standing is a no-op anyway.
Fix: lift only when `Standing(key, now)` is not null.

H6 — minor — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:302-307` (`ParkedAsync`)
A stated reset already in the past (from `CooldownParser`) is parked and logged as "parked until …", but it is written as an entry that is expired at once. The plan (D6, for agy) says a past instant is never a park.
Fix: treat `reset.UntilUtc <= now` as not parked, with the note naming it.

H7 — minor (not fixed) — `src_mcp/runners/Reviewers/QuotaCooldowns.cs:65` (`_warned`)
The plan says "ONE warning per process"; the code warns once per instance. Making it static would make S19 depend on test order. Not fixed; the wording of the plan is the only deviation.

H8 — minor (not fixed) — `AntigravityRuntime.cs` `Decided` (six arms) against doctrine §6 ("cyclomatic complexity ≤ 4 — extract, or use a switch expression"). The doctrine explicitly allows a switch expression, so I leave it; flagged for the second reviewer.

## Outcomes (after the fixes)

- H1 — fixed. Commit c8943883. Test `ADeepseekRowHasNoCodexQuotaTests` was red (`Expected string to be empty … but found "codex"`), now green.
- H2 — fixed. Commit ebbf6b30. `ReadEntries(underLock: true)` lets an I/O failure propagate, so `Locked` refuses. Test `ACooldownFileThatCannotBeReadIsNotReplacedTests` was red (`Written` instead of `Refused`), now green.
- H3 — fixed. Commit ebbf6b30. `SpentWithoutReset` routes through `WithoutAGauge`. Test `AnUndecidedExhaustion_WithASpentBucketThatNamesNoReset_IsNotParked` was red (parked as `guess`), now green.
- H4 — fixed. Commit c8943883. Members moved above `RateLimited`'s doc comment.
- H5 — fixed. Commit ebbf6b30. A lift needs a standing entry. Test `ALiftWithNothingStanding_WritesNothingAndSaysNothing` was red (a refused-write notice on a healthy round), now green.
- H6 — fixed. Commit ebbf6b30. A passed reset is not a park. Test `AStatedResetAlreadyPast_ParksNothing` was red (file written), now green.
- H7 — not fixed (see finding).
- H8 — not fixed (doctrine allows a switch expression).

Verification: build 0 warnings / 0 errors. The 12 changed test classes: 109 passed. Whole MCP suite: 13,883 total, 13,765 succeeded, 117 skipped (Windows-only), 1 failed: `RegularFilesTests.A_fifo_a_socket…`. Re-run alone, it fails again. The file is not touched by this branch. The coder's explanation is a socket path over 108 bytes under this session's temp root; by my count the path is about 112 bytes. I did not see the exception text, so the cause is plausible, not proven. Format: `dotnet format whitespace` and `style` clean on `CoaiMcp.Tests.csproj` and `CoaiMcp.Runners.csproj`. Extension tests not run: no `src_vs_code` file changed in this pass.

## Checked and found correct
- Concurrency: probe runs outside the lock; all writes under `quota-cooldowns.lock`; refused writes never throw and never discard results; `AfterRoundAsync` returns the list unchanged (S42).
- agy key table (D3), `AgyError` shapes (D2), `/quota` argv (D6), Claude spend-limit ordering in the executor (D7), `Hopeless` wiring (D1), wire member (D9), `CanRun`/`ReasonFor` (D9/D11), RoundEngine call placement (after `RunAllAsync`).
- Extension: parser drops half-cooldowns; `cooldownLine` in the viewer's zone; badge and line replace the reset line (D9).
