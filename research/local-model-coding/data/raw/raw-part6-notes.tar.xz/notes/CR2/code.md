# Coder notes — quota cooldown (Sonnet)

Started 10:48 UTC, deadline 13:48 UTC. Branch `feat/quota-cooldown`, nothing pushed.

## Commits
- 219e5be1 story 1 (S1–S8)
- 0e46e675 story 2 (S9–S25, S34–S37, S39–S43) + RESULTS §3.4 row + RetryLadder note
- b4c8a592 stories 3 and 4 (S26–S33, S38) + docs + plan status line and §12 deviations

## Decisions / deviations (also in the plan §12)
1. `IReviewerRuntime.ReadResetAsync` takes an extra `bool? spent` (undecided vs explicit agy refusal cannot be told from the reason). A reading that parks nothing is `QuotaReset.NotSpent(note)`.
2. `QuotaCooldowns(dataDir, clock, log, launcher?, lockWait?, onRefused?)`; refused-write notice is an `Action<string>` (runners cannot see `NoticeWriter`), wired in `PanelService` to `QuotaNotices.Unsaved` (code `storage-note`). `AfterRoundAsync` returns the results unchanged. In-lock hook `InLock(phase)`: `lock`/`read`/`write`.
3. Guard tests extended: `EveryBudgetInAClockedClassReadsItsClockTests` (QuotaCooldowns scanned; PanelService named not-scanned) and `TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` (new `QuotaNotices.cs`).
4. S25 codex part uses a ManualClock at 2026-07-14 (plan NOW is after the July date).
5. S34's rows are undecided (`Spent: null`), otherwise the Gemini row would park per S41.
6. `RateLimitVerdict.Because(reason, usage, bool? spent = null)`.
7. Default `QuotaReset.ByText`; Kimi overrides `ReadResetAsync` → guess (clause never parsed). `CustomCodexRuntime.QuotaKeyOf` → empty (inherits CodexRuntime otherwise).
8. TS: `cooldownLine` lives in `cooldownWords.ts`; `standingCooldown` (modelCardWorld.ts) holds the server report to the clock too; `verdictBadge` gained a `nowMs` parameter. S33 sets `process.env.TZ = 'Europe/Paris'` around the render (works on Node 26/Linux).

## Reds seen (against stubs — I wrote story 2–4 production code before their tests, then stubbed to watch the reds)
- S1 `Expected launched to be 1 ... but found 4`; S2 `... 4 ... found 1`; S3 green from the start (no wiring = today); S4/S5 `Expected True, but found <null>` (plan names `verdict.Spent`; FluentAssertions drops the subject on `bool?`); S6a red was `Expected exhausted.Limited to be True, but found False`; S7 `Expected type to be ...RateLimited, but found ...NonZeroExit`; S8 green from the start.
- S9–S13, S34, S40: `Expected Verdict(...) to be ...Spent..., but found ...Available`; S14: prefix-rule stub differs at index 12 (`antigravity/argon` vs `/gemini`); S15 `Expected verdicts to be equal to` (stub answered an empty report).
- S16–S18, S20, S21, S39: `NullReferenceException` / `DirectoryNotFoundException` (stubbed Apply wrote nothing) instead of the plan's `Expected standing not to be <null>`; S19 `Expected log.Warnings to contain a single item, but the collection is empty` (not the plan's JsonException escape — I did not write the unguarded read); S37(a) `Expected type to be Refused, but found Written`.
- S35/S36 (lock swapped for a private file): `Expected bTask.Wait(300ms) to be False because B waits for A's lock, but found True`.
- S22–S25, S41, S42 against the stub: `Expected launcher.Launched to be 1, but found 0`, NullReference, `Expected _log.Said ... stopped` — S42's plan red (TaskCanceledException escaping) was not produced.
- S26/S27/S29 (CanRun without cooling, Cooldown = null): `Expected excluded to contain a single item, but the collection is empty`; `KeyNotFoundException` for the `cooldown` property. S28 and S38 stayed green under that stub (their red needs a different stub: not run).
- S30–S33 against stubs: `actual: undefined, expected: { untilUtc ... }`; `actual: '' expected: 'quota spent — back 14.10.2026 09:19 (in 63 h)'`; stated wording `''`; S33 `the page draws no cooldown line`.
- Break-its of S3, S6, S8, S14's exact "found antigravity/gemini" message were not all run.

## Checks
- Build: 0 warnings, 0 errors.
- `dotnet format whitespace --verify-no-changes`: clean; `dotnet format style` on the changed folders: clean. Whole-solution `dotnet format --verify-no-changes` stops on pre-existing IL2026/IL3050 errors in src_server (untouched).
- `npm --prefix src_vs_code run typecheck` and `lint`: clean. `plan-lifecycle`, `pin-check`: clean.
- First whole-suite run (before the two guard-test fixes): 3 failures — the two guards (fixed in b4c8a592) and `RegularFilesTests.A_fifo_a_socket...` (socket path > 108 chars because TMPDIR is under the session scratch; environmental, not mine).

## Final runs (11:38 UTC, after b4c8a592, tree clean)
- Whole MCP suite: 13,876 tests, 13,758 succeeded, 117 skipped (Windows-only), **1 failed**: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — fails alone too, with `ArgumentOutOfRangeException … invalid length for use with domain sockets (108)`: this session's TMPDIR is a long path. Unrelated to the change; not fixed.
- Extension: `npm --prefix src_vs_code test` exit 0 (includes the 4 new tests); typecheck and lint clean.

## What remains
- The code gate (coai review of the whole branch with the plan as scope) has not been run — out of this brief.
- Not run: break-its of S3, S6, S8; the plan's literal red for S19 (unguarded read) and S42 (TaskCanceledException escaping); S28/S38 reds.
- The first real `/quota` answer read by coai's own probe goes into RESULTS_vendor_quota_gauges.md §3.4 (row is there, marked owed).
- Plan not promoted (it still needs the gate); status line says "in progress".
- No push, no PR.
