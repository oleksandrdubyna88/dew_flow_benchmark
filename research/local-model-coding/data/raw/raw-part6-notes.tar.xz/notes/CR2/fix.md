# Fix notes — review of the quota cooldown (Sonnet)

Branch `feat/quota-cooldown`, one fix commit `407442b5` on top of `ebbf6b30`. Nothing pushed. Started 12:15 UTC, done ~12:40 UTC (deadline 13:14).

## Findings

- **R1 (major) — fixed.** Opened the code: the finding is right. `ProcessLauncher` answers a caller's cancellation as `TimedOut: true, Cancelled: true` and never throws.
  - Test first: S42's `Waiting` fake now answers that way (it used to throw), and a new `ARoundAlreadyStopped_LaunchesNoProbeAndParksNothing`. Reds seen: `ACancelledProbe_…` found a parked entry whose note said "timed out after 30 s"; `ARoundAlreadyStopped…` `Expected launcher.Launched to be 0 … but found 1`.
  - Fix: `AgyQuotaProbe.ReadAsync` calls `ct.ThrowIfCancellationRequested()` before launching and throws `OperationCanceledException` for `result.Cancelled`; `AfterRoundAsync`'s existing handler logs "stopped" and parks nothing for that key.
- **R2 (major) — fixed.** `Apply` now writes with `AtomicFile.SharingRetry`. To make it testable I added an `internal AtomicSeams Seams { get; init; }` on `QuotaCooldowns` (default `AtomicSeams.Real`) and a Windows-only test, `APark_ThatMeetsAFileAReaderHolds_IsRetriedAndLands` (the repo's own pattern, `Assert.SkipUnless(IsWindows)`).
  - **Not seen red here:** the held-file refusal is Windows' (.NET's Unix locks are advisory), so the test skips on this host. It is the same shape as `ASessionSaveMeetsABusyFileTests`.
- **R3 (minor) — fixed.** S3's undecided case now uses `"You've hit your usage limit."` (spent by its words, no reset). Break-it run: wiring `BoundedScheduler.Hopeless` as `limited.Spent == true` turns `AnUndecidedVerdict_ReadsTheTextAsBefore` red (`Expected spentWords to be 1 … but found 4`); the mutation was reverted (`git checkout`), the commit does not contain it. The now-unused `Agy133Reason` const in that class was removed.
- **R4 (minor) — fixed.** `AfterRoundAsync` takes the lock via `Task.Run(() => Apply(changes), CancellationToken.None)` (a stopped round still writes what it decided). No separate test: the behaviour is identical, only the thread differs.
- **R5 (minor) — fixed.** Each key is judged in its own `try`; a failure is logged ("could not be judged") and skipped, a cancellation logs "stopped" and ends the loop, and the changes already decided are still written in one locked write. Test first: `OneKeyThatCannotBeJudged_DoesNotCostTheOtherKeysTheirPark` — red `Expected store.Standing("claude", Now) not to be <null> because the other key's park was decided`.
- **R6 (minor) — fixed.** `module_runners.md` lists DeepSeek among the empty-key runtimes and describes the R1/R2/R4/R5 behaviour; `module_tests.md` says "Nine C# classes", adds `ACooldownFileThatCannotBeReadIsNotReplacedTests` and `ADeepseekRowHasNoCodexQuotaTests`, and the new cases; the plan's §12 has item 10 for this round. The `notes/hreview.md` reference in `ACooldownFileThatCannotBeReadIsNotReplacedTests` is replaced by "the lock's purpose in D4 of the plan".
  - The "§12" of the finding is the plan's §12 (deviations); I recorded DeepSeek's key there only inside item 10, not in the earlier items (the coder's item 2 etc. stand).

## Results (after `407442b5`)

- Build: 0 warnings, 0 errors.
- Format: `dotnet format whitespace dew_flow_connect_other_ais.slnx --verify-no-changes` clean; `dotnet format style` on `src_mcp/runners` and `src_mcp/tests` clean.
- Changed test classes (`TheRoundParksAndLiftsTheQuotaTests`, `AStructuredVerdictOutranksTheWordScanTests`, `ASpentQuotaIsRememberedUntilItsResetTests`, `TheAgyQuotaReportPicksTheResetTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`): 46 total, 45 passed, 1 skipped (the Windows-only test).
- Whole MCP suite, once: 13,886 tests, 13,766 passed, 118 skipped, **2 failed**:
  - `HeldFileInheritableOnLinuxTests.L_N1a_ProcLocks_NamesTheKindOfFlockTheInheritableHoldTook` — passes when its class is run alone: a flake under the whole suite's load, unrelated to this change (it asks `/proc/locks`).
  - `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — fails alone too, `ArgumentOutOfRangeException … invalid length for use with domain sockets (108)`: this session's TMPDIR path (`…/tmp/testsToDelete-coai-run-…/…/shown.sock`) is longer than 108 characters. Environmental, as in the coder's notes; not touched.
- Extension (`npm --prefix src_vs_code test`; `src_vs_code` is unchanged in this round): 0 failures in every suite.
