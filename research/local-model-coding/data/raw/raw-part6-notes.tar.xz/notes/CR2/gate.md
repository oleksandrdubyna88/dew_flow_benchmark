# Gate notes — quota cooldown (Sonnet, claude-sonnet-5-5)

Branch `feat/quota-cooldown`, coai session `e1e170a0`. Nothing pushed. Started 12:34 UTC, deadline 15:04 UTC.

## Operator commands (carried by the plan and code replies)
The plan reply carried five `commands` (split into 3-4 epics with Fable and Opus, autonomous mode, consultants first, consult cadence);
the code reply carried two (autonomous mode, consultants first).
**Not applied**: splitting into epics/stories and the consult cadence — the change is already written and reviewed once, and the brief
for this run says the plan is frozen, the gate runs once over the finished branch, and I decide alone (no epic/plan declaration was passed
for the same reason). **Applied** (they are what I do anyway): the autonomous-mode orders — a failing test first for a real defect (none
was accepted), docs updated with each change (the one accepted finding is a doc), the whole suite before stopping. No question was
blocking, so the consultants and the person were not asked.

## Plan round 1 — verdict `proceed`, gating 4 of threshold 6, 2 of 2 reviewers asked and answered (codex, antigravity)
All six findings rejected with: "The plan is frozen for this change: it passed its own plan gate before the code was written, and this branch
implements it as committed; a plan change is out of scope here." None showed a defect in the code (two were checked against it).

1. Major, plan §4/S42 — no RoundEngine-level check that completed results survive a cancelled probe. Rejected (plan text).
2. Major, plan D4 — a missing file vs an unreadable one. Rejected; the code already separates them (`ebbf6b30`).
3. Minor, plan §7/§12 — the DoD says every scenario was seen red first, §12 records exceptions. Rejected (plan text).
4. Major, plan D5/S41 — parks on refusal text although the gauge says Available. Rejected (recorded design decision).
5. Major, plan D12 — consultation and question rows are not tracked. Rejected (D12 names them out of scope).
6. Minor, plan D9/S31 — blank cooldown line for up to 10 s after expiry. Rejected (plan text).

## Code round 1 — verdict `proceed`, gating 11 of threshold 5, 8 of 8 reviewers asked and answered (codex and antigravity, four roles each)
Scope sent: the goal, seven numbered "must be true" statements, the constraints, and D12 as out of scope; no diff.
The stage closed when I resolved ("The code stage is complete. This session is done.").

A note on my own scope text: I wrote that the cooldown file is "never overwritten blindly". The plan (§8, S19) says a TORN or unparseable
file is overwritten whole by the next park, and only a file that cannot be read right now (I/O, permissions) is refused. Findings 3 and 11
were decided against the plan and the code, not against my wording.

| # | Severity | File | Finding | Decision | Reason |
|---|---|---|---|---|---|
| 0 | Blocking | plan §12 | Stories 2-4 coded before their tests | reject | Process history, not a code defect; recorded in §12; reds were seen against stubs; the first review's R1-R6 were test-first |
| 1 | Major | research/architecture.md | The new `cooldown` wire member is not in architecture.md | **accept** | architecture.md documents `--providers` members; section added — fixed in `4a045a85` (docs only) |
| 2 | Major | ReviewerExecutor.cs:234 | `bool? Spent` against "no null in business logic" | reject | Plan D1 mandates the three-valued `Spent`; plan frozen |
| 3 | Major | QuotaCooldowns.cs:259 | A malformed or oversized file is overwritten under the lock | reject | Plan §8 / S19: a torn file is overwritten whole by the next park; a file unreadable right now already refuses (`ebbf6b30`) |
| 4 | Major | QuotaCooldowns.cs:256 | Up to 30 s per spent key after the round | reject | Plan §8 "The probe": one bounded child per spent key; a parallel or shared budget is an enhancement |
| 5 | Minor | QuotaCooldowns.cs:105 | Read guard is 256 KiB, budget 16 KiB | reject | 16 KiB is what is WRITTEN (S20); the read guard only stops a runaway file |
| 6 | Major | QuotaCooldowns.cs:158 | Sync file I/O inside Task.Run | reject | Already covered: the first review's R4 put it there; only sync helpers exist |
| 7 | Major | AntigravityRuntime.cs:178 | The runtime launches the `/quota` probe | reject | Plan D3/D6 seam (`ReadResetAsync`) |
| 8 | Minor | ServerJsonContext.cs:67 | `CooldownReport` not registered | reject | Wrong: covered transitively through `ProviderStatus`; sibling `SurvivorMarkerReport` is the same |
| 9 | Major | PanelService.cs:498 | Auth outranks cooling in `ExcludedFrom` | reject | Deliberate: a row that cannot sign in is excluded for that, the cure a person can act on |
| 10 | Major | QuotaCooldowns.cs:298 | `CancellationToken.None` on Apply | reject | Decided in R4: a stopped round still writes what it decided; wait bounded by the 30 s lock wait |
| 11 | Minor | QuotaCooldowns.cs:159 | JsonException under the lock drops entries | reject | Same as 3 |
| 12 | Minor | QuotaCooldowns.cs:331 | Raw vendor reason is stored | reject | Already redacted by `VendorReason.Written` (`Redaction.SafeText`) and capped at 400 characters |
| 13 | Major | QuotaCooldowns.cs:106 | Uncached file read per decision | reject | Plan D4 chooses read-every-decision (cross-process visibility) |
| 14 | Major | QuotaCooldowns.cs:269 | Sequential probes | reject | Same as 4 |
| 15 | Minor | QuotaWords.cs:28 | "2 h" for 61 minutes | reject | Plan: the time left is rounded up (S31-S33) |

The one accepted finding is documentation, so no failing test applies. I did not run a second code round: the stage was already at
`proceed` and closed, and the instructions stop at `proceed`.

## Final checks (after `4a045a85`)
- Build: 0 warnings, 0 errors.
- `dotnet format whitespace dew_flow_connect_other_ais.slnx --verify-no-changes`: clean (no output).
- Whole MCP suite, once (`./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests`; there is no `.exe` on Linux): 13,886 tests, 13,767 succeeded,
  118 skipped, **1 failed** — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`, the known
  environmental failure (a unix socket path over 108 characters, from this session's TMPDIR); unrelated to the change. The flaky
  `HeldFileInheritableOnLinuxTests` case of the earlier run passed this time.
- Extension tests: not run — `src_vs_code` is unchanged in this run (the only change is `research/architecture.md`).
