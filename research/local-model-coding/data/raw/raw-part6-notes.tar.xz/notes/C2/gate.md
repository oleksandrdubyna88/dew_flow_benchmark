# Gate record — feat/quota-cooldown (coai session 23d58cdb)

Providers configured: codex, antigravity, codex-3, antigravity-2, vibe. Session opened with callerModel `claude-sonnet-5-5`.
Worked autonomously (no person available); every fix test-first.

Operator COMMANDS in the replies: plan round — split into 3-4 epics, Fable/Opus/Sonnet roles, autonomous mode, consultants first, consult cadence; code round — autonomous mode, consultants first.
Applied: autonomous mode (red test first, docs unchanged because the fix needs none, whole suite before stopping), no question needed the consultants. NOT applied: the epic split, role/model split and cadence — this change is already implemented on one branch, the plan is frozen with a recorded "no epics" decision (D12), and my orders were to reject plan findings and not change the plan.

## Plan round 1 — verdict `proceed` (gating 4 of threshold 6); reviewers asked 2, answered 2
All six rejected with the frozen-plan reason; none showed a defect in the code.
1. Major — no live check of the server→extension cooldown contract. Reject (frozen).
2. Minor — the 30 s lock wait can delay delivery of results. Reject (D4 decided the wait, plan gate round 2 F5).
3. Blocking — a cooling row is never launched, so a successful launch can never lift it. Reject (frozen; D12 puts a manual try-now out of scope; the cooldown ends by itself at its instant).
4. Major — doubling restarts after expiry, so the ladder never advances past 30 min. Reject (D5/S39 decided it).
5. Major — tests call AfterRoundAsync directly. Reject (frozen; `ARoundThatEndsSpentParksTheQuotaTests` runs the engine).
6. Minor — en-GB gives slashes. Reject; I read the code: `dateTimeOf` joins `formatToParts` with dots.

## Code round 1 — verdict `proceed` (gating 9 of threshold 5 — the gate passed anyway); reviewers asked 8, answered 8
1. Major, `ReviewerRuntime.cs` — quota keys/sources as untyped strings. Reject: D3 fixes the string interface; a typed redesign is a plan change.
2. Major, `QuotaCooldowns.cs` — a hand-edited far-future entry parks a quota indefinitely. Reject: coai's own file, a hand edit is a deliberate park, the plan asks for no bound.
3. Major, `QuotaRound.cs` — probes run serially (up to 90 s). Reject: D5 asks one call per key, not concurrency; worst case needs three spent groups all timing out.
4. Major, `PanelService.cs` — keys via ephemeral runtime instances. Reject: `RuntimeFor` is the existing pattern (lines 141, 314, 315, 353), D9 prescribes it, runtimes are stateless.
5. Major, `QuotaCooldowns.cs` — uncached reads in `Standing`. Reject: D4 says "no cache"; a cache would hide other processes' parks.
6. Minor, `AgyQuotaReport.cs` — family parsing strips fixed suffixes. Reject: D3, one explicit measured table, unknown family gets its own key.
7. Major, `QuotaCooldowns.cs` — a null element in `entries` throws NullReferenceException out of `ReadFile`. **Accept.** Reproduced: test `ANullEntryInTheFile_IsSkipped_AndItsSiblingsStillStand` failed with a NullReferenceException from `Parsed`; guard `e is not null &&` added; green. Fixed in `ddd12695`.
8. Major, `QuotaRound.cs` — the `when (ct.IsCancellationRequested)` filter lets a non-ct cancellation abort other keys. Reject: `ProcessResult.Cancelled` is set only as `timedOut && ct.IsCancellationRequested` (`ProcessLauncher.cs:570`) and `ReadAsync` calls `ct.ThrowIfCancellationRequested()` before `Judged`, so the filter always matches.
9. Major, `PanelService.cs` — file re-read per provider. Reject: duplicate of 5.
10. Major, `AgyError.cs` — `Split` allocation on stderr. Reject: stderr is bounded, error path once per launch.
11. Minor, `CooldownWords.cs` — `TimeLeft` shows 1 min for a non-positive span. Reject: `Standing` returns only unexpired entries; `Math.Max(1, …)` is the deliberate round-up.

No second code round: round 1's verdict was `proceed`, which the task names as the stop; the only fix is a one-line null guard with its own red-then-green test. Not re-reviewed by the gate — said here rather than implied.
