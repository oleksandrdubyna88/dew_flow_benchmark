# Coder notes — `todo/PLAN_a_spent_quota_cools_the_model_down.md` (branch `feat/quota-cooldown`)

Written as I went (finalised at the end). Times are UTC; the deadline was 13:48.

## Commits
1. `feat(reviewers): a structured verdict says whether the allowance is spent (S1-S8)` — story 1.
2. `feat(reviewers): a spent quota is read, remembered and released (…)` — story 2.
3. story 3 (server) and 4 (extension) — see `git log`.

## Decisions and deviations from the plan (also listed in the plan's own deviation list)
- **D-1 S9–S12 keys.** The plan writes `ResetFor("gemini", NOW)` / `("3p", NOW)`; S14/S34/S43 write `antigravity/…`. I use the FULL key
  (`antigravity/gemini`, `antigravity/argon`, `antigravity/3p`) everywhere (`AgyQuotaGroups.Gemini/Argon/ThirdParty`); the short forms are not accepted.
- **D-2 `ReadResetAsync` has one more parameter.** `(invocation, reason, bool? spent, consecutive, launcher, nowUtc, ct)`. The undecided agy case
  (`Spent == null`: park only if the gauge shows a bucket at 0) cannot be decided without the verdict's own word, and the plan's signature has no place
  for it. It returns `QuotaReset`, which also has a "does not park" state (`Source == "none"`, `QuotaReset.NotParked(note)`).
- **D-3 `AfterRoundAsync` takes the launcher.** `(results, launcher, ct)` and returns `results` unchanged (S42 asserts the same list). The plan's
  `AfterRoundAsync(results, ct)` has no way to reach a launcher; `RoundEngine` gets `QuotaCooldowns` and the `IProcessLauncher` as two constructor parameters.
- **D-4 The probe's result type.** `AgyQuotaProbe.ReadAsync` returns `AgyQuotaRead` (`Report` | `CannotCheck(Why)`); `ResetFor` returns `AgyQuotaGauge`
  (`Available` | `Spent` | `SpentWithoutReset` | `GroupMissing`). S15's "CannotCheck" is the former. Messages as in the plan.
- **D-5 Notice seam.** `QuotaCooldowns` lives in the Runners project and cannot see `NoticeWriter` (src). It takes an `OnRefused` callback; `PanelService`
  wires it to `Noticing.Offer(CooldownNotices.Refused(…))` (own file because `TheRefusalsAreWrittenDownTests` keeps a census of notice producers; I added the
  file to it). The code is the existing `storage-note` (no new code, so no extension-side list changed). The notice is raised inside `Park`/`Lift` when a
  write is refused (S37(a) wants it from `Park`), not only from `AfterRoundAsync`.
- **D-6 S25 date.** The plan's codex sample says *will refresh on July 15, 2026* with `NOW = 2026-10-11`: a date BEFORE its own `NOW`, so nothing could
  stand. I used *October 15, 2026* → `2026-10-16T00:00:00Z`. `QuotaRound` also refuses to park a reset that is not after now (logged).
- **D-7 S34 round half.** The plan says both rows "ended spent" and only Argon stands; but D5/S41 park an explicitly spent refusal even over an Available
  gauge, so a `Spent == true` Gemini row would stand too. The Gemini row in my S34 is the UNDECIDED kind (`Spent == null`), which the Available gauge declines.
- **D-8 Test seams.** `QuotaCooldowns` has internal hooks `AfterLockedRead(op)` and `AfterWrite(op)` (ops: `park <key>`, `lift <key>`, `round`) for
  S35/S36; S36's "no write outside the lock" is asserted inside `AfterWrite` with `HeldFile.IsHeld(lock)`.
- **D-9 Codex key.** `CodexRuntime.QuotaKeyOf` is virtual and answers `codex` only for the stock id `codex`; `DeepseekRuntime` (id `deepseek`) answers empty by
  that, `CustomCodexRuntime` overrides to empty.
- **D-10 `PanelService.cs` in the clock guard.** It gained a `TimeProvider` constructor parameter, so `EveryBudgetInAClockedClassReadsItsClockTests` lists it
  under *not scanned* with a reason (forward + instant comparisons only). `QuotaCooldowns.cs` is under *scanned*, as the plan says.
- **D-11 `UtcDateTime` strings.** The wire's `untilUtc` is `yyyy-MM-ddTHH:mm:ssZ`; the file stores `DateTimeOffset` (zero offset, `+00:00`).
- **D-12 `reasonFor` order.** A cooling row whose auth is "unavailable" still gets the auth reason; the cooling sentence is used when the only obstacle is the cooldown.
- **D-13 S33 zone.** The card formats in the viewer's zone (no parameter reaches the card), so the test sets `process.env.TZ = 'Europe/Paris'` for the test's
  length (restored in `finally`) — Node honours it at runtime — and reads the card off the drawn tree (`pageTree`) after running the page script with `runPageHtml`.
  `.cooldown-line` is static html from `modelsTabHtml`; "running page" here = the page's script is run over the drawn cards and wrote nothing.

## Red messages that differ from the plan's
(see the per-scenario table in the final report; summary)
- S3 case 1, S8 (second half) and S28, S38 passed before the production change — they are guards (S3/S8/S28) or the member was added with the stub (S38). Their
  plan "red" is for a break-it variant that I did not perform (time).
- S6: red was `Expected transient.Limited to be True, but found False` (no override yet at all), not the break-it message.
- S14/S9–S13/S15 (report): red from a stub of `ResetFor`/`KeyOf`/probe — `… but found Available` as the plan says; the S14 red is the stub's, not a prefix rule's.
- S16–S42 first red was against a STUB `QuotaCooldowns` (every method a no-op), so several reds are the stub's, not the plan's natural ones: S18
  `FileNotFoundException`, S19 `Expected _log.Warnings to contain a single item` (no `JsonException` escaping), S20 `FileNotFoundException`, S35/S36 `pause.Reached … False`, S37(a) `Expected … Refused, but found Written`, S42
  `TimeoutException` (the stub never launched), S25 `Expected codex not to be <null>`.
- S26 as the plan; S27 `Expected excluded to contain a single item, but the collection is empty` (not the break-it); S29 `KeyNotFoundException` for the missing `cooldown` property.
- S30–S33 as the plan except S32 whose stub returned `''` (not the `quota` wording).

## Break-it runs (performed, then `git checkout`)
S3 (wire `Hopeless` as `Spent == true`): the plan's S3 case 1 stayed GREEN at first — the agy sample states "Resets in 88h49m9s", so `RetryLadder.ResetOutlasts`
ends the ladder anyway. I changed case 1 to a words-only reason ("You have exhausted your daily quota on this model"); under the mutation it is red with
`Expected spentWords.Launched to be 1 … but found 4`. S6 (`RESOURCE_EXHAUSTED` alone is spent): red. S8 (Claude keyed on `is_error` alone): `Expected type to be
…NonZeroExit because an HTTP 400 is not a spend limit, but found …RateLimited`. S27 (every agy row on `antigravity/gemini`): `Expected excluded to contain a
single item, but found {…two rows…}` (a key of `antigravity` alone, the plan's variant, makes S26 red instead because the file's key no longer matches).

## Results
- MCP suite, first full run (before two small fixes): 13,876 tests, 13,756 passed, 117 skipped, 3 failed: two were mine and fixed (the clock-class guard needed
  `PanelService.cs` listed; the notice-producer census needed `CooldownNotices.cs`), the third is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused…`:
  an AF_UNIX path of 115 characters (> 108) because this session's `TMPDIR` is `/home/jinx/git/coai-exp2/r/d98b47854380/tmp` — environmental, fails alone, unrelated to this change.
- Final full MCP run (after all commits): 13,879 tests, 13,761 passed, 117 skipped, 1 failed — only the environmental `RegularFilesTests` socket-path test above.
- Extension: `npm --prefix src_vs_code test` exit 0, 6,641 passed, 0 failed, 2 skipped; `typecheck` and `lint` clean.
- Format: `dotnet format whitespace --verify-no-changes` clean (I fixed two of my files); `dotnet format style` clean over my new product files. The plan's full
  `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes` cannot run here: it stops on IL2026/IL3050 trimming-analyzer errors in `src_server` (files I did not touch).
- `plan-lifecycle.mjs`: clean.

## What remains / not done
- **The code gate** over the branch (with the plan as scope) has not run — it spends vendor money; not mine to run.
- **Not performed:** the first real `/quota` answer coai's own probe reads (RESULTS §3.4 second row); any live `agy`/`claude`/`codex`/`kimi` call (forbidden).
- **Not proved (said in module_tests.md):** the 3p and Argon groups at 0 and their error answers; `/quota` on an agy other than 1.4.9.
- **Not done on purpose (D12):** fallback model / automatic switching, the consultation / consultant-check / question-row roads, api rows, Vibe, the Team server, a
  "try now" button, the help-page sentence in five languages, a ticking countdown.
- Small things a reviewer may want: `CooldownNotices` reuses code `storage-note` (no new notice code); `QuotaCooldowns.Apply` blocks the calling thread up to the lock wait
  (30 s) on contention — it runs after the round, once; the standing entry's `Note` carries the vendor's redacted sentence and travels to the card's badge title
  (the server's own `ReasonFor` sentence never quotes it).
