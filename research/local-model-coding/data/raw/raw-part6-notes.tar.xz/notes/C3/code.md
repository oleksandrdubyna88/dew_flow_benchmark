# Coder notes — quota cooldown (13:59 – ~15:00 UTC)

Branch `feat/quota-cooldown`, nothing pushed. Commits: a9a1d7a0 (story 1), the report/probe commit, the store+round commit, e32d36e1 (story 3), 34b15471 (story 4), 484a2ff3 (docs, registers, CSS pin).

## State
- All 43 scenarios exist with the plan's class and name (S34 whole in `TheAgyQuotaReportPicksTheResetTests`; S40 is a `[Theory]` over `EdgeCases`; S18's lift test is `AnAnsweredLaunch_LiftsTheCooldown`).
- Whole MCP suite (before my last small edits): 13,876 tests, 13,756 passed, 117 skipped, 3 failed — two were mine (two registers: `TheRefusalsAreWrittenDownTests`, `EveryBudgetInAClockedClassReadsItsClockTests`), fixed, re-run green; the third is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_…` — an `ArgumentOutOfRangeException`: the unix-socket path (this harness's deep TMPDIR `…/tmp/testsToDelete-coai-run-…/…/shown.sock`) is over 108 characters. Environment, not the change; it fails alone too. A final whole-suite run was started after the last commit (see the end of this file).
- Extension: `npm --prefix src_vs_code test` 6,540 tests, 0 failed (4 further small suites pass); `typecheck` and `lint` clean.
- Format: `dotnet format <slnx> --verify-no-changes` cannot run on this host — it stops on AOT analyzer errors (IL2026/IL3050) in `src_server` (not touched). `dotnet format whitespace` and `style` with `--include` over every file I changed: no changes.
- `plan-lifecycle.mjs`: clean (the status line deliberately says "in progress — coded", because a word like "implemented" makes the tool call the plan misfiled in `todo/`).

## Reds seen (and where they differ from the plan)
- S1, S2: red as planned (message `Expected launched to be 1 … found 4`; variable is `launched`, not `launcher.Launched`).
- S3: green from the start (the plan's red needs the "tempting" `Spent == true` wiring; not tried). S8: green from the start (break-it not run).
- S4, S5: red as planned. S6: red DIFFERS — `Expected transient.Limited to be True, but found False` (without the override the sentence-less line is not limited at all by the text, because the replaced sentence also removes the word "quota"); the plan's break-it (`Spent` found True) not run.
- S7: red as planned (`NonZeroExit`). The old pin in `AClaudeReasonInItsEnvelopeTests` was reversed in the same commit.
- S9–S13, S40: red with `ResetFor` stubbed to Available (`found Available`). S14: red with a prefix-rule stub (`antigravity/argon` vs `gemini`). S15, S43: written after the implementation — no red seen.
- S16–S18, S20–S25, S34, S35, S36, S39, S41: red with `Mutate` stubbed to write nothing (`Expected standing not to be <null>` …; several of them show NullReference/FileNotFound instead because the stub writes no file). S19, S37, S42: no red run.
- S26, S27, S29: red with `Standing(provider)` stubbed to null (`Expected excluded to contain a single item, but the collection is empty`; S29 a KeyNotFound for the missing `cooldown`). S28 and S38 stayed green under that stub (S28's red needs a naive "expired still excluded" implementation; S38 is independent of the stub).
- S30–S33: red (compile-level for the first attempt, then assertion level): `undefined !== { untilUtc … }`, `'' !== 'quota spent — back 14.10.2026 09:19 (in 63 h)'`, `'' !== …estimated from the error text`, and the card's `cooldown-line` absent.
- None of the "break-it" variants was run (time): S6, S8, S27, S1–S3 tempting shapes.

## Deviations (also §12 of the plan)
1. `ReadResetAsync` has an extra `bool? spent` parameter after `reason`.
2. `QuotaReset.Parks` / `QuotaReset.NotParked` carry the "do not park" answers.
3. A stated instant not after now is read as unnamed (→ guess); S25's codex sub-case therefore runs on a clock of 2026-07-10 (the plan's NOW is after *July 15, 2026*).
4. S34's AfterRound half: the Gemini row is undecided (`Spent = null`), otherwise S41's rule would park it.
5. Report parsed with `JsonDocument` by hand, not a source-generated context; probe in `AgyQuotaProbe.cs`.
6. `QuotaCooldowns` is a partial class in two files; launcher via the constructor; the server notice via `Action<string> onRefused` (runners cannot see `NoticeWriter`); `PanelService` wires a `storage-note`/`failure` notice (`CooldownNotices` in `CooldownSentences.cs`). The refusal notice is emitted by every refused locked write, not only `AfterRoundAsync`.
7. A change that alters nothing writes nothing (lift of a key that does not stand).
8. `DeepseekRuntime` and `CustomCodexRuntime` override `QuotaKeyOf` to empty.
9. Cooldown file instants are `…Z` (`UtcInstantConverter`).
10. Files the plan does not name were touched: `catalogCss.ts` / `catalogSheet.ts` (styles; the byte pin in `teamServerTab.test.ts` was re-pinned), `TheRefusalsAreWrittenDownTests` and `EveryBudgetInAClockedClassReadsItsClockTests` (registers), `CustomRuntime.cs`, `ReviewerRuntime.cs` (DeepSeek override).
11. `PanelService` takes `TimeProvider? clock` as the LAST constructor parameter (after `hostStopping`).

## What remains
- The plan's code gate (not run: no reviewers here), promotion of the plan, and the "first `/quota` answer coai's own probe reads" record (RESULTS §3.4 holds the hand capture only).
- Break-it variants listed above; cyclomatic-complexity ≤ 4 was trimmed by hand on the obvious methods only (no tool measured it) — `AgyQuotaReport.ResetFor`/`Reading`, `AntigravityRuntime.ReadResetAsync` (a 5-arm switch) and `QuotaCooldowns.Read` may still be at 5.
- `src_server` format/AOT-analyzer errors under `dotnet format` are pre-existing and not touched.

## Final whole-suite run (after the last commit, 15:06 UTC)
13,876 tests: 13,758 passed, 117 skipped, 1 failed — `RegularFilesTests.A_fifo_a_socket_and_a_device_…` (socket path over 108 chars in this harness temp root; environmental, see above). Working tree clean after commit 484a2ff3 except these notes (outside the repo).
