# t3 — agy classified from its AGY_ERROR line, keyed by its group, reads its own reset

## Done

- `src_mcp/runners/Reviewers/AgyError.cs` (new): the record, `IsExhausted`, `IsIndividualQuota`, `Parse`. Both observed
  shapes read by name (`status`/`code`, `short_error`/`message`). Torn, non-object and nameless lines are dropped; `Parse` never throws.
- `src_mcp/runners/Reviewers/AgyResets.cs` (new): `internal static Decide`, the ten-cell table from the document.
- `src_mcp/runners/Reviewers/AntigravityRuntime.cs`: `RateLimited` (exit != 0 and a `RESOURCE_EXHAUSTED` line gives a
  `Because` verdict; the individual-quota sentence makes it spent, anything else is undecided; otherwise `ByText`),
  `QuotaKeyOf`, `ReadResetAsync` (probe, then `Decide`). `Build`, `AntigravityStream`, `AntigravityReadOnly` untouched.
- `src_mcp/tests/AnAgyQuotaIsReadFromItsStructuredErrorTests.cs` (new): S4, S5, S6, the key test, the parse test, and
  `Decide_FollowsTheTable` as a 10-row theory. 15 tests.

## Red then green

- Stub phase (Parse → `[]`, `QuotaKeyOf` → `""`, `Decide` → `NoPark("stub")`, `ReadResetAsync` → `NoPark("stub")`,
  `RateLimited` = `ByText`). Build succeeded, so every failure was an assertion:
  - S4: `Expected verdict.Spent to be True, but found <null>.` (matches the document).
  - S5: same message, on `TheOlderErrorShape_IsReadToo`.
  - S6: failed at (a) `Expected refusedTransient.Limited to be True, but found False.` The stub is the word scan, and
    "Too many requests" is not a phrase `RateLimit.Hit` knows. The document said "pass-or-fail as the stub dictates".
  - Key test: `Expected Runtime.QuotaKeyOf("gemini-3.8-flash-high") to be "antigravity/gemini" ..., but "" ...`.
  - Parse test: `Expected AgyError.Parse(AGY_1_3_3) to contain a single item, but the collection is empty.`
  - Decide theory: all ten rows failed on `Source` or on `Note` (stub `"stub"`).
- Parse and `RateLimited` implemented: S4, S5, S6, parse test green. Decide theory and key test still red.
- `QuotaKeyOf`, `ReadResetAsync`, `Decide` implemented: 15/15 green.
- S6 break-it (override keyed on `RESOURCE_EXHAUSTED` alone, `Because(..., true)`): `WithoutTheQuotaSentence_NothingIsSpent`
  went red, the other 14 stayed green. Restored; green again.

## Deviations (all small; the document is otherwise followed)

- `AgyError` helper names are `StatusOf` / `MessageOf` (not `Status` / `Message`). The record's positional properties
  already carry those names, so the helpers could not share them (CS0102).
- `AgyResets.Iso` formats the instant with `CultureInfo.InvariantCulture`. The document's interpolation
  `{until:yyyy-MM-dd'T'HH:mm:ss'Z'}` would follow the current culture, which can change the digits in some calendars.
- `AgyResets.Decide` uses a `switch` expression with helpers (`SpentNote`, `Because`, `Unchecked`, `Iso`), not
  nested ifs, to hold complexity down.
- The stub phase had `RateLimited` written in full for a moment before I restored it to `ByText` for the red run.
  Red was confirmed against the stub, not against the full body.

## Test results

- Build (`dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers`): Build succeeded, 0 errors.
- `AnAgyQuotaIsReadFromItsStructuredErrorTests`: 15 total, 15 passed.
- Neighbours, all green: `AStatedResetIsNeverWaitedOutTests` 9/9, `EveryPaidLaunchIsWrittenTests` 12/12,
  `ConsultFailureTests` 41/41, `ConsultAntigravityDenialScenarioTests` 11/11, `GateReportingTests` 27/27.
- Whole MCP suite: see the final line in this file (appended after the run).
- `dotnet format ... --verify-no-changes`: exit 2. Every reported error is an IL trimming / AOT analyzer
  error in `src_server` (`SessionEndpoints.cs`, `ReviewEndpoints.cs`, `UsageEndpoints.cs`, `CatalogEndpoints.cs`, and
  others). None mention `src_mcp`. I did not touch `src_server` (out of bounds), so I did not fix it. Not verified against the
  base commit in this session.

## Left

- Nothing in scope. `ReadResetAsync` has no direct test (the document lists none, and the decision table covers
  `Decide`). The probe itself is t2's and is not exercised through the runtime here.

## Whole suite: NOT completed

- Run 1 (`CoaiMcp.Tests`, no filter, background): reached 13,290 of 13,807 completed with 1 failure, then stalled on
  `EndToEndTests.CodeRound_WithEveryReviewerFailing_CallsAHuman_NeverProceeds` for a while and resumed. The background run
  was killed at its 30-minute limit before it wrote totals. So there is no whole-suite total from this session.
- The one failure: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`:
  `ArgumentOutOfRangeException: ... shown.sock is of an invalid length for use with domain sockets ... 1 and 108 characters`.
  It fails the same way when run alone (32 total, 30 passed, 1 failed, 1 skipped). The temp path under this worktree is
  too long for a Unix socket. My four files do not touch this test. I did not check it against the base commit.
- `dotnet format --verify-no-changes`: exit 2, all errors in `src_server` IL analyzers, none in `src_mcp`.

## Commit

- `99f4008f feat(quota): agy's spent verdict is read from its AGY_ERROR line, keyed by its group (t3)`, the four files by name.
  Not pushed.
