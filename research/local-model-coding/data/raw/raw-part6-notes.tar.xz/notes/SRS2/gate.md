# Gate record — feat/quota-cooldown (coai session 5e498be5)

Caller model: claude-sonnet-5-5. Providers enabled: codex, antigravity, codex-3, antigravity-2, vibe.

## Decisions about the run itself

- **Plan path.** The brief names `todo/PLAN_a_spent_quota_cools_the_model_down.md`; the last commit (f5c912b4) promoted it to
  `research/PLAN_a_spent_quota_cools_the_model_down.md` (plan-lifecycle rule), so `committedPlan` is the `research/` path. The file was not changed.
- **Operator commands in the replies** (plan round: split into 3-4 epics with a Fable split, work autonomously, consult first, cadence with
  `plan`/`epic`; code round: autonomous, consult first). NOT applied as a restructuring: the brief fixes this change as one branch implementing a
  frozen plan, and the plan's own §11/§12 record that the same commands were declined for this experiment by the owner. Applied: working
  autonomously (red-then-green for the accepted defect, docs and tests updated with the fix, the whole suite before stopping, re-read the
  repository rules); no question blocked, so none was asked and the consultants were not needed.
- **Test executable.** On Linux it is `src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests` (no `.exe`), filtered with `--filter-class`.

## Plan round 1 — verdict `proceed`, gating 5 of threshold 6, reviewers asked 2, answered 2 ("all 2 reviewers answered")

All six findings rejected with the frozen-plan reason (the gate's maxRounds is 2; no second plan round was asked for).

| # | sev | summary | decision | note |
|---|---|---|---|---|
| 0 | Major | cancelled agy probe suppresses an explicit spent park | reject | D5/S42 chose it; code matches |
| 1 | Major | fail-open read can erase valid cooldowns on a later write | reject (plan) | carried to the code round (see below) |
| 2 | Major | `--providers` one-shot path not verified end to end | reject | plan scope |
| 3 | Major | lock contention / probes inside the lock | reject | already covered: probes run before the lock |
| 4 | Major | bare agy ids without a tier suffix | reject | wrong: `WithoutEffort` leaves them unchanged, table has bare families |
| 5 | Minor | badge/line disagree for ≤10 s after expiry | reject | D9 "no ticking" deliberate |

## Code round 1 — verdict `proceed`, gating 13 of threshold 5, reviewers asked 8, answered 8 ("all 8 reviewers answered")

Session reports "Done" after the resolve (a code round resolved at proceed closes it). 18 findings, 1 accepted, 17 rejected.

| # | sev | file | summary | decision | reason |
|---|---|---|---|---|---|
| 0 | Major | QuotaReset.cs | `Source` is an untyped string | reject | D4 fixes the three wire strings; an enum would touch file format, wire and tests for no behaviour |
| 1 | Minor | AgyQuotaReport.cs | agy family/bucket/name tables can disagree | reject | S14/S43 cross-check them against fixtures; no defect today |
| 2 | Major | AgyQuotaReport.cs | a spent bucket without usable reset is masked by another's reset | reject | D6/S40 decide exactly this ("Spent on the known one, note names the unknown") |
| 3 | Major | AgyQuotaReport.cs | probe stderr persisted / sent to the card | reject | S15 requires the stderr line; notes pass `Redaction.SafeText` and the 400-char cap |
| 4 | Major | QuotaCooldownsRound.cs | probes sequential, up to 90 s | reject | one probe per key bounded 30 s is D5; concurrency not asked |
| 5 | Major | AgyQuotaReport.cs | `Fraction` complexity > 4 | reject | wrong: it is 4; CA1502 is on for the security lane's files only |
| 6 | Major | AgyQuotaReport.cs | `TryGroups` complexity > 4 | reject | wrong: 1 + three `&&` = 4 |
| 7 | Minor | AgyQuotaReport.cs | `Number` complexity > 4 | reject | wrong: 4 |
| 8 | Major | QuotaCooldownsRound.cs | probe bypasses the invocation's launcher | reject | wrong: the refused invocation's own request is used; the launcher is injected per D5 |
| 9 | Major | QuotaCooldowns.cs | `Apply` blocks on a sync lock wait | reject | HeldFile.TakeWithin is D4; already moved off-thread in the prior review |
| 10 | Minor | QuotaCooldownsRound.cs | `AskingOf` probes for non-hopeless Spent==null | reject | wrong: the default `ReadResetAsync` answers NoPark without any launch |
| 11 | Blocking | AgyError.cs | wrong JSON offset with a leading-whitespace token | reject | wrong by arithmetic; pinned by a new test, green at once (b45d1ea2) |
| 12 | Blocking | QuotaCooldownsRound.cs | `Task.Run(Apply)` exception escapes the round | **accept** | real: red test `ADataFolderTheOsCannotUse_…` showed `ArgumentException` escaping (from the read path via `Standing` first); fixed in **b45d1ea2** |
| 13 | Major | AgyQuotaReport.cs | reset == now is "unusable" | reject | D6: "not after nowUtc" is no reset; consistent with `Standing` |
| 14 | Minor | QuotaCooldowns.cs | `WarnOnce` only once ever | reject | D4/S19: once per process |
| 15 | Major | AgyError.cs | allocations when parsing | reject | once per refused launch on a bounded, redacted stderr; speculative |
| 16 | Major | QuotaCooldownsRound.cs | sequential probes (dup of 4) | reject | as 4 |
| 17 | Minor | AgyQuotaReport.cs | multi-bucket note names only one window | reject | note shape fixed by S40 |

### The accepted fix (b45d1ea2)
Red: `ADataFolderTheOsCannotUse_IsARefusedWrite_NeverAnExceptionOutOfTheRound` (NUL in the data path) →
`System.ArgumentException : Null character in path` out of `AfterRoundAsync` via `QuotaCooldowns.TextOrNull` ← `Standing` (the read path too,
so D4's "every read is fail-open" was also broken, and `CanRun` reads the same way). Fix: one `IsFileFault` predicate (I/O, access, `ArgumentException`,
`NotSupportedException`) used by the read, the data-dir creation and the persist; `AfterRoundAsync` guards the off-thread write and turns any throw into
the usual refusal + notice. Green: 48 of 48 in the five quota classes. The "red again without the fix" step was observed as the first red above
(same test, same code before the edit). Docs: `research/module_runners.md`, `research/module_tests.md`. Also added
`AnIndentedTokenAndACarriageReturn_AreReadLikeAnyOther` (a pin, green on arrival — it documents why finding 11 was rejected).

## Final results (after b45d1ea2)
- Build of the whole solution (Debug, -m:4): 0 warnings, 0 errors.
- Changed classes (five quota classes): 48 of 48 passed.
- Whole MCP suite: total 13,916; 13,798 passed; 117 skipped; **1 failed** — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`
  (the same failure as before this gate: the sandbox temp path is over the 108-character Unix-socket limit; untouched by this branch; not run under a short TMPDIR).
- Format: `dotnet format --verify-no-changes` on `src_mcp/tests` and `src_mcp/runners`: clean. `plan-lifecycle.mjs`: clean.
- Extension: `src_vs_code` was not changed by this gate (only `src_mcp` and `research/`), so its tests were not re-run; the previous run (fix.md) was `fail 0`.

No second code round was run: round 1's verdict was `proceed` (the stop condition) and the session closed on its resolve.
Plan finding 1 (a transient read error being treated as an empty file by a later write) was NOT raised again by the code reviewers and was not changed:
D4/§8 say a file that cannot be parsed is overwritten whole by the next park; a transient I/O error on read is the same road. Left as the plan wrote it.
