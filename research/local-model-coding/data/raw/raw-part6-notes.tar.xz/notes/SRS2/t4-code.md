# t4 — the durable record (quota-cooldowns.json under a cross-process lock)

## Done
- `src_mcp/runners/Reviewers/QuotaCooldowns.cs` — new. Records `QuotaCooldownEntry`, `QuotaChange` (Park/Lift), `CooldownWrite` (Written/Refused).
  `QuotaCooldowns` (partial, public sealed): consts, ctor, `InsideLock` hook, `FilePath`/`LockPath`, `Standing` (lock-free, fail-open),
  `Park`/`Lift` (each = `Apply` of one change), `Apply` (one locked write: `Directory.CreateDirectory` → `HeldFile.TakeWithin` → locked re-read →
  changes → write only if something changed → `AfterLockedWrite`), `Iso`, `QuotaNameOf`. Internal wire DTOs `QuotaCooldownFile` / `QuotaCooldownWire`
  and the source-generated `QuotaCooldownsJson` context (pattern of `KimiSurvivorMarker`).
- `src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs` — new. S16–S21, S35–S37, S39, and the names test.
- `src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs` — guard: `QuotaCooldownsFile` const added and in `Clocked`.

## Choices the document left open
- `launcher` is kept as `internal IProcessLauncher Launcher { get; }`, not a private field, so an unread field cannot trip `TreatWarningsAsErrors` before t5 reads it. t5's `AfterRoundAsync` should use `Launcher`.
- An unreadable file warns once per instance: `"{File} could not be read ({Why}); no spent quota is taken from it"`.
- Refusal sentence: `quota-cooldowns.json could not be updated: <why>; a spent quota was not remembered`, as the document says.
- A Park over a standing entry keeps that entry's `SinceUtc`. An entry whose times do not parse is skipped, with the one warning.

## Red (stub: Standing → null, Park/Lift/Apply → Written)
All reds were assertion failures:
- S16: `Expected entry not to be <null> because antigravity/gemini should stand …`. The document words it "standing"; same meaning.
- S17, S18, S20, S21 (TheGuess), and the first assertions of S35/S36: the same not-null failure. S35/S36 first hit `aPaused.Wait` ("A should reach its locked read") because the stub never calls `InsideLock`.
- S19: `Expected _said to contain a single item, but the collection is empty.`
- S37: `Expected type to be …CooldownWrite+Refused, but found …CooldownWrite+Written.`
- S39: `Expected GuessedPark(continuous, steady, Key) … <17:40> … but <17:10>`, the second guess with no gap.
- Names: `Expected QuotaCooldowns.QuotaNameOf("codex", "gpt-5") to be the same string …`
- Guard: green before and after. `QuotaCooldowns.cs` had no clock-budget shapes.

## Results
- Build (`dew_flow_connect_other_ais.slnx`, Debug, `-m:4 --disable-build-servers`): succeeded, 0 warnings. CA1502 (complexity 4, error-level here) passes.
- `ASpentQuotaIsRememberedUntilItsResetTests`: all 11 green.
- `EveryBudgetInAClockedClassReadsItsClockTests`: green. `NoTestHoldsAnInheritableHandleTests`: green.
- Whole suite finished: total 13867, succeeded 13749, skipped 117, failed 1. The one failure is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`. It fails alone too, at `Socket.Bind` in the test's own setup: the Unix socket path is over 108 characters because the worktree path is long (`ArgumentOutOfRangeException`). Environmental, not caused by t4. Log: `tmp/claude-1000/.../tasks/btyq7dc3g.output`.
- `dotnet format --verify-no-changes` on the solution exits 2 only from IL2026/IL3050 analyzer errors in `src_server` (not touched). `dotnet format whitespace` on my three files is clean.
- Committed as `d6002478`.

## Left
- Nothing in scope. Not touched: `QuotaCooldownsRound.cs` (t5), the Kimi and panel files, the extension, `src_mcp/src/*`.
