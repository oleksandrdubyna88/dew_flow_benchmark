# Review of todo/PLAN_a_spent_quota_cools_the_model_down.md on feat/quota-cooldown (reviewer H)

Written before any code change (Step 1). Scope: commits after 6786582e (t1–t7). Plan and decisions D1–D12, scenarios S1–S43,
Definition of Done (§7). Opened: plan §3–§7, split.md, every new production file (QuotaCooldowns*.cs, QuotaReset.cs,
AgyQuotaReport.cs, AgyError.cs, AgyResets.cs), the runner and server diffs, the extension diffs, and all test classes named by
§4 (every S-name exists; S1–S43 all have a test; S30–S33 are in src_vs_code/src/test/aCoolingRowSaysWhenItIsBack.test.ts).

## Scenario check (all 43)

- Each scenario has a test with the plan's name (or the judge's split name for S34: report half `ArgonSpent_WithOrdinaryGeminiAvailable_ParksOnlyArgon`, AfterRound half `ArgonSpent_ThroughAfterRound_ParksOnlyArgon`).
- Assertions read against the plan's *Then* for S1–S43. Each test is able to fail on the change: no scenario is vacuous on the paths
  it names. S28 (reset has passed → no write) passes with NO implementation, so it is a regression guard, not a red-first test;
  the plan's red text describes a broken implementation, not the stub. Noted, not a defect.

## Findings

| id | severity | file:line | one sentence | fix |
|---|---|---|---|---|
| H1 | major | src_mcp/runners/Reviewers/AgyResets.cs:12 (test rows AnAgyQuotaIsReadFromItsStructuredErrorTests.cs:117-118) | An UNDECIDED agy refusal (`Spent == null`) whose gauge is `SpentWithoutReset` is parked on the stated/guess road, but D5 says the undecided case is never parked ("cannot check → not parked; the undetermined is never a parked row"). | Guard the `SpentWithoutReset` arm with `spent == true`; undecided falls to `NoPark` with a "could not check" note. Change the two DecisionTable rows first (red), then the code. |
| H2 | major | src_mcp/runners/Reviewers/ReviewerRuntime.cs (default `ReadResetAsync`, ~:541-546) and src_mcp/runners/Kimi/KimiRuntime.cs | Kimi's refusal clause is parsed by `FromText` → `CooldownParser.StatedReset`, but Kimi D3 and plan D5 say Kimi's clause is never parsed and always lands on `guess`; a Kimi reason that names a reset would park as `stated`. | Override `ReadResetAsync` in `KimiRuntime` → `QuotaReset.Guess` (spent or hopeless), NoPark otherwise. Red first: a Kimi row whose reason is `MonthlyLine + " Resets in 3h."` must park `guess`. |
| H3 | minor | src_mcp/runners/Reviewers/ReviewerRuntime.cs (~:633-637) | The new `QuotaKeyOf` was inserted between `TierDependsOnRelease`'s XML doc and its method, so the doc now sits on the wrong member and `TierDependsOnRelease` has none. | Move the two `QuotaKeyOf` lines above that doc block. Doc only. |
| H4 | minor | src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs:151 | The comment "Its probe is still one probe" is wrong: the test expects 2 launches (one per key, as D5 says). | Reword the comment. Test-only. |
| H5 | minor | src_mcp/runners/Reviewers/QuotaCooldownsRound.cs:10-11, src_mcp/runners/Reviewers/QuotaCooldowns.cs:118-125 (`Standing`, `Apply`) | `AfterRoundAsync`'s doc says it "never throws" but it only catches `OperationCanceledException`; a non-IO exception (e.g. ArgumentException from a NUL in the data dir) escapes `Apply`/`Standing` and fails the round. | Not fixed. D4's fail-open list names IO, Unauthorized and Json only; the only path that raises the other exception is a NUL in the data dir, which settings do not produce. Adding a catch-all would hide real bugs. |
| H6 | minor | src_mcp/runners/Reviewers/QuotaCooldownsRound.cs:17-18 (ResetOfAsync is fine) | Undecided-but-probed key with `SpentWithoutReset` is also the judge's split.md decision ("parked on stated/guess"), recorded there but NOT in plan §12. | Covered by H1. Resolved by H1's fix; §12 is not edited (the plan is the spec). |

## Checked and found correct (no finding)

- D1 `Spent` three-valued; `BoundedScheduler.Hopeless` reads `Spent ?? Hopeless(text)` first (BoundedScheduler.cs:680-682).
- D2 `AgyError.Parse` reads both shapes by name, a torn line is no error; exit code, `retryable`, stream `status` not read.
- D3 table: prefix stripped only when present; Argon by id; empty model → default; unknown family → `antigravity/?<model>` with no gauge launch.
  Codex/Claude/Kimi keys; Local/Api/Remote/Vibe keep "" (default). CustomCodexRuntime (subclass of Codex) overrides ProviderOverrides, so it keeps "".
- D4 file, lock (`HeldFile.TakeWithin`, 30 s), probe outside the lock, one `Apply` per round, `Refused` logged + one notice, expiry by clock, Lift on Ok, source-generated JSON.
- D5 aggregation: pairs, per-key one decision, spent wins over a sibling Ok in either order (S41), undecided gauge rules, one probe per key (S34 2 launches).
- D6 probe argv exactly the owner's, environment and working dir from the refused request, `TrackAs`, no `--disable-slash-commands`; edge cases decided as written.
- D7 Claude `RateLimited` before `WhyItFailed`; sentence ends `(HTTP 429)`; pin reversed in AClaudeReasonInItsEnvelopeTests.cs:63.
- D8/D9 Intl in viewer zone; `dd.MM.yyyy HH:mm`; the wire member `Cooldown` `[JsonIgnore(WhenWritingNull)]`; CanRun fourth condition; ReasonFor words; card `cooldown-line` replaces `reset-line` only while standing; `cooling down` badge with note title.
- D10 five states; D11 no new outcome subtype; D12 out-of-scope items not built.
- Extension: parser rejects a half (no instant) and an unknown source; `cooldownLine` boundary; S33 runs the page via `runPanel`.
- Fixtures tracked, no personal data (the grep hit is the word "users" in a description).
- Budget: 400-char note cap; file under 16 KiB (S20).
- Docs: research/module_tests.md has entries for the new classes; RetryLadder note and statedReset header updated.

## Results of the baseline (before fixes)

- `dotnet build` on dew_flow_connect_other_ais.slnx: exit 0 (log in the scratchpad).
- Extension `npm --prefix src_vs_code test`: exit 0; S30–S33 print as passing.
- Whole MCP suite: running at the time of this write-up (its result goes in the final report).

## Added after the baseline run (findings found by the suite, not by reading)

| id | severity | file:line | one sentence | fix |
|---|---|---|---|---|
| H7 | major | src_mcp/tests/TheRefusalsAreWrittenDownTests.cs:441-453 | The hand-kept census of `ServerNotice.Shortened(` producers does not list the new `src_mcp/src/Server/QuotaNotices.cs`, so `ANoticeProducerCutsOnlyThroughTheSharedHelper` is red on this branch (plan §12 leaves it open). | Add QuotaNotices.cs to the list; the file does call the shared cut. Test-maintenance fix. |
| H8 | major | src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs (Unscanned list) | `PanelService` now takes a `TimeProvider` in its constructor and is in neither the scanned nor the reasoned list, so `EveryProductFileWhoseConstructorTakesAClock_…` is red. | Add PanelService to `Unscanned` with its reason (it reads the clock only to compare a parked instant). Plan §6 did not name it. |

Baseline (before any fix): the whole MCP suite had three failures: H7, H8, and
`RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`, which the plan §12 names as a
WSL2 path-length failure that is not this change; it is re-run alone before it is called environmental.

## Status of the fixes

- H1 AgyResets: red test rows first (AnAgyQuotaIsReadFromItsStructuredErrorTests `SpentWithoutReset` + undecided), then the `when spent == true` guard and the `Unchecked` note.
- H2 Kimi: red test `AKimiRefusal_NamingAReset_IsStillAGuess` (TheRoundParksAndLiftsTheQuotaTests), then the `KimiRuntime.ReadResetAsync` override.
- H3, H4: doc and comment only, no test.
- H5: not fixed (see table).
- H7, H8: test-list fixes made; the two tests were already red on the branch.

## Result of each finding (final)

- H1 fixed. Red first: against the old code both DecisionTable row and test show `stated` where `none` is expected. Green after the guard.
- H2 fixed. Red first: `AKimiRefusal_NamingAReset_IsStillAGuess` gets `stated`. Green after `KimiRuntime.ReadResetAsync`.
  The test's expected until is `CooldownParser.Fallback(...)`, not a fixed 30 min; the reason text names `3h`, and the fallback for it is the 5 h ceiling.
- H3 fixed (doc only). H4 fixed (comment only).
- H5 not fixed. Reason stated in the table.
- H6 is the same defect as H1; resolved by H1.
- H7 fixed (census list). H8 fixed (`PanelService` added to the reasoned `Unscanned` list).
- Judge's split.md decision on undecided + spent-without-reset is overruled by H1 (the plan's D5 text is the spec). §12 of the plan is not edited.

## Final results

- Build (slnx, Debug): succeeded, 0 warnings, 0 errors.
- Whole MCP suite, after the fixes (before the last test-only spacing fix): 13,907 total, 13,789 passed, 117 skipped, 1 failed.
  The failure is RegularFilesTests.A_fifo_a_socket_and_a_device…: a Unix socket path of 108+ characters under the worktree's temp folder. It fails alone too; plan §12 names it as environmental.
- After the last edit (ClaudeSentence spacing): the four edited classes pass, 62 of 62.
- Format: whitespace check on the changed test and runner files is clean. The whole-solution `dotnet format --verify-no-changes` reports pre-existing IL analyzer errors in unrelated projects (CoaiBugs, CoaiServer); not from this branch and not investigated further.
- Extension tests: not re-run; src_vs_code did not change in this pass. The earlier run exited 0 with S30–S33 passing.
- Commits: 903d282f (H1), ac36cc23 (H2), 338f0068 (H3, H4 is in the round test commit), 26bebc96 (H7, H8).
