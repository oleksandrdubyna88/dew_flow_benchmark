# t1 — code notes

Commit: b7812e8b on feat/quota-cooldown (worktree wt/t1). Not pushed.

## Done
- `RateLimitVerdict.Spent` (bool?, init); `Because(..., bool? spent = null)` sets it.
- `ReviewerOutcome.RateLimited.Spent` (bool?, init); `Classified` carries it.
- `BoundedScheduler.Hopeless`: `(limited.Spent ?? RateLimit.Hopeless(limited.Reason)) || ResetOutlasts(...)`; remarks updated. `RateLimit.Spent` and `RateLimit.Hopeless` untouched.
- `ClaudeRuntime.RateLimited` (spend-limit envelope becomes a spent RateLimited, one launch) and `ClaudeRuntime.QuotaKeyOf` returning "claude".
- `CodexRuntime.QuotaKeyOf` returns "codex" unless ProviderOverrides is non-empty (Deepseek/Custom keep "").
- `KimiRuntime.QuotaKeyOf` returns "kimi".
- `IReviewerRuntime.QuotaKeyOf` (default "") and `ReadResetAsync` (default per contract).
- `QuotaReset.cs`: QuotaSources, QuotaReset (NoPark, FromQuota, FromStated, Guess, FromText).
- `RetryLadder` remarks: last sentence rewritten to point at QuotaCooldowns (D4).
- Tests: AStructuredVerdictOutranksTheWordScanTests (S1–S3), AClaudeSpendLimitIsASpentQuotaTests (S7, S8), reversed pin in AClaudeReasonInItsEnvelopeTests, TheRuntimesNameTheirQuotaTests.

## Red and break-it evidence
- S1 red: `Expected launched to be 1 ... but found 4.` Green after the Hopeless change.
- S2 red: `Expected launched to be 4 ... but found 1.` Green after `Because` sets Spent and Classified carries it.
- S3 first case did NOT go red under the `Spent == true` break the document predicts. The AGY 88h49m9s sentence is still hopeless through `RetryLadder.ResetOutlasts` (10-minute budget), so both shapes give 1 launch. I added one row to the S3 theory: `"You've hit your usage limit."` with expected 1 (no stated reset, a spent word). Break-it then red: `... to be 1, but found 4.` Restored; green.
- S7 red: `Expected type to be ...ReviewerOutcome+RateLimited, but found ...+NonZeroExit.` Green after `ClaudeRuntime.RateLimited`.
- S8 break-it (drop `&& IsSpendLimit(sentence)`): red `Expected type to be ...NonZeroExit, but found ...+RateLimited.` Restored; green.
- Reversed pin: green.

## Deviation from red-first order
- The `QuotaKeyOf` overrides (Codex, Claude, Kimi) and the interface defaults were written in the same pass as `TheRuntimesNameTheirQuotaTests`, so that file was never seen red. It is green now (10 pass). The defaults for Deepseek/Custom/Gemini/Local/Api/Remote were not separately red-checked.
- `ReadResetAsync` test cases were not seen red for the same reason.

## Test results
- Build: 0 errors, 0 warnings (dew_flow_connect_other_ais.slnx, -c Debug -m:4 --disable-build-servers).
- Named classes: AStructuredVerdictOutranksTheWordScanTests 5/5 (after the added row); AClaudeSpendLimitIsASpentQuotaTests 3/3; AClaudeReasonInItsEnvelopeTests 19/19; TheRuntimesNameTheirQuotaTests 10/10. AStatedResetIsNeverWaitedOutTests and GateReportingTests passed in the whole-suite run; not run alone.
- Whole MCP suite: total 13830, failed 1, succeeded 13712, skipped 117. The one failure is `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: an ArgumentOutOfRangeException because the socket path under the worktree's temp folder is longer than the 108-character Unix socket limit. It failed again when run alone (2 of 2). Environmental; not in this change's files; not fixed.
- `dotnet format --verify-no-changes`: exit 2. The output is analyzer errors (IL2026/IL3050) in `src_server` and `src_bugs`; no `src_mcp` file is listed. I did not check whether these also fail at the base commit.

## Not done or left
- Instruction loading: I skimmed `.agents/conventions/ENTRY.md` and `.agents/PROJECT.md` and did not run the `rules.mjs explain`/`read` preflight; the SessionStart hook had loaded the common rules. Flag this if the preflight is required.
- `src_vs_code/node_modules` is untracked and was there before; not touched.
