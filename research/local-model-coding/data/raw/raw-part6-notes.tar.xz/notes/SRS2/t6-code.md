# t6 — the extension: parse `cooldown`, say it, draw it on the card

Branch `tmp/t6` (worktree `wt/t6`), commit `9ed4d71f`, on top of `6786582e`. Not pushed.

## What was done

- `providers.ts`: `Cooldown` interface and `ProviderHealth.cooldown?`; `oneProvider` spreads `cooldownOf(cooldown)` beside `warningOf`.
  `cooldownOf` keeps the member only when `untilUtc` parses, `source` is `quota | stated | guess`; `note` defaults to `''`; otherwise no key.
- `resetWords.ts`: `spanOf` exported. Nothing else changed.
- `cooldownWords.ts` (new leaf, imports `./resetWords` and `type Cooldown` only): `cooldownLine(report, nowMs, timeZone?)`.
  `''` once passed; the three wordings; date assembled as `dd.MM.yyyy HH:mm` from `formatToParts`. Wait via `spanOf`.
- `modelCard.ts`: `foot` draws `cooldown-line` INSTEAD of `reset-line` while `cooldownLine(...)` is non-empty, through a small helper
  `resetOrCooldown`. `top` passes `facts.now` to `verdictBadge`.
- `modelCardWorld.ts`: `verdictBadge(id, context, nowMs)` draws `cooling down` (title = note) while a cooldown stands; otherwise the old badge.
- `statedReset.ts` header: the "nothing is persisted" sentence replaced as the contract gives it.
- `research/module_extension.md`: one dated paragraph after story 5.3b.
- `test/aCoolingRowSaysWhenItIsBack.test.ts`: four tests S30–S33, as named in the document.

## Red, as seen

Stubbed first: `cooldownWords.ts` was a placeholder returning a string concatenation (not `null`), and `Cooldown`/`ProviderHealth.cooldown`
were added as types only. Every failure was an assertion:

- S30: `AssertionError … actual: undefined, expected: { untilUtc: '2026-10-14T07:19:16Z', source: 'quota', note: 'n' }`.
- S31: `actual: '2026-10-14T07:19:16Z1791736200000Europe/Paris', expected: 'quota spent — back 14.10.2026 09:19 (in 63 h)'`.
- S32: the same stub string against the `stated` wording.
- S33: `the cooling card draws no cooldown line — actual: 0, expected: 1`.

The document's expected `null !== …` wording is not what I got; the failures are assertions on the same meaning, as the document allows.
(S32's `guess` case was not reached in that run because S32 stops at its first assertion; it was checked after green.)

## Green

- `npm run compile`, `npm run typecheck`, `npm run lint`: clean (lint first flagged `verdictBadge` at complexity 5; fixed by splitting
  out `standingCooldown` and `runsBadge`).
- Named test files, run from `src_vs_code`:
  `node --test out/test/providersBadge.test.js out/test/statedReset.test.js out/test/cyclomatic.test.js out/test/aCoolingRowSaysWhenItIsBack.test.js`
  → **49 pass, 0 fail** (the new file 4/4; `providersBadge`, `statedReset` and `cyclomatic` unchanged and green).
- `plan-lifecycle.mjs`: "no todo/ + research/ pair — nothing to check" (exit clean).
- NOT run: full `npm test` (the coder rule says do not run the whole suite). The document's "Done when" lists it; it has not been run here.
- NOT run: a break-it check. None of S30–S33 names one.

## Choices and deviations

- S31's Dec-1 case: the document gives no number. Computed: 11 Oct 16:30 UTC to 1 Dec 07:19:16 UTC is 1214 h 49 m → `(in 1215 h)`, with
  `01.12.2026 08:19` in Paris (CET). Asserted as that.
- S33 says `.cooldown-line` text "equals the S31 line". The card's foot calls `cooldownLine(report, now)` with no zone (host zone), so the
  test compares to `cooldownLine(QUOTA, NOW_MS)` with no zone too. Zone-independent; the Paris string is not used there.
- S33's `runPanel` takes `now` via `state.now` (panelView `PanelState.now`); no fallback harness was needed.
- Helper names (`resetOrCooldown`, `standingCooldown`, `runsBadge`, `wordsOf`, `dateTimeOf`) are my additions for complexity ≤ 4 and
  lint; the contracts name only the exported functions.

## Left, and why

- **No CSS for `cooldown-line` or `.badge.verdict.cooling`.** The contract does not name a style, and the styles live outside the files
  this task may change. Today `cooldown-line` is an unstyled foot line, and `cooling` gets no colour. `.reset-line` has a warning-tone
  rule in the catalog sheet; the cooldown line should probably get the same. Needs a styles file outside t6's list.
- The full `npm test` run and the MCP side are not mine; nothing here touches C#.
