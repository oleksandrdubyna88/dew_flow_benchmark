# Split of PLAN_a_spent_quota_cools_the_model_down — judge's decisions

Seven tasks (t1..t7), 43 scenarios, every file in exactly one task. Parallel layers: {t1, t2, t6} → {t3, t4} → t5 → t7.

## Decisions a task document does not show
- **Plan gaps filled:** `ReadResetAsync` gained `bool? spent` (D5 needs it to separate the undecided agy case; the default parks only for `spent == true` or a hopeless reason, else `QuotaReset.NoPark`). `QuotaReset`/`QuotaSources` live in `QuotaReset.cs` (t1) so the interface compiles without waiting for the store.
- **Runners cannot see `NoticeWriter`** (it is in `src_mcp/src`): `QuotaCooldowns` takes `Action<string>? onRefused`; t7 wires it to `Noticing.Offered` with existing code `ServerNoticeCodes.StorageNote` (no new code → no parity files).
- **`QuotaCooldowns` is `partial`** across `QuotaCooldowns.cs` (t4: store, lock) and `QuotaCooldownsRound.cs` (t5: `AfterRoundAsync`) so files are not shared. Constructor takes an optional launcher (only `AfterRoundAsync` uses it).
- `AgyQuotaReport` is hand-parsed with `JsonDocument` (AOT-safe, no context) — plan said "source-generated context"; the store keeps a source-generated context (t4). Times in the file and wire are whole-second `yyyy-MM-ddTHH:mm:ssZ` (`QuotaCooldowns.Iso`).
- `AgyQuotaProbe.ReadAsync` takes `key` and `nowUtc` and returns the verdict (S15 says "CannotCheck"); a key with no gauge (unknown family) launches nothing; cancellation throws.
- Empty agy model → `DefaultModel` (`gemini-3.7-flash-high`) → Gemini key. `CodexRuntime.QuotaKeyOf` = `"codex"` unless `ProviderOverrides` is non-empty (Deepseek, custom codex keep the empty key).
- **Plan defects resolved:** S25's codex date (`July 15, 2026` → `2026-07-16`) is before the plan's `NOW` (October) — that part runs on its own July clock. S34 is split: report half in t2, AfterRound half in t5 (`..._ThroughAfterRound_ParksOnlyArgon`, Gemini row made undecided because a spent+Available row is parked by S41's rule). S9 etc. use full keys (`antigravity/gemini`). The plan's `Spent: true` named argument is `spent: true`.
- Undecided agy + spent bucket with no reset → parked on the stated/guess road (the bucket is at 0).
- S7's reversal of the Claude pin is in t1 (it owns `AClaudeReasonInItsEnvelopeTests.cs`). The clock guard test file (`EveryBudgetInAClockedClassReadsItsClockTests.cs`) is t4's.
- Docs: `module_extension.md` + `RESULTS_vendor_quota_gauges.md` §3.4 travel with t6/t5; `module_runners/server/tests.md` and the plan file belong to t7 (last).
- S33 reads the RUNNING page through `runPanel` + `pageTree` (as `aRowsPromptCapIsSetOnTheModelCard.test.ts`), not `runPageHtml` on a string; `modelsTab.ts` needs no change.
- Time: the deadline hit while writing t5–t7; those three briefs are shorter than t1–t4 (fewer copied signatures) — a reviewer should check them first.
