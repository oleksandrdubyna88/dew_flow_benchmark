# t2 — code notes

## Done
- `src_mcp/runners/Reviewers/AgyQuotaReport.cs` (261 lines): `AgyQuotaGroups` (table by id, one effort suffix stripped, ordinal-ignore-case), `AgyQuotaBucket`/`AgyQuotaGroup`/`AgyQuotaReport` (hand-written `JsonDocument` reader; `Parse` never throws; `ResetFor`), `AgyQuotaVerdict`, `AgyQuotaProbe` (kept in this file; far under 400 lines, so no split).
- `src_mcp/tests/TheAgyQuotaReportPicksTheResetTests.cs`: 19 test cases (S9–S15, S34 report half, S40 as an 8-row Theory, S43, and the cancel / no-gauge probe cases).
- `src_mcp/tests/fixtures/antigravity/quota-sample.json`: plan lines 38–81 (the JSON between the fences), 44 lines, valid JSON.

## Red first
- Stub build: every verdict Available, KeyOf → Gemini, Parse → empty report. The reds were assertion failures, e.g. `Expected report.Groups to contain 3 item(s), but found 0`, `Expected a <System.OperationCanceledException> to be thrown, but no exception was thrown.`, `Expected type to be CannotCheck, but found Available`, `Expected AgyQuotaGroups.KeyOf(id) to be the same string, but they differ at index 12`.
- Break-it for S14 (KeyOf replaced by the prefix rule `model.StartsWith("gemini-")`): `AnUnknownModel_HasNoGroup` failed, as expected. Restored.

## Deviations and judgement calls
- Group `name` is read into `AgyQuotaGroup.Name` for the log only; nothing decides by it. "Never read" is taken as "never used to find or decide". Verdicts are unchanged when names are blanked (S43 checks this).
- `TryGetDouble` throws `InvalidOperationException` on a JSON string in this runtime, not `false` as its doc suggests, so `Number` checks `ValueKind == Number` first. Found by the S40 `"0"` row.
- The S40 test's `Edge(...)` is a switch expression over the eight edge names, one theory row each, returning `(Json, Expected)`.
- The S15 test is `async Task` (the stub had it `void`; the first red build showed it).

## Results
- `low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests --filter-class 'CoaiMcp.Tests.TheAgyQuotaReportPicksTheResetTests'`: 19 total, 19 passed.
- Whole suite (`CoaiMcp.Tests`, no filter): 13830 total, 13712 passed, 117 skipped, 1 failed. The failure is `CoaiMcp.Tests.RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException` from `UnixDomainSocketEndPoint` because the temp path (under this worktree's `tmp/`) is longer than the 108-character Unix socket limit. It does not touch the quota code. Not re-run green (its class run: 32 total, the same one failing), so it is an environment/path issue of this worktree, not a flake that passed.
- `dotnet format <solution> --verify-no-changes`: exit 2, 54 error lines, all IL2026/IL3050 analyzer errors in `src_server/src/CoaiServer.csproj` (not my files). It did not reach a formatting verdict for the solution.
- `dotnet format src_mcp/tests/CoaiMcp.Tests.csproj --verify-no-changes --include <my two .cs files>`: exit 0. The two new C# files are format-clean.

## Left
- The solution-wide format gate is blocked by the `src_server` IL errors (pre-existing, outside t2).
- The `RegularFilesTests` socket-path failure needs a shorter temp path (the worktree path), not a change here.
- Commit: `ae970a03` on `tmp/t2` (`feat(quota): the /quota reader — the model table, the report, the verdict and the probe`), three files by name. The conventions block said "leave uncommitted" and the brief said "commit"; I followed the brief. Not pushed.
