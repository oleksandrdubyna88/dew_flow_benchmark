# Fixes after the review (`review.json`, verdict fix-then-ready)

Commits: `de44689f` (code + tests), `f5c912b4` (docs + plan promotion).

## R1 (major) — plan-lifecycle fails: plan "implemented" but in `todo/` — FIXED
Promoted `todo/PLAN_a_spent_quota_cools_the_model_down.md` to `research/` (status `**IMPLEMENTED, 2026-10-29.**`, §12 kept, D12's later-plan line kept). Links rewritten for the destination (the three sibling plans still in `todo/` got `../todo/`, the two `../research/` links lost their prefix); the `todo/README.md` row removed; a row added to `research/README.md`; every inbound path citation (`todo/PLAN_…` → `research/PLAN_…`) rewritten in 4 test files, `KimiRuntime.cs`, `RetryLadder.cs`, `cooldownWords.ts` and the four `research/module_*.md`. `node .agents/conventions/tools/plan-lifecycle.mjs` → `clean`.

## R2 (major) — nothing runs a real round — FIXED
New `ARoundThatEndsOnASpentQuotaParksItTests` (fakecli-env collection): a real `PanelService` + engine over the vendor-mode fake Codex that answers exit 1 with its spent-allowance sentence, clock at 2026-07-10. Round 1 → `quota-cooldowns.json` holds `codex` until `2026-07-16T00:00:00Z`, and `ExcludedFrom(PlanReview)` names the row.
Teeth, observed: with `await _cooldowns.AfterRoundAsync(...)` commented out in `RoundEngine.cs`, both tests of the class went red (`Expected File.Exists(record) to be True because the round handed its results to the cooldown store, but found False.`; and `Expected var notice = storage to contain a single item, but the collection is empty.`). Line restored, green. `research/module_tests.md` gained the row.

## R3 (minor) — a cancelled probe discards the other keys' changes; the probe's token is the round clock's — FIXED
Red first: `ACancelledProbe_DoesNotThrowAwayWhatTheOtherKeysDecided` (agy probe hangs till cancelled, Codex's stated park rides the same round) → `Expected entry not to be <null> because codex should stand`. `AfterRoundAsync` now catches `OperationCanceledException` per key and still applies the rest. `RoundEngine` now hands it a token linked from the caller's `ct` and the host's stop only (`RoundCancellation.Token`, which includes the round's own deadline, is no longer used there). The token change itself has no test of its own (the round deadline is not reproducible cheaply in a real round); that half is by reading.

## R4 (minor) — `HeldFile.TakeWithin` polled on an async thread — FIXED
Red first: `TheWriteWaitsForItsLockOffTheCallersThread` (lock held by the test, 20 s patience) → `Expected running.IsCompleted to be False because the lock wait must not block the caller's thread, but found True.` (it blocked 20 s). `Apply` is now called as `await Task.Run(() => Apply(changes), CancellationToken.None)` from `AfterRoundAsync` (the public sync `Park`/`Lift`/`Apply` are unchanged; tests and `Task.Run` callers use them).

## R5 (minor) — pretty-printed `AGY_ERROR` (issue #765's own sample) not read — FIXED
Red first: `ThePrettyPrintedLineOfIssue765_…` → `Expected AgyError.Parse(stderr) to contain a single item, but the collection is empty.`; `TwoErrorsInOneStderr_…` → found 1 of 2. `AgyError.Parse` now finds each line starting with the token and reads the first JSON value that follows it in the whole remaining stderr (`Utf8JsonReader` + `JsonDocument.ParseValue`), so the object may run over lines; a torn object is no error and the next token line is still read. The #765 sample is in the tests verbatim.

## R6 (minor) — the notice road was proved only to `onRefused` — FIXED (test, not doc change)
`ARoundThatEndsOnASpentQuotaParksItTests.ARefusedWriteOfTheRecord_ReachesTheNoticeWriter_AsOneStorageNote`: a directory sits where the lock file belongs, so the write is refused at once; the `Noticing` of the `PanelService` receives exactly one notice, `failure`, code `storage-note`, subject `quota-cooldowns`, title naming `quota-cooldowns.lock`. Red with the engine line removed (see R2). The NOT-proved paragraph in `module_tests.md` now says what is and is not proved.

## R7 (minor) — two stale docs — FIXED
Plan §12: the stale "Open at the time of this status" census bullet replaced by what happened (26bebc96), plus a new bullet recording the post-review deviations (multi-line `AGY_ERROR`, per-key cancellation, the probe's token, the off-thread lock). `research/module_runners.md` (the superseded "Persisted" bullet) now says the record is lifted by an answered launch or by the clock; the round-rule bullet says the per-key cancellation, the token, and the `Task.Run`.

## Not fixed / wrong
None wrong. Nothing left open from the review.

## Results
- Build (`dotnet build dew_flow_connect_other_ais.slnx -c Debug`): succeeded, 0 warnings, 0 errors.
- Changed classes (`ARoundThatEndsOnASpentQuotaParksItTests`, `TheRoundParksAndLiftsTheQuotaTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`, `ASpentQuotaIsRememberedUntilItsResetTests`, `ACoolingRowStaysOutOfTheRoundTests`): 46 of 46 passed.
- Whole MCP suite (Debug): total 13,914; 13,796 passed; 117 skipped; **1 failed** — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`. Re-run alone it fails the same: `ArgumentOutOfRangeException: The path '…/tmp/testsToDelete-coai-run-e5f58f/testsToDelete-regular-files-ZWJhWu/shown.sock' is of an invalid length for use with domain sockets` — the sandbox temp folder (`…/b2fa80b416bf/tmp/…`) is over the 108-character Unix socket limit. It is deterministic and about the path, not about this branch (the test and what it covers are untouched). Not run under a short `TMPDIR` (the harness would not allow a `/tmp` folder), so "it passes with a short path" is not observed here.
- `plan-lifecycle.mjs`: clean.
- Format: `dotnet format --verify-no-changes` on `src_mcp/tests`, `src_mcp/runners` and `src_mcp/src`: clean, exit 0. The solution-wide run was not usable (it prints the `src_server` AOT/trim analyser errors IL2026/IL3050 — those projects are not touched here).
- Extension (`npm --prefix src_vs_code test`; only a comment in `cooldownWords.ts` changed): 16 runs, `fail 0` in each; the main run 6,539 tests, 6,519 passed, the rest skipped.
