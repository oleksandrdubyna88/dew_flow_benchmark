# t5 — `AfterRoundAsync`: aggregate per key, one probe per key, park and lift

## Done
- `src_mcp/runners/Reviewers/QuotaCooldownsRound.cs` — the second half of `QuotaCooldowns` (same `public sealed partial`). `AfterRoundAsync`
  groups the rows by `Adapter?.QuotaKeyOf(Model)` (empty dropped), decides each key (`DecideAsync`: `AskingOf`, `FirstOf`, `ResetOfAsync`,
  `LiftIfAnswered`, `KeyedBy`), applies ONE `Apply` for the round, returns the same list. A cancelled probe logs
  `the quota probe was cancelled; nothing parked` and returns with nothing applied. Any other exception from one key's `ReadResetAsync` is
  logged (`the quota of {Key} could not be read; nothing parked for it`) and skips that key. Complexity ≤ 4 per method.
- `src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs` — S22, S23, S24 (a/b/c as one test), S25, S34 (AfterRound half), S41 (Theory, both orders),
  S42. Fixtures read as `fixtures/antigravity/quota-sample.json` and `quota-2026-10-28.json`; the constructed variants are `Replace`d copies with a guard that the text changed.
- `research/RESULTS_vendor_quota_gauges.md` — new `### 3.4` with the one table row for the 2026-10-28 hand capture and the "next row" sentence. `plan-lifecycle.mjs` reports clean.

## Red (stub: `AfterRoundAsync` returns `results`)
All eight failed on assertions, none on compile:
- S22 `ASpentAgyRefusal_…`: `Expected entry not to be <null> because antigravity/gemini should stand at 2026-10-11T16:30:00Z` (via `Entry`). Same for S23 (`WhenQuotaCannotBeRead_…`) and S25 (the codex `Entry`).
- S24 `AnUndecidedExhaustion_…`: `Expected _said {empty} to contain a match of "*transient*"`.
- S34 `ArgonSpent_…`: `Expected launcher.Launched to be 2, but found 0`.
- S41 (both orders): `Expected launcher.Launched to be 1, but found 0`.
- S42 `ACancelledProbe_…`: `Expected _said {empty} to contain a match of "*cancelled*"`. Took 10 s on the stub because the test's canceller waits for a probe the stub never makes; it then cancels.

## Green (after the implementation)
- `TheRoundParksAndLiftsTheQuotaTests`: 8/8 (S41 as 2 cases).
- `ASpentQuotaIsRememberedUntilItsResetTests`: 11/11.
- `EveryBudgetInAClockedClassReadsItsClockTests`: 9/9.
- Build (`dew_flow_connect_other_ais.slnx`, Debug, `-m:4 --disable-build-servers`): succeeded, 0 warnings.
- `dotnet format --verify-no-changes`: exit 2, only the IL2026/IL3050 analyzer errors in `src_server` and `src_bugs` (not touched; same as t4's note). No format finding names my three files.

## Choices the document left open
- "Per key `now = clock.GetUtcNow()` read once" is read literally: read in `DecideAsync`, once per key.
- A spent refusal whose reset does not park (only possible for an undecided `Spent == null` or a transient one) falls to the `!reset.Parks` branch, which lifts when the same key has an `Ok`. That is the document's literal order. For `Spent == true`, `ReadResetAsync` always parks, so "a spent refusal wins over an Ok" holds in both orders (S41).
- `AskingOf` excludes `Spent == false` (transient); transient + `Ok` therefore lifts, as "No asking outcome and an Ok → Lift" says.
- S34's Gemini row is `Spent = null`, as the document's comment rule says (the `Spent = true` line in the scenario is superseded by it).
- S25 used the instant the document asserted, `2026-07-16T00:00:00Z`; it passed, so no adjustment was needed.
- `DecideAsync` and friends use `Launcher` (t4's internal property), per t4's note.

## Left
- Whole suite: see the final report (run in the background after the green targeted runs).
- Not touched: `QuotaCooldowns.cs` (t4), scheduler, executor, ladder, extension, `src_mcp/src/*`, the plan.
