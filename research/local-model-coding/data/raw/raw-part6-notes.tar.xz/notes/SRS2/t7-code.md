# t7 — the server keeps the cooling row out and says why; docs; the plan's status

## Did

- **Wire type** (`src_mcp/src/Server/ServerJsonContext.cs`): `ProviderStatus.Cooldown` (`CooldownReport?`, `WhenWritingNull`), and `record CooldownReport(string UntilUtc, string Source, string Note)`. No new `[JsonSerializable]`.
- **PanelService** (`src_mcp/src/Server/PanelService.cs`): `TimeProvider? clock = null` as the last constructor parameter; `_clock`; `_cooldowns = new QuotaCooldowns(dataDir, _clock, log, launcher, onRefused: sentence => noticing.Offered(() => QuotaNotices.Refused(sentence)))` beside the ledger; `_cooldowns` passed to `RoundEngine`.
  - `CanRun` gets the fourth condition `!IsCooling(provider)`.
  - `CoolingOf` (runtime's `QuotaKeyOf(model)` → `_cooldowns.Standing(key, now)`), `IsCooling`, `CooldownOf`.
  - `ReasonFor`: cooling branch after the row refusal, before `ExclusionReason`; `CoolingSentence` with the three shapes (quota / stated / guess), `HoursUntil` = whole hours rounded up, minimum 1.
  - `ProbeAsync`: `Cooldown = CooldownOf(provider)`.
- **RoundEngine** (`src_mcp/src/Server/Rounds/RoundEngine.cs`): constructor parameter `QuotaCooldowns cooldowns` (before `excludedFrom`), field `_cooldowns`, `await _cooldowns.AfterRoundAsync(results, cancellation.Token);` between the `RunAllAsync` call and `var summary`. The only `new RoundEngine(` call is in `PanelService`; no test constructs it.
- **QuotaNotices** (`src_mcp/src/Server/QuotaNotices.cs`, new): `Refused(sentence)` → `failure` / `coai-mcp` / `ServerNoticeCodes.StorageNote` / subject `quota-cooldowns` / title `ServerNotice.Shortened(sentence)`.
- **Tests** (`src_mcp/tests/ACoolingRowStaysOutOfTheRoundTests.cs`, new): S26, S27, S28, S29, S38 as named in the document.
- **Docs**: `research/module_runners.md` (the "Nothing is persisted" bullet replaced and marked superseded; the agy paragraph at ~1231 marked partly superseded; new section "A spent quota is parked and lifted by the round"), `research/module_server.md` (new section at the end), `research/module_tests.md` (new section with the flow table and "what is NOT proved"), `todo/PLAN_a_spent_quota_cools_the_model_down.md` (status line → implemented, 2026-10-29; new §12 Deviations).

## Red and green

- Red, before the behaviour (structure in place, `CanRun`/`ReasonFor`/`ProbeAsync` not yet changed):
  - S26 `ACoolingAgyRow_IsExcluded_WithThisSidesSentence`: `Expected excluded to contain a single item … but the collection is empty.`
  - S27 `AnotherGroupOnTheSameCli_StillRuns`: `Expected excluded to contain a single item … but the collection is empty.`
  - S29 `TheProvidersAnswer_CarriesTheCooldown_AndNothingForARowThatIsNotCooling`: `KeyNotFoundException: The given key was not present` (no `cooldown` member).
  - S28 `WhenTheResetHasPassed_TheRowRunsAgain_WithoutAnyWrite`: PASSED at this stage. Expected: its assertion is that nothing is excluded and the file is unchanged; with no behaviour yet, nothing is excluded, so it passed. It is a guard, not a driver of the change. Not forced red.
  - S38 `AProvidersAnswerWithACooldown_SerialisesThroughTheGeneratedContext`: PASSED at this stage, because the wire type was added in the structure step (it is a serialisation-shape test, and the type had to exist to compile). Not a red on the behaviour; it is green on the contract.
- Break-it for S27 (`CoolingOf` keyed on the Gemini quota for every antigravity row): `AnotherGroupOnTheSameCli_StillRuns` red with two lines: `antigravity: its Gemini quota … (in 63 h)` and `gpt-oss-120b-medium: its Gemini quota … (in 63 h)`. Restored; green.
- Green after the behaviour: `ACoolingRowStaysOutOfTheRoundTests` 5/5.
- `RoundNamesTheExcludedTests` 11/11 (the class's own count from the run: 11 succeeded).
- `TheRefusalsAreWrittenDownTests`: 28 of 29 pass; **`ANoticeProducerCutsOnlyThroughTheSharedHelper` FAILS** (see Left).

## Commands run

- `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers` → Build succeeded, 0 warnings, 0 errors (three times, the last after the break-it was restored).
- `CoaiMcp.Tests --filter-class CoaiMcp.Tests.ACoolingRowStaysOutOfTheRoundTests` → 5/5 (red run: 3 failed, 2 passed; break-it run: 2 failed).
- `CoaiMcp.Tests --filter-class CoaiMcp.Tests.RoundNamesTheExcludedTests` → passed.
- `CoaiMcp.Tests --filter-class CoaiMcp.Tests.TheRefusalsAreWrittenDownTests` → 1 failed (the census), 28 passed.
- `plan-lifecycle.mjs` → one finding: see Left.
- Whole MCP suite: started in the background after the green targeted runs; log at `tmp/.../scratchpad/whole-suite.log`. Result: see the final report.

## Choices

- `CoolingOf` checks the runtime's `QuotaKeyOf` first, and only reads the record when the key is non-empty (a runtime with no quota key, e.g. Deepseek, is never cooling).
- The `stated` / `guess` / `quota` cases of `CoolingSentence` use a switch expression with `_` for guess (the record's only other source is the one the store writes; `none` is never written).
- The S26 sentence is built from the entry's own key via `QuotaCooldowns.QuotaNameOf`, so an unknown group reads as "quota for {model} on Antigravity (group unknown)".

## Left

1. **Notice census fails** (`src_mcp/tests/TheRefusalsAreWrittenDownTests.cs`, `ANoticeProducerCutsOnlyThroughTheSharedHelper`). The test lists by hand the files that call `ServerNotice.Shortened(`, and `src_mcp/src/Server/QuotaNotices.cs` is a new caller. The fix is one line in that list (`"src_mcp/src/Server/QuotaNotices.cs"`, after `HostCrash.cs`). That test file is outside t7's set, so I did not edit it. The failure is exactly the census's own message: "contains 1 item(s) too many" for `QuotaNotices.cs`. Needs the owner (or the task that owns that file) to add the line.
2. **`plan-lifecycle.mjs` is not green.** The status line the document asks for (`implemented, 2026-10-29`) makes the tool report the plan as misfiled: a plan whose status says implemented belongs in `research/` and is moved by `/promote-plan`. I did not move it (outside t7's files). The owner runs `/promote-plan` after the branch is reviewed.
3. **Whole MCP suite** (commit `e5def019`): total 13,906, failed 3, succeeded 13,786, skipped 117. Failures:
   - `ANoticeProducerCutsOnlyThroughTheSharedHelper` (item 1 above).
   - `EveryBudgetInAClockedClassReadsItsClockTests.EveryProductFileWhoseConstructorTakesAClock_IsScanned_OrNamedAsNotScannedWithItsReason`: `src_mcp/src/Server/PanelService.cs` now takes a `TimeProvider` constructor parameter and is in neither the scanned list nor the not-scanned list. A reason-bearing entry in `Unscanned` (it forwards the clock to `QuotaCooldowns` and reads instants only) would clear it. That file is t4's, outside my set, so I did not edit it.
   - `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: environmental (WSL2 temp path longer than the 108-character Unix socket limit), reported by t1 and t3 too.
   Extension tests (`npm --prefix src_vs_code test`): NOT run by me. The extension is t6's; the document lists the command, and it still needs a run before the plan is called shipped.
4. `dotnet format --verify-no-changes`: exit 2, all findings in `src_server` (76) and `src_bugs` (32); none in `src_mcp`.
5. `S28` and `S38` did not go red on the behaviour; they are guards / shape tests (see above).
