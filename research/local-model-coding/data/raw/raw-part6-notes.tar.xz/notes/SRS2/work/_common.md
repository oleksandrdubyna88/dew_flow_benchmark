
## Conventions (apply to every task of this plan)

- **Repo and plan.** You work in a clone of ConnectOtherAIs at commit `6786582e`, branch `feat/quota-cooldown`, in your own worktree. The plan is
  `todo/PLAN_a_spent_quota_cools_the_model_down.md`; this document is your whole specification — where the plan and this document differ, THIS document wins
  (the judge resolved the plan's gaps on purpose). Leave your changes **uncommitted** in your worktree; do not touch a file that is not in your "Files".
- **Nothing is known to fail at the base commit**: the whole MCP suite (13,807 tests) and the extension tests pass on this host (Linux/WSL2; Windows-only tests skip).
  A failure you see is yours or flaky: re-run that ONE test alone before you decide.
- **Red first.** For each test: write it, run it, and see it FAIL on an *assertion* (never a compile error — if a type you need does not exist yet, stub it so the
  test returns `null`/`Available`/empty first, then fill it in). The "Red:" text in a scenario is the plan's expected failure; an assertion failure of the same meaning is
  acceptable, the exact wording is not required. Then production code, then green. Where a scenario says *break-it*, break the production code the stated way, see the test
  go red, restore.
- **C# style** (`csharp.doctrine`): .NET 10, latest C#, `TreatWarningsAsErrors`, file-scoped `namespace`, records for data and classes for services, collection expressions
  (`[]`), no `null` in business logic where an empty value will do (the contracts below say where `null` is the plan's own contract), **cyclomatic complexity ≤ 4 per
  method** (split methods), XML-doc `<summary>` on every public type/member you add (match the density of the neighbouring code), UTC everywhere (`DateTimeOffset`,
  ISO 8601 with `Z`). Tests: xUnit v3 + FluentAssertions, `TestContext.Current.CancellationToken`, every temp folder `TempDir.For("testsToDelete-quota-")`
  (`src_mcp/tests/TempDir.cs:31`, `IDisposable`), no real id/path/secret in a test or fixture (the repository is public), no test runs `agy`/`claude`/`codex`/`kimi`.
- **Fixtures are read like this** (`src_mcp/tests/ConsultFailureTests.cs:32`): `File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures", "antigravity", name))`
  (the csproj copies `fixtures\**` to the output).
- **Build and test commands** (from the worktree root; ALWAYS through `low-priority.mjs`; the test host is the MTP executable — NEVER `dotnet test`):
  ```bash
  node .agents/conventions/tools/low-priority.mjs dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers
  node .agents/conventions/tools/low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests --filter-class '<namespace>.<Class>'
  node .agents/conventions/tools/low-priority.mjs ./src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests          # the whole suite, last
  node .agents/conventions/tools/low-priority.mjs dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes
  ```
  (On Linux the executable is `CoaiMcp.Tests`, without `.exe`.) The test namespace is `CoaiMcp.Tests`; so `--filter-class 'CoaiMcp.Tests.<Class>'`.
- **Report** (your final message): for each scenario the red message you saw and "green"; the commands you ran with their pass counts; anything in this document you
  could not follow and why.
