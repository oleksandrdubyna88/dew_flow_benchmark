# FIX notes — review of the quota-cooldown branch

Commit `74312833` (one commit for R1–R5, all in `src_mcp`; `src_vs_code` is untouched, so the extension tests were not re-run). Times UTC; deadline 16:56.

Instruction loading: ran `rules.mjs explain --task implement --task test` for the changed files. As the coder did, I did NOT read every selected rule in
full (about 280 KB); I worked from the review's fixes, the plan, and the neighbouring code and tests.

| # | Severity | Verdict | What I did |
|---|---|---|---|
| R1 | major | fixed | `AgyQuotaProbe.ReadAsync` (AgyQuotaReport.cs) throws `OperationCanceledException` before the launch when the token is already cancelled, and after it when the launcher answers `Cancelled` (the real launcher never throws). `QuotaCooldowns.AfterRoundAsync` already catches that and parks nothing. Test first: S42's `WaitsForItsToken` now answers the way the real launcher does (`TimedOut: true, Cancelled: true`, no throw) and a new `AnAlreadyCancelledRound_LaunchesNoProbe_AndParksNothing`. Red before: `ACancelledProbe_…` found a parked Gemini entry, the new test found 1 launch. Green after. |
| R2 | major | fixed | New `ARoundThatEndsSpentParksTheQuotaTests` (fakecli-env collection, shape of `ADocumentIsReviewedEndToEndTests`): a document round through `PanelService` with a codex row on FakeCli answering "You've hit your usage limit … October 15, 2026" (exit 1); afterwards `ExcludedFrom(DocumentReview)` names `codex: its Codex usage limit is spent — back at about 2026-10-16T00:00:00Z`. Break-it run: with `RoundEngine.cs`'s `AfterRoundAsync` line commented out the test is red (`collection is empty`); restored (no diff in RoundEngine.cs). The "a later round's Ok lifts it" half is NOT through the engine: a parked row is excluded, so no later round runs it until the reset; lifting stays covered by the direct `AfterRoundAsync` tests (the same engine line carries both). |
| R3 | minor | fixed | `QuotaCooldowns.Refusal` now orders spent-by-field first, then `RateLimit.Hopeless(reason)`, so a transient 429 row no longer hides a hopeless one. Test first: `ATransientRefusal_NextToAnUndecidedHopelessOne_DoesNotHideIt_InEitherOrder_EvenBesideAnAnswer` (codex, both orders, and with a sibling Ok) — red (`Standing("codex")` null) before. |
| R4 | minor | fixed | `[JsonIgnore]` on `UntilIso` and `QuotaName`; both are still read in code (the sentence, the provider card). Test first: `TheFileHoldsExactlyTheSevenFieldsOfTheSchema_AndNoComputedOne` — red (nine properties) before. |
| R5 | minor | fixed | S40's two rows now set BOTH Gemini buckets to -1 / 2 and expect `GroupMissing`. Break-it run: with the `[0, 1]` check removed from `AgyQuotaReport.Fraction` both rows are red (`Plain` expected); check restored. |

## Not done / residual
- The `src_server` and AOT/trim analyzer diagnostics that the coder noted are untouched and unchecked against the base.
- Code gate not re-run (out of scope).

## Results
- Build (`dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers`): 0 warnings, 0 errors.
- Changed classes (`ARoundThatEndsSpentParksTheQuotaTests`, `TheRoundParksAndLiftsTheQuotaTests`, `ASpentQuotaIsRememberedUntilItsResetTests`,
  `TheAgyQuotaReportPicksTheResetTests`, `ACoolingRowStaysOutOfTheRoundTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`): 54 of 54 passed.
- Whole MCP suite, once, after the commit (16:18): 13,886 total, 13,768 passed, 117 skipped, 1 failed — `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_…`.
  Re-run alone, it fails the same way: `ArgumentOutOfRangeException … shown.sock … invalid length for use with domain sockets`. This session's `TMPDIR`
  (`…/8aa1d6ed6f50/tmp`) makes the socket path longer than 108 characters; the test touches nothing this branch changes. Environmental, as the coder found; not fixed.
- `dotnet format whitespace` and `dotnet format style --severity warn` with `--verify-no-changes`: clean.
- Extension tests: not run — `src_vs_code` is untouched by this fix (the coder's own run was exit 0).
- Test binary on Linux is `src_mcp/tests/bin/Debug/net10.0/CoaiMcp.Tests` (no `.exe`).
