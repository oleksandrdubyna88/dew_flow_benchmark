# REVIEW — a spent quota cools the model down (branch feat/quota-cooldown, base 6786582e)

Reviewer notes, written BEFORE any code change. Times UTC. Scope: `todo/PLAN_a_spent_quota_cools_the_model_down.md`
(D1–D12, S1–S43, §7 DoD, §12 deviations), the 42 files of `git diff 6786582e..HEAD`.

## What I read

- Instructions: AGENTS.md → ENTRY.md → PROJECT.md; resolver `explain` for audit/implement/test on the changed files; selected
  rules read in full: csharp.doctrine, typescript.doctrine, common.coding-style (always). The coder's notes (code.md) read.
- Production: QuotaCooldowns.cs, AgyQuotaReport.cs, AgyError.cs, AntigravityRuntime.cs (RateLimited, QuotaKeyOf, ReadResetAsync),
  ClaudeRuntime.cs (RateLimited), ReviewerExecutor.cs (verdict→outcome), ReviewerRuntime.cs (interface defaults), BoundedScheduler.cs
  (Hopeless), PanelService.cs (CanRun, CoolingOf, ReasonFor, ProbeAsync, OfferCooldownNotice), RoundEngine.cs (the call),
  ServerJsonContext.cs (wire), providers.ts, cooldownWords.ts, modelCard.ts, modelCardWorld.ts, modelsTab.ts, statedReset.ts.
- Tests: every S-name located (all 43 present; S34 is one test in the report file plus a round test named `..._ThroughTheRound`);
  assertions of S1–S43 read; the TS test read.
- Decisions D1–D12 checked one by one against the code (see "Decisions checked" below).

## Findings

| id | severity | file:line | finding | fix |
|---|---|---|---|---|
| H1 | major | src_mcp/runners/Reviewers/AgyQuotaReport.cs:202-204 | `AgyReset.Decide` parks an UNDECIDED refusal (`Spent == null`) when the gauge says `SpentWithoutReset`: the ternary calls `FromText` without the `spent == true` guard, so a transient refusal gets a stated/guess park. Plan D5/D6: an undecided refusal with a cannot-check (incl. a spent bucket without `reset_time`) parks nothing; §10 and the DoD say the undetermined is never a parked row. | Guard the branch with `spent == true`; otherwise `NotParked` with the note "could not check /quota (…)". Red first: a round test with an undecided refusal and QUOTA_REAL with `gemini-weekly` at 0 and no `reset_time` must stay unparked. |
| H2 | major | src_mcp/runners/Reviewers/AgyError.cs:32-58 | The parser is line-based: the owner's `AGY_ERROR: {` sample in plan §1 is a MULTI-LINE pretty JSON, so `ReadLine` gets `{` alone, parses nothing, and the structured `Spent: true` verdict is lost (the outcome falls back to the word scan, `Spent == null`; only the gauge path can still park it). No test covers a multi-line AGY_ERROR; the committed stderr fixture is single-line. | Read the JSON object that starts at the first `{` after the marker across lines (`JsonDocument.ParseValue` over the stderr from that brace), keep one-line behaviour. Red first: a test over the §1 multi-line sample expects `Spent == true`. |
| H3 | minor | src_mcp/runners/Reviewers/QuotaCooldowns.cs:209-233 | `DecidedKeyAsync` has cyclomatic complexity ≈6 (rule csharp.doctrine §6 and plan §4 story 2: ≤ 4). | Extract the "refused" pick and the "no-probe" outcome into small private static methods. Behaviour unchanged, covered by S22–S25/S41/S42. |
| H4 | minor | src_mcp/runners/Reviewers/AgyQuotaReport.cs:188-205 | `AgyReset.Decide` has complexity ≈5 (csharp.doctrine §6). | Split the Available / SpentWithoutReset branches into a helper, as in H3. Covered by S24, S34, S41. |
| H5 | minor | src_mcp/runners/Reviewers/AntigravityRuntime.cs:~200 (`RateLimited`) | Complexity ≈5 (`?:`, `??`, `?:`, `?:`). | Not fixed unless cheap after H1–H4; `??` and collection expression are the readable shape. |
| H6 | minor | src_mcp/runners/Reviewers/QuotaCooldowns.cs:223 vs :352 | `DecidedKeyAsync` computes `consecutive` from an UNLOCKED `Standing` read and passes it to `ReadResetAsync`; `ParkOp.Applied` recomputes the stored count under the lock. If another process parks the same key between the two reads, the until-instant uses the stale count while the stored count is right. | Not fixed. Plan D5 puts the probe outside the lock by design; the window is one round's probe, and the effect is one guess step (30 min doublings) on a race between two processes. Recorded here. |
| H7 | minor | src_vs_code/src/test/aCoolingRowSaysWhenItIsBack.test.ts:70-95 | S33 reads the card through `pageTree` (the static markup) and not `runPageHtml` as the plan's S33 says. | Not fixed. `pageTree` is the harness the other card tests use (`pageDom.ts`); the cooldown line and badge are static markup, so the tree is what the page shows. Plan wording differs; behaviour is checked. |
| H8 | minor | plan §4 S34 vs test `TheRoundParksAndLiftsTheQuotaTests.ArgonSpent…ThroughTheRound` | The round half of S34 uses undecided rows (coder's deviation 5, recorded in §12). The plan's "both ended spent" would contradict S41's contradiction rule. | Accepted: the deviation is recorded and the plan is internally inconsistent here. No change. |

## Decisions checked (D1–D12)

- D1 (tri-state verdict, `Hopeless` reads `Spent` first, ResetOutlasts unchanged): implemented as written (BoundedScheduler.cs:681-682, ReviewerExecutor.cs:226-232, 266-285).
- D2 (agy from AGY_ERROR, both observed shapes, exit 3 / 429 / retryable / stream status not read): shapes handled by name; multi-line sample NOT handled (H2).
- D3 (key per quota, explicit table, unknown family own key, Claude/Codex/Kimi keys, empty for local/api/remote/custom/vibe/deepseek): matches; `CustomCodexRuntime` and `DeepseekRuntime` override empty; Local/Api/Remote/Vibe use the interface default (empty).
- D4 (file under the data dir, `AtomicFile`, fail-open read, refused write with notice, `HeldFile.TakeWithin` lock, no unlocked write, expiry at the instant with no write, lift on Ok): matches; the two-process tests S35–S37 discriminate.
- D5 (after the round, per key, one probe per key, spent wins over Ok, lift on Ok, cancellation parks nothing, doubling restarts after expiry, `consecutive` passed in): matches; H1 is the one exception (undecided + SpentWithoutReset).
- D6 (`/quota` argv = owner's command, no `--disable-slash-commands`, group by id, the edge cases): matches; S15 and S40 test it.
- D7 (Claude spend limit `RateLimited`, `Spent == true`, one launch, RateLimited checked before WhyItFailed): matches; S7 pins the order.
- D8 (UTC on the server, viewer's zone on the card, `dd.MM.yyyy HH:mm`, Paris as a test parameter): matches; cooldownWords.ts.
- D9 (wire `cooldown`, `CanRun` fourth condition, `ReasonFor` words, card line replaces the reset line, badge `cooling down`): matches.
- D10 (five states table): matches the code paths.
- D11 (no new `ReviewerOutcome` subtype, excluded from the roster, security roster shares `_canRun`): matches.
- D12 (scope): nothing outside the plan found in the diff except the documented `PanelService` allow-list entries.

## Scenario check (S1–S43)

Every name exists. Assertions read against each *Then*:
- S1–S8, S9–S15, S40, S43, S16–S21, S35–S39, S22–S25, S34 (round half: deviation 5), S41, S42, S26–S29, S38, S30–S33: assertions match the Then-clauses in the plan.
- Vacuity: S3 has no break that the first case discriminates (the plan's first case stays hopeless through ResetOutlasts); the coder added a words-only case that does. S27, S35 and S36 break-its were not run; reasoning says each test would fail under the named break (a per-CLI key, an unlocked write). Not a defect.
- S13 and the undecided + SpentWithoutReset path (H1) have no test; S2 and S14 are asserted through the stub's prefix rule, as the coder recorded.

## Outcomes

- **H1 — fixed** (commit 7d93ad5f). Red first: `AnUndecidedExhaustion_WithASpentBucketThatNamesNoReset_IsNotParked` failed with
  `Expected store.Standing("antigravity/gemini", Now) to be <null>, but found QuotaCooldownEntry { Source = "guess", … }`. Green after
  `AgyReset.Decide` was split: an undecided refusal with a cannot-check is `NotParked`; a decided-spent one is still parked on its text.
- **H2 — fixed** (commit f3ffa608). Red first: `TheMultiLineSample_IsReadToo` failed with `Expected verdict.Spent to be True, but found
  <null>`. Green after `AgyError.Parse` reads the JSON after each marker across lines (`JsonDocument.ParseValue`), one-line shapes unchanged.
- **H3 — fixed** (commit 7ca50f74). Refactor: `DecidedKeyAsync` → `Refusal` / `ParkOfAsync` / `ResetOfAsync`; behaviour unchanged,
  covered by S22–S25, S34, S41, S42 (green).
- **H4 — fixed** (commit 7d93ad5f, with H1). `AgyReset.Decide` → `FromQuota` / `Available` / `Unchecked` / `Why`, each at complexity ≤ 4.
- **H5 — fixed** (commit 8f679f65). `AntigravityRuntime.RateLimited` → `Exhaustion` picks the line; `RateLimited` maps it. Covered by S4–S8.
- **H6 — not fixed.** The unlocked `consecutive` read in `ResetOfAsync` can be one step stale against a concurrent park of the same key
  by another process. Plan D5 puts the probe outside the lock by design; the effect is one doubling step on a two-process race, and the stored
  count is recomputed under the lock. Recorded, not changed.
- **H7 — not fixed.** S33 reads the card through `pageTree` and not `runPageHtml`. `pageTree` is the harness the other card tests use; the
  cooldown line and badge are static markup. The behaviour is checked; the harness differs from the plan's wording.
- **H8 — accepted, no change.** The round half of S34 uses undecided rows (coder's deviation 5). The plan's "both ended spent" would contradict
  S41's rule, so the deviation is the consistent reading.

## Final results

Commands, all through `low-priority.mjs`, on the final code (commit 8f679f65):

- Build (`dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers`): succeeded, 0 warnings, 0 errors.
- Focused classes (quota, agy, Claude, Kimi, gate, cooling-row, stated-reset): 729 total, 0 failed (rest skipped, Windows-only).
- Whole MCP suite, once: 13,881 total, 13,763 passed, 117 skipped, 1 failed. The one failure is
  `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: the Unix-socket path under this
  session's TMPDIR (`.../r/8aa1d6ed6f50/tmp/...`) is over the 108-character limit. It fails alone too (1 of 32 in its class). It touches nothing
  this branch changes. Not re-run with a short TMPDIR: setting the variable needed approval in this session.
- Format: `dotnet format whitespace --verify-no-changes` and `dotnet format style --severity warn --verify-no-changes` clean. The plan's
  full `dotnet format ... --verify-no-changes` reports only AOT/trim diagnostics (IL2026, IL3050) in `src_server` and `src_bugs` files
  I did not touch, the same as the coder recorded.
- Extension (`npm --prefix src_vs_code test`, src_vs_code not changed here): every test file reports 0 failures; the run ended with a
  cleanup notice about a temp folder held by a scanner, not a failure. Exit status was not captured separately.
