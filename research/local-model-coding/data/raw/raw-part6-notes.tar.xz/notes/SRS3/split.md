# Split of PLAN_a_spent_quota_cools_the_model_down.md — decisions (judge, Sonnet; base 6786582e on feat/quota-cooldown)

Seven tasks, 43 scenarios (S1–S43, each exactly once in `tasks.json`), every file in exactly one task. Task documents: `work/t1.md … t7.md`; list: `work/tasks.json`.

| id | scope | scenarios | depends |
|---|---|---|---|
| t1 | three-valued `Spent` on verdict/outcome + `Hopeless`; `QuotaReset`; `IReviewerRuntime.QuotaKeyOf/ReadResetAsync`; codex/kimi keys | S1–S3 | – |
| t2 | agy `/quota` reader: `AgyQuotaGroups` table, `AgyQuotaReport.Parse/ResetFor`, `AgyQuotaProbe`; fixture `quota-sample.json` | S9–S15, S40, S43 (+S34 first half) | – |
| t3 | `AgyError`, agy `RateLimited`/`QuotaKeyOf`/`ReadResetAsync`, Claude `RateLimited`/`QuotaKeyOf`, the `AClaudeReasonInItsEnvelopeTests` pin | S4–S8 | t1, t2 |
| t4 | `QuotaCooldowns` store (file + lock + `Apply`), `RetryLadder` note | S16–S21, S35–S37, S39 | t1 |
| t5 | `AfterRoundAsync` (partial class, second file), runners docs, RESULTS §3.4 | S22–S25, S34, S41, S42 | t3, t4 |
| t6 | `PanelService` (`CanRun`, `ReasonFor`, `ProbeAsync`), `ServerJsonContext`, `RoundEngine`, `module_server.md` | S26–S29, S38 | t3, t4, t5 |
| t7 | extension (`cooldownWords.ts`, parser, card, badge), `module_extension.md`, `module_tests.md`, the plan's status + deviations | S30–S33 | t1–t6 |

Parallel waves: {t1, t2} → {t3, t4} → t5 → t6 → t7. t7 only depends on the others because the plan file must belong to the LAST task; the TS work itself is independent of the C#.

## Architecture decisions the plan left open (all written into the task documents)

1. **Shared vocabulary lives in t1** so later tasks compile against it without owning the same file: `QuotaReset(Source, UntilUtc, Note, Reading)`, `QuotaReading {NotAsked, Spent, Available, CannotCheck}`, `QuotaSources`, `QuotaKeys`. `Reading` is how agy's gauge result reaches the park rule through the plan's FIXED `ReadResetAsync` signature (which has no `Spent` argument).
2. **Park rule** (t5): per key, `refusal` = first `RateLimited{Spent:true}` else first `RateLimited{Spent:null}` that `RateLimit.Hopeless`; a refusal beats a sibling `Ok`; undecided + `Reading.Available` → "transient", undecided + `CannotCheck` → "could not check", neither parked; `Spent==true` is always parked (on `stated`/`guess` with a contradiction note when the gauge read Available). Generic — no vendor-name `if`.
3. **Store API** (t4): `Standing(key, now)`, `Park`, `Lift`, and `Apply(IReadOnlyList<QuotaMove>)` — the one locked read-modify-write the round's aggregate uses. No write when nothing changes (`CooldownWrite.Unchanged`), so S36 run 2 can assert "A wrote nothing". `QuotaCooldowns` is a `partial` class so t4 and t5 own different files. Test seams: `internal AfterLockedRead`, `internal Wrote(bool)`. `Consecutive` = 1 for a first guess park, +1 when a guess stands.
4. **`AfterRoundAsync(results, launcher, ct)`** takes the launcher (the plan's `(results, ct)` has no way to reach `IProcessLauncher`); `RoundEngine` gets `QuotaCooldowns` + `IProcessLauncher` as last ctor parameters. Returns the same list instance.
5. **Notice for a refused write**: `QuotaCooldowns` lives in the Runners assembly and cannot see `NoticeWriter`/`Noticing`; it takes an `Action<string> refused` callback, `PanelService` turns it into one `ServerNotice` with the EXISTING code `storage-note` (no new code → no census/guard churn). The string-building helper `PanelService.CooldownRefusalNotice` is `internal static` and has a direct test.
6. **Codex key**: `ProviderOverrides.Any() ? "" : "codex"` — `DeepseekRuntime` also inherits `CodexRuntime` and would otherwise park the real codex quota; both it and `CustomCodexRuntime` already override `ProviderOverrides`.
7. **`AgyQuotaGroups.KeyOf("")`** = the runtime default model's key (an agy row without a model runs `gemini-3.7-flash-high`).
8. **ReasonFor order** (t6): no adapter → row refusal → `AuthFor == unavailable` (existing reason) → cooling sentence, so a cooling sentence never replaces a more basic reason.
9. **Card** (t7): `modelCard.ts` computes the line from `facts.context.reported[id].cooldown` and `facts.now` itself — `modelsTab.ts` is not in the plan and not needed. `verdictBadge` gets an optional `nowMs` third parameter. `spanOf` in `resetWords.ts` is exported (that file joins t7's list; the plan said "reused by export" without listing the file).
10. **Claude spend verdict** carries `ReadUsage` (the NonZeroExit path used to record it; keep the ledger honest).
11. **Extra tests added** (marked EXTRA in the briefs): `TheRuntimesNameTheirQuotaTests` (t1), three in `AnAgyQuotaIsReadFromItsStructuredErrorTests` (t3), `TheRefusedWrite_BecomesOneStorageNotice` (t6) — each task is self-checking since nobody reviews a task alone.

## Plan inconsistencies found while reading, and how the briefs resolve them (t7 records them in the plan as §12)

- **S34** says "both rows ended spent" yet "only argon stands": by D5/S41 an explicit `Spent==true` refusal is parked even when its gauge reads Available. Resolution: report half in t2 (`ResetFor` only); round half in t5 as `ArgonSpent_ThroughTheRound_ParksOnlyArgon` with the Gemini row UNDECIDED.
- **S25**'s codex sentence ("refresh on July 15, 2026") predates the plan's shared `NOW` (2026-10-11): the codex part runs on its own clock (2026-07-01).
- **S33** expects the Paris line from the card, but the card has no zone parameter (viewer's zone is the point): the test matches a pattern and `cooldownLine(...)` in the host's zone; Paris/Kyiv/winter are pinned in S31.
- **D5 vs D6 wording**: "a spent bucket without `reset_time`" is "cannot check" in D5 but a distinct `SpentWithoutReset` verdict in D6; t3 maps it to `Reading.CannotCheck` (D5 literal) so an undecided refusal is not parked on it.
- The plan's `Standing("antigravity/?...")` unknown-family keys and the `3p` row for a Claude model on agy are kept as written.

## Risks I could not close (no time to run anything; I wrote no code)

- Whether `RateLimit.Hopeless` is true for the S24 reason ("RESOURCE_EXHAUSTED (code 429): Too many requests"): the brief tells the coder to report, not change the rule, if it is not.
- `ProviderSettings` spelling for a second agy row (`Runtime = "antigravity"`?) and whether `AuthFor` lets a bare antigravity row run on this host: t6 sends the coder to the neighbouring tests and forbids weakening production rules.
- `ReviewerSummaryFactory.Describe` text for `RateLimited` ("rate limited (after 1 attempt)") is the plan's claim; t3 lets the coder assert the real prefix and say so.
- Linux advisory-lock behaviour for two handles in one process (S35–S37): the plan asserts it; t4 requires the S35 break-it to be run.
- Wall clock: the Workflow's per-task commands run the full 13.8k-test suite last; budget accordingly.
