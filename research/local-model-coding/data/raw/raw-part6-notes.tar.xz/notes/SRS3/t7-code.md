# t7 — code notes

Commit 0c6117d9 on feat/quota-cooldown (not pushed).

## Done
- `cooldownWords.ts` (new): `CooldownFacts`, `cooldownLine` with the three wordings; stamp built with the en-GB formatToParts contract; span from `spanOf`.
- `resetWords.ts`: `spanOf` exported, nothing else changed.
- `providers.ts`: `ProviderHealth.cooldown?`, `cooldownOf` spread in `oneProvider`.
- `modelCardWorld.ts`: `verdictBadge(id, context, nowMs)` → `coolingBadge` + `availableBadge` (split to meet the lint complexity limit of 4).
- `modelCard.ts`: `top` passes `facts.now`; `foot` draws `cooldown-line` instead of `reset-line` while a cooldown stands.
- `statedReset.ts`: header paragraph's last sentence replaced; no code change.
- Test `aCoolingRowSaysWhenItIsBack.test.ts`: S30–S33.
- Docs: `module_extension.md` (new section at end), `module_tests.md` (new section at end with the flow table and NOT proved list).
- Plan: status line, §12 deviations, DoD card box ticked.

## Red
- Stub stage (cooldownWords returns ''): S31, S32, S33 red. S31 `Expected values to be strictly equal: '' !== 'quota spent — back 14.10.2026 09:19 (in 63 h)'` (as the document). S32 the same shape for the `stated` wording.
- S33 red message differs from the document: the document's `null !== 'quota spent — back …'`; ours is `the page draws no cooldown line on the claude card` (the `pageTree.one` message), because the foot had no `cooldown-line` element at all.
- S30 red: the parser spread was removed for the check: `Expected values to be strictly deep-equal: undefined !== {…}` as the document. The spread was then restored.
- Break-it S33 (draw `reset-line` too): `AssertionError: the ledger's reset line is drawn beside the cooldown line …` (`true !== false`) on the `.reset-line` assertion. Restored.

## Deviations from the document's contracts / steps
- S31: "NOW_MS + 33 min as ISO → (in 34 min)" cannot hold under the rounded-UP rule (33 min exactly is `33 min`). The test uses `NOW_MS + 33.5 min` and says why in its message. Recorded here only; not in the plan's §12 list (which the lead specified verbatim).
- S31 winter case: 2026-12-01T07:19:16Z from 2026-10-11T16:30Z is 1215 h (rounded up), asserted as `(in 1215 h)`.
- `verdictBadge` helpers split (`coolingBadge`, `availableBadge`) and `cooldownLine` split (`wordsOf`, `saidOf`, `stampOf`) because `eslint` complexity max is 4; behaviour unchanged.
- The `cooldownLine` comment on NaN is a one-liner, not in the contract's doc.

## Checks run
- `npm run typecheck` clean (before and after changes).
- `eslint` on the seven changed source/test files: clean.
- `npx tsc -p ./` then `node --test` on: `aCoolingRowSaysWhenItIsBack`, `modelsTab`, `providersBadge`, `statedReset`, `roundsBlock` → 73 pass, 0 fail. Neighbouring card/panel suites (`cardGauge`, `panelView`, `bundledPage`, `twoCliPathFieldsOnTheCard`, `vendorClassIsNotACard`, `aWarnedReviewerIsShown`, `apiSettingsCard`, `kimiNetworkSignInSetting`, `aRowHasAFastModeSwitch`, `theCheckButtonIsNotOfferedOnAReviewerOnlyRow`, `teamServerTab`, `vendorColour`) → 233 pass, 0 fail.
- `plan-lifecycle` clean (after changing the status to "built … not promoted", because "implemented" is the promoted verdict and the plan is not promoted).

## Not run
- Full `npm test` (the whole extension suite) and the C# build/test commands: the brief said not to run the whole suite. The task's Done-when asks for `npm test` green — NOT verified by me.
- `dotnet build` / `CoaiMcp.Tests.exe`: not run (the C# side is untouched by this task).

## Open (from the sibling notes, not this task)
- `notes/t4-code.md` records an open failure: `EveryBudgetInAClockedClassReadsItsClockTests` reports `QuotaCooldowns.cs` as unscanned. Still open; the plan's status says "not promoted" until it closes.
