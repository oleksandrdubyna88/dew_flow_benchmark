# Review of todo/PLAN_a_spent_quota_cools_the_model_down.md — branch feat/quota-cooldown

Scope: commits after 6786582e30d3e771549d05ed719478396f8099cd (7 feat commits, 38 files). Reviewed before any code change (Step 1).
Read: AGENTS.md → ENTRY.md, PROJECT.md; resolver `explain` for the changed files (selected rules listed in the run; the
long rule texts were checked by a reviewing agent, see H-rules below). Plan §4 (S1–S43) mapped by a scout agent and
spot-verified by me; production diff read in full by me (QuotaCooldowns*.cs, AgyQuotaReport.cs, AgyError.cs,
AntigravityRuntime.cs, ClaudeRuntime.cs, ReviewerExecutor/BoundedScheduler/ReviewerRuntime/Kimi/Codex diffs,
PanelService.cs, RoundEngine.cs, ServerJsonContext.cs, the extension files).

Baseline before fixes: `dotnet build` (solution) succeeded, 0 warnings. `npm run typecheck` clean. `npm run lint` see below.
Full MCP suite: run before fixes (log in the scratchpad), see the final report.

## Findings

| id | severity | file:line | one sentence | fix |
|---|---|---|---|---|
| H1 | blocking | src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs (the `Clocked` / `Unscanned` lists, ~l.24–50) | The clock guard is RED on this branch: `QuotaCooldowns.cs` (ctor takes a TimeProvider) is in neither list, and `PanelService.cs` (ctor now takes `TimeProvider? clock`) is in neither either; the base commit was green. | Add `QuotaCooldowns.cs` to `Clocked` (the plan §6 says it joins the list in story 2); add `PanelService.cs` to `Unscanned` with an accurate reason (it reads its clock only for the quota instants, and carries pre-existing `DateTime.UtcNow` stamps that are not budgets). |
| H2 | major | src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs:153, 156, 159, 299, 304, 311 | `store.Standing(...)?.Consecutive.Should()` short-circuits when the entry is missing, so S21's doubling counter and S39's gap-restart counter pass silently in the very case they guard (a park that wrote nothing). | Assert non-null first (`Standing(...)!.Consecutive`, the house style at line 147), so a missing entry is red. |
| H3 | major | src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs (S36, `parkRun.Should().NotBeEmpty().And.OnlyContain(wrote => wrote)`) and src_mcp/runners/Reviewers/QuotaCooldowns.cs:61,160 | The `Wrote` seam is `Action<bool>` and production always passes `true`, so the "no write outside the lock" check in S36 can never fail. | Make the seam `Action` (no constant bool) and assert the write count per run instead (run 1: two writes; run 2: one). The lock itself is proven by the 300 ms blocking checks, which stay. |
| H4 | minor | src_mcp/runners/Reviewers/AntigravityRuntime.cs:202 | The gauge note formats the instant with `yyyy-MM-ddTHH:mm:ssZ` without `InvariantCulture`, so the `:` separator follows the host's culture. | Pass `CultureInfo.InvariantCulture` (the same as `QuotaCooldowns.Stamp`). |
| H5 | minor | src_mcp/src/Server/PanelService.cs:338 and src_mcp/runners/Reviewers/QuotaCooldowns.cs:233 | Two copies of the same ISO-8601 UTC formatter. | Reuse one (make `QuotaCooldowns.Stamp` internal and call it from PanelService). |
| H6 | minor | src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs (S35 name) | The test is `TwoWritersInterleavedUnderTheLock_LoseNeitherKey`, the plan names it `TwoWriters_InterleavedUnderTheLock_LoseNeitherKey`. | Rename to the plan's name (no behaviour change). |
| H7 | minor | src_mcp/src/Server/PanelService.cs:~110 (the `refused:` lambda) | The refused-write → server-notice wiring is not exercised by any test; S37 covers only the store's callback and the static notice factory. | Not fixed: needs a PanelService-level harness; the wiring is one line and is covered by reading. |
| H8 | minor | src_mcp/tests/TheAgyQuotaReportPicksTheResetTests.cs:~226 (S40 rows "missing", "-1", "2") | Those rows expect Available, which does not discriminate the skip logic (only "unreadable counted as spent" is caught). | Not fixed: the rows do catch the mutation the plan names as the danger (unreadable = spent), and the other S40 rows discriminate. |
| H9 | minor | src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs:~140–147 (S25 Kimi) | Only `Source` is asserted for the Kimi row, not its `UntilUtc`. | Not fixed: the guess instant is covered by S21's `QuotaReset.Guess` test; a gap, not a defect. |
| H10 | minor (doc) | todo/PLAN_a_spent_quota_cools_the_model_down.md, D9 example vs S32 | D9 writes `next try 11.10.2026 17:00 (in 30 min)` (UTC) where S32 writes `19:00` (Paris, the zone the card uses). | Not fixed in this review: a plan-text inconsistency for the owner; the code follows S32. |
| H11 | minor | src_mcp/runners/Reviewers/QuotaCooldowns.Round.cs:10–30 | A cancelled probe discards every move of the round, including lifts for other keys. | Not fixed: a lift that is dropped only leaves a standing entry until its own reset; it fails safe toward parking, which the plan's "parks nothing" also says. |
| H12 | minor | src_mcp/runners/Reviewers/QuotaCooldowns.cs:~181 | The "warn once per process" flag is per instance, not per process. | Not fixed: PanelService makes one store, and the `--providers` one-shot makes its own process; the plan's intent holds. |

## Rules (the reviewing agent's findings are appended below when it reports)

## Checked and right (not findings)

- D1: `Hopeless` is `limited.Spent ?? RateLimit.Hopeless(...)` with the ResetOutlasts half unchanged (BoundedScheduler.cs:681).
- D2: AgyError parses both shapes by name; AntigravityRuntime.RateLimited uses the structured line, exit 0 and non-RESOURCE_EXHAUSTED fall to ByText.
- D3: AgyQuotaGroups table and KeyOf match the plan's table; no prefix rule; unknown → `antigravity/?<model>`.
- D4/F3: every write runs under the lock (HeldFile.TakeWithin), re-reads under the lock, AtomicFile.Write, refusal is a value; reads take no lock.
- D5: aggregate per key, a spent refusal wins over Ok, one probe per refused key outside the lock, cancellation never throws past the engine.
- D6: probe argv is the owner's command; NO --disable-slash-commands; the fixtures parse as single JSON documents.
- D7: Classified asks RateLimited before WhyItFailed (ReviewerExecutor.cs:1016).
- D9/D10/D11: CanRun gains the cooldown term; ReasonFor/CoolingSentence name no vendor text; ProviderStatus.Cooldown is nullable and omitted when null.
- D8: extension formats in the viewer's zone (stampOf), spanOf reused by export.
- Typecheck clean.

## Outcomes (Step 2)

- H1 — FIXED. Red first: the guard failed on QuotaCooldowns.cs and PanelService.cs. QuotaCooldowns.cs is now in `Clocked`; PanelService.cs is in `Unscanned` with its reason (its DateTime.UtcNow reads are stamps, as RoundsDb's are). Guard green.
- H2 — FIXED. `?.Consecutive.Should()` → `!.Consecutive.Should()` (6 sites). A missing entry is now red. Not separately red-proved against a broken Park; the assertion throws on null by construction.
- H3 — FIXED. `Wrote` is an `Action`; S36 asserts write order (`"A","B"` run 1, `"B"` run 2) instead of a constant `OnlyContain(true)`.
- H4 — FIXED. The agy gauge note uses `QuotaCooldowns.Stamp`, which is invariant.
- H5 — FIXED. `PanelService.IsoUtc` removed; `QuotaCooldowns.Stamp` is the one formatter (now public).
- H6 — FIXED. S35 test renamed to the plan's `TwoWriters_InterleavedUnderTheLock_LoseNeitherKey`.
- H7 — NOT FIXED. The refused → notice wiring in PanelService has no test. Needs a PanelService harness; one line, read-verified.
- H8 — NOT FIXED. S40 rows expecting Available do not catch "skip logic missing", but do catch "unreadable counted as spent" (the danger the plan names).
- H9 — NOT FIXED. Kimi row asserts Source only; the guess instant is covered by S21.
- H10 — NOT FIXED (plan text). D9's example is UTC (17:00) and S32 is Paris (19:00); the code follows S32. For the owner to reconcile.
- H11 — FIXED (see rules-major below): an unrequested cancel no longer drops the round's moves. A requested cancel still drops them (plan D5: a cancelled probe parks nothing).
- H12 — NOT FIXED. The warn-once flag is per instance; one store per PanelService, so the intent holds.

Rules review (opus judge, via agent) — outcomes:
- Blocking (clock guard) — FIXED (H1).
- Major: lock wait `Thread.Sleep` (up to 30 s) on a pool thread with no CancellationToken (HeldFile.TakeWithin, reached from AfterRoundAsync). NOT FIXED: bounded at 30 s, contends only with another coai process; a Task.Run wrap moves the block rather than removing it. Recorded as an open item for the owner.
- Major: `when (e is not OperationCanceledException)` → `when (!ct.IsCancellationRequested)` in ParkOrSkipAsync. FIXED, test first: AProbeThatCancelsItself_ParksNothingOfItsKey_AndStillLiftsTheOthers was red ("claude" not lifted, the round's moves dropped), green after.
- Major: the `?.Consecutive` silent passes — FIXED (H2).
- Major: S36-style constant seam — FIXED (H3).
- Major: ACoolingRowStaysOut does not prove the `refused:` wiring — NOT FIXED (H7).
- Major: complexity ≤ 4 (plan §9): ClaudeRuntime.IsSpendLimit split (ApiErrorCode, ReasonOf); QuotaCooldowns.Entry (Text helper) and Parked (ConsecutiveAfter). FIXED.
- Major: `bool?` for Spent and `AgyQuotaRead` with a nullable report; EnsureDirectory's nullable reason. NOT FIXED: `bool?` is the plan's D1 decision (three values); the rest is a judgement call, recorded as wrong on a second look to change now.
- Minor: stamp duplicates — FIXED (H4/H5). cooldownWords.ts stampOf vs resetWords clockOf — NOT FIXED (different format: clockOf is HH:mm; the stamp adds the date). Arguments public mutable array — NOT FIXED (ProcessRequest takes string[]). Timeout literal — FIXED (derived from Timeout). Real-time waits in tests (Task.Delay as negative check) — NOT FIXED (plan-prescribed FinishesWithin checks). File split: NOT FIXED (under the limit).
- Also found by the full-suite run (not by the agent): TheRefusalsAreWrittenDownTests census did not list PanelService.cs as a notice producer. FIXED: added with a comment (the census is the mechanism the test describes).
- RegularFilesTests fifo test failed in the baseline run — environment (FIFO on WSL); checked in the after-run.

## Final results (after fixes, commit 0b1f3917)

- Build: solution succeeded, 0 warnings, 0 errors.
- MCP suite: 13,886 total, 13,768 passed, 1 failed, 117 skipped. The failure is RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed: the Unix socket path is 108+ characters on this checkout (the test's temp folder is under the long repo path). It fails the same way in the baseline run; the test is not touched by this branch. Not fixed: it is environment-specific (the checkout path), and the fix belongs to the test's temp-folder helper, outside this review.
- Baseline (before fixes): 13,885 total, 3 failed (the clock guard, the notice census, the FIFO test).
- Format: dotnet format --verify-no-changes clean for src_mcp/src, src_mcp/runners, src_mcp/tests. The solution-wide run exits 2 on AOT analyzer errors in src_server and src_bugs, which this branch does not touch.
- Extension: typecheck clean; lint exit 0; npm test exit 0, 6,662 tests, 0 failures.
