# t4 — the record `quota-cooldowns.json` under its lock (notes)

## Done

- `src_mcp/runners/Reviewers/QuotaCooldowns.cs` (new, under 400 lines, DTO + JSON context in the same file; `QuotaCooldownsJson.cs` not created): the records and the `partial class QuotaCooldowns` with `Standing`, `Park`, `Lift`, `Apply`; reads without lock or cache, fail open with one warning per instance; every write under `quota-cooldowns.lock` via `HeldFile.TakeWithin`, re-read under the lock, `AtomicFile.Write` only on a real change; refusals are `CooldownWrite.Refused` + one log warning + one `refused` callback.
- `src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs` (new): S16, S17, S18, S19, S20, S21, S35, S36, S37, S39 (11 test methods; S37 is split into a lock-held test and a data-dir-is-a-file test; S36 and S21 hold their two runs in one method each).
- `src_mcp/runners/Reviewers/RetryLadder.cs`: doc comment only, the "Nothing is persisted" sentence replaced as the document gives it.

## Red

Run against the stub (all 11 red), messages seen:
- S16 `Expected standing not to be <null>.` — matches the document.
- S19 `Expected _sink.Levels to contain a single item matching ... but the collection is empty.` — assertion, not the `JsonException` the document expects (the stub never read the file).
- S18 and S17 went red on the stub's null `Standing` (`Expected answered to be ... but found <null>`), not the document's `found QuotaCooldownEntry`: the stub has no store, so no entry exists to be found after Lift.
- S18 / S35 / S36 / S37(b) / S21 / S39 / S20 on the stub: the stub never writes, so the red is a `FileNotFoundException` (S18, S20) or a null entry, not the document's `Expected entries to contain 2 item(s), but found 1` (S35 went red on `Signalled(inLock)`: the stub never calls its `AfterLockedRead` hook).
- S21 red was a NullReferenceException through `!`; changed the test to `?.Consecutive` so it is an assertion.
- S37(b) went red on `Expected type to be ...Refused, but found ...Written` (stub), not an `IOException` escaping.
- S37(a): not run as its own red line; it failed in the same run among the 11.

## Break-it (S35)

Temporarily read the table BEFORE taking the lock (`_breakItPreRead`). Result: `TwoWritersInterleavedUnderTheLock_LoseNeitherKey` failed with `Expected KeysOnDisk() to be a collection with 2 item(s), but {"claude"}` (the document's "found 1" is FluentAssertions' wording for the same loss). `AParkAndALift_...` also failed under the break-it. The production file was restored byte-for-byte from a backup copy and rebuilt; both pass again.

## Green

- `ASpentQuotaIsRememberedUntilItsResetTests`: 11 / 11 passed.
- `NoTestHoldsAnInheritableHandleTests`: 2 / 2 passed.
- Build of `dew_flow_connect_other_ais.slnx`: 0 warnings, 0 errors (after the final edits).

## NOT green — needs a decision outside this task's file list

- `EveryBudgetInAClockedClassReadsItsClockTests.EveryProductFileWhoseConstructorTakesAClock_IsScanned_OrNamedAsNotScannedWithItsReason` FAILS: it reports `src_mcp/runners/Reviewers/QuotaCooldowns.cs` as a product file whose constructor takes a `TimeProvider` and that is neither in `Clocked` nor in `Unscanned`. The fix belongs in `src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs`, which is NOT in my four files, so I did not edit it.
  - The mandated constructor takes `TimeProvider clock` (the contract), so the file cannot leave the scan by changing its constructor.
  - Options for whoever owns that test: (a) add an `Unscanned` entry for `QuotaCooldowns.cs` with its reason (a wall stamp, instant compares only, the expiry compare reads `_clock.GetUtcNow()`); or (b) think about it first: the lock wait (`HeldFile.TakeWithin`) is a 30 s budget that reads `DateTime.UtcNow` inside `HeldFile`, not the injected clock. The scan only looks at the constructor's file, so this is not caught by the scan today, but it is the same shape the scan's doc warns about. Decide whether the wait belongs on the injected clock before adding (a).
  - Suggested line for (a), if chosen: `new("src_mcp/runners/Reviewers/QuotaCooldowns.cs", "the store reads its clock only as instants (the expiry compare and the stamp of a new entry); its one wait is HeldFile.TakeWithin's bounded lock take, not a timer on this clock")` — the reviewer should check that wording against the (b) question.

## Final checks

- `dotnet format dew_flow_connect_other_ais.slnx --verify-no-changes`: exit 0. Its output printed IL2026/IL3050 errors from `src_server/src/Usage/UsageEndpoints.cs`, which is not in my files; not investigated.
- Whole MCP suite (`CoaiMcp.Tests`, 13,852 tests): 13,733 passed, 117 skipped, 2 failed.
  1. `EveryBudgetInAClockedClassReadsItsClockTests` — my file is unclassified (see above). Caused by this task; NOT fixed (needs an edit to a file outside my list).
  2. `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — re-run alone: still fails. Cause: `ArgumentOutOfRangeException` building a Unix socket path of `…/testsToDelete-regular-files-…/shown.sock`; the path is longer than the 108-character limit because this worktree lives under a long temp path. Environment, not this change; the file is not mine.

## Commit

- `0ad80a47 feat(quota): the cooldown record under its lock — quota-cooldowns.json (D4, t4)` — three files by name (`QuotaCooldowns.cs`, the test class, `RetryLadder.cs`). Not pushed.
- The commit is red on `EveryBudgetInAClockedClassReadsItsClockTests` until the `Unscanned` decision above is made.

## Left for the lead

1. Decide and add the `EveryBudget` entry (or `Clocked`) for `QuotaCooldowns.cs` in `src_mcp/tests/EveryBudgetInAClockedClassReadsItsClockTests.cs`; this is the only red I caused.
2. The `RegularFilesTests` socket-path failure is a host/worktree-path issue, not t4.
