# t2 — code notes

Commit: `18b42879` feat(agy): the /quota reader (3 files, all new).

## What was done

- `src_mcp/runners/Reviewers/AgyQuotaReport.cs` (265 lines): AgyQuotaKeys, AgyQuotaGroups (explicit table, no prefix rule), AgyQuotaBucket/Group, AgyQuotaVerdict, AgyQuotaReport (Parse, ResetFor), AgyQuotaRead, AgyQuotaProbe (ReadAsync). Everything is in this one file, so `AgyQuotaProbe.cs` was NOT created or touched (the doc says split only past 400 lines).
- `src_mcp/tests/TheAgyQuotaReportPicksTheResetTests.cs`: S9, S10, S11, S12, S13, S14, S15, S34 (first half), S40 (Theory over 8 inline cases), S43.
- `src_mcp/tests/fixtures/antigravity/quota-sample.json`: QUOTA_SAMPLE verbatim, 2-space indent, trailing newline.

## Red → green

- Stub red: 13 failing tests, all assertion messages, no compile errors. Several differ from the document's wording, e.g. S43 failed on `Expected report.Groups to contain 3 item(s), but found 0` (the stub returns an empty report), not on the bucket count. S12 failed on the verdict equality, not on `Which`.
- Green: `TheAgyQuotaReportPicksTheResetTests` 17/17 passed.
- Break-it for S14 (a `gemini-` prefix rule in `KeyOf`): `TheAgyQuotaReportPicksTheResetTests.AnUnknownModel_HasNoGroup` failed with `Expected AgyQuotaGroups.KeyOf("gemini-4-argon-low") to be the same string, but they differ at index 12`. Restored, then green again.

## Deviations and decisions

- `Parse` stub returns an empty report (not null), so the red messages are assertions rather than the `Report` helper's exception.
- `ResetFor` returns `Available` only for a key with active buckets, none at 0 (or only unknown-window buckets at 0). A key with no active bucket is `GroupMissing`.
- `ReadAsync` maps the launcher result with a switch expression (TimedOut → Cancelled → non-zero exit → parse), to keep each method at complexity ≤ 4 without a helper per branch.
- Record property `AgyQuotaReport.Groups` clashed with a private helper named `Groups`; the helper is `ReadGroups`.
- `ReadAsync`'s `Cannot("timed out after 30 s")` etc. are the exact `Why` strings from the document.
- Test helper `Edge(string)` is a switch over InlineData names rather than a MemberData TheoryData, since xUnit v3 needs serialisable theory arguments and `AgyQuotaVerdict` is a record hierarchy used as a value.
- The S34 second half (through `AfterRoundAsync`) is t5's `ArgonSpent_ThroughTheRound_ParksOnlyArgon`, as the document says.

## Not done / not run

- **Whole MCP suite not run.** The document's command list ends with the whole suite, but my coder rules say not to run it. Only `TheAgyQuotaReportPicksTheResetTests` was run. The solution build succeeded, 0 warnings.
- **`dotnet format --verify-no-changes` exits 2**, but not because of my files. The output is only IL2026/IL3050 AOT/trim diagnostics from `src_server/src/SessionEndpoints.cs` and `src_server/src/Vendors/CatalogEndpoints.cs`, which I did not touch. No format diagnostic names `AgyQuota*` or `TheAgyQuota*`. Those src_server errors are pre-existing as far as I can tell, not confirmed against the base commit.
- Instruction resolver: `rules.mjs check` resolved. I read the task-selected rules that matter for this work (`csharp.doctrine`, `common.testing`, `common.git-workflow`); I did not read every selected rule body (about 30 ids) given the 15:04 deadline.
- Commit made by path only; `src_vs_code/node_modules` untracked and left alone.
