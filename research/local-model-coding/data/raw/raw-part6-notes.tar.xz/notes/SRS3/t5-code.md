# t5 — the round parks and lifts (D5) + the runners docs

## What was done

- `src_mcp/runners/Reviewers/QuotaCooldowns.Round.cs` (new, `partial class QuotaCooldowns`): `AfterRoundAsync(results, launcher, ct)`.
  - Stub first (returns `results`), then the algorithm as the document gives it: group by `QuotaKeyOf` (empty keys dropped, first-appearance order); per key the refusal is the first `Spent: true`, else the first `Spent: null` that `RateLimit.Hopeless` names; a refusal wins over an `Ok`; no refusal + an `Ok` → `Lift`.
  - Park decision: one `ReadResetAsync` per refused key (outside the lock). Undecided + `Available` → not parked, logs `transient`; undecided + `CannotCheck` → not parked, logs `could not check`; otherwise `Park` with the note `reset.Note; the /quota gauge read Available while the refusal said spent …; the vendor said: VendorReason.Written(...)`.
  - One `Apply(moves)` per round; zero moves → no call. A `Refused` result logs `quota cooldowns: {N} move(s) not recorded`.
  - `OperationCanceledException` anywhere in the reading → logs `cancelled`, applies nothing, returns `results`. Any other exception from one key → `Warning(e, …)` and that key is skipped (`ParkOrSkipAsync`); an outer catch-all wraps the rest.
  - Helpers: `Record`, `MovesAsync`, `MoveAsync`, `ParkOrSkipAsync`, `Decide`, `NotParked`, `NoteOf`, `Pieces`, `RefusalOf`, `Refusals`, `Groups`, `KeyOf`; private record `Refusal(Invocation, RateLimited Outcome)`; a file-level `using Pair = (…)` alias (a `using` alias cannot sit inside a class body).
- `src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs` (new): S22, S23, S24, S25, S34 (second half), S41, S42 as the document names them.
- `research/module_runners.md`: the stale "Nothing is persisted" bullet (agy section) superseded; new `### The agy quota, the /quota gauge and the round's parking (2026-10-29, t5)` section (classifier, key table, `/quota` probe, parking rule, claude/kimi guesses, covered vs not covered).
- `research/RESULTS_vendor_quota_gauges.md`: new `### 3.4` with the 2026-10-28 hand capture as its first row; states that it supersedes §3.2 for agy 1.4.9.

## Red → green

Red first (stub): 7 of 7 failed, each an assertion. Messages that differ from the document:
- S22: `Expected launcher.Launched to be 1 because two rows of one group ask /quota once, but found 0` (the document expected `Expected standing not to be <null>`; the launch count is asserted first).
- S23: `Expected standing not to be <null>.` (document: `Expected source to be "stated"`; the stub has no standing).
- S24: `Expected _sink.Lines {empty} to have an item matching line.Contains("transient")` (the stub parks nothing, so the first assertion passes; the log line is the first to fail).
- S25: `Expected standing not to be <null>.` (matches).
- S34b: `Expected argon not to be <null>.` (matches the "otherwise" branch).
- S41: `Expected firstLauncher.Launched to be 1, but found 0` (document: `Expected standing not to be <null>` on `[Ok, RateLimited]`; the stub never probes).
- S42: `Expected _sink.Lines {empty} to have an item matching line.Contains("cancelled")` (the stub never launches, so no `TaskCanceledException` escapes; the document expected the escape).

Green after implementation: `TheRoundParksAndLiftsTheQuotaTests` 7/7; `ASpentQuotaIsRememberedUntilItsResetTests` 11/11.

## Deviations (recorded)

- `TimeSpan.Parse("88:49:09")` throws `OverflowException` (hours must be below 24). The document's expression cannot be used; the tests use `TimeSpan.FromHours(88) + FromMinutes(49) + FromSeconds(9)` (`Stated88h49m9s`). Same value.
- S24 with the document's "Too many requests" wording: `RateLimit.Hopeless` is true (the `RESOURCE_EXHAUSTED` word matches `exhausted`, case-insensitively), so the rule was not changed.
- S25's Codex stated date: `CooldownParser.StatedReset` read `2026-07-16T00:00:00Z` as the document expected; no change needed.

## Break-it (S41)

Temporarily made an `Ok` win over a refusal (answer-first rule). S41 failed (`Expected firstLauncher.Launched to be 1, but found 0`). Restored the real rule; the file is back to the committed-intended text.

## Verification

- Build: `dotnet build dew_flow_connect_other_ais.slnx -c Debug -m:4 --disable-build-servers` → 0 warnings, 0 errors.
- `TheRoundParksAndLiftsTheQuotaTests` 7/7; `ASpentQuotaIsRememberedUntilItsResetTests` 11/11.
- `EveryBudgetInAClockedClassReadsItsClockTests`: 8 of 9 pass; the failure is `EveryProductFileWhoseConstructorTakesAClock_IsScanned_OrNamedAsNotScannedWithItsReason`, which names `src_mcp/runners/Reviewers/QuotaCooldowns.cs`. That file is t4's (it takes a `TimeProvider` constructor and is in neither `Clocked` nor `Unscanned` of the test). It is out of my bounds, so I did not touch it. My file has no clock constructor. This failure comes from t4's commit on this branch.
- Whole suite, two full runs: 13,876 total, 13,757 passed, 117 skipped, 2 failed in both. The two failures:
  1. `EveryBudgetInAClockedClassReadsItsClockTests.EveryProductFileWhoseConstructorTakesAClock_…` — t4's `QuotaCooldowns.cs` (see below).
  2. `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed` — NOT flaky: fails alone too. Cause: `ArgumentOutOfRangeException` from `UnixDomainSocketEndPoint` because the test's socket path (`…/tmp/testsToDelete-coai-run-…/testsToDelete-regular-files-…/shown.sock`) is longer than the 108-character Unix limit, given this worktree's long temp path. Environmental; the test touches no quota code. Not fixed (not my file).
  The first run's truncated output had hidden the second name; `AFeatureIsReviewedEndToEndTests` passes 32/32 alone, so it was never a failure.
- `dotnet format --verify-no-changes` on the whole solution: fails before format runs, on IL2026/IL3050 analyzer errors in `src_server/src/*.cs` (`CoaiServer.csproj`), files I did not touch. Scoped to my two C# files (`--include`), it reports no formatting changes.

## Left / for the lead

- t4's `QuotaCooldowns.cs` needs an entry in `EveryBudgetInAClockedClassReadsItsClockTests` (`Unscanned` with a reason, or `Clocked` if its `GetUtcNow` use is judged by the scan). Its file is out of my bounds.
- The whole-solution `dotnet format --verify-no-changes` is red on `CoaiServer`'s AOT analyzers at this base; not from this task.
- A `[coai-mcp] the log could not be flushed: the log's disk is full` line appeared during the suite run; the disk shows 21 % used, and the cause is not established. No test failed because of it.
- `research/module_tests.md` is not in this task's file list, so the scenario flows are not recorded there.
- Nothing pushed; not run: `agy`, `kimi`, `vibe`, `codex`, `claude`.
