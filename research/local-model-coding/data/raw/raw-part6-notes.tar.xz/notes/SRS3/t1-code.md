# t1 — code notes

Task: `work/t1.md` (D1 verdict `Spent` + the runtime quota members).

## What was done

- `ReviewerExecutor.cs`: `RateLimitVerdict.Spent` (`bool?`, init) and `Because(reason, usage, bool? spent = null)`;
  `ReviewerOutcome.RateLimited.Spent` (`bool?`, init); `Classified` carries `verdict.Spent` onto the limited outcome.
- `BoundedScheduler.cs`: `Hopeless` reads `limited.Spent ?? RateLimit.Hopeless(limited.Reason)` first; the `ResetOutlasts` half is unchanged.
  `RateLimit.Spent`/`RateLimit.Hopeless` untouched.
- `QuotaReset.cs` (new): `QuotaKeys`, `QuotaSources`, `QuotaReading`, `QuotaReset` with `Stated`, `Guess`, `FromGauge`, `FromText` — exactly the contract.
- `ReviewerRuntime.cs`: `IReviewerRuntime.QuotaKeyOf` (default empty) and `ReadResetAsync` (default `QuotaReset.FromText`) after `LaunchesOneAtATime`;
  `CodexRuntime.QuotaKeyOf` = `ProviderOverrides.Any() ? string.Empty : QuotaKeys.Codex`.
- `KimiRuntime.cs`: `QuotaKeyOf` => `QuotaKeys.Kimi`.
- Tests (new): `AStructuredVerdictOutranksTheWordScanTests` (S1–S3), `TheRuntimesNameTheirQuotaTests` (EXTRA).

## Red messages

Red-first was run with the signatures in place and `Classified`/`Hopeless` still at base.

- S1 `ASpentVerdict_IsHopeless_WhateverTheWordsSay`: `Expected launcher.Launched to be 1 because ..., but found 4.` (matches the document).
- S2 `ATransientVerdict_ClimbsTheLadder_EvenWhenTheTextSaysExhausted`: `Expected launcher.Launched to be 4 because ..., but found 1.` (matches).
- S3 `AnUndecidedVerdict_ReadsTheTextAsBefore`: **passed at base**, not red as the document says. At base the word scan already reads the AGY line as spent
  (`exhausted`/`quota`), so the null case is already correct. It is a regression guard, not a red.
- EXTRA `CodexIsOneQuota_AndTwoCodexRowsShareIt` and `KimiIsOneQuota` went red against empty-key stubs (`Expected ... to be "codex"/"kimi" ..., but "" ...`).
  The other EXTRA tests were green at once: their bodies are the contract's own (the empty default, the `DeepseekRuntime`/custom empty key, and `FromText`).

## Break-it (S3)

- The document's break-it (`Hopeless` as `limited.Spent == true`) does **not** fail S3's first case. The AGY line `Resets in 88h49m9s` is still caught by the
  unchanged `RetryLadder.ResetOutlasts` half, so it stays at one launch. The document's expectation is wrong for that case.
- Run instead: `(limited.Spent ?? true)`. S3's second case failed: `Expected throttleLauncher.Launched to be 4 ..., but found 1.` The production line was restored after it.

## Results

- Build: `dew_flow_connect_other_ais.slnx` Debug, 0 warnings, 0 errors (after each step).
- Green: `AStructuredVerdictOutranksTheWordScanTests` (3/3), `TheRuntimesNameTheirQuotaTests` (5/5), `AStatedResetIsNeverWaitedOutTests` (9/9),
  `GateReportingTests` (27/27), `CooldownParserTests` (18/18), `AReasonThatWentToStdoutTests` (23/23), `KimiMonthlyQuotaTests` (34/34).
- `AStatedResetIsNeverWaitedOutTests` and `GateReportingTests` are unedited.
- `dotnet format --verify-no-changes`: exits 2, but every diagnostic is an IL2026/IL3050 trim/AOT warning in `src_server` (38) or `src_bugs` (16), none in my files.
  I did not check whether this is already true at base.

## Not done

- **Whole MCP suite not run**: the dispatch said not to run the whole suite. The document's "Done when" asks for it, so the lead should run it.
- **Commit**: the document says "leave uncommitted"; the dispatch said commit with a conventional message. I followed the dispatch.
- No `dotnet format` clean-up was attempted, since it is not clear that the diagnostics are mine.
