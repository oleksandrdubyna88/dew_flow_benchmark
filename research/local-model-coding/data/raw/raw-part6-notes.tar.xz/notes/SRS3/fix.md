# Fix notes — review of `feat/quota-cooldown`

Every defect fix began with a test seen red for the real symptom, then green. Tests are in the existing classes.

| Finding | Verdict | What was done |
|---|---|---|
| R1 (major) probe checks `TimedOut` before `Cancelled` | **fixed** | `AgyQuotaProbe.ReadAsync` matches `{ Cancelled: true }` first. S42's `HangingLauncher` now answers the way the real launcher does (`TimedOut: true, Cancelled: true`, no throw). Red before the fix: the cancelled round parked `antigravity/gemini` on `stated` with the note "could not check /quota: timed out after 30 s". |
| R2 (minor) an unrequested probe exception skips a spent key | **fixed** | New `AntigravityRuntime.ReadQuotaAsync` turns an exception the caller did not request (`!ct.IsCancellationRequested`) into `AgyQuotaRead.Cannot(...)`. A spent refusal then parks on `stated`; the round's own cancel still reaches the caller. Test renamed `AProbeThatCancelsItself_IsACannotCheck_SoASpentRefusalStillParksOnItsStatedReset_AndTheOthersAreStillLifted`; red: standing was null. |
| R3 (minor) a Lift of nothing takes the lock | **fixed** | `MoveAsync` emits a `Lift` only when an unlocked `Standing(key, now)` shows an entry; the locked re-read still decides. New tests: `AnAnsweredRow_WithNothingStanding_TakesNoLockAndRaisesNoNotice` (red: the refused notice "lock … held by another process"), and `AnAnsweredRow_WithTheKeyStanding_StillLifts_WhenTheLockIsFree`. Residual: a park by another process between the unlocked read and the answer is not lifted by this round; that is an ordering race with no right answer. |
| R4 (minor) an I/O failure under the lock empties the table | **fixed** | `ReadFile()` returns `FileRead(Entries, Blocked)`. Torn JSON or a wrong version stays "overwrite"; `IOException`/`UnauthorizedAccessException` sets `Blocked`, and `WriteUnderLock` refuses (`CooldownWrite.Refused`, logged, `refused` callback). `Standing` stays fail-open. Tests: `AFileThatCannotBeOpenedUnderTheLock_IsRefusedNotReplaced_SoTheOtherKeysStillStand` (red: `Written`, the other key erased) and `ATornFileUnderTheLock_IsOverwrittenByTheRoundsMoves` (the positive companion). |
| R5 (minor) multi-line `AGY_ERROR` parses to nothing | **fixed** | `AgyError.Parse` takes the text after each `AGY_ERROR[:]` plus the following lines and reads the first JSON value with `JsonDocument.TryParseValue`, so a pretty-printed object (plan §1 verbatim) and trailing stderr lines both work. Test `AnErrorObjectPrintedOverSeveralLines_IsReadLikeOneOnASingleLine` (red: collection empty); the old single-line and "not JSON" cases still pass. |
| R6 (minor) a standing key can never be lifted through a round | **recorded, not changed in code** | The finding is right and the cause is the plan (D4 + D9). The plan now says so: DoD lift line qualified, D12's *try now* bullet states the cost and that the follow-up must give the lift a road that is not a round, and a last §12 item records it. |

Nothing was judged wrong. R2's fix follows D5 (plan line 357: "stated/guess for a spent one, the failure named").

## Results

- Build `dew_flow_connect_other_ais.slnx -c Debug`: 0 warnings, 0 errors.
- Whole MCP suite (once, after all fixes): 13,891 total, 13,773 passed, 117 skipped, **1 failed** —
  `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`.
  Environmental, not from this change: `ArgumentOutOfRangeException … path … is of an invalid length for use with domain sockets (1–108)`.
  The session's `TMPDIR` is `…/r/68b68cbc1f57/tmp/…/testsToDelete-coai-run-…/testsToDelete-regular-files-…/shown.sock`, over 108 characters.
  It fails identically alone. I could not re-run it with a short `TMPDIR` (the sandbox asked for approval and nobody answers); the stack trace is a path-length check in `UnixDomainSocketEndPoint`, before any code of this branch.
- The changed test classes (`TheRoundParksAndLiftsTheQuotaTests`, `ASpentQuotaIsRememberedUntilItsResetTests`, `AnAgyQuotaIsReadFromItsStructuredErrorTests`): all green.
- Format: `dotnet format --verify-no-changes` is clean on `CoaiMcp.Tests`, `CoaiMcp.Runners` and `CoaiMcp` projects. On the whole `.slnx` it fails with IL2026/IL3050 AOT-analyzer errors in `src_server` (files this branch does not touch), so the plan's solution-wide command cannot be used on this host.
- Extension tests: not run, because `src_vs_code` was not changed by these fixes.
- Commit: one, `fix(quota): review R1-R6 …`; nothing pushed.
