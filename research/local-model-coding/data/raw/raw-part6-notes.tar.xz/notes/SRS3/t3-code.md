# t3 — code notes

Commit: `1e0aa396` on `tmp/t3` (worktree `wt/t3`). Not pushed.

## What was done

- `AgyError.cs` (new): `AgyErrorLine`, `AgyError.Parse` reads both `AGY_ERROR` shapes by name (`status`/`code`, `short_error`/`message`). A non-JSON, non-object or status-less line is skipped; no exception escapes.
- `AntigravityRuntime.cs`: `RateLimited` (D2) from the first `RESOURCE_EXHAUSTED` line on a non-zero exit. The Individual-quota sentence gives `Spent = true`; any other exhaustion gives `Spent = null`. Everything else falls back to `RateLimitVerdict.ByText`. `QuotaKeyOf` delegates to `AgyQuotaGroups.KeyOf`. `ReadResetAsync` runs `AgyQuotaProbe.ReadAsync` once and maps the verdict through a private `Answer` switch.
- `ClaudeRuntime.cs`: `QuotaKeyOf` returns `QuotaKeys.Claude`. `RateLimited` (D7) returns a spent verdict only for a non-zero exit with `is_error` true, `api_error_status` 429 and the "hit your monthly spend limit" sentence. The JSON guard is `JsonException` or `InvalidOperationException`. `RateLimit.Spent`, `WhyItFailed`, `FailureSentence`, `ReadUsage` and the executor are untouched.
- `AClaudeReasonInItsEnvelopeTests.cs`: the pin at `:62` is reversed to `RateLimited`, and the summary notes D7. Nothing else in the file changed.
- New tests: `AnAgyQuotaIsReadFromItsStructuredErrorTests` (S4, S5, S6, the three EXTRA tests) and `AClaudeSpendLimitIsASpentQuotaTests` (S7, S8).

## Red messages

- S4: `Expected verdict.Spent to be True, but found <null>.` (as the document).
- S5: `Expected verdict.Spent to be True, but found <null>.` (as the document).
- S7: `Expected type to be ...+RateLimited, but found ...+NonZeroExit.` (as the document).
- S6 (stub): `Expected exhausted.Limited to be True, but found False.` The document gives no red message for S6, only its break-it. The stub is `ByText`, which does not see a `RESOURCE_EXHAUSTED` line with no sentence as a limit. The real code does (the document's "undecided" rule).
- S8: passes at the stub, as the document expects. It is covered by its break-it.
- EXTRA tests (stub): key `""` vs `antigravity/argon`; reset `stated` vs `quota`; `AgyError.Parse` empty.

## Break-its (each run once, then restored)

- S6 break-it: `Spent` forced to `true` for any `RESOURCE_EXHAUSTED` line. Result: `Did not expect a value, but found True.` FluentAssertions 8 words `BeNull` on `bool?` differently from the document's `Expected ... to be <null>, but found True`. The failure is the same one: `Spent` is `True` where it must be `null`.
- S8 break-it: `IsSpendLimit` replaced by `SaysItFailed` (`is_error` alone). Result: `Expected type to be ...+NonZeroExit, but found ...+RateLimited.` (as the document).
- Both restored. Checked: the committed diff is the implementation with no break-it residue; the final build and tests ran on the restored code.

## Deviations from the document

- `TimeSpan.Parse("88:49:09")` throws `OverflowException` (hours above 23 are not valid there). The test uses `new TimeSpan(88, 49, 9)`, the same value.
- `ReadResetAsync`'s `Answer` switch has a `_ => throw` arm. I added it for the non-sealed `AgyQuotaVerdict` base without testing whether the compiler would warn without it. Its cyclomatic complexity is above 4; the switch maps one-to-one onto the table in the document.
- The constants are named `AGY_1_3_3` and `AGY_OLD` as in the document. Only the names come from the document; the values are verbatim.

## Results

- Build (`dew_flow_connect_other_ais.slnx`, Debug, `-m:4 --disable-build-servers`): 0 warnings, 0 errors, with the final code.
- `AnAgyQuotaIsReadFromItsStructuredErrorTests`: 6/6 pass.
- `AClaudeSpendLimitIsASpentQuotaTests`: 2/2 pass.
- `AClaudeReasonInItsEnvelopeTests`: 19/19 pass.
- `AStatedResetIsNeverWaitedOutTests`: 9/9 pass. `GateReportingTests`: 12/12 pass. `EveryPaidLaunchIsWrittenTests`: 27/27 pass. `ConsultFailureTests`: 41/41 pass. All are unedited.
- `dotnet format --verify-no-changes` on `src_mcp/runners/CoaiMcp.Runners.csproj` and `src_mcp/tests/CoaiMcp.Tests.csproj`: exit 0.
- `dotnet format` on the whole solution: exits 2 with IL2026/IL3050 errors in `CoaiBugs` and `CoaiServer` (`Program.cs`, `*Endpoints.cs`, all of which I did not touch). I did not check whether these appear at the base commit, so I cannot say they are pre-existing.

## Not done

- The whole MCP suite was NOT run. The brief says "Do not run the whole suite" and the task document's Done-when asks for it. I ran the named classes and neighbours only. Whole-suite verification is for the lead.
- Solution-wide `dotnet format --verify-no-changes` does not exit 0 here (see above). Project-level verify passes for both projects I touched.
- The `AClaudeReasonInItsEnvelopeTests` pin was not seen red separately; I edited it with the stub already in place, and it passes with the real code.
