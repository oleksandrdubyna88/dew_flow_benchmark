# Gate notes — feat/quota-cooldown (coai session 71c24ff6, caller claude-sonnet-5-5)

Commands carried by the replies (operator switches): plan round — split into epics; Fable split; work autonomously; consultants
first; consult on a cadence. Code round — work autonomously; consultants first.
Applied: *autonomous* (a red test first for behaviour fixes, docs with the change, the whole suite before stopping).
No question to the person arose, so *consultants first* had nothing to act on. Not applied: the epic split, Fable/Opus staffing and
cadence — the change is already built as one branch and the task fixes the plan as frozen; there is nothing left to split.

## Plan round 1 — verdict `proceed`, gating 4 of 6, reviewers asked 2, answered 2 (codex, antigravity)

All six rejected with: "The plan is frozen for this change: it passed its own plan gate before the code was written, and this
branch implements it as committed; a plan change is out of scope here."

| # | sev | summary | decision / note |
|---|---|---|---|
| 0 | Major | restored account stays parked; lift unreachable via a round | reject; known and recorded (plan D12, §12 last item, review item R6) |
| 1 | Major | S35–S37 contend in one process only | reject; plan's chosen method |
| 2 | Minor | no kill-during-write scenario | reject |
| 3 | Major | lift/doubling dead code because CanRun excludes the key | reject; same item as #0 |
| 4 | Major | Spent==true + gauge Available: no reset instant | reject; code already falls back to the text (QuotaCooldowns.Round.cs:122, S41) |
| 5 | Minor | D9 date examples differ on the year | reject |

## Code round 1 — verdict `proceed`, gating 12 of threshold 5, reviewers asked 8, answered 8 (codex, antigravity; 4 roles each)

Scope sent: goal, 12 numbered "must be true" statements, constraints (incl. D12 out-of-scope and the recorded R6 lift item).

| # | sev | file | summary | decision | reason / commit |
|---|---|---|---|---|---|
| 0 | Major | QuotaCooldowns.cs:32 | hand-written `partial` split of QuotaCooldowns | **accept** | rule: extract a named unit, never partial; the only hand-written partial in src_mcp (the others are source-generated/LibraryImport) |
| 1 | Major | QuotaCooldowns.cs:228 | no bound on entry count/size | reject | plan §8 budget; keys only from configured rows |
| 2 | Major | QuotaCooldowns.Round.cs:49 | probes run serially | **accept** | same as #13 |
| 3 | Blocking | AgyQuotaReport.cs:31 | Claude models in the agy quota table violate vendor-routing | reject | plan D3 specifies the row; a key mapping routes nothing |
| 4 | Major | QuotaCooldowns.cs:139 | mutable dictionary in WriteUnderLock | reject | local builder under the lock, never shared |
| 5 | Minor | QuotaCooldowns.cs:269 | List<T> in internal JSON record | reject | doctrine is about public contracts |
| 6 | Blocking | QuotaCooldowns.Round.cs:155 | key via Invocation.Adapter drops adapter-less runtimes | reject | Adapter is the runtime; Kimi's Bound() is a KimiRuntime; tested |
| 7 | Major | PanelService.cs:439 | second QuotaCooldowns instance | reject | one instance, passed to RoundEngine (PanelService.cs:109,153) |
| 8 | Major | AgyQuotaReport.cs:40 | closed model table | reject | plan D3 chose it deliberately |
| 9 | Major | AgyError.cs:35 | multi-line parse throws on trailing lines | reject | caught; TryParseValue reads one value; the R5 test pins it |
| 10 | Major | QuotaCooldowns.cs:109 | `using var held` disposal of the lock | reject | disposing the Taken stream is HeldFile's contract |
| 11 | Minor | AntigravityRuntime.cs:218 | cancel bubbles from ReadQuotaAsync | reject | by design (D5); AfterRoundAsync catches it |
| 12 | Major | PanelService.cs:438 | file read on every CanRun, no cache | reject | plan D4 decision |
| 13 | Major | QuotaCooldowns.Round.cs:50 | `/quota` probes sequential, adds latency | **accept** | probes of distinct keys should run together |
| 14 | Minor | AgyError.cs:21 | allocations in Parse | reject | negligible |

Fixes, all in commit **6927d17b**: #0 `QuotaRound` extracted from the partial (a behaviour-preserving refactor: no red exists for it, the
existing round/store/clocked-class tests stayed green); #2/#13 the `/quota` reads of distinct keys run together — test
`TheProbesOfTwoSpentKeys_RunTogether_AndBothAreParked` seen red first (`Expected launcher.MostAtOnce to be 2 … but found 1`), green after.
Doc: `research/module_runners.md` (parking rule). Not changed: `todo/PLAN_a_spent_quota_cools_the_model_down.md` §12 line 840 still says
"`QuotaCooldowns` is a `partial` class in two files" — now stale, left alone because the plan is frozen for this change.

## Code round 2 (`again: true`, after 6927d17b) — verdict `proceed`, gating 7 of threshold 5, reviewers asked 8, answered 8

All twelve rejected (the scope text said what round 1 had decided).

| # | sev | file | summary | decision | reason |
|---|---|---|---|---|---|
| 0 | Major | AgyQuotaReport.cs:57 | quota table outside a "shared seam" | reject | plan D3; every caller uses AgyQuotaGroups |
| 1 | Minor | QuotaCooldowns.cs:231 | 16 KiB not enforced at write | reject | §8; decided in round 1 |
| 2 | Minor | RoundEngine.cs:442 | round waits for probes | reject | D5; bounded to one 30 s timeout now |
| 3 | Major | PanelService.cs:439 | provider.Model vs resolved model mismatch | reject | wrong: RosterBuilder.cs:529 uses the same `provider.Model` |
| 4 | Major | QuotaRound.cs:59 | unlocked Standing before Lift | reject | review fix R3; locked re-read decides |
| 5 | Minor | BoundedScheduler.cs:681 | ResetOutlasts evaluated when Spent is false | reject | D1: "ResetOutlasts half unchanged" |
| 6 | Major | AgyQuotaReport.cs:40 | casing of unknown-model key | reject | same string on both sides |
| 7 | Major | PanelService.cs:548 | TimeLeft "0 min" at expiry | reject | sub-tick window, truthful |
| 8 | Minor | AgyQuotaReport.cs:236 | probe stderr unredacted | reject | wrong: goes through VendorReason.Written = Redaction.SafeText |
| 9 | Major | PanelService.cs:438 | file read per provider, no cache | reject | D4; decided in round 1 |
| 10 | Major | AgyError.cs:21 | allocations in Parse | reject | no measured cost; decided in round 1 |
| 11 | Minor | PanelService.cs:548 | TimeLeft negative (duplicate of #7) | reject | same |

Stop: the verdict is `proceed` and the session is Done.

## Final results (HEAD 6927d17b, 17:35 UTC start of the run)

- Build `CoaiMcp.Tests` (and what it builds), Debug: 0 warnings, 0 errors.
- Whole MCP suite, once: 13,892 total, 13,774 passed, 117 skipped, **1 failed** —
  `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`: `ArgumentOutOfRangeException`, the
  session's TMPDIR socket path is over 108 characters. Environmental, same failure as before this gate, fails alone, not from this branch.
- Format: `dotnet format --verify-no-changes` clean on `CoaiMcp.Tests` and `CoaiMcp.Runners` (the solution-wide command fails on AOT analyzers in `src_server`, untouched).
- Extension tests: not run, `src_vs_code` unchanged by the gate fixes.
- Commits by this gate: `6927d17b`. Nothing pushed.
