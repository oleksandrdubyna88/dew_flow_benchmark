# Review of the spent-quota cooldown (branch feat/quota-cooldown, commits after 6786582e)

Plan: `todo/PLAN_a_spent_quota_cools_the_model_down.md`. Written before any code change (Step 1).

## Coverage of this review

- Scenarios: each of S1–S43 has a test with that exact name (checked by grep over `src_mcp/tests/`; S30–S33 in `src_vs_code/src/test/aCoolingRowSaysWhenItIsBack.test.ts`). I read the assertions of S1–S8, S9–S25, S34–S43 (C#) and S26–S33, S38 (C# and TS).
- Decisions D1–D12: checked one by one against the code (see "Decisions checked").
- Rules: resolver `check` = resolved; `explain` selected about 40 rules. Read: `csharp.doctrine`, `local.common.vendor-routing`, `local.common.review-gate`, `PROJECT.md`. Not read in full (over the 32 KiB limit, read per id only if needed): `common.testing`, `common.reliability`, `common.logging-serilog`, `common.scenario-tests`, `common.measurement`, `common.utc-timestamps`, `common.security`, `typescript.doctrine`, `common.test-leftovers`, `common.reuse-first`, `common.durable-status`, `common.generated-code-tests`. Their checks are covered by the review below only where I looked; they are not fully checked.

## Findings

| id | severity | file:line | one sentence | fix |
|---|---|---|---|---|
| H1 | major | `src_mcp/runners/Reviewers/QuotaCooldowns.cs:183-199` and `:292-297` | The locked re-read (`Applied` calls `Read()`) turns an `IOException` or `UnauthorizedAccessException` into an empty list, so a park or lift under the lock can rewrite the file without the other keys, which breaks D4's "never a lost park or lift" under F3. | Add a strict read for the locked path: `IOException`/`UnauthorizedAccessException` propagate to `Mutate` and become `CooldownWrite.Refused`; `JsonException` stays "torn file, treated as empty" (plan §8). Test first: a locked read that cannot read keeps the entries and is refused. |
| H2 | minor | `src_mcp/runners/Reviewers/AgyError.cs` (`Parse`, one line at a time) | The issue's sample in plan §1 shows the `AGY_ERROR` JSON pretty-printed over several lines, and the parser reads only single-line JSON. | Not fixed. Both observed captures (RESULTS §3.1, `consult-quota.stderr.txt`) are single-line, and D2 names those two shapes. A multi-line answer falls back to today's text reading, which is undecided, so the gauge decides: no false park. Residual risk, to note in the docs. |
| H3 | minor | `src_mcp/tests/TheRoundParksAndLiftsTheQuotaTests.cs:205-223` | S34 as written in the plan ("both rows ended spent") contradicts D5/S41 (a spent refusal parks on its stated reset whatever the gauge says), so the coder made both rows undecided. | Not fixed. The coder's deviation is recorded (code.md, plan §12) and the choice is the only consistent reading. The plan owner should correct S34's wording. |
| H4 | minor | `src_vs_code/src/test/teamServerTab.test.ts:208-213` | The golden hash of the Settings sheet was re-pinned for the two new CSS rules; the claim that the sheet without them hashes to the old pin is not verified by me. | Not fixed (not verified by me). Check if time allows. |
| H5 | minor | `src_mcp/tests/ASpentQuotaIsRememberedUntilItsResetTests.cs:191-198` | S35's "B waits" check is a 300 ms sleep plus `IsCompleted == false`, which is weak on a slow machine; the write-order assertion (`writes == A, B`) is the real guard. | Not fixed. The write-order check catches an unlocked write, so the test is not vacuous. |

## Decisions checked (D1–D12)

- D1 (three-valued `Spent`): `RateLimitVerdict.Spent`, `ReviewerOutcome.RateLimited.Spent`, `BoundedScheduler.Hopeless` = `Spent ?? RateLimit.Hopeless` with the `ResetOutlasts` half unchanged. Matches.
- D2 (agy from `AGY_ERROR`): `AntigravityRuntime.RateLimited` reads status and sentence; exit, 429, retryable and `status:"ERROR"` are not read. Matches (H2 is the parse-shape caveat).
- D3 (keys by quota, explicit table): `AgyQuotaGroups` is an exact-family table; unknown families get `antigravity/?<model>`. Matches. Codex, Claude, Kimi keys match. `CustomCodexRuntime` returns empty.
- D4 (file, lock, fail open): file under data dir, `AtomicFile.Write`, `HeldFile.TakeWithin` lock with a 30 s default, refusals via `onRefused` and a notice. Matches, except H1.
- D5 (after the round, aggregate per key, one probe per key, spent wins over Ok, cancel parks nothing): `AfterRoundAsync` and `ParkAndLiftAsync`. Matches.
- D6 (`/quota` argv verbatim, report read by name, edge cases): `AgyQuotaProbe` argv is the owner's command; `AgyQuotaReport.ResetFor` implements the edge cases. Matches.
- D7 (Claude spend limit is `RateLimited`, one launch): `ClaudeRuntime.RateLimited` runs before `WhyItFailed` in `Classified`. Matches.
- D8 (UTC on server, viewer's zone on card, `dd.MM.yyyy HH:mm`): `cooldownWords.ts` `stampOf` uses `Intl` with the viewer's zone or a test zone. Matches.
- D9 (wire member, `CanRun` fourth condition, `ReasonFor` words, card line and badge): match, and the wording of the three sources matches S31/S32.
- D10 (five states): matches the table in code.
- D11 (no new `ReviewerOutcome` subtype): none added. Matches.
- D12 (scope): nothing outside the plan found in the diff except the `teamServerTab` re-pin (H4) and the two guard extensions (both recorded by the coder).

## Deviations recorded by the coder, checked

- S3 third case, S25 date, `consecutive + 1` (needed: without it the doubling never happens), `Action<string> onRefused` in place of `NoticeWriter`, unknown family not probed, S9–S13 full keys: each is a reasonable reading and is recorded. Accepted.
- S34 both rows undecided (H3): accepted with the reason.

---

## Fixes (Step 2)

- **H1 — fixed.** Test first: `ALockedReadThatCannotReadTheFile_RefusesTheWrite_AndKeepsTheEntries` ran red with `Expected type to be ...Refused, but found ...Written` (the write went through). Fix: `QuotaCooldowns.cs` gets `ReadForWrite` (only a torn file reads as empty) over `ReadStrict`; `Applied` uses `ReadForWrite`; the IOException reaches `Mutate`, which refuses. Green after the fix (store class: 11 of 11). Committed with its test (commit message names H1).
- **H2 — not fixed.** Multi-line `AGY_ERROR` JSON is not read; both observed shapes are single-line; the fallback is undecided, so no false park. Residual risk, to document.
- **H3 — not fixed.** The S34 wording in the plan contradicts D5/S41; the coder's reading is the only consistent one. The plan owner should fix the wording.
- **H4 — not fixed (not verified).** The Settings sheet hash re-pin: not checked by me.
- **H5 — not fixed.** The S35 timing check is weak; the write-order check guards the same point.

## Final results (after the resume, 2026-10-29)

- Build: `dew_flow_connect_other_ais.slnx` Debug, 0 warnings, 0 errors (after the H1 fix; log work/build2.log).
- MCP suite, once, after the H1 fix: 13,874 total, 13,756 passed, 117 skipped (Windows-only), 1 failed: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`. Cause: the temp path is too long for a Unix socket (108 characters). Re-run alone: same failure. Environmental on this host; not touched by the quota work.
- Format: `dotnet format whitespace --verify-no-changes` on src_mcp/runners, src_mcp/src and src_mcp/tests: no output. The whole-solution `dotnet format` stops on IL2026/IL3050 analyzer errors in src_server (not touched by this branch); these errors predate the branch.
- Extension (src_vs_code): typecheck clean; lint clean; tests 6641 pass, 0 fail, 21 skipped.
- New commit: 0484298f (H1).
