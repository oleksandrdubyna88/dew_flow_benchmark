# Coder notes — a spent quota cools the model down (branch feat/quota-cooldown)

Started 20:26 UTC. Plan: `todo/PLAN_a_spent_quota_cools_the_model_down.md`. Commits are on `feat/quota-cooldown`, never pushed.

## Progress

- Story 1 (S1–S8): done, committed `8e29c977`.
- Story 2 (S9–S25, S34–S37, S39–S43): done, committed `4f541e49`.
- Story 3, story 4, docs: see the end of this file (updated as I go).

## Decisions and deviations (code is the fact)

### Story 1
- S3: the plan's first case (AGY_1_3_3 reason, `Spent: null`) gives 1 launch even with the "tempting" wiring `limited.Spent == true`, because
  `RetryLadder.ResetOutlasts` also ends the ladder for the 88 h reset in that sentence. So I added a third case: the same sentence WITHOUT its reset
  (constructed). With `Spent == true` wiring it is red with `Expected wordsOnlyLaunches to be 1 ... but found 4` (seen). The first two cases stay as the plan has them.
- S3 and S8 are green at the stub stage (they pin today's behaviour); their break-it reds were seen instead (S3 above; S8 with `is_error` alone: `Expected type to be NonZeroExit ... but found RateLimited`).
- S6 red at the stub stage was `Expected exhausted.Limited to be True, but found False` (case a), not the plan's break-it message; the plan's break-it
  (`Spent == true` for every RESOURCE_EXHAUSTED) was seen red: `Did not expect a value ... but found True`.
- S7 reversal at `AClaudeReasonInItsEnvelopeTests` (NonZeroExit → RateLimited) done in the story-1 commit.
- `ClaudeRuntime.RateLimited` carries the usage the old path read (`ReadUsage`), so a spent launch keeps its cost in the ledger.
- Shared helper `AgyQuotaSamples` (tests): constants for AGY_1_3_3, AGY_OLD, QUOTA_SAMPLE (`fixtures/antigravity/quota-sample.json`, byte for byte as the issue), QUOTA_REAL, MODELS_REAL.

### Story 2
- Types: `AgyQuotaGroups` (the D3 table; also `NameOf` for the card's words), `AgyQuotaReport` (`Parse` → null when no report; `ResetFor(key, now)`),
  `AgyQuotaVerdict` (closed union), `AgyQuotaRead` (`Got` / `CannotCheck`) and `AgyQuotaProbe.ReadAsync`, `QuotaReset` (+ `GaugeReading`), `QuotaCooldownEntry`,
  `CooldownWrite` (`Written` / `Refused`), `QuotaCooldowns`.
- S9–S13 use full keys (`antigravity/gemini`), not the plan's `"gemini"`/`"3p"` abbreviations.
- S15: `AgyQuotaProbe.ReadAsync` returns `AgyQuotaRead.CannotCheck(why)` (not a verdict of the report) — the probe does not know the key.
- S34 is split in two tests: the report half (`..._ParksOnlyArgon_AtTheReport`, in the report class) and the round half
  (`ArgonSpent_WithOrdinaryGeminiAvailable_ParksOnlyArgon`, in the round class). **In the round half both rows end undecided (`Spent == null`), not "spent"**:
  with `Spent == true` the Gemini row would park on its stated reset (D5/S41), which contradicts the plan's expected "only argon stands". The Gemini gauge is
  `Available`, so it is "transient, not parked".
- S25: the plan's codex date "July 15, 2026" is before NOW (2026-10-11), so a park on it would already be expired. I used "October 15, 2026" → `2026-10-16T00:00:00Z`.
  Product rule added for the same reason: `QuotaReset.Of` takes a stated reset only when it is AFTER now, else it falls back to `guess` (a past instant is no reset — D6's own rule for agy, applied to the default reader too).
- Consecutive: `AfterRoundAsync` passes `standing.Consecutive + 1` when a `guess` entry stands, else 0, and `Park` stores the same rule. The plan's "the standing entry's count" is ambiguous; without the +1 the doubling could never happen.
- S37 "one notice handed to the notice writer": `QuotaCooldowns` cannot reference `NoticeWriter` (it lives in `src`, `QuotaCooldowns` in `runners`). It has an `Action<string>? onRefused` constructor parameter, called once per refused mutation (Park, Lift or the round's one write) next to the warning log; PanelService wires it to `NoticeWriter.Shared` in story 3. The S37 test checks the callback.
- Constructor: `QuotaCooldowns(dataDir, clock, log, launcher = null, onRefused = null, lockWait = default)`; the plan's S16 builds it with three arguments. Test seams are `internal` `AfterLockedRead` and `BeforeWrite` (init properties).
- An agy model the table does not know is not probed at all (no `/quota` call): `Gauge = CannotCheck`, the park is `stated`/`guess` when explicitly spent, nothing when undecided.
- Undecided + `RateLimit.Hopeless(reason)` false: the outcome does not qualify, so there is no gauge call (plan D5). An undecided + not parked key with an `Ok` sibling is lifted.
- `CustomCodexRuntime.QuotaKeyOf` overrides to empty (CodexRuntime's is `virtual` and answers `codex`).
- `EveryBudgetInAClockedClassReadsItsClockTests`: `QuotaCooldowns.cs` joined its `Clocked` list (the plan allowed it).
- Break-it for S35/S36: with the lock removed, S35 failed at "B waits on the lock" and S36 run 1 ended with `codex` standing (the plan's red); S37 (a) returned `Written`. Restored.
- Reds at the stub stage differ from the plan in S18 (`FileNotFoundException`), S19 (collection empty, not `JsonException`), S39 (NRE), S35/S42 (the 20 s gate/probe wait failed first): my stubs answered null/no-op instead of the plan's shapes. Not a problem for the assertions; they are all assertion failures, never compile errors.

### Story 3
- `PanelService`: ctor gains `TimeProvider? clock = null`; `_cooldowns` built beside the ledger; `CanRun` has the fourth condition `!IsCooling(provider)`; `ReasonFor` says the cooling sentence (only when the row is otherwise available); `ProbeAsync` sets `Cooldown`.
- `RoundEngine` takes the `QuotaCooldowns` as a last constructor parameter and calls `AfterRoundAsync(results, cancellation.Token)` right after `RunAllAsync`. No scenario drives a whole round through it (the plan has none).
- The refused-write notice uses the existing closed code `storage-note` (class `failure`, subject `quota-cooldowns.json`): a new code would need `shared/` changes the plan rules out.
- Two guards had to be extended: `EveryBudgetInAClockedClassReadsItsClockTests` (`PanelService.cs` in `Unscanned` with its reason) and `TheRefusalsAreWrittenDownTests.ANoticeProducerCutsOnlyThroughTheSharedHelper` (`PanelService.cs` is a `ServerNotice.Shortened` producer).
- Break-its seen: S27 (every agy model on the Gemini key) → `Expected excluded to contain a single item, but found {2 lines}`; S28 (`Standing(key, MinValue)`) → `Expected excluded to be empty ... found {"antigravity: ... (in 1 min)"}`. S29 also went red under the S27 break.
- Red at the stage where only the wire type and the ctor param existed: S26/S27 `Expected excluded to contain a single item, but the collection is empty`, S29 `KeyNotFoundException` (no `cooldown` member). S28 and S38 were green at that stage (S38 because the wire type is final code, not a stub).
- Refactor for the ≤4 complexity rule after the tests were green: `AfterRoundAsync` → `ParkAndLiftAsync` / `SettledAsync` / `ParkedAsync` / `Parks`; `Locked` → switch expression. Behaviour identical (tests re-run green).

### Story 4
- `ProviderHealth.cooldown?`, `cooldownWords.ts` (`cooldownLine`, `cardCooldownLine`), `modelCard.ts` foot (`cooldown-line` instead of `reset-line`), `modelCardWorld.verdictBadge(id, context, nowMs)` (new third parameter; its only caller is `modelCard.ts`), `modelsTab.ts` passes `cooldownLine`. `resetWords.spanOf` is exported (reuse, not copy).
- S33 runs the page (`catalogHtml` + `pageTree` + `runPageHtml`) and also shows, as a control, that the same ledger draws the `reset-line` when no cooldown is reported. The card text is compared with `cooldownLine(REPORT, now)` in the machine's own zone plus a zone-free regex; the Paris/Kyiv pins are in S31.
- The Settings sheet hash pin (`teamServerTab.test.ts`) had to be re-taken for the two CSS rules; I checked that the sheet without them hashes to the previous pin.
- Lint complexity limit (4) forced small splits in `cooldownLine` (a wording table) and `verdictBadge`.

### Results
- MCP suite, first full run (before the last two guard fixes): 13,871 tests, 3 failed: `RegularFilesTests.A_fifo_a_socket_and_a_device...` (unix socket path over 108 chars because this session's temp folder is long: environment, not mine; fails alone too), and the two guard tests above, which I fixed. Targeted re-run of both guards + all my classes: green.
- `dotnet format whitespace` and `style --verify-no-changes` over my changed C# files: clean. The whole-solution `dotnet format --verify-no-changes` prints AOT analyzer errors (IL2026/IL3050) in `src_server` files I did not touch: not mine, not run to completion.
- Extension: `npm run typecheck`, `npm run lint` clean; `npm test` no failures.
- `plan-lifecycle.mjs`: clean.

### What remains
- The code gate (it runs over the whole branch with the plan as scope, per the plan) was not run: it needs the product's own reviewers, which spend money.
- Owed by the plan: the first `/quota` answer coai's own probe reads in a real round (RESULTS §3.4).
- No push, no PR, no release.
