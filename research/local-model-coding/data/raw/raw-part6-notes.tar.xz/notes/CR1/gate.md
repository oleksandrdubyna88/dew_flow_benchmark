# The review gate — branch feat/quota-cooldown (coai session 33ea7878), resumed 2026-10-29

Providers: codex, antigravity, codex-3, antigravity-2, vibe configured; the plan round asked 2 reviewers and the code round 8, all answered.
Gate commands in the replies (split into epics / Fable split / consultants / cadence; later "work autonomously", "ask consultants first"): NOT applied as
orders. The plan §11 records the owner's decision that this plan stays one file with four stories and one code gate over the whole branch, and my brief fixes
the flow (frozen plan, one branch, no questions). What the "autonomous" command asks for that fits the brief I did anyway: red-green for any fix (none was needed),
docs unchanged, whole suite before stopping.

## Plan round 1 — verdict `proceed`, gating 3 of 6, 2 of 2 reviewers answered
All four rejected with "The plan is frozen for this change…". Checked against the code:
1. Major — D6 skips an unreadable bucket and may report Available: the code matches D6; undecided + Available parks nothing by design. No code defect.
2. Major — no test drives RoundEngine → AfterRoundAsync: already covered in code, `ARoundThatFindsAQuotaSpentParksItForTheNextTests` (a2b3fb55).
3. Major — sequential 30 s agy probes: the code does what D5/D6 say (one probe per spent key, launcher timeout).
4. Minor — D9 cooldown-line replaces the reset-line: plan design.

## Code round 1 — verdict `proceed`, gating 12 of 5, 8 of 8 reviewers answered
All 16 rejected in round 1, each after opening the code; no accepted finding, so no fix commit and no second round (the verdict was `proceed`).

| # | sev | file | finding | decision / reason |
|---|---|---|---|---|
| 0 | Major | ReviewerRuntime.cs:542 | quota keys are untyped strings | reject — D3 plan decision (also the persisted/wire key); typed key is a refactor beyond scope |
| 1 | Major | TheAgyQuotaReportPicksTheResetTests.cs:35 | helper mutates parsed JSON | reject — edits a fresh local parse of an immutable string and returns a new string |
| 2 | Major | QuotaCooldowns.cs:423 | malformed Ok lifts the cooldown | reject — `Ok` carries an accepted `NormalisedReview`; a malformed answer is not `Ok` |
| 3 | Major | QuotaCooldowns.cs:391 | gauge failure erases a cooldown | reject — `Quiet` lifts only on an answered launch, else `Nothing`; extending would invent a date (S24) |
| 4 | Minor | QuotaCooldowns.cs:193 | unreadable file reads as no cooldown | reject — fail open by design (D4, S19, S37); the write side refuses and notices (H1) |
| 5 | Major | QuotaCooldowns.cs:429 | probes sequential | reject — plan specifies one bounded probe per key; at most three agy groups are probed |
| 6 | Blocking | PanelService.cs:123 | private QuotaCooldowns, not DI | reject — PanelService is the composition root and builds the neighbouring stores the same way; other roads are a later plan (D12) |
| 7 | Major | QuotaCooldowns.cs:402 | store drives the adapter's probe | reject — plan decision D4/D5 |
| 8 | Major | AgyQuotaReport.cs:16 | static model table | reject — D3: one explicit table, never a prefix |
| 9 | Major | QuotaCooldowns.cs:409 | inconsistent choice among refusals | reject — refusals are pre-filtered by `Qualifies`; the gauge is per key; no such inconsistency |
| 10 | Major | AgyError.cs:33 | CRLF stderr dropped | reject — `TrimEntries` trims the CR; no failing input |
| 11 | Minor | QuotaCooldowns.cs:344 | temp file after unexpected write exception | reject — existing `AtomicFile` helper used as D4 prescribes |
| 12 | Minor | QuotaCooldowns.cs:427 | vendor text persisted verbatim | reject — already through `VendorReason.Written` (the one redactor) and the cap |
| 13 | Major | PanelService.cs:435 | uncached reads per provider | reject — D4: no cache, file under 16 KiB, cross-process writer |
| 14 | Major | QuotaCooldowns.cs:387 | sequential probes (duplicate of 5) | reject — as 5 |
| 15 | Minor | QuotaCooldowns.cs:87 | 61 min shows 2 h | reject — the plan requires rounding up (S31–S33) |

Points a later plan could take (not defects here): a typed quota key (0), concurrent probes if more groups appear (5/14), a notice for a failed cooldown-file read (4).
