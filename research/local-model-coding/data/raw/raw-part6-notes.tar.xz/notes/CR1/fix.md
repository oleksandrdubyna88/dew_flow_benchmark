# Fixes for review.json (R1–R3), branch feat/quota-cooldown

Resumed 2026-10-29 08:53 UTC; the earlier self-review fix H1 (commit 0484298f, in `hreview.md`) was already in the branch and is not part of this review.

## R1 (major) — DeepSeek shared codex's cooldown key: FIXED, commit 6f29b6a8
- Verified in code: `DeepseekRuntime : CodexRuntime("deepseek")` inherited `QuotaKeyOf => "codex"`; only `CustomCodexRuntime` overrode it.
- Test first: `ACoolingRowStaysOutOfTheRoundTests.ASpentCodexAllowance_LeavesADeepseekRowAlone` (a codex park; a deepseek row with a vault key; `ExcludedFrom` must be empty and the runtime's key empty).
  Red: `Expected string to be empty ... but found "codex"`.
- Fix: `DeepseekRuntime.QuotaKeyOf` returns `string.Empty` (`ReviewerRuntime.cs`). Green.
- Note: the test row has no `Runtime` set: a deepseek row resolves through its id; `Runtime = "deepseek"` is refused as an unknown runtime.

## R2 (minor) — agy row with no model keyed `antigravity/?`: FIXED, commit 348b7f95
- Verified: the launch uses `DefaultModel` when `settings.Model` is empty (`AntigravityRuntime.Model`), `QuotaKeyOf("")` did not.
- Test first: `TheAgyQuotaReportPicksTheResetTests.ARowWithNoModel_IsKeyedByTheModelItIsLaunchedOn`. Red: `...tigravity/?` vs `...tigravity/gemini`.
- Fix: `QuotaKeyOf(model) => AgyQuotaGroups.KeyOf(model.Length > 0 ? model : DefaultModel)`. This covers every caller (`ReadResetAsync`, `QuotaCooldowns.KeyOf`, `PanelService.StandingCooldown`), since all go through `QuotaKeyOf`.

## R3 (minor) — nothing drove `AfterRoundAsync` from a real round: FIXED, commit a2b3fb55
- New `ARoundThatFindsAQuotaSpentParksItForTheNextTests`: a whole plan round through the real `PanelService` and git; the only codex row's launches are played as a spent allowance
  ("You've hit your usage limit. ... refresh on October 15, 2026.", exit 1). After the round `Standing("codex")` is set and the next `ExcludedFrom(PlanReview)` names `codex: ...`.
- Break-it seen: with the `results = await _cooldowns.AfterRoundAsync(...)` line in `RoundEngine.cs` replaced by a comment, the test is red (`Expected parked not to be <null>`); line restored (`git checkout`).
- This is a test-only change (the finding asked for a test). It uses a codex row, not agy/claude: the line under test is runtime-neutral.

## Results (2026-10-29, after the three commits)
- Build `dew_flow_connect_other_ais.slnx` Debug: 0 warnings, 0 errors.
- MCP suite, once: 13,878 total, 13,760 passed, 117 skipped (Windows-only), 1 failed: `RegularFilesTests.A_fifo_a_socket_and_a_device_are_refused_at_once_never_waited_on_nor_streamed`.
  Re-run alone: same failure, `ArgumentOutOfRangeException`: the unix-socket path `.../tmp/testsToDelete-coai-run-xxxxxx/testsToDelete-regular-files-xxxxxx/shown.sock` is over 108 characters because this session's
  temp folder is long. Environmental; the test file is not touched by this branch. (The brief said nothing fails at base; on a host with a short temp path it should pass — not verified here.)
- Format: `dotnet format whitespace` and `style --verify-no-changes` over the five C# files I touched: clean. (Whole-solution run stops on IL2026/IL3050 in `src_server`, not touched, as before.)
- Extension: `src_vs_code` not changed by these fixes, so its tests were not re-run (last run before: 6641 pass, 0 fail).
- Not touched from `hreview.md`: H2–H5 stay as recorded there; review.json has no finding on them.
