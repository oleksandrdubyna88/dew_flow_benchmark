# DR4 review of E5.5 and E5.6 (reviewer: Haiku, 2026-10-27)

Scope read: `git diff b4e2ea96..HEAD`, the untracked `src_mcp/tests/AKimiDiskQuestionRowTests.cs`, E5 plan §0, E5.5, E5.6,
"Where the parent plan and the code disagree". No `DR4-code.md` existed, so there was no coder note to check against.

Baseline before any change: build succeeded, 0 warnings. The 12 new story tests pass on this host (AKimiConsultantCheckTests 5,
AKimiQuestionRowTests 4, AKimiDiskQuestionRowTests 3). Generator `--check`: up to date (21 rows, 7 runtimes × 3 capabilities).
The 12 Kimi tests skipped on Linux (D18) are old shim tests, none of them E5.5/E5.6.

## Scenario coverage
- S5.5.1, S5.5.2 (both arms), S5.5.3, S5.5.4: tests exist.
- S5.6.1, S5.6.2 (existing test, now covers kimi), S5.6.3, S5.6.4, S5.6.5, S5.6.6: tests exist.
- S5.6.7: exists only as an UNTRACKED file (H1).
- S5.6.8: TS test `kimi rows admit flagged, web refuses naming its record` exists (checked by reading, TS run pending).

## Findings

- **H1 — blocking** — `src_mcp/tests/AKimiDiskQuestionRowTests.cs` (whole file) — S5.6.7 is untracked, so no commit of this work contains it.
  Fix: commit the file by name.

- **H2 — major** — `src_mcp/tests/AKimiDiskQuestionRowTests.cs:20-26` (`TempDir.For("coai-qkimi-")`) — the MANDATORY rule
  `.agents/conventions/common/test-leftovers.md` requires the prefix `testsToDelete-`. Fix: rename the prefix to `testsToDelete-qkimi-`.

- **H3 — major** — `src_mcp/tests/AKimiConsultantCheckTests.cs` `ACheckCancelledMidTurn_StillDisposesItsHome` (~l.176-203) — the test
  asserts only that the home is gone. The plan's Then also needs the record to say cancelled and the junction to go first; the
  recorder is not wired, and the try/catch hides whatever `Check` returns. Fix: wire `GitScratch.AfterUnlink`, assert the record
  is `failed` with the cancelled kind, and drop the try/catch if `Check` returns normally (`ConsultantCheck.cs:186-188`).

- **H4 — minor** — `src_mcp/tests/AKimiConsultantCheckTests.cs` `AfterTheCheck_TheHomeIsGone_JunctionFirst`, the failing arm
  (~l.128-134) — the plan names exit 70 for the failing arm; the test asserts only "not answered". Fix: assert code 70 in that arm,
  if the run confirms it.

- **H5 — minor** — `src_mcp/tests/AKimiDiskQuestionRowTests.cs` `TheHomesFolderIsEmpty` — `EnumerateFileSystemEntries` throws
  `DirectoryNotFoundException` when the `coai-vh` folder is absent, so "nothing left" becomes a test error. Fix: treat a missing
  folder as empty.

- **H6 — minor** — `src_mcp/core/QuestionConsult/ConfinementPlanner.cs:205-212` (`Kimi`, `_` arm) — if a `web` grant ever reached
  it, it would plan unconfined with no refusal. The matrix refuses web first, and the comment says so. Fix: not made. A refusal arm
  is not in the plan, and the matrix already decides this pair (S5.6.3 pins the refusal).

- **H7 — minor** — `AKimiConsultantCheckTests.cs` `AKimiCheck_RunsInACopy_OnAOneShotHome` — the plan's Then also names the
  scratch repository and canary unchanged; the test does not assert them. Fix: not made. The check's `answered` state is the
  check's own verdict on those invariants (`ConsultantCheck.cs` `Broken`, `:263`). Not verified by a test run.

## Not checked yet (time)
- Teeth runs: no test was run against a reverted change, so "fails without the change" is read, not shown.
- TS tests and format verify: pending after the fixes.
